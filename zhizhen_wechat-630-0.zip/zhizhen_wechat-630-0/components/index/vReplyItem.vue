<template>
	<view class="vReplyItem">
		<view class="item">
			<view class="title">
				<view class="avatar-con">
					<image class="avatar" v-if="replyObj.roleType=='1'" :src="replyObj.headImg"
						@click="onGoto('avatar')" mode="">
					</image>
					<image class="avatar" v-else-if="replyObj.roleType=='2'" :src="defaultHeadimg" mode="">
					</image>
					<!-- <view class="avatar iconfont icon-gongsi" v-else></view> -->
					<image class="avatar" v-else src="../../static/img/company.jpg" mode="">
					</image>
				</view>
				<view class="middle">
					<view class="name" @click="onGoto('name')">{{replyObj.name}}</view>
					<view class="time">{{replyObj.time}}</view>
				</view>
				<view class="right">
					<view class="icon-container" v-if="parentType=='details'" @click="onShowMore">
						<view class="iconfont icon-msg-pinglun"></view>
					</view>
					<view class="icon-container" @click="onLike()">
						<view class="iconfont" :class="replyObj.isLike?'icon-msg-zan-xuanzhong active':'icon-zan'">
						</view>
						<text class="txt">{{replyObj.likeCount}}</text>
					</view>

				</view>
			</view>
			<view class="content" @longpress="onLongpress" @click="onShowMore">{{replyObj.content}}</view>
			<view class="second-reply" v-if="replyObj.secondReplyArr&&replyObj.secondReplyArr.length>0">
				<view class="name-time">
					<text class="name">{{secondReply.name}}</text>
					<text class="time">{{secondReply.time}}</text>
				</view>
				<view class="txt">{{secondReply.content}}</view>
				<view class="more" @click="onShowMore" v-if="replyObj.secondReplyArr.length>1">
					查看全部{{replyObj.secondReplyArr.length}}条评论>>
				</view>
			</view>
		</view>

	</view>
</template>

<script>
	export default {
		props: {
			passInType: {
				type: String,
				default: "comment"
			},
			parentType: {
				type: String,
				default: "details"
			},
			serverTime: {
				type: String,
				default: ""
			},
			replyObj: {
				type: Object,
				default: () => {
					return {
						headImg: "",
						name: "",
						roleType: "",
						time: "",
						content: "",
						secondReplyArr: [],
						isLike: false,
						likeCount: 0,
						dataDetails: {}
					}
				}
			}

		},
		data() {
			return {
				defaultHeadimg: this.$defaultHeadimg,
				secondReply: {
					name: "",
					time: "",
					content: ""
				}

			}
		},
		created() {
			//console.log("replyObj:",JSON.stringify(this.replyObj) )
			if (this.replyObj.secondReplyArr && this.replyObj.secondReplyArr.length > 0) {
				this.secondReply = {
					name: this.$util.nameTransform(this.passInType, this.replyObj.dataDetails.in_open_id,
						this.replyObj.dataDetails.orgRoletype,
						this.replyObj.secondReplyArr[0].open_id, this.replyObj.secondReplyArr[0].roleType, this.replyObj
						.dataDetails.openShowName),
					time: this.$util.timeMatch(this.replyObj.secondReplyArr[0].create_time, this.serverTime),
					content: this.replyObj.secondReplyArr[0].text_evaluate
				}
			}
		},
		methods: {
			onGoto(type) {
				if (this.replyObj.roleType == '1') {
					this.$emit("emitReplyItem", {
						type: "goto",
						dataDetails: this.replyObj.dataDetails
					})
				}

			},
			onLike() {
				this.$emit("emitReplyItem", {
					type: "like",
					dataDetails: this.replyObj.dataDetails
				})
			},
			onShowMore() {
				this.$emit("emitReplyItem", {
					type: "showMore",
					dataDetails: this.replyObj.dataDetails
				})
			},
			onLongpress() {
				this.$emit("emitReplyItem", {
					type: "longpress",
					item: this.replyObj.dataDetails
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.vReplyItem {

		.item {
			padding: 30rpx 0;
			border-bottom: 1rpx solid $uni-border-color;

			.title {
				padding-right: 7rpx;
				display: flex;
				align-items: center;

				.avatar-con {
					.avatar {
						width: 80rpx;
						min-width: 80rpx;
						height: 80rpx;
						margin-right: 15rpx;
						border-radius: 100rpx;
					}

					.iconfont {
						width: 80rpx;
						min-width: 80rpx;
						height: 80rpx;
						margin-right: 15rpx;

						color: $uni-text-color-greyA;
						font-size: 50rpx;

					}
				}

				.middle {
					flex: 1;

					.name {
						font-size: 28rpx;
						font-family: Microsoft YaHei;
						font-weight: 400;
						color: $uni-text-color;
					}

					.time {
						font-size: 24rpx;
						font-family: Microsoft YaHei;
						font-weight: 400;
						color: $uni-text-color-greyA;
					}
				}

				.right {
					display: flex;
					align-items: center;

					.icon-container {
						margin-left: 40rpx;

						display: flex;
						align-items: center;

						.iconfont {
							font-size: 30rpx;
							margin-right: 5rpx;
						}

						.active {
							color: $uni-color-active;
						}

						.txt {
							font-size: 24rpx;
							font-weight: 400;
							color: $uni-text-color-grey;
						}

					}

				}
			}

			.content {
				font-size: 32rpx;
				color: $uni-text-color;
				margin-left: 95rpx;
				margin-top: 18rpx;
				word-wrap:break-word;
			}

			.second-reply {
				margin-top: 27rpx;
				margin-left: 95rpx;
				background: #F7F7F7;
				border-radius: 10rpx;
				padding: 20rpx 26rpx 20rpx 26rpx;

				.name-time {
					display: flex;
					align-items: center;

					.name {
						margin-right: 25rpx;
						font-size: 24rpx;
						font-weight: 400;
						color: $uni-text-color;
					}

					.time {
						font-size: 24rpx;
						font-weight: 400;
						color: $uni-text-color-greyA;
					}
				}

				.txt {
					margin-top: 20rpx;
					font-size: 28rpx;
					font-family: Microsoft YaHei;
					font-weight: 400;
					color: $uni-text-color;
				}

				.more {
					font-size: 28rpx;
					font-family: Microsoft YaHei;
					font-weight: 400;
					color: $uni-color-active;
					margin-bottom: 18rpx;
					margin-top: 32rpx;
				}
			}
		}

	}
</style>
