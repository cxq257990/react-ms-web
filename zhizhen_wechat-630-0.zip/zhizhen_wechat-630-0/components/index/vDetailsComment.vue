<template>
	<view class="vDetailsComment">
		<view class="top">
			<view class="info">
				<image class="avatar" :src="obj.headImg" mode="" @click="onGoto('avatar')"></image>
				<view class="right">
					<view class="name-job-desc">
						<text class="nameTxt" :class="{commentName:obj.nameObj.isName}" @click="onGoto('name')">
							{{obj.nameObj.name}}
						</text>
						<text class="job" v-if="obj.job">{{obj.job}}</text>
						<text class="txt" v-if="whichPage =='details'">点评</text>
					</view>
					<view class="company">{{obj.company}}</view>
				</view>
			</view>
			<view class="icon-contaienr" v-if="whichPage=='secondReply'" @click="onLike">
				<view class="iconfont" :class="obj.dataDetails.isFabu=='1'?'icon-msg-zan-xuanzhong active':'icon-zan'">
				</view>
				<text class="txt">{{obj.dataDetails.fabuCount}}</text>
			</view>
		</view>
		<view class="content">
			{{obj.content}}
		</view>
		<view class="time">{{obj.time}}</view>
		<slot></slot>
	</view>
</template>

<script>
	export default {
		name: "vDetailsComment",

		props: {
			whichPage: {
				type: String,
				default: "details"
			},
			obj: {
				type: Object,
				default: () => {
					return {
						headImg: "/static/img/anonymity.png",
						job: "人力资源",
						nameObj: {
							name: "张三",
							isName: true
						},

						company: "吉利汽车控股集团 (北京)",
						content: "好评好评好评好评好评好评好评好评好评好 好评好评好评好评好评好评好评。",
						time: "21-04-05 12:02",
						dataDetails: {}
					}
				}
			}
		},
		data() {
			return {};
		},
		created() {
			//console.log("emitDetailsComment:",this.obj)
		},
		methods: {
			onGoto(type) {
				//console.log("vDetailsComment:", type)
				if ((type == "name" || type == "avatar") && !this.obj.nameObj.isName) {
					return;
				}
				this.$emit('emitMainComment', {
					type: type,
					dataDetails: this.obj.dataDetails
				})

			},
			onLike() {
				this.$emit('emitMainComment', {
					type: 'like',
					dataDetails: this.obj.dataDetails
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.vDetailsComment {
		border-bottom: 1rpx solid $uni-border-color;

		.top {
			margin-bottom: 44rpx;
			display: flex;
			align-items: center;
			justify-content: space-between;

			.info {
				display: flex;
				align-items: center;
				justify-content: flex-start;

				.avatar {
					width: 80rpx;
					min-width: 80rpx;
					height: 80rpx;
					margin-right: 20rpx;
					border-radius: 100rpx;
				}

				.right {
					.name-job-desc {
						margin-bottom: 6rpx;
						display: flex;
						align-items: flex-end;
						justify-content: flex-start;


						.name {
							margin-right: 25rpx;
							font-size: 34rpx;
							font-family: Microsoft YaHei;
							font-weight: 400;
							color: $uni-color-active;
						}

						.nameTxt {
							white-space: nowrap;
							margin-right: 25rpx;
							font-size: 34rpx;
							font-family: Microsoft YaHei;
							font-weight: 400;
							color: $uni-text-color-greyA;
						}

						.commentName {
							color: $uni-color-active;
						}

						.job {
							font-size: 24rpx;
							font-family: Microsoft YaHei;
							font-weight: 400;
							color: $uni-text-color-greyA;
							margin-right: 25rpx;
						}

						.txt {
							font-size: 24rpx;
							font-family: Microsoft YaHei;
							font-weight: 400;
							color: $uni-text-color-greyA;
						}
					}

					.rich {
						.desc {
							word-break: keep-all;
							overflow: hidden;
							text-overflow: ellipsis;
							white-space: nowrap;

							display: flex;
							align-items: center;
							font-size: 24rpx;
							font-family: Microsoft YaHei;
							font-weight: 400;
							color: $uni-text-color-greyA;
						}
					}

					.company {
						font-size: 28rpx;
						font-family: Microsoft YaHei;
						font-weight: 400;
						color: $uni-text-color-grey;
						word-wrap: break-word;
					}
				}
			}

			.icon-contaienr {
				margin-left: 10rpx;
				display: flex;
				align-items: center;

				.iconfont {
					margin-right: 5rpx;
					font-size: 30rpx;
					color: #444;
				}

				.active {
					color: $uni-color-active
				}

				.txt {
					font-size: 24rpx;
					font-family: Microsoft YaHei;
					font-weight: 400;
					color: $uni-text-color-greyA;
				}
			}
		}

		.content {
			line-height: 46rpx;
			font-size: 32rpx;
			font-family: Microsoft YaHei;
			font-weight: 400;
			color: $uni-text-color;
			margin-bottom: 30rpx;
			word-wrap: break-word;
		}

		.time {
			margin-bottom: 24rpx;
			font-size: 24rpx;
			font-family: Microsoft YaHei;
			font-weight: 400;
			color: $uni-text-color-greyA;
		}

	}
</style>
