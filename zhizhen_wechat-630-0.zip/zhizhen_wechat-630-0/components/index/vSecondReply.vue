<template>
	<view class="vSecondReply">
		<view class="main">
			<scroll-view class="scroll" scroll-y="true">
				<view class="top">
					<view class="iconfont icon-shanchu" @click="onHideBg"></view>
					<view class="txt">{{secondReplyArr.length}}条回复</view>
				</view>
				<view class="firstReply" id="firstReply">
					<vDetailsComment v-if="passInType=='comment'" whichPage="secondReply" 
						:obj="commentObj" @emitMainComment="eventMainComment">
					</vDetailsComment>
					<vAskItem v-if="passInType=='ask'" parentType="secondReply" :showLike="true" :obj="commentObj"
						@emitAskItem="eventAskItem"></vAskItem>
				</view>
				<view class="title-container">
					<view class="txt">全部回复 {{secondReplyArr.length}}</view>
					<view class="line"></view>
				</view>
				<!-- <view class="reply-list" :style="{height:`calc(100vh - var(--safe-area-inset-bottom) - ${upH}px)`}"> -->
				<view class="reply-list">
					<vReplyItem class="item" parentType="secondReply" v-for="(item,index) in secondReplyArr"
						:key="index" @emitReplyItem="eventReplyItem" :replyObj="item"></vReplyItem>
				</view>
			</scroll-view>
			<view class="send-container">
				<vSend @emitSend="eventSend"></vSend>
			</view>
		</view>

		<view class="bg" @touchmove.stop="moveStop" @click="onHideBg"></view>
		<vActionSheet v-if="showActionsheet" :arr="actions" @emitActionSheet="eventActionSheet"></vActionSheet>
		<vDialog class="vDialog" v-if="showDialog" msg="确定要删除此评论吗？" @emitDialog="eventDialog"></vDialog>
		<view class="bottom-mask"> </view>

	</view>
</template>

<script>
	import {
		mapState
	} from "vuex";
	import vDetailsComment from "./vDetailsComment.vue";
	import vAskItem from "./vAskItem.vue";
	import vReplyItem from "./vReplyItem.vue";
	import vSend from "../common/vSend.vue";
	import vDialog from "../common/vDialog.vue"
	import vActionSheet from "../common/vActionSheet.vue"
	export default {
		components: {
			vDetailsComment,
			vAskItem,
			vReplyItem,
			vSend,
			vActionSheet,
			vDialog
		},
		props: {
			passInType: {
				type: String,
				default: "comment"
			},
			serverTime: {
				type: String,
				default: ""
			},
			mainId: {
				type: Number,
				default: 0
			},
			obj: {
				type: Object,
				default: () => {
					return {}
				}
			}
		},
		data() {
			return {
				count: 12,
				upH: 0,
				commentObj: {},
				secondReplyArr: [],

				showActionsheet: false,
				showDialog: false,
				selectDeleteObj: {},
				actions: [{
					txt: '删除',
					type: 'delete'
				}, {
					txt: '取消',
					type: 'cancel'
				}],
			}
		},
		computed: {
			...mapState(['userPhone', 'userInfoObj', 'loginInfoObj'])
		},
		created() {
			console.log("vSecondReply-obj:", this.obj.orgRoletype)
			if (this.passInType == "comment") {
				this.commentObj = {
					headImg: this.obj.roleType == "1" ? this.obj.avatar : this.$defaultHeadimg,
					job: this.obj.position_name,
					nameObj: {
						name: this.$util.nameTransform('comment', this.obj.in_open_id, this.obj.orgRoletype, this.obj
							.open_id, this.obj.roleType, this.obj.openShowName),
						isName: this.obj.roleType == "1" ? true : false
					},
					company: this.obj.company_name,
					content: this.obj.text_evaluate,
					time: this.$util.timeMatch(this.obj.create_time, this.serverTime),
					dataDetails: this.obj
				}
			} else {
				this.commentObj = {
					headImg: this.obj.avatar,
					name: this.$util.nameTransform("ask", this.obj.in_open_id, this.obj.orgRoletype, this.obj
						.open_id, this.obj.roleType, this.obj.openShowName),
					roleType: this.obj.roleType, //1个人,2 访客，3公司
					company: this.obj.openShowName,
					title: this.obj.text_evaluate,
					time: this.$util.timeMatch(this.obj.create_time, this.serverTime),
					imgArr: [],
					dataDetails: this.obj
				}
				console.log("vSecondReply-ask:", this.commentObj)
			}

			this.secondReplyArr = this.obj.threeRelativesList.map(item => {
				return {
					headImg: item.avatar,
					name: this.$util.nameTransform('comment', this.obj.in_open_id, this.obj.orgRoletype, item
						.open_id,
						item.roleType, this.openShowName),

					roleType: item.roleType,
					time: this.$util.timeMatch(item.create_time, this.serverTime),
					content: item.text_evaluate,
					secondReplyArr: [],
					isLike: item.isFabu == "1" ? true : false,
					likeCount: item.fabuCount,
					dataDetails: item
				}
			})
			console.log("this.secondReplyArr:", this.secondReplyArr)
		},
		mounted() {
			// const query = uni.createSelectorQuery().in(this);
			// query.select('#firstReply').boundingClientRect(data => {
			// 	this.upH = data.height + 80 + 150
			// }).exec();
		},
		methods: {
			onHideBg() {
				this.$emit("emitSecondReply")
			},
			async eventMainComment(obj) {
				console.log("vSecondReply-eventMainComment:", obj)
				if (obj.type == 'avatar' || obj.type == 'name') {
					this.$util.checkJumpRelation(obj.dataDetails.open_id)
				} else if (obj.type == 'like') {
					let data = {
						"parent_id": obj.dataDetails.id,
						"comment_type": "2",
						"oper_type": obj.dataDetails.isFabu == "1" ? "3" : "2",
						"show_name": this.userInfoObj.nickName,
						"open_id": this.loginInfoObj.open_id
					}
					let res = await this.$http.postHasLoad('/zxxt/careerEvalu/operComment', data);
					if (res) {

						this.commentObj.dataDetails.fabuCount = obj.dataDetails.isFabu == '1' ?
							Number(obj.dataDetails.fabuCount) - 1 : Number(obj.dataDetails
								.fabuCount) + 1;
						this.commentObj.dataDetails.isFabu = obj.dataDetails.isFabu == '1' ? '0' : '1';
					}
				}
			},
			async eventAskItem(obj) {
				if ((obj.type == 'avatar' || obj.type == 'name') && obj.dataDetails.roleType == '1') {
					this.$util.checkJumpRelation(obj.dataDetails.open_id)
				} else if (obj.type == 'like') {

					let data = {
						"parent_id": obj.dataDetails.id,
						"comment_type": "2",
						"oper_type": obj.dataDetails.isFabu == "1" ? "2" : "1",
						"show_name": this.userInfoObj.nickName,
						"open_id": this.loginInfoObj.open_id
					}
					let res = await this.$http.postHasLoad('/zxxt/askEmploy/operComment', data);
					if (res) {

						this.commentObj.dataDetails.fabuCount = obj.dataDetails.isFabu == '1' ?
							Number(obj.dataDetails.fabuCount) - 1 : Number(obj.dataDetails
								.fabuCount) + 1;
						this.commentObj.dataDetails.isFabu = obj.dataDetails.isFabu == '1' ? '0' : '1';
					}
				}
			},
			async eventReplyItem(obj) {
				//console.log("vSecondReply-eventReplyItem:", obj)
				if (obj.type == "goto") {
					if (obj.dataDetails.roleType == "1") {
						this.$util.checkJumpRelation(obj.dataDetails.open_id)
					}
				} else if (obj.type == 'longpress') {
					this.selectDeleteObj = obj.item;
					this.showActionsheet = true;
				} else if (obj.type == 'like') {
					if (this.passInType == "comment") {
						let data = {
							"parent_id": obj.dataDetails.id,
							"comment_type": "3",
							"oper_type": obj.dataDetails.isFabu == "1" ? "3" : "2",
							"show_name": this.userInfoObj.nickName,
							"open_id": this.loginInfoObj.open_id
						}
						this.postLike('/zxxt/careerEvalu/operComment', data, obj)

					} else {
						let data = {
							"parent_id": obj.dataDetails.id,
							"comment_type": "3",
							"oper_type": obj.dataDetails.isFabu == "1" ? "2" : "1",
							"show_name": this.userInfoObj.nickName,
							"open_id": this.loginInfoObj.open_id
						}
						this.postLike('/zxxt/askEmploy/operComment', data, obj)
					}


				}

			},
			eventActionSheet(item) {
				console.log("eventActionSheet:", item)
				if (item.type == "delete") {
					this.showDialog = true;
				} else {
					this.showActionsheet = false
				}
			},
			async eventDialog(type) {
				if (type == "ok") {
					if (this.passInType == "comment") {
						this.deleteCommentReply(type);
					} else {
						this.deleteAskReply(type)
					}
				} else {
					this.showDialog = false;
				}
			},
			eventSend(obj) {
				console.log("commentObj:", this.commentObj)
				if (this.passInType == "comment") {
					this.postCommentReply(obj)
				} else {
					this.postAskReply(obj);
				}

			},
			async deleteCommentReply(type) {
				let data = {
					"comment_type": "3",
					"open_id": this.loginInfoObj.open_id,
					"oper_type": "6",
					"parent_id": this.selectDeleteObj.id,
					"show_name": this.userInfoObj.nickName
				}
				let res = await this.$http.postHasLoad("/zxxt/careerEvalu/operComment", data);
				if (res) {
					this.$util.toast('删除成功');
					this.showDialog = false;
					this.showActionsheet = false;
					this.getRefresh("comment", "/zxxt/careerEvalu/lookSingleModule");

				}
			},
			async deleteAskReply(type) {
				let data = {
					"comment_type": "3",
					"open_id": this.loginInfoObj.open_id,
					"oper_type": "3",
					"parent_id": this.selectDeleteObj.id,
					"show_name": this.userInfoObj.nickName
				}
				let res = await this.$http.postHasLoad("/zxxt/askEmploy/operComment", data);
				if (res) {
					this.$util.toast('删除成功');
					this.showDialog = false;
					this.showActionsheet = false;
					this.getRefresh("ask", "/zxxt/askEmploy/lookSingleModule");


				}
			},
			async postCommentReply(obj) {
				let data = {
					"cid1": this.mainId,
					"cid2": this.commentObj.dataDetails.id,
					"comment_type": "3",
					"in_open_id": this.commentObj.dataDetails.open_id,
					"open_id": this.loginInfoObj.open_id,
					"open_show_name": obj.openName,
					"role_type": obj.roleType,
					"text_evaluate": obj.val
				}
				console.log("eventSend:", data)
				let res = await this.$http.postHasLoad("/zxxt/careerEvalu/addSubComment", data);
				if (res) {
					this.getRefresh("comment", "/zxxt/careerEvalu/lookSingleModule");
				}
			},

			async postAskReply(obj) {
				//console.log("postAskReply:",obj)
				let data = {
					"cid1": this.mainId,
					"cid2": this.commentObj.dataDetails.id,
					"comment_type": "3",
					"in_open_id": this.commentObj.dataDetails.open_id,
					"open_id": this.loginInfoObj.open_id,
					"open_show_name": obj.openName,
					"role_type": obj.roleType,
					"text_evaluate": obj.val
				}
				//console.log("eventSend:", data)
				let res = await this.$http.postHasLoad("/zxxt/askEmploy/addAskEmployComment", data);
				if (res) {
					this.getRefresh("ask", "/zxxt/askEmploy/lookSingleModule");
				}
			},
			async getRefresh(type, url) {
				let data = {
					msgId1: this.mainId,
					msgId2: this.obj.id,
					open_id: this.loginInfoObj.open_id
				}
				let res = await this.$http.getNoLoad(url, data);
				if (res) {
					this.secondReplyArr = res.data.relativesDoList.map(item => {
						return {
							headImg: item.avatar,
							name: this.$util.nameTransform(type, this.obj.in_open_id, this.obj.orgRoletype,
								item.open_id, item.roleType, item.openShowName),
							roleType: item.roleType,
							time: this.$util.timeMatch(item.create_time, this.serverTime),
							content: item.text_evaluate,
							secondReplyArr: [],
							isLike: item.isFabu == "1" ? true : false,
							likeCount: item.fabuCount,
							dataDetails: item
						}



					})
				}
			},
			async postLike(url, data, obj) {
				let res = await this.$http.postHasLoad(url, data);
				if (res) {
					this.secondReplyArr.forEach(item => {
						if (item.dataDetails.id == obj.dataDetails.id) {
							item.likeCount = obj.dataDetails.isFabu == "1" ? Number(obj.dataDetails
									.fabuCount) -
								1 : Number(obj.dataDetails
									.fabuCount) + 1;
							item.isLike = obj.dataDetails.isFabu == "1" ? false : true;


							item.dataDetails.fabuCount = item.dataDetails.isFabu == "1" ? Number(item
									.dataDetails.fabuCount) - 1 :
								Number(item.dataDetails
									.fabuCount) + 1;
							item.dataDetails.isFabu = item.dataDetails.isFabu == "1" ? "0" : "1";
						}
					})
				}
			},
			moveStop() {}
		}
	}
</script>

<style lang="scss" scoped>
	.vSecondReply {
		position: fixed;
		top: 0;
		left: 0;
		z-index: 9;
		width: 100vw;
		height: 100vh;

		.main {
			position: absolute;
			left: 0;
			bottom: var(--safe-area-inset-bottom);
			z-index: 9;
			width: 100%;

			height: calc(100vh - 150rpx - var(--safe-area-inset-bottom));
			padding-bottom: 88rpx;
			// overflow-y: auto;

			box-sizing: border-box;
			background: #fff;
			border-radius: 20rpx 20rpx 0 0;
			//background-color: red;
.scroll{
	width: 100%;
	height: 100%;
}
			.top {
				position: relative;
				padding: 30rpx;

				.iconfont {
					position: absolute;
					top: 30rpx;
					left: 30rpx;
					font-size: 20rpx;
				}

				.txt {
					text-align: center;
					font-size: 32rpx;
					font-family: Microsoft YaHei;
					font-weight: 400;
					color: $uni-text-color;
				}
			}

			.firstReply {
				padding: 30rpx 30rpx 0 30rpx;

			}

			.title-container {
				margin-top: -2rpx;
				border-top: 1rpx solid $uni-border-color;

				.txt {
					padding: 30rpx;
				}

				.line {
					margin: 0 30rpx;
					border-bottom: 1rpx solid $uni-border-color;
				}

			}

			.reply-list {
				padding: 0 30rpx;
				overflow-y: auto;
				min-height: 500rpx;

				.item:last-of-type {
					/deep/ .vReplyItem {
						.item {
							border-bottom: none;
						}
					}
				}
			}

			.send-container {
				position: fixed;
				left: 0;
				bottom: var(--safe-area-inset-bottom);
				z-index: 4;
				width: 100%;
				//background-color: red;
			}
		}

		.bg {
			position: absolute;
			z-index: 2;
			width: 100%;
			height: 100%;
			opacity: 0.2;
			background: #000;
		}

		.bottom-mask {
			position: absolute;
			left: 0;
			bottom: 0;
			z-index: 3;
			width: 100%;
			height: 100rpx;
			background-color: #fff;
		}
	}
</style>
