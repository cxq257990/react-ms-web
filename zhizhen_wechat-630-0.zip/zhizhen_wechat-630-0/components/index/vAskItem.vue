<template>
	<view class="vAskItem">
		<view class="top">
			<view class="info">
				<view class="avatar-con">
					<image class="avatar" v-if="obj.roleType=='1'" :src="obj.headImg" @click="onGoto('avatar')" mode="">
					</image>
					<image class="avatar" v-else-if="obj.roleType=='2'" :src="defaultHeadimg" mode="">
					</image>
					<!-- <view class="avatar iconfont icon-gongsi" v-else></view> -->
					<image class="avatar" v-else src="../../static/img/company.jpg" mode="">
					</image>
				</view>
				<view class="right" v-if="parentType=='search'">
					<view class="name-job-desc">
						<rich-text class="name" :nodes="obj.name" @click="onGoto('name')">
						</rich-text>
						<!-- <view class="name anonymity" v-else>{{obj.name}}</view> -->
					</view>
					<rich-text class="company" :nodes="obj.company"></rich-text>
				</view>
				<view class="right" v-else>
					<view class="name-job-desc">
						<view class="name">{{obj.name}}</view>
						<text class="txt" v-if="parentType=='details'">发布</text>
					</view>
					<view class="company">{{obj.company}}</view>
				</view>
			</view>
			<view class="icon-contaienr" v-if="showLike" @click="onLike">
				<view class="iconfont" :class="obj.dataDetails.isFabu=='1'?'icon-msg-zan-xuanzhong active':'icon-zan'">
				</view>
				<text class="txt">{{obj.dataDetails.fabuCount}}</text>
			</view>

		</view>
		<view class="content" @click="onGoto('content')">

			<template v-if="parentType=='search'">
				<rich-text :nodes="obj.title"></rich-text>
			</template>
			<template v-else>
				<view class="">
					{{obj.title}}
				</view>
				<view class="" v-if="!!obj.content">
					{{obj.content}}
				</view>
				
			</template>
		</view>


		<template v-if="obj.imgArr">
			<view v-if="obj.imgArr.length==0"></view>
			<view class="img-container one-img" v-else-if="obj.imgArr.length==1" data-type="wrapper" @click="onImgWrapper">
				<image class="img" :src="obj.imgArr[0]" mode="aspectFill" @click="bigImg(obj.imgArr,index)"></image>
			</view>
			<view class="img-container four-img" v-else-if="obj.imgArr.length==4" data-type="wrapper" @click="onImgWrapper">
				<image class="img" :src="item" mode="aspectFit" v-for="(item,index) in obj.imgArr" :key="index"
					@click="bigImg(obj.imgArr,index)"></image>
			</view>
			<view class="img-container more-img" v-else data-type="wrapper" @click="onImgWrapper">
				<image class="img" :src="item" mode="aspectFit" v-for="(item,index) in obj.imgArr" :key="index"
					@click="bigImg(obj.imgArr,index)"></image>
			</view>
		</template>

		<view class="bottom">
			<view class="time">{{obj.time}}</view>
			<view class="btn" v-if="parentType=='search'" @click="onGoto('comment')">
				<view class="iconfont icon-msg-pinglun"></view>
				<text class="txt">{{obj.dataDetails.comment_count}}</text>
				<image v-if="obj.dataDetails.comment_count>10" class="hot" src="../../static/img/hot.png" mode="">
				</image>
			</view>
		</view>

	</view>
</template>

<script>
	export default {
		props: {
			parentType: {
				type: String,
				default: 'search'
			},
			showLike: {
				type: Boolean,
				default: false
			},
			obj: {
				type: Object,
				default: () => {
					return {
						headImg: "",
						name: "吴<span style='color:#F64135;'>明珠</span>",
						roleType: "1", //1个人,2 访客，3公司
						company: "<span style='color:#F64135;'>吉利</span>汽车控股集团 (北京)",
						title:"",
						content: "",
						time: "",
						imgArr: [],
						dataDetails: {}
					}
				}
			}
		},

		data() {
			return {
				defaultHeadimg: this.$defaultHeadimg
			}
		},
		created() {
			//console.log('vAskItem:',this.obj)
		},
		methods: {
			onGoto(type) {
				console.log("askItem:",this.obj)
				if ((type == "avatar" || type == "name") && this.obj.roleType!="1") {
					return
				}
				this.$emit('emitAskItem', {
					type: type,
					dataDetails: this.obj.dataDetails
				})
			},
			onLike() {
				this.$emit('emitAskItem', {
					type: 'like',
					dataDetails: this.obj.dataDetails
				})
			},
			onImgWrapper(e){
				//console.log("onImgWrapper:",e)
				if(e.target.dataset.type&&e.target.dataset.type=='wrapper'){
					this.$emit('emitAskItem', {
						type: 'content',
						dataDetails: this.obj.dataDetails
					})
				}
			},
			bigImg(imglist, index) {
				//this.$emit('emitAskItem', {'type':"showBigImg"});
				uni.previewImage({
					urls: imglist,
					current: index
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.vAskItem {

		border-bottom: 1rpx solid $uni-border-color;

		.top {
			margin-bottom: 35rpx;
			display: flex;
			align-items: center;
			justify-content: space-between;

			.info {
				display: flex;
				align-items: center;
				justify-content: flex-start;

				.avatar-con {
					.avatar {
						width: 80rpx;
						min-width: 80rpx;
						height: 80rpx;
						margin-right: 20rpx;
						border-radius: 100rpx;
					}

					.iconfont {
						width: 80rpx;
						min-width: 80rpx;
						height: 80rpx;
						margin-right: 20rpx;

						color: $uni-text-color-greyA;
						font-size: 72rpx;
						text-align: center;

					}
				}

				.right {
					.name-job-desc {
						margin-bottom: 6rpx;
						display: flex;
						align-items: flex-end;
						justify-content: flex-start;

						.name {
							margin-right: 28rpx;
							font-size: 34rpx;
							font-family: Microsoft YaHei;
							font-weight: 400;
							color: $uni-color-active;
						}

						.anonymity {
							color: #666
						}

						.txt {
							font-size: 24rpx;
							font-family: Microsoft YaHei;
							font-weight: 400;
							color: $uni-text-color-greyA;
						}
					}

					.company {
						font-size: 28rpx;
						font-family: Microsoft YaHei;
						font-weight: 400;
						color: $uni-text-color-grey;

						.match {
							color: $uni-color-search-match
						}
					}
				}
			}

			.icon-contaienr {
				margin-left: 10rpx;
				display: flex;
				align-items: center;

				.iconfont {
					margin-right: 5rpx;
					font-size: 30rpx;
					color: #444;
				}

				.active {
					color: $uni-color-active
				}

				.txt {
					font-size: 24rpx;
					font-family: Microsoft YaHei;
					font-weight: 400;
					color: $uni-text-color-greyA;
				}
			}
		}

		.content {
			line-height: 46rpx;
			font-size: 32rpx;
			font-family: Microsoft YaHei;
			font-weight: 400;
			color: $uni-text-color;
			margin-bottom: 30rpx;
			word-wrap:break-word;
		}


		.img-container {
			width: 100%;
			display: flex;
			flex-wrap: wrap;

			.img {
				margin-bottom: 10rpx;
			}
		}

		.one-img {
			align-items: flex-start;

			.img {
				max-width: 50%;
				max-height: 444rpx;
			}
		}

		.four-img {
			max-width: 80%;

			.img {
				width: 200rpx;
				max-height: 200rpx;
			}

			.img:nth-of-type(2n-1) {
				margin-right: 10rpx;
			}
		}

		.more-img {
			.img {
				width: 200rpx;
				max-height: 200rpx;
			}

			.img:nth-of-type(3n-1) {
				margin-left: 10rpx;
				margin-right: 10rpx;
			}
		}

		.bottom {
            margin-top: 30rpx;
			padding-bottom: 24rpx;
			display: flex;
			align-items: center;
			justify-content: space-between;

			.time {
				font-size: 24rpx;
				font-family: Microsoft YaHei;
				font-weight: 400;
				color: $uni-text-color-greyA;
			}

			.btn {
				margin-right: 18rpx;
				display: flex;
				align-items: center;
				position: relative;



				.iconfont {
					color: #444444;
					font-size: 38rpx;
				}

				.hot {

					position: absolute;
					top: -8rpx;
					left: 10rpx;
					z-index: 9;
					width: 46rpx;
					height: 24rpx;
				}

				.txt {
					margin-left: 15rpx;
					font-size: 24rpx;
					font-family: Microsoft YaHei;
					font-weight: 400;
					color: $uni-text-color-greyA;
				}
			}

		}
	}
</style>
