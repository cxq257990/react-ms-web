<template>
	<view class="v-Head-title">
		<view class="box">
			<view class="Head-title-box">
				<view v-if="isShowdeleteBtn" :data-id="obj.id" @click="onDeleteBtn" class="iconfont"
					:class="['icon-delete','icon-shanchu']"></view>
				<view class="left-box" @tap="onUserImg(obj)">
					<template v-if="haveAnonymityType">
						<image class="left" v-if="obj.role_type=='3'" src="/static/img/company.jpg" mode=""></image>
						<image class="left" v-else-if="obj.role_type=='2' || obj.if_anonymity==1 " :src="defaultHeadimg"
							mode=""> </image>
						<image class="left " v-else :src="obj.avatar " mode=""></image>
					</template>
					<template v-else>
						<image class="left " :src="obj.avatar " mode=""></image>
					</template>
				</view>
				<view class="right">
					<template v-if="haveAnonymityType">
						<template v-if="pageType=='ask'">
							<view class="one">
								<text v-if="obj.role_type==2 " class="name">访客</text>
								<text v-else @tap="onUserName(obj)" class="name ">{{obj.user_name}}</text>
							</view>
						</template>
						<template v-else>
							<view class="one">
								<template v-if="obj.if_anonymity==1">
									<text class="name">访客</text>
								</template>
								<template v-else>
									<text class="name " @tap="onUserName(obj)">{{obj.user_name}}</text>
									<text class="job">{{obj.position_name}}</text>
									<view class="two "> {{obj.company_name}}</view>
								</template>
							</view>
						</template>
					</template>
					<template v-else>
						<view class="one">
							<text class="name " @tap="onUserName(obj)">{{obj.user_name}}</text>
							<text class="job">{{obj.position_name}}</text>
						
						</view>
						<view class="two "> {{obj.company_name}}</view>
					</template>
				</view>
			</view>
			<view>
				<view v-if="hasOneLine" class="one-line"> </view>
			</view>

		</view>
	</view>
</template>
<script>
	export default {


		components: {},
		props: {

			hasOneLine: {
				type: Boolean,
				required: false,
				// default: []
			},

			isShowdeleteBtn: {
				type: Boolean,
				default: false
			},
			pageType: {
				type: String,
				default: ""
			},
			haveAnonymityType: {
				type: Boolean,
				default: true
			},

			avatarOpenIdType: {
				type: String,
				default: "open_id"
			}, //letter_open_id  in_open_id myOpenId


			obj: {
				type: Object,
				default: () => {

					return {
						writers_name: "",
						user_name: "user_nameuser_name",
						company_name: "company_name",
						avatar: "avataravatar",
						position_name: "positionon_name"
					}



				}
			}


		},


		data() {
			return {
				defaultHeadimg: this.$defaultHeadimg
			}
		},

		methods: {
			

			onUserName(obj) {
				this.onUserImg(obj)
				
			},
// cxq-00
			checkJumpRelation(open_id, obj) {
				console.log('objobjobj=====',obj)
				if (obj && obj.in_phone && obj.in_outer_id) {
					console.log('objobjobj==2===',obj)
					this.$util.checkJumpRelation(open_id, obj.in_phone, obj.in_outer_id)
					return
				
				} else{
					if (obj && obj.in_phone) {
						
						this.$util.checkJumpRelation(open_id, obj.in_phone)
					    return
					} 
					if (obj && obj.in_outer_id) {
						
						this.$util.checkJumpRelation(open_id,'', obj.in_outer_id)
					    return
					} 
					
				}
					
				this.$util.checkJumpRelation(open_id)

			},
			onUserImg(obj) {
				if (this.haveAnonymityType) {
					if (obj.role_type == '2' || obj.if_anonymity == 1) {
						return

					}
				}

				switch (this.avatarOpenIdType) {
					case 'in_open_id':
						this.checkJumpRelation(obj.in_open_id, obj)
						break;

					case 'letter_open_id':
						this.checkJumpRelation(obj.letter_open_id, obj)
						break;
					case 'myOpenId':
						this.checkJumpRelation(obj.myOpenId, obj)
						break;

					default:
						this.checkJumpRelation(obj.open_id, obj)
				}

			},
			onDeleteBtn(event) {
				// 删除-弹窗
				var _this = this
				uni.showModal({
					title: '提示',
					content: '确定删除吗？',
					success(res) {
						if (res.confirm) {
							console.log('用户点击确定')
							_this.$emit("onDeleteBtn", event.currentTarget.dataset.id)
						} else if (res.cancel) {
							console.log('用户点击取消')
						}
					}
				})
			}
		}

	}
</script>


<style lang="scss" scoped>
	.name_one {
		font-size: 34rpx;
		font-family: Microsoft YaHei;
		width: 400rpx;
		font-weight: 400;
	}





	.one-line {
		// margin-top: 40rpx;
		width: 100%;
		height: 4rpx;
		background-color: $uni-line-color-grayA;
	}


	.icon-delete {
		position: absolute;
		font-size: 25rpx;
		color: $uni-color-active;
		right: 30rpx;
		top: 20rpx;

	}

	.Head-title-box {
		display: flex;
		align-items: center;
		position: relative;
		min-height: 150rpx;

		.left-box {
			min-width: 80rpx;
			margin-right: 30rpx;
			// background: yellow; //cxq-1
		}

		.left {
			border-radius: 50%;
			width: 80rpx;
			height: 80rpx;
		}

		.right {
			// background: pink; //cxq-1
			margin-right: 60rpx;

			.one {
				// flex-wrap: wrap;
				// display: flex;

				.name {
					margin-right: 28rpx;
					font-size: 34rpx;
					font-family: Microsoft YaHei;
					font-weight: 400;
					color: $uni-color-active;
					// background-color: red;
				}



				.job {
					font-size: 24rpx;
					font-family: Microsoft YaHei;
					font-weight: 400;
					color: $uni-text-color-greyA;
					margin-right: 20rpx;
					// background-color: pink;


				}
			}

			.two {
				font-size: 28rpx;
				font-family: Microsoft YaHei;
				font-weight: 400;
				color: $uni-text-color-grey;


			}
		}
	}
</style>
