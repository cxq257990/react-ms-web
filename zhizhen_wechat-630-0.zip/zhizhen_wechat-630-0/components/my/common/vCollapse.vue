<template>
	<view class="vCollapse">
		<view class="cell-item-box" @tap="OnIsShowMore()">
			<view class="center">{{Obj.title}}</view>
			<view v-if='Obj.list.length>1'
				:class="{ 'arrowTransform icon-s-xiangxia': isShowMore, 'icon-s-xiangyou arrowTransformReturn': !isShowMore}"
				class="right iconfont "></view>
		</view>
		<!-- ttt -->
		<!-- <view  v-if='0'> -->
		<view class="items-box" v-if='Obj.list.length>0'>
			<view v-if='isShowMore &&Obj.list.length>1'>
				<slot name="showMoreData"></slot>
			</view>
			<template v-else>
				<view :key="index">
					<slot name="showOneData"></slot>
				</view>
			</template>
		</view>
		<view v-else>
			<vNoContent>
			</vNoContent>

		</view>

	</view>
</template>
<script>
	import vNoContent from "components/my/common/vNoContent.vue";
	export default {
		components: {
			vNoContent

		},
		props: {
			text: {
				type: String,
				default: '暂时没有相关的信息'
			},
			Obj: {
				type: Object,
				default: () => {
					return {
						// title: '--',
						title: '',
						// list: [1]
						// list: [1,2,3]
						list: []
					}

				}
			}
		},
		data() {
			return {

				isShowMore: false
			}
		},


		methods: {
			OnIsShowMore() {
				if (this.Obj.list.length > 1) {
					this.isShowMore = !this.isShowMore
				}


			}

		}
	}
</script>


<style lang="scss" scoped>
	.items-box {
		padding: 0 40rpx;
	}

	.arrowTransform {
		transition: 0.2s;
		transform-origin: center;
		transform: rotateZ(0deg);
	}

	.arrowTransformReturn {
		transition: 0.2s;
		transform-origin: center;
		transform: rotateZ(360deg);
	}

	.cell-item-box {

		display: flex;
		justify-content: space-between;
		height: 70rpx;
		// background-color: pink;
		padding: 0 40rpx;
		align-items: center;

		.left {
			width: 40rpx;
			height: 40rpx;
			padding-right: 20rpx;

		}

		.center {
			flex: 1;
			color: $uni-color-active;
			font-size: $uni-font-size-15;
			font-weight: bold;
			// color: $uni-line-color-grayA;
		}

		.right {
			width: 40rpx;
			height: 40rpx;
			font-size: 26rpx;
			color: $uni-text-color-greyA;
		}

	}


	.one-line {
		height: 1rpx;
		width: 85%;
		margin: auto;
		background-color: $uni-border-color;
	}
</style>
