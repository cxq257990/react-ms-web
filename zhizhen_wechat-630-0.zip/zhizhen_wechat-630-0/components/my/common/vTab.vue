<template>
	<view>
		<view class="tab-box">

			<view class="tab-items-box">
				<view class="tab-item-box" v-for="(item,index) in tabTitleArr" :key="index">
					<view :class="['tab-item',activeIndex === index ?'active':'']" @click="handleChange(item,index)">
						{{ item }}
					</view>
					<view :class="['one-line',activeIndex === index ?'one-line-active':'']"></view>
				</view>
			</view>
			<slot name="{{activeIndex}}"></slot>
		</view>
	</view>
</template>

<script>
	/** 
	 * activeIndex 选中索引
	 * tab tab 数据 字符串数组
	 * drawWidth 底部滑条宽度
	 * drawHeight 底部滑条高度
	 */
	export default {
		props: {
			activeIndex: {
				type: Number,
				default: 0,
			},
			tabTitleArr: {
				type: Array,
				default: () => {
					return []
				}
				// default:['1','2','3','4']
				// default:[]
			}

		},
		computed: {

		},
		data() {
			return {}
		},

		methods: {
			handleChange(item, index) {

				this.$emit('update:activeIndex', index)
				this.$emit('change', item)
			},

		}
	}
</script>

<style lang="scss" scoped>
	.tab-box {

		.tab-items-box {

			display: flex;
			height: 100rpx;
		}

		.tab-item-box {
			height: 100rpx;
			flex: 1;
			text-align: center;
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;
		}

		.tab-item {

			font-size: 30rpx;
			line-height: 70rpx;
			// background: pink;

		}

		.active {
			// transition: all .8s;
			color: $uni-color-active;

		}

		.one-line-active {
			// transition: all .8s;
			background-color: $uni-color-active;

		}

		.one-line {
			width: 30%;
			height: 5rpx;
		}
	}
</style>
