<template>
	<view class="vImgList" v-if="List.length!==0">
			<view class="img-container one-img" v-if="List.length==1">
				<image class="img" :src="    List[0]" mode="aspectFit" @click="bigImg(    List,index)"></image>
			</view>
			<view class="img-container four-img" v-else-if="    List.length==4">
				<image class="img" :src="item" mode="aspectFit" v-for="(item,index) in     List" :key="index"
					@click="bigImg(    List,index)"></image>
			</view>
			<view class="img-container more-img" v-else>
				<image class="img" :src="item" mode="aspectFit" v-for="(item,index) in     List" :key="index"
					@click="bigImg(    List,index)"></image>
			</view>
	</view>
</template>

<script>
	export default {
		props: {
		
			List: {
				type: Array,
				default: () => {
					return ["/static/img/anonymity.png","/static/img/anonymity.png","/static/img/anonymity.png"]
				}
			}
		},

		data() {
			return {
				defaultHeadimg: this.$defaultHeadimg
			}
		},
		created() {
			console.log('  List==:',this.List)
		},
		methods: {
			bigImg(imglist, index) {
				uni.previewImage({
					urls: imglist,
					current: index
				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.vImgList {

		// border-bottom: 2rpx solid $uni-border-color;




		.img-container {
			width: 100%;
			padding-bottom: 20rpx;
			display: flex;
			flex-wrap: wrap;

			.img {
				margin-bottom: 10rpx;
			}
		}

		.one-img {
			align-items: flex-start;

			.img {
				max-width: 100%;
				max-height: 444rpx;
			}
		}

		.four-img {
			max-width: 80%;

			.img {
				width: 200rpx;
				height: 200rpx;
			}

			.img:nth-of-type(2n-1) {
				margin-right: 10rpx;
			}
		}

		.more-img {
			.img {
				width: 200rpx;
				height: 200rpx;
			}

			.img:nth-of-type(3n-1) {
				margin-left: 10rpx;
				margin-right: 10rpx;
			}
		}

	}
</style>
