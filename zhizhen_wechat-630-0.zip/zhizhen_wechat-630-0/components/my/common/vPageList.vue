<template>
	<view class="pageList">
		<view class="pageList-box">
			<scroll-view v-if="pageListObj && pageListObj.totalPageSize>0" class="scroll-Y" scroll-y="true"
				refresher-enabled="true" :refresher-triggered="triggered" @scrolltolower="onLower"
				@refresherrefresh="onRefresh" @refresherrestore="onRestore">
				<view class="item">
					<slot name="item"></slot>
					<view class="notHaveMoreData" v-if="notHaveMoreData">
						没有更多数据
					</view>
				</view>
			</scroll-view>
			<template v-else>
				<vNoResult v-if="isShowNoResult" txt="暂时没有相关的信息"></vNoResult>
			</template>
		</view>

	</view>
</template>
<script>
	import vNoResult from "components/common/vNoResult.vue"
	export default {
		props: {

			isShowNoResult: {
				type: Boolean,
				default: true

			},

			pageListObj: {
				type: Object,
				default: () => {
					return {}
				}
			}
		},
		components: {
			vNoResult
		},

		watch: {
			pageListObj() {

				if( this.pageListObj && this.pageListObj.totalPageSize == 0) {
					this.notHaveMoreData = false
				}
			},
			notHaveMoreData() {
				if( this.notHaveMoreData) {
					console.log("notHaveMoreData",this.notHaveMoreData);
					// this.$util.toast('没有更多数据');
				}
			}

		},
		data() {
			return {
				notHaveMoreData: false,
				triggered: true


			}
		},


		methods: {

			// ------------------------滚动加载，刷新-----------------------------
			onRefresh() {
				this.triggered = false;
				this.notHaveMoreData = false;
				this.$emit('onRefresh');
			},
			onRestore() {
				this.triggered = 'restore';
				// 需要重置
				console.log("onRestore");
			},
			onLower() {
				let totalPageNum = this.pageListObj.totalPageSize / this.pageListObj.pageSize;
				console.log("totalPageNum", totalPageNum)
				if (
					this.pageListObj.pageNo > totalPageNum
				) {
					this.notHaveMoreData = true;
					return
				}

				let pageNo = this.pageListObj.pageNo + 1;
				console.log("pageNo", pageNo);
				this.$emit('onLower', pageNo);
			}



		}
	}
</script>


<style lang="scss" scoped>
	.notHaveMoreData {

		line-height: 100rpx;
		text-align: center;
		font-size: 28rpx;
	}

	.pageList-box {
		position: relative;
		height: calc(100vh - 200rpx);
		// background-color: pink; //cxq-1

		.scroll-Y {
			height: 100%;

			.item {
				padding: 0 30rpx;
				box-sizing: border-box;
				margin-bottom: 38rpx;
			}
		}

	}
</style>
