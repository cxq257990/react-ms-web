<template>
	<view class="vNoContent">
		<view class="vNoContent-box">
			<view  class="title-box"><view class="title"> {{title}} </view>
			<slot name="right-icon"> </slot></view>
			
			<template v-if="List.length>0">
				<slot name="contentItems"> </slot>
			</template>
			<template v-else>
					<view class="txt">{{text}}</view>
					<view class="one-line"></view>
			</template>
		</view>
		
	</view>
</template>
<script>
	export default {
		props: {
			title: {
				type: String,
				default: ''
			},
			text: {

				type: String,

				default: '暂时没有相关的信息'

			},

			List: {
				type: Array,
				default: () => {
					return []
				}
			}
		},
		data() {
			return {
			}
		},


		methods: {

		}
	}
</script>


<style lang="scss" scoped>
	
	
	.one-line {
		height: 1rpx;
		width: 85%;
		margin: auto;
		background-color: $uni-border-color;
	}
	.title-box{
		display: flex;
		justify-content: space-between;
		line-height: 80rpx;
		padding:0 32rpx ;
		.title {
			color: $uni-color-active;
			font-size: $uni-font-size-15;
			font-weight: bold;
			
		}
		
		
	}

	.vNoContent{
	}
	.vNoContent-box {

		.txt {
			color: $uni-text-color-greyA;
			font-size: 26rpx;
			text-align: center;
			line-height: 70rpx;
		}
	}

</style>
