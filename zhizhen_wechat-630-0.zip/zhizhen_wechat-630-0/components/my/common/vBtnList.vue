<template>
	<view>
		
		
				<template v-if="pageType=='ask'">
					<view class=" btn-list btn-list-ask">
						<view class="btn">
							<view @click="onClickAsk(btnList[0])" class="iconfont icon-msg-pinglun"></view>
							<text class="txt">{{btnList[0].count}}</text>
						</view>
					</view>
			
				</template>
			
			<template v-if="pageType=='comment'">
				<view class="btn-list">
					<template v-for="item  in btnList">
						<view class="btn" :key="item.type" @click="onClick(item)">
							<template v-if="item.type=='forward'">
								<button class="share" :data-id="item.parentId" :data-obj="item.obj?item.obj:''"
									open-type="share">
									<view class="iconfont icon-i-zhuanfa" :class="item.iconclass"></view>
								</button>
							</template>
							<template v-if="item.type=='comment'">
								<view class="iconfont icon-msg-pinglun"></view>
							</template>
							<template v-if="item.type=='cai'">
								<view v-if="item.isCai" class="iconfont"
									:class="['','icon-xuanzhong','icon-msg-cai-xuanzhong']">
								</view>
								<view v-else class="iconfont" :class="['iconfont','icon-cai']"></view>
							</template>
							<template v-if="item.type=='like'">
								<view v-if="item.isLike" class="iconfont"
									:class="['iconfont','icon-xuanzhong','icon-msg-zan-xuanzhong']">
								</view>
								<view v-else class="iconfont" :class="['iconfont','icon-zan']"></view>
							</template>
							<text class="txt">{{item.count}}</text>
						</view>
					</template>
				</view>
			</template>
				
				
	
	</view>
</template>
<script>
	export default {
		props: {

			List: {
				type: Array,
				default: () => {


					return []
				}
			},
			pageType: {
				type: String,
				default: 'comment' //1评论，2为问员工
			},
			
		
			btnList: {
				type: Array,
				default: () => {
					return

					[{
							type: "forward",
							count: 11,
							parentId: 1,
							obj: item
						},
						{
							type: "comment",
							count: 99,
							parentId: 22
						},
						{
							type: "cai",
							count: 33,
							parentId: 33,
							isCai: true
						},
						{
							type: "like",
							count: 3,
							parentId: 3,
							isLike: true
						}
					]
				}




			},

		},

		data() {
			return {}
		},
		methods: {
			//-----点赞、评论---------
			onClickAsk(obj) {
				if (obj.type == "comment") {
					uni.navigateTo({
						url: `/pages/index/askDetails?id=${obj.parentId}`
					});
				}
			}

			,

			 onClick(obj) {

				var details = obj.obj
				if (obj.type == "comment") {
					uni.navigateTo({
						url: `/pages/index/commentDetails?id=${obj.parentId}`
					});
				}

				if (this.pageType == "comment") {
					if (obj.type !== "like" && obj.type !== "cai") {

						return
					}
					this.getCaiAndLike(obj)

				}

				if (this.pageType == "ask") {

					this.onLike(obj)
				}
			},
			
			// 	评论级别,1或者2或者3
			// 	操作类别，1为点赞  2为取消点赞，3为删除
			async onLike(obj) {

				var details = obj.obj
				console.log("onLike===:", details)
				if (obj.type !== "like") {

					return
				}
				let oper_type

				if (obj.type == "like") {

					oper_type = obj.isLike ? "1" : "2"
				}

				let data = {
					"parent_id": obj.parentId,
					"comment_type": "1",
					"oper_type": oper_type,
					"show_name": obj.myNickname ? obj.myNickname : '',
					"open_id": obj.myOpenId ? obj.myOpenId : ''
				}
				let res = await this.$http.postHasLoad('/zxxt/askEmploy/operComment', data);
				if (!res) {
					return
				}
				let datas = this.likeData(obj)
				this.$emit("onLike", datas)
			},


			async getCaiAndLike(obj) {
				
				var details = obj.obj

				// 评论级别,1或者2或者3
				// 操作类别，1为转发  2为点赞  3为取消点赞 4为点踩  5为取消点踩 6为删除
				// pageType

				let oper_type
			
				console.log("getCaiAndLike==nowDataCai=:",details)
				if (obj.type == "cai") {
					
					oper_type = !obj.isCai ? "4" : "5"
				}
				if (obj.type == "like") {
					oper_type = !obj.isLike ? "2" : "3"
				}

				let data = {
					"parent_id": obj.parentId,
					"comment_type": "1",
					"oper_type": oper_type,
					"show_name": obj.myNickname ? obj.myNickname : '',
					"open_id": obj.myOpenId ? obj.myOpenId : ''
				}

				let res = await this.$http.postHasLoad('/zxxt/careerEvalu/operComment', data);
				if (!res) {
					return
				}
				let datas
				if (obj.type == "cai") {
					datas = this.caiData(obj)
				}

				if (obj.type == "like") {
					datas = this.likeData(obj)
				}

				console.log("new-DATA", datas)
				this.$emit("onLikeAndCai", datas)

			},

			likeData(obj) {
				let data = JSON.parse(JSON.stringify(this.List))

				console.log("likeData==", obj, data)
				//data部分更新，不完全，需要的更新
				data.forEach(item => {


					var nowData = !obj.isLike
					var fabu_count = nowData ? Number(obj.count) + 1 : Number(obj.count) - 1
					var if_like = nowData ? 2 : 1;

					if (obj.parentId == item.id) {
				
						console.log("likeData=parentId=", obj.parentId )

						item.btnList.forEach(opt => {
							if (opt.type == "like") {
								opt.isLike = nowData;
								opt.count = fabu_count
							}
						})


					}

				})

				return data


			},

			caiData(obj) {
				let data = JSON.parse(JSON.stringify(this.List))
				data.forEach(item => {
					var nowData = !obj.isCai
					var tread_count = nowData ? Number(obj.count) + 1 : Number(obj.count) - 1
					var if_tread = nowData ? 2 : 1;
					if (obj.parentId == item.id) {
						item.btnList.forEach(opt => {
							if (opt.type == "cai") {
								opt.isCai = nowData;
								opt.count = tread_count

							}

						})

					}




				})
				return data
			}
		}
	}
</script>


<style lang="scss" scoped>
	.icon-xuanzhong {
		color: $uni-color-active;
	}

	.share {
		line-height: 1;
		background-color: #fff;
		border: none;

		display: flex;
		align-items: center;
	}

	.share::after {
		border: none;
	}

	.btn-list {
		border-top: 2rpx solid $uni-border-color;
		border-bottom: 2rpx solid $uni-border-color;
		height: 84rpx;
		margin-bottom: 38rpx;
		display: flex;
		align-items: center;

		padding-left: 40rpx;
		padding-right: 40rpx;
		justify-content: space-between;

		.btn {
			display: flex;
			align-items: center;

			.iconfont {
				// color: #444444;
				font-size: 38rpx;
				margin-right: 15rpx;
			}

			.txt {
				font-size: 24rpx;
				font-family: Microsoft YaHei;
				font-weight: 400;
				color: $uni-text-color-greyA;
			}
		}
	}


	.btn-list-ask {
		border-top: 2rpx solid #ffffff;
		border-bottom: 2rpx solid #ffffff;
	}
</style>
