<template>
	<view class="vMyCommentItem">


		<template v-if="noDetail==false">
			<view class="content " @tap='onDetails(obj)'>{{obj.commentContent}}</view>

		</template>
		<template v-if="noDetail==true">
			<view class="content">{{obj.commentContent}}</view>

		</template>

		<view class="time-box">
			<view v-if="obj.writers_name" class="writers_name" @tap="onWriteName(obj)">收到
				<text class="newCommentFriendName"> {{obj.writers_name=='**'?'':obj.writers_name}}
				</text>
				新评价
			</view>
			<view class="time ">{{obj.time}}</view>

		</view>

		<view v-if="hasOneLine" class="one-line"> </view>
	</view>
</template>
<script>
	export default {
		props: {
			noDetail: {
				type: Boolean,
				default: false
			},

			hasOneLine: {
				type: Boolean,
				required: false,
				// default: []
			},
			obj: {
				type: Object,
				default: () => {
					return {
						commentContent: "commentContentcommentContent",
						time: "timetime"
					}


				}
			},

		},
		methods: {
			// cxq-00
			checkJumpRelation(open_id, obj) {
				console.log('objobjobj=====', obj)
				if (obj && obj.in_phone && obj.in_outer_id) {
					console.log('objobjobj==2===', obj)
					this.$util.checkJumpRelation(open_id, obj.in_phone, obj.in_outer_id)
					return

				} else {
					if (obj && obj.in_phone) {

						this.$util.checkJumpRelation(open_id, obj.in_phone)
						return
					}
					if (obj && obj.in_outer_id) {

						this.$util.checkJumpRelation(open_id, '', obj.in_outer_id)
						return
					}

				}

				this.$util.checkJumpRelation(open_id)

			},
			onWriteName(obj) {
				if (obj.if_anonymity == 1) {
					return
				}
				this.$util.checkJumpRelation(obj.open_id)

			},
			onDetails(obj) {
				console.log('onDetails:', obj)
				if (this.noDetail) {
					return

				}
				switch (this.pageType) {
					case '--':
						break;
					default:
						uni.navigateTo({
							url: `/pages/index/commentDetails?id=${obj.dataDetails.id}`
						});
				}
			}


		}

	}
</script>

<style lang="scss" scoped>
	.time-box {
		display: flex;
		justify-content: space-between;
		align-items: center;

		.newCommentFriendName {
			color: $uni-color-active;
		}

		.writers_name {
			font-size: 24rpx;
			font-family: Microsoft YaHei;
			font-weight: 400;
			color: $uni-text-color-greyA;
			// background-color: pink;


		}
	}

	.one-line {
		// margin-top: 40rpx;
		width: 100%;
		height: 2rpx;
		background-color: $uni-border-color;
	}

	.content {

		font-size: 28rpx;
		font-family: Microsoft YaHei;
		font-weight: 400;
		line-height: 80rpx;
		padding-right: 60rpx;
		color: $uni-text-color;
	}

	.time {
		line-height: 60rpx;
		font-size: 24rpx;
		font-family: Microsoft YaHei;
		font-weight: 400;
		margin-bottom: 20rpx;
		color: $uni-text-color-greyA;


	}
</style>
