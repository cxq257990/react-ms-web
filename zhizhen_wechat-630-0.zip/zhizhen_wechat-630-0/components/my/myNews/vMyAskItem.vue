<template>
	<view class="vMyCommentItem">
		<view class="content " @tap='askDetails(obj)'>{{obj.commentContent}} </view>
	    <vImgList  :List="obj.imgArr" > </vImgList>
		<view class="time ">{{obj.time}}</view>
	</view>
</template>
<script>
	
	import vImgList from "components/my/common/vImgList.vue"
	export default {
		components: {
			vImgList
		},
		props: {
			
			obj: {
				type: Object,
				default: () => {
					return {
						content: "好评好评好评好评好评好评好评好评好评好 好评好评好评好评好评好评好评。",
						time: "21-04-05 12:02",
						imgArr: ["/static/img/anonymity.png","/static/img/anonymity.png"],
						
					}
				
					
				}
			}

		},
		
		data() {
			return {
				
			}
		},
		methods: {
			
			askDetails(obj) {
				console.log('askDetails:', obj)
				uni.navigateTo({
					url: `/pages/index/askDetails?id=${obj.dataDetails.id}`
				});
			},
		
		}

	}
</script>


<style lang="scss" scoped>
	.vMyCommentItem{
	}
	.content {
	
		font-size: 28rpx;
		font-family: Microsoft YaHei;
		font-weight: 400;
		line-height: 80rpx;
		padding-right: 60rpx;
		color: $uni-text-color;
	}
	
	.time{
		    line-height: 60rpx;
			font-size: 24rpx;
			font-family: Microsoft YaHei;
			font-weight: 400;
			color: $uni-text-color-greyA;
		
		
	}
	.img-container {
		width: 100%;
		padding-bottom: 20rpx;
		display: flex;
		flex-wrap: wrap;
	
		.img {
			margin-bottom: 10rpx;
		}
	}
	
	.one-img {
		align-items: flex-start;
	
		.img {
			max-width: 100%;
			max-height: 444rpx;
		}
	}
	
	.four-img {
		max-width: 80%;
	
		.img {
			width: 200rpx;
			height: 200rpx;
		}
	
		.img:nth-of-type(2n-1) {
			margin-right: 10rpx;
		}
	}
	
	.more-img {
		.img {
			width: 200rpx;
			height: 200rpx;
		}
	
		.img:nth-of-type(3n-1) {
			margin-left: 10rpx;
			margin-right: 10rpx;
		}
	}
	
</style>
