<template>
	<view class="" >
		<view class=" myComment-box" @tap="vMyPraiseItem(obj)">
			<view class="myComment">{{obj.answerText}}</view>
			<view class="myComment-title">
				<text class="title1">{{obj.user_name}}:</text>
				<text>{{obj.requestionText}}</text>
			</view>
		</view>
	</view>
</template>
<script>
	/**
	 * author        cxq
	 * time          2021-5-31 17:26:50
	 * description   
	 */
	export default {
		name: "vMyCommentItem",
		components: {
		},
		props: {
			
			// type: {
			// 	type: String,
			// 	default: "comment"   // 
			// },
			obj: {
				type: Object,
				default: () => {
					return {
						answerText: "answerTextanswerText",
						user_name: "namenamename",
						requestionText: "requestionText",
						time: "21-04-05 12:02",
						// imgArr: ["/static/img/anonymity.png"]

					}
				}

			}
		},
		data() {
			return {

			}
		},
		methods:{
			
			vMyPraiseItem(obj){
				
				
				if(obj.type=='comment'){
					this.onCommentDetails(obj)
				}
				
				if(obj.type=='ask'){
					this.askDetails(obj)
				}
			},
			onCommentDetails(obj) {
				console.log('onCommentDetails:', obj)
				uni.navigateTo({
					url: `/pages/index/commentDetails?id=${obj.dataDetails.id}`
				});
			},
			askDetails(obj) {
				console.log('askDetails:', obj)
				uni.navigateTo({
					url: `/pages/index/askDetails?id=${obj.dataDetails.id}`
				});
			},
		}
	}
</script>

<style lang="scss" scoped>
	.box-padding {
		padding: 32rpx;
	}

	.myComment-box {
		.myComment {
			font-size: 28rpx;
			margin-bottom: 40rpx;
			line-height: 40rpx;
			width: 686rpx;
		}

		.myComment-title {
			font-size: 24rpx;
			// width: 686rpx;
			padding: 32rpx;
			background-color: #f3f3f3;
			line-height: 40rpx;
			margin-bottom: 32rpx;

			.title1 {
				color: $uni-color-active;
			}
		}
	}

	.bottom {

		padding-bottom: 30rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;

		.time {
			font-size: 24rpx;
			font-family: Microsoft YaHei;
			font-weight: 400;
			color: $uni-text-color-greyA;
		}

		.btn {
			margin-right: 18rpx;
			display: flex;
			align-items: center;
			position: relative;

			.hot {
				position: absolute;
				top: 0;
				left: 0;
				z-index: 9;
				font-size: 20rpx;
			}

			.iconfont {
				color: #444444;
				font-size: 38rpx;
			}

			.txt {
				margin-left: 15rpx;
				font-size: 24rpx;
				font-family: Microsoft YaHei;
				font-weight: 400;
				color: $uni-text-color-greyA;
			}
		}
	}
</style>
