<template>
	<view class="vTotalScoreItem" >
		<view class="left">
			<view class="one">{{obj.total_score}}</view>
			<view class="two">综合评分</view>
		</view>
		<view class="right">
			<template v-for="(i,index) in obj.labels">
				<view :key="index" class="btn">
					{{i}}
				</view>
			</template>
		</view>
	</view>
</template>

<script>
	/**
	 * author        cxq
	 * time          2021-5-31 17:16:38
	 * description   
	 */
	export default {
		props: {
			obj: {
				type: Object,
				default: () => {
					return {
						labels: ["优秀可爱",'优秀可爱1'],
						total_score: "88"
					}
				}
			}
		},
		methods: {}
	}
</script>

<style lang="scss" scoped>
	.vTotalScoreItem {
		display: flex;
		min-height: 174rpx;
		background-color: $uni-bg-color-blueA;
		align-items: center;
		.left {
			min-width: 200rpx;
			min-height: 174rpx;
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;

			.one {
				font-size: $uni-font-size-30;
				margin-top:-20rpx;
				font-weight: 900;
			}

			.two {
				font-size: $uni-font-size-base;
				margin-top:10rpx;
				color: $uni-text-color-placeholder;
			}

		}

		.right {
			min-height: 174rpx;
			display: flex;
			margin-top: 30rpx;
			// background-color: pink;
			flex-wrap: wrap;

			.btn {
				background-color: $uni-bg-color-blueA;
				border-radius: 30rpx;
				min-width: 75rpx;
				line-height: 22rpx;
				padding: 20rpx;
				height: 25rpx;
				text-align: center;
				margin-right: 20rpx;
				margin-bottom: 20rpx;
				border: 2rpx solid $uni-text-color-placeholder;
				font-size: $uni-font-size-13;
				color: $uni-text-color-greenA;

			}
		}

	}
</style>
