<template>
	<view class="vWorkRecord">
		<view class="info">
			<template v-for=" (i,index) in info">
				<view class="item-box" :key="i.id">
					<view class="item">
						<view>
							<view class="date">{{i.startDate}} - {{i.endDate}}</view>
							<template v-if="isWork">
								<view>{{i.companyName}}</view>
								<view>{{i.jobName}}</view>
							</template>
							<template v-else>
								<view>{{i.schoolName}}</view>
								<view>{{i.education}} - {{i.major}}</view>
							</template>
						</view>

						<view v-if="isShowEdit" :data-info="i" @tap="jumpEdit" class="btn iconfont icon-s-bianji">
						</view>
					</view>
				</view>
			</template>
		</view>


	</view>
</template>

<script>
	/**
	 * author        cxq
	 * time          2021-5-28 14:52:57
	 * description   
	 */


	export default {
		name: '',
		props: {

			isShowEdit: {
				type: Boolean,
				default: true
			},
			info: {
				type: Array,
				required: true,
				// default: []
			},
			isWork: {
				type: Boolean,
				default: true
			}
		},
		// 数字有默认值
		data() {
			return {

			}
		},
		onLoad() {

		},


		methods: {

			jumpEdit(e) {
				console.log("----id---", e.currentTarget.dataset.info)
				this.$emit("jumpEdit", e.currentTarget.dataset.info.id)
			}
		}
	}
</script>

<style>
	.vWorkRecord .item-box {
		margin-bottom: 40rpx;

	}

	.item-box:last-of-type {
		margin-bottom: 0;
	}
</style>
<style lang="scss" scoped>
	.btn {

		width: 30rpx;
		height: 30rpx;
		color: $uni-color-active;
	}

	.deep-title /deep/ .van-cell__title {
		color: $uni-color-active;
		font-size: $uni-font-size-15;
		font-weight: bold;
	}

	.info {
		padding-left: 32rpx;
		padding-right: 32rpx;
		line-height: 60rpx;

		.date {
			color: $uni-text-color-greyA;
			font-size: $uni-font-size-base;
		}

		.item {
			display: flex;
			justify-content: space-between;
			padding-bottom: 40rpx;
			border-bottom: 2rpx solid $uni-border-color;



		}

		// .one-line {
		// 	height: 4rpx;
		// 	// width: 90%;
		// 	// background-color: $uni-line-color-grayA;
		// 	margin: auto;
		// }

	}
</style>
