import http from './http'
let util = {
	toast: (data, time, callback) => {
		uni.showToast({
			title: data ? data : '',
			icon: 'none',
			duration: time ? time : 2000,
			success: function(res) {
				if (callback) {
					let timeoutName = setTimeout(function() {
						clearTimeout(timeoutName);
						callback();
					}, (time ? time : 2000))
				}
			}
		});
	},
	toastSuccess: (data, time, callback) => {
		uni.showToast({
			title: data ? data : '',
			icon: "success",
			duration: time ? time : 2000,
			success: function(res) {
				if (callback) {
					let timeoutName = setTimeout(function() {
						clearTimeout(timeoutName);
						callback();
					}, (time ? time : 2000))
				}
			}
		});
	},
	// toastFail: (data, callback) => {
	// 	uni.showToast({
	// 		title: data ? data : '',
	// 		icon: "success",
	// 		success: function(res) {
	// 			if (callback) {
	// 				let timeoutName = setTimeout(function() {
	// 					clearTimeout(timeoutName);
	// 					callback();
	// 				}, 1500)
	// 			}
	// 		}
	// 	});
	// },
	guid: () => {
		function S4() {
			return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
		}
		return (S4() + S4() + "-" + S4() + "-" + S4() + "-" + S4() + "-" + S4() + S4() + S4());
	},
	timeMatch: (time, serverTime) => {
		if (!time) {
			return ''
		}
		if (time.split(' ')[0] == serverTime.split(' ')[0]) {
			return time.substr(11, 5);
		} else {
			return time.split(' ')[0]
		}
	},


	// ===========================时间处理===================================
	// server_time: "06-25 15:07:34"
	timeMatch2: (time, serverTime) => {
		if (!time) {
			return ''
		}
		if (time.split(' ')[0] == serverTime.split(' ')[0]) {
			return time.substr(6, 5);
		} else {
			return time.split(' ')[0]
		}
	},
	formatNumber: (n) => {
		n = n.toString()
		return n[1] ? n : '0' + n
	},
	// 今天时间  xxxx-xx
	todayTime: () => {
		var todayTime = new Date()
		todayTime.setTime(todayTime.getTime())
		var month = todayTime.getMonth() + 1
		var month2 = month.toString()
		var month3 = month2[1] ? month2 : '0' + month2

		var data = todayTime.getFullYear() + "-" + month3
		return data
	},
	// 是不是本周
	isNowWeek: (time, serverTime) => {
		// let time="06-25 15:07:34"
		// let serverTime="07-01 15:07:34"
		if (!time) {
			return ''
		}
		if (time.split(' ')[0] == serverTime.split(' ')[0]) {
			return true
		} else {
			return false
		}

	},
	//时间字符串截取-当天显示时分-非当天显示月日
	//服务端未有返回服务端当前时间时，暂时使用
	formatDateIsToday: (date) => {
		// var date='06-10 17:20:30'
		var now = new Date()
		// const year = (now.getFullYear()).toString()
		const month = (now.getMonth() + 1).toString()
		const day = (now.getDate()).toString()
		// let y = year[1] ? year : '0' + year
		let m = month[1] ? month : '0' + month
		let d = day[1] ? day : '0' + day
		let nowStr = [m, d].join('-')

		console.log(nowStr, date.substring(0, 5))
		if (date.substring(0, 5) === nowStr) {

			return date.substring(6, 11)

		}
		return date.substring(0, 5)
	},
	// 时间处理
	formatTime: (date) => {
		var date = new Date(date)
		const year = date.getFullYear()
		const month = date.getMonth() + 1
		const day = date.getDate()
		const hour = date.getHours()
		const minute = date.getMinutes()
		const second = date.getSeconds()

		const formatNumber = n => {
			n = n.toString()
			return n[1] ? n : '0' + n
		}

		return [year, month, day].map(formatNumber).join('-') + ' ' + [hour, minute, second].map(formatNumber)
			.join(':')
	},
	checkIslogin: (fn) => {
		if (!!uni.getStorageSync('userPhone')) {
			fn();
		} else {
			uni.navigateTo({
				url: '/pages/login/login'
			});
		}
	},
	async checkJumpRelation(openId = '', mobileNum = '', outerId = '') {
		console.log("checkJumpRelation:", `openId:${openId},mobileNum:${mobileNum},outerId:${outerId}`)
		// openId 被查看人的
		// mobileNum 被查看人的手机号
		// outerId 被查看人的（数据库Id）
		if (!!openId) {
			if (openId == uni.getStorageSync('loginInfoObj').open_id) {
				// util.toast("不能点击自己")
				uni.navigateTo({
					url: '/pages/my/myInfo/myArchives'
				});
			} else {
				let data = {
					open_id1: uni.getStorageSync('loginInfoObj').open_id,
					open_id2: openId
				}
				let res = await http.getNoLoad("/zxxt/askEmploy/lookFriendShop", data);
				if (res.data.relation == "1") {
					uni.navigateTo({
						url: `/pages/multiEntry/information?openId=${openId}`
					});
				} else {
					// 手机号/openid 必有一个；
					uni.navigateTo({
						url: `/pages/multiEntry/guessYoudo?outerid=''&phone=${res.data.phone}&hisopenid=${openId}`
					});
				}
			}
		} else {
			uni.navigateTo({
				url: `/pages/multiEntry/guessYoudo?phone=${mobileNum}&outerid=${outerId}`
			});
		}

	},
	//搜索高亮
	brightenKeyword: (val, keyword) => {
		if (keyword.length > 0) {
			val = val + "";
			val = val.replace(
				new RegExp(keyword, 'g'),
				'<span style="color:#F64135">' + keyword + '</span>'
			);
			return val;
		} else {
			return val;
		}
	},
	nameTransform: (type, orgOpenid, orgRoletype, currentOpenid, currentRoletype, currentName) => {
		// console.log("nameTransform:", {
		// 	type,
		// 	orgOpenid,
		// 	orgRoletype,
		// 	currentOpenid,
		// 	currentRoletype,
		// 	currentName
		// })
		// 职评圈：
		// 访客评价：访客回复显示访客；实名回复显示实名；公司回复显示公司；
		// 实名评价： 访客回复显示访客；实名、公司回复显示楼主；

		// 问员工
		// 访客提问：访客回复显示访客；实名回复显示实名；公司回复显示公司；
		// 实名、公司提问： 访客回复显示访客；实名、公司回复显示楼主；

		if (orgOpenid != currentOpenid) {
			if (currentRoletype == '2') {
				return "访客"
			}
			return currentName;
		} else {
			if (type == 'comment') {
				if (orgRoletype == "1") {
					if (currentRoletype == "2") {
						return "访客"
					}
					return currentName
				} else if (currentRoletype == "2") {
					return "访客"
				}
				return "楼主";
			} else {
				if (orgRoletype == "2") {
					if (currentRoletype == "2") {
						return "访客"
					}
					return currentName
				} else if (currentRoletype == "2") {
					return "访客"
				}
				return "楼主";
			}

		}

	}

};


export default util;
