// let baseUrl = "https://platform.xuanyu.com.cn"; //正式
// let baseUrl= "https://test.platform.xuanyu.com.cn";//阿里云测试
// let baseUrl="http://10.200.150.212:8005";//高健本地
let baseUrl="http://10.190.233.60:8805";//测试
//let baseUrl="http://10.200.147.137:8005" //孟世翔
 // let wssUrl = "wss://platform.xuanyu.com.cn"; //正式
let wssUrl = "wss://test.platform.xuanyu.com.cn";//阿里云
// let wssUrl = "ws://10.200.147.174:8005";//本地


export {
	baseUrl,
	wssUrl
}
