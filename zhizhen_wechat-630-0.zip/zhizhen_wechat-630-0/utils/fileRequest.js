import { baseUrl } from "./config.js";

let uploadFile = function(url, fileUrl) {
	return new Promise((resolve, reject) => {
		uni.uploadFile({
			url: baseUrl + url,
			filePath: fileUrl,
			name: 'file',
			success: (res) => {
				//console.log("uploadFile:", res)
				if (JSON.parse(res.data).code == "success") {
					resolve({
						type: 'ok',
						url: JSON.parse(res.data).data[0]
					})
				} else {
					//console.log("11111----")
					uni.showToast({
						title: JSON.parse(res.data).message,
						icon: 'none',
						duration: 3000
					})
					reject({
						type: "err",
						url: JSON.parse(res.data).message,
					})
				}
			},
			fail: (err) => {
				//console.log("-----fail-----")
				uni.showToast({
					title: err.message,
					icon: 'none',
					duration: 3000
				})
				reject({
					type: "err",
					url: err
				})
			}
		});
	})


}
export {
	uploadFile
}
