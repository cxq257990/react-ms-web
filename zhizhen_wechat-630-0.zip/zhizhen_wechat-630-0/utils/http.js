import {
	baseUrl
} from "./config.js";

let http = function(url, data, method, showLoad) {
	let arr = ["/zxxt/careerEvalu/getCareEvalList", "/zxxt/askEmploy/getAskEmployList",
		"/zxxt/askEmploy/lookSubComment", "/zxxt/careerEvalu/lookSubComment", "/zxxt/wechat/code2Session",
		"/zxxt/askEmploy/lookRoles", "/zxxt/wechat/updateInfo", "/zxxt/wechat/updateInfo",
		"/zxxt/wechat/getPhone"
	]
	if (!uni.getStorageSync('userPhone') && arr.indexOf(url) == -1) {
		//首页（职评圈、问员工、详情）、app.vue、login页 不需要去授权，其他必须授权
		uni.navigateTo({
			url: '/pages/login/login'
		});
		return;
	}


	let requestTask = null;
	let header = {}
	if (showLoad) {
		uni.showLoading({
			title: '加载中'
		});
	}
	return new Promise((resolve, reject) => {
		requestTask = uni.request({
			url: baseUrl + url,
			data: data,
			header: header,
			method: method,
			success: (res) => {
				if (showLoad) {
					uni.hideLoading();
				}
				//console.log('success:',res)
				if (res.data.code == "success") {
					resolve(res.data)
				} else {
					uni.showToast({
						title: res.data.message,
						icon: 'none',
						duration: 3000
					})
				}
			},
			fail: (err) => {
				if (showLoad) {
					uni.hideLoading();
				}
				//console.log('err:',err)
				uni.showToast({
					title: err.message,
					icon: 'none',
					duration: 3000
				})
			},
			complete: () => {}
		});
	})
	//requestTask.abort();
}

const getHasLoad = (url, data) => {
	return new Promise((resolve, reject) => {
		resolve(http(url, data, "GET", true))
	})
}
const getNoLoad = (url, data) => {
	return new Promise((resolve, reject) => {
		resolve(http(url, data, "GET", false))
	})
}
const postHasLoad = (url, data) => {
	return new Promise((resolve, reject) => {
		resolve(http(url, data, "POST", true))
	})
}
const postNoLoad = (url, data) => {
	return new Promise((resolve, reject) => {
		resolve(http(url, data, "POST", false))
	})
}





export default {
	getHasLoad,
	getNoLoad,
	postHasLoad,
	postNoLoad,
	http
};
