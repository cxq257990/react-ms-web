const date = new Date()
const formatNumber = n => {
  n = n.toString()
  return n[1] ? n : '0' + n
}
const nowYear = date.getFullYear()
const nowMonth = formatNumber(date.getMonth() + 1)
const nowDay = formatNumber(date.getDate())
// 每月的天数

let daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

// 根据年月 获取当月的总天数
function getDays(year, month) {
  if (month == 2) {
    return ((year % 4 === 0) && ((year % 100) !== 0)) || (year % 400 === 0) ? 29 : 28
  } else {
    return daysInMonth[month - 1]
  }
}

// 根据年月日设置当前月有多少天 并更新年月日数组
function setDate(quick, year, month, day, that) {
  let daysNum = getDays(year, month)
  month = month ? month : 1
  day = day ? day : 1
  let monthsNum = 12
  let years = quick ? ['至今'] : []
  let months = []
  let days = []
  let yearIdx = 0
  let monthIdx = 0
  let dayIdx = 0
  // 重新设置年份列表
  if (quick){
    for (let i = nowYear; i >= 1900; i--) {
      years.push(i)
    }
  } else {
    for (let i = nowYear + 10; i >= 1900; i--) {
      years.push(i)
    }
  }
  years.map((v, idx) => {
    if (v === year) {
      yearIdx = idx
    }
  })
  // 重新设置月份列表
  for (let i = 1; i <= monthsNum; i++) {
    months.push(formatNumber(i))
  }
  months.map((v, idx) => {
    if (v === month) {
      monthIdx = idx
    }
  })
  // 重新设置日期列表
  for (let i = 1; i <= daysNum; i++) {
    days.push(formatNumber(i))
  }
  days.map((v, idx) => {
    if (v === day) {
      dayIdx = idx
    }
  })
  

     that.years=years//年份列表
     that.months=months//月份列表
     that.days=months//日期列表
     that.year=year
     that.month=formatNumber(month)
     that.day=formatNumber(day)

  // 年月日数组有数据后，重新再设置一下vualue才能跳转到对应位置
  that.value= [yearIdx, monthIdx, dayIdx]
}

 export {
		 nowYear,
		 nowMonth,
		 nowDay,setDate
	 }