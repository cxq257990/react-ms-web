import Vue from 'vue'
import App from './App'
import './static/iconfont/iconfont.css'
import store from './store/store'
import http from './utils/http'
import util from './utils/util'
import config from './utils/config'
import defaultHeadimg from "./static/img/anonymity.png"

Vue.config.productionTip = false
App.mpType = 'app'
Vue.prototype.$store = store  
Vue.prototype.$http = http  
Vue.prototype.$util = util  
Vue.prototype.$config = config 
Vue.prototype.$defaultHeadimg = defaultHeadimg  
 


const app = new Vue({
	store,
    ...App
})
app.$mount()
