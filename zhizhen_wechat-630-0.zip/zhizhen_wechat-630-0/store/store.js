import Vue from 'vue'
import Vuex from 'vuex'
import modeleA from "./module/moduleA.js"

Vue.use(Vuex)


const store = new Vuex.Store({
	strict: true,
	state: {
		userInfoObj: uni.getStorageSync('userInfoObj') ? uni.getStorageSync('userInfoObj') : {},
		loginInfoObj: uni.getStorageSync('loginInfoObj') ? uni.getStorageSync('loginInfoObj') : {},
		userPhone: uni.getStorageSync('userPhone') ? uni.getStorageSync('userPhone') : "",
		roleArr: uni.getStorageSync('roleArr') ? uni.getStorageSync('roleArr') : [],
		userBaseInfo: uni.getStorageSync('userBaseInfo') ? uni.getStorageSync('userBaseInfo') : [],
		evaluateDetail: {}, //评价对象详情
		hasSendAsk: false //发表新的问员工
	},
	getters: {

	},
	mutations: {
		submitUsrInfo(state, val) {
			state.userInfoObj = val;
			try {
				uni.setStorageSync('userInfoObj', val);
			} catch (e) {}
		},
		submitLoginInfo(state, val) {
			state.loginInfoObj = val;
			try {
				uni.setStorageSync('loginInfoObj', val);
			} catch (e) {}
		},
		submitUserBaseInfo(state, val) {
			state.userBaseInfo = val;
			try {
				uni.setStorageSync('userBaseInfo', val);
			} catch (e) {}
		},

		submitUserPhone(state, val) {
			state.userPhone = val;
			try {
				uni.setStorageSync('userPhone', val);
			} catch (e) {}
		},
		submitRole(state, val) {
			val.map(item => {

			})
			state.roleArr = val;
			try {
				uni.setStorageSync('roleArr', val);
			} catch (e) {}
		},
		submitvaluateDetail(state, val) {
			state.evaluateDetail = val || {};
		},
		submitSendAsk(state, bool) {
			state.hasSendAsk = bool
		}
	},

	actions: {
		// lazy loading openid
		getUserOpenId: async function({
			commit,
			state
		}) {
			return await new Promise((resolve, reject) => {

			})
		}
	},
	modules: {
		a: modeleA
	}
})

export default store
