## 指针小程序 2 期

UI --> https://org.modao.cc/app/5xypbcl4hq3pvfnq9pmcu3gyat9mawe2?simulator_type=device&sticky#screen=skkuuuitcnckkjn

## 指针小程序 3 期

1. 指真 3.0 产品的原型设计链接地址为：https://modao.cc/app/cbfda0afd8952c8d05c8401cd401fe3ed452838d?simulator_type=device&sticky
2. 指真 3.0 产品的 UI 设计链接地址为:https://lanhuapp.com/url/GH5LV-r2ORt

## 结构说明

说明---
components ------- 组件
|---common : 公用组件
|---index : 首页组件
|---my : 个人中心组件

pages ----------- 主包
|-- index : 首页模块
|-- multiEntry : 多入口页面

static ----------
|---iconfont : 图标字体
|---img : 图片

store ----------- vuex

utils ----------- 工具函数

wxcomponents ---- vant: 插件

pages.json ------ 路由

pages ---------my  
myRecord -------
|---eduDetail : 教育履历详情
|---eduList : 教育履历列表
|---evaluatedetail : 工作履历详情
|---exerciseList : 工作履历列表

myRecommendLetter
|-- recommendLetterList : 推荐信列表
|-- recommendLetterDetail : 推荐信详情

myPage ----------
|---helpCenter : 帮助中心
|---privacyPolicy :隐私政策
|---userAgreement : 用户协议
myNews ----------
|---myCommentAndLike : 我的点赞
|---myNewsIndex : 我的动态入口
|---myRelease : 我的发布
myInfo ----------
|---lookAtMe : 谁看过我
|---myArchives : 我的档案
|---myBaseInfo : 基础信息
