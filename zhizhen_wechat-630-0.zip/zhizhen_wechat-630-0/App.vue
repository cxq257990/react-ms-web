<script>
	export default {
		onLaunch:  function() {
		
			console.log('App Launch')
			// 登录
			uni.login({
				success: async res => {
					let params = {
						code: res.code
					}
					let res2 = await this.$http.getHasLoad('/zxxt/wechat/code2Session', params);
					this.$store.commit('submitLoginInfo', {
						open_id: res2.data.open_id,
						session_key: res2.data.session_key,
						id: res2.data.id,
						issue_id: res2.data.issue_id,
						user_name: res2.data.user_name
					})
					let data = {
						open_id: res2.data.open_id
					}
					let roleRes = await this.$http.getNoLoad("/zxxt/askEmploy/lookRoles", data);
					if (roleRes) {
						this.$store.commit("submitRole", roleRes.data.roleMap);
					}
				}
			})
		},
		onShow: async function() {
			console.log('App Show')
			// bar未读消息
			if (!uni.getStorageSync('userPhone')) {
				return 
			}
			let params = {
				openId: uni.getStorageSync('loginInfoObj').open_id
			}
			let res3 = await this.$http.getNoLoad('/zxxt/user/getNoRead', params);
			
			if (res3 && res3.data) {
			// if (1) {
				let text3 = res3.data + ''
				uni.setTabBarBadge({
					index: 3,
					text:text3
				})
			} else {
				uni.removeTabBarBadge({
					index: 3
				})
			}
			
			let res = await this.$http.getNoLoad('/zxxt/msg/count', params);
			if (res.data) {
				let text = res.data + ''
				uni.setTabBarBadge({
					index: 2,
					text
				})
			} else {
				uni.removeTabBarBadge({
					index: 2
				})
			}
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style lang="scss">
	/*每个页面公共css */
	@import "/wxcomponents/vant-weapp/common/index.wxss";

	.van-action-sheet__item {
		border-bottom: 2rpx solid $uni-border-color;
		width: calc(100% - 100rpx);
		margin: 0 50rpx;
	}
</style>
