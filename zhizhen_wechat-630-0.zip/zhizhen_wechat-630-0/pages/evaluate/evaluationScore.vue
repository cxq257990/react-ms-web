<template>
	<view>
		<template v-if="allEvaluate == true">
			<view class="thispage">
				<image class="successimage" src="/static/img/fillin-success.svg"></image>
				<view class="succes">您已完成评价</view>
				<view class="thanks">感谢您的评价</view>
				<view class="tonext2" v-if="source == 2" bindtap="upInfo">即将进入指真小程序~</view>
			</view>
		</template>
		<template v-else>
			<view class="head">
				<image src="../../static/img/mine_bg.svg" class="base_bg"></image>
				<view class="card-info">
					<image class="headimg" :src="avatar ? avatar : '../../static/img/anonymity.png'"></image>
					<view class="info">
						<view class="name">{{username}}</view>
						<view class="company">
							<template v-if="company">{{company}}</template>
							<template v-if="positionname"> - {{positionname}}</template>
						</view>
					</view>
					<view class='canvasBox'>
						<view class='bigCircle'></view>
						<view class='littleCircle'></view>
						<canvas canvas-id="runCanvas" id="runCanvas" class='canvas'></canvas>
						<view class="new-grade">
							<view class="grade-score">{{compositeScore}}</view>
							<view class="grade-tag">综合印象</view>
						</view>
					</view>
					<cover-view class="mask-fff"
						style="height:36px;width:54%;border-top-left-radius:100%;border-top-right-radius:100%;">
					</cover-view>
				</view>
			</view>
			<view class="main">
				<view class="colleague">
					<view class="evaluate-slider">
						<!-- 同学显示 -->
						<view class="evaluate-slider-title" v-if="state == 1">组织能力</view>
						<!-- 同事显示 -->
						<view class="evaluate-slider-title" v-if="state == 0">综合能力</view>
						<!-- 同学和同事外的其他显示情况 -->
						<view class="evaluate-slider-title" v-if="state != 0 && state != 1">综合评价</view>
						<view class="evaluate-slider-main">
							<slider @change="sliderOverall" @changing="sliderOverallChanging" data-flag="sliderOverall"
								block-size="sliderOverallBlockSize" activeColor="#169171" block-color="#169171"
								class="progress-self">
								<view class="zhanwei-view"></view>
								<view class="zhanwei-bgc-view" :style="widthValue1"></view>
							</slider>
							<view class="progress-kedu progress-kedu60">
								<view class="kedu-dian"></view>
								<view class="kedu-xian"></view>
								<view class="kedu-num">60</view>
							</view>
							<view class="progress-kedu progress-kedu70">
								<view class="kedu-dian"></view>
								<view class="kedu-xian"></view>
								<view class="kedu-num">70</view>
							</view>
							<view class="progress-kedu progress-kedu80">
								<view class="kedu-dian"></view>
								<view class="kedu-xian"></view>
								<view class="kedu-num">80</view>
							</view>
							<view class="progress-kedu progress-kedu90">
								<view class="kedu-dian"></view>
								<view class="kedu-xian"></view>
								<view class="kedu-num">90</view>
							</view>
							<view class="evaluate-sum ">{{scoreOverall}}</view>
						</view>
					</view>
					<view class="evaluate-slider">
						<view class="evaluate-slider-title">学习能力</view>
						<view class="evaluate-slider-main">
							<slider @change="sliderStudy" @changing="sliderOverallChanging" data-flag="sliderStudy"
								block-size="sliderStudyBlockSize" activeColor="#169171" block-color="#169171"
								class="progress-self">
								<view class="zhanwei-view"></view>
								<view class="zhanwei-bgc-view" :style="widthValue2"></view>
							</slider>
							<view class="progress-kedu progress-kedu60">
								<view class="kedu-dian"></view>
								<view class="kedu-xian"></view>
								<view class="kedu-num">60</view>
							</view>
							<view class="progress-kedu progress-kedu70">
								<view class="kedu-dian"></view>
								<view class="kedu-xian"></view>
								<view class="kedu-num">70</view>
							</view>
							<view class="progress-kedu progress-kedu80">
								<view class="kedu-dian"></view>
								<view class="kedu-xian"></view>
								<view class="kedu-num">80</view>
							</view>
							<view class="progress-kedu progress-kedu90">
								<view class="kedu-dian"></view>
								<view class="kedu-xian"></view>
								<view class="kedu-num">90</view>
							</view>
							<view class="evaluate-sum evaluate-sum1">{{scoreStudy}}</view>
						</view>
					</view>
					<view class="evaluate-slider" v-if="state != 0">
						<view class="evaluate-slider-title">人品三观</view>
						<view class="evaluate-slider-main">
							<slider @change="sliderCharacter" @changing="sliderOverallChanging"
								data-flag="sliderCharacter" block-size="sliderCharacterBlockSize" activeColor="#169171"
								block-color="#169171" class="progress-self">
								<view class="zhanwei-view"></view>
								<view class="zhanwei-bgc-view" :style="widthValue3"></view>
							</slider>
							<view class="progress-kedu progress-kedu60">
								<view class="kedu-dian"></view>
								<view class="kedu-xian"></view>
								<view class="kedu-num">60</view>
							</view>
							<view class="progress-kedu progress-kedu70">
								<view class="kedu-dian"></view>
								<view class="kedu-xian"></view>
								<view class="kedu-num">70</view>
							</view>
							<view class="progress-kedu progress-kedu80">
								<view class="kedu-dian"></view>
								<view class="kedu-xian"></view>
								<view class="kedu-num">80</view>
							</view>
							<view class="progress-kedu progress-kedu90">
								<view class="kedu-dian"></view>
								<view class="kedu-xian"></view>
								<view class="kedu-num">90</view>
							</view>
							<view class="evaluate-sum evaluate-sum1">{{scoreCharacter}}</view>
						</view>
					</view>
					<view class="evaluate-slider" v-if="state == 1 || state == 6">
						<view class="evaluate-slider-title">行为担当</view>
						<view class="evaluate-slider-main">
							<slider @change="sliderSex" @changing="sliderOverallChanging" data-flag="sliderSex"
								block-size="sliderSexBlockSize" activeColor="#169171" block-color="#169171"
								class="progress-self">
								<view class="zhanwei-view"></view>
								<view class="zhanwei-bgc-view" :style="widthValue4"></view>
							</slider>
							<view class="progress-kedu progress-kedu60">
								<view class="kedu-dian"></view>
								<view class="kedu-xian"></view>
								<view class="kedu-num">60</view>
							</view>
							<view class="progress-kedu progress-kedu70">
								<view class="kedu-dian"></view>
								<view class="kedu-xian"></view>
								<view class="kedu-num">70</view>
							</view>
							<view class="progress-kedu progress-kedu80">
								<view class="kedu-dian"></view>
								<view class="kedu-xian"></view>
								<view class="kedu-num">80</view>
							</view>
							<view class="progress-kedu progress-kedu90">
								<view class="kedu-dian"></view>
								<view class="kedu-xian"></view>
								<view class="kedu-num">90</view>
							</view>
							<view class="evaluate-sum evaluate-sum1">{{scoreSex}}</view>
						</view>
					</view>
					<view class="evaluate-slider" v-if="state == 0 || state == 5 || state == 6">
						<view class="evaluate-slider-title" v-if="state == 0">工作能力</view>
						<view class="evaluate-slider-title" v-else>职业技能</view>
						<view class="evaluate-slider-main">
							<slider @change="sliderProfession" @changing="sliderOverallChanging"
								data-flag="sliderProfession" block-size="sliderProfessionBlockSize"
								activeColor="#169171" block-color="#169171" class="progress-self">
								<view class="zhanwei-view"></view>
								<view class="zhanwei-bgc-view" :style="widthValue5"></view>
							</slider>
							<view class="progress-kedu progress-kedu60">
								<view class="kedu-dian"></view>
								<view class="kedu-xian"></view>
								<view class="kedu-num">60</view>
							</view>
							<view class="progress-kedu progress-kedu70">
								<view class="kedu-dian"></view>
								<view class="kedu-xian"></view>
								<view class="kedu-num">70</view>
							</view>
							<view class="progress-kedu progress-kedu80">
								<view class="kedu-dian"></view>
								<view class="kedu-xian"></view>
								<view class="kedu-num">80</view>
							</view>
							<view class="progress-kedu progress-kedu90">
								<view class="kedu-dian"></view>
								<view class="kedu-xian"></view>
								<view class="kedu-num">90</view>
							</view>
							<view class="evaluate-sum evaluate-sum1">{{scoreProfession}}</view>
						</view>
					</view>
					<view class="evaluate-slider" v-if="state == 0 || state == 5 || state == 6">
						<view class="evaluate-slider-title" v-if="state == 0">协作能力</view>
						<view class="evaluate-slider-title" v-else>专业技能</view>
						<view class="evaluate-slider-main">
							<slider @change="sliderMajor" @changing="sliderOverallChanging" data-flag="sliderMajor"
								block-size="sliderMajorBlockSize" activeColor="#169171" block-color="#169171"
								class="progress-self">
								<view class="zhanwei-view"></view>
								<view class="zhanwei-bgc-view" :style="widthValue6"></view>
							</slider>
							<view class="progress-kedu progress-kedu60">
								<view class="kedu-dian"></view>
								<view class="kedu-xian"></view>
								<view class="kedu-num">60</view>
							</view>
							<view class="progress-kedu progress-kedu70">
								<view class="kedu-dian"></view>
								<view class="kedu-xian"></view>
								<view class="kedu-num">70</view>
							</view>
							<view class="progress-kedu progress-kedu80">
								<view class="kedu-dian"></view>
								<view class="kedu-xian"></view>
								<view class="kedu-num">80</view>
							</view>
							<view class="progress-kedu progress-kedu90">
								<view class="kedu-dian"></view>
								<view class="kedu-xian"></view>
								<view class="kedu-num">90</view>
							</view>
							<view class="evaluate-sum evaluate-sum1">{{scoreMajor}}</view>
						</view>
					</view>
				</view>
			</view>

			<view class="tonext" @tap="toImpression">下一步</view>
		</template>
	</view>

</template>

<script>
	/**
	 * 评价分数
	 */
	import Canvas from '../../utils/canvas.js'
	export default {
		...Canvas.options,
		data() {
			return {
				...Canvas.data,
				hisopenid: '', //邀请人openid
				state: '', //关系类别 0同事，1同学，2战友，3亲属，4群聊，5同行，6其他',
				id: '', //..

				avatar: '', //头像
				username: '', //姓名
				company: '', //公司名
				positionname: '', //职位名
				commonid: '', //共事id
				textevaluate: '', //综合评价内容

				allEvaluate: false, //是否已经评价完成

				compositeScore: 0, //综合评分
				scoreOverall: 0, //综合评价
				scoreSex: 0, //异性缘
				scoreProfession: 0, //职业技能
				scoreMajor: 0, //专业技能
				scoreStudy: 0, //学习能力
				scoreCharacter: 0, //人品指数
				// 新增字段start
				sliderOverallBlockSize: '20',
				sliderStudyBlockSize: '20',
				sliderCharacterBlockSize: '20',
				sliderSexBlockSize: '20',
				sliderProfessionBlockSize: '20',
				sliderMajorBlockSize: '20',
				widthValue1: 'width:0;',
				widthValue2: 'width:0;',
				widthValue3: 'width:0;',
				widthValue4: 'width:0;',
				widthValue5: 'width:0;',
				widthValue6: 'width:0;',
				// 新增字段end
				first: false, //
				logEvaluate: 1, //2一键点评 1正常邀请点评

				source: 2, //来源 1一键点评  2卡片进入点评
				hisphone: '',
				outerid: '', //
			}
		},
		onLoad(options) {
			console.log("-----pingfen-----:",options)
			this.outerid = options.outerid ? options.outerid : ''
			this.username = options.username ? options.username : ''
			this.hisopenid = options.openid ? options.openid : '' //被评价人员的openid
			this.hisphone = options.hisphone ? options.hisphone : ''
			if (options.logEvaluate) {
				this.logEvaluate = options.logEvaluate
			}
			this.state = options.states //与被评价人员关系    0同事，1同学，2战友，3亲属，4群聊，5同行，6其他',
			this.commonid = options.commonid ? options.commonid : 0 //共事单位或学校，来源是一键点评
			this.textevaluate = options.textevaluate ? options.textevaluate : '' //综合评价，来源是一键点评
			this.source = options.textevaluate ? 1 : 2 //来源 1一键点评  2卡片进入点评
			let source = options.textevaluate ? 1 : 2 //来源 1一键点评  2卡片进入点评
			// let info = uni.getStorageSync("userInfoObj")
			// let hasphone = uni.getStorageSync("userPhoneObj")
			// if (info || hasphone) { //先校验登录
			let openid = uni.getStorageSync("loginInfoObj").open_id //提交人openid
			if (this.hisopenid == openid) { //自己不能评价自己 提示
				setTimeout(() => {
					uni.showToast({
						icon: 'error',
						title: '不能评价自己噢！',
					});
					setTimeout(() => {
						uni.hideToast();
						uni.switchTab({
							url: '/pages/contacts/contacts'
						});
					}, 2000)
				}, 0);
			} else {
				Canvas.options.draw('runCanvas', 70, 1000);
				// if (source == 2) {//来源 1一键点评  2卡片进入点评
				// 	this.ifEvaluate()
				// }
				this.getInfo()
			}
			// } else {
			// 	this.first = true
			// 	//无信息跳转登录
			// 	uni.navigateTo({
			// 		url: '/pages/login/login'
			// 	});
			// }
		},
		onShow() {
			if (this.first == true) {
				// Canvas.options.draw('runCanvas', 70, 1000);
				// this.ifEvaluate()
				this.getInfo()
			}
		},
		methods: {
			// 评价完成，返回人脉页
			upInfo() {
				uni.switchTab({
					url: '/pages/contacts/contacts',
				})
			},

			// 下一步，去选择印象
			async toImpression() {
				let that = this
				let openid = uni.getStorageSync("loginInfoObj").open_id //提交人openid

				let params = {
					evaluate: that.scoreOverall, //综合评价
					// evaluate_id: that.id, //评价id\
					log_evaluate: that.logEvaluate,
					in_open_id: that.hisopenid, //邀请人的id
					moral: that.scoreCharacter, //人品指数
					open_id: openid, //评价人的id
					profession: that.scoreProfession, //职业技能
					re_states: that.state, //好友和用户的关系
					sex_luck: that.scoreSex, //异性缘
					specialty: that.scoreMajor, //专业技能
					study: that.scoreStudy, //学习能力
					total_score: that.compositeScore, //综合印象分
					common_id: that.commonid, //共事id
					text_evaluate: that.textevaluate, //综合评价内容
					in_phone: that.hisphone ? that.hisphone : "",
					outer_id: that.outerid?that.outerid:"",
				}
				let res = await this.$http.postHasLoad('/zxxt/user/updates', params)
				if (res.code == 'success') {
					let userevaluateid = res.data
					uni.navigateTo({
						url: '/pages/evaluate/evaluationTag?hisopenid=' + that.hisopenid + '&state=' +
							that.state + '&user_evaluate_id=' + userevaluateid + '&source=' + that.source +
							'&logEvaluate=' + that.logEvaluate + '&hisphone=' + that.hisphone + '&username=' +
							that.username + '&outerid=' + that.outerid,
					})
				}

			},

			// 获取是否已经评价完成
			async ifEvaluate() {
				let that = this
				let openid = uni.getStorageSync("loginInfoObj").open_id //提交人openid
				let params = {
					openId: openid,
					inOpenId: that.hisopenid,
					reStates: that.state,
					// openId: 'oNIYe5AJTocLLdtJ99zL5VJ960OE'
				}
				let res = await this.$http.getHasLoad('/zxxt/user/ifEvaluate', params)
				this.allEvaluate = res.data
				if (this.allEvaluate == true) {
					setTimeout(() => {
						uni.switchTab({
							url: '/pages/contacts/contacts',
						})
					}, 3000);
				}
			},
			// 获取头部信息
			async getInfo() {
				let that = this
				let params = {
					openId: that.hisopenid,
					// phone: that.hisphone,//一键点评，简报
					// userName: that.username,//从人脉搜索传
					outerId: that.outerid
				}
				let res = await this.$http.getHasLoad('/zxxt/user/listMessage', params)
				this.first = true
				this.avatar = res.data.avatar
				this.company = res.data.company_name
				this.positionname = res.data.position_name
				this.username = res.data.user_name
				if (res) {
					if (res.code == "success") {
						if (this.source == 2) { //来源 1一键点评  2卡片进入点评
							this.ifEvaluate()
						}
					}
				}
			},
			// 综合评价
			sliderOverall(e) {
				console.log(e)
				var scoreOverallStart = e.detail.value

				// 处理背景加粗
				var widthValue1 = e.detail.value
				widthValue1 = 'width:' + widthValue1 + '%'

				this.widthValue1 = widthValue1

				if (scoreOverallStart > 4 && scoreOverallStart < 100) {
					scoreOverallStart = scoreOverallStart - 4
				}

				var scoreOverall = 0
				if (scoreOverallStart > 20) {
					var scoreOverall = (scoreOverallStart - 20) * 0.5 + 60
				}
				if (scoreOverallStart == 20) {
					var scoreOverall = 60
				}
				if (scoreOverallStart < 20) {
					var scoreOverall = scoreOverallStart * 3
				}

				scoreOverall = Math.ceil(scoreOverall)

				this.scoreOverall = scoreOverall

				let composite
				if (this.state == 0 || this.state == 5) { //0同事 5同行

					var compositeArray = [this.scoreMajor, this.scoreProfession, this.scoreStudy, this.scoreCharacter, this
						.scoreOverall
					]
					var newCompositeArray = compositeArray.filter(item => {
						return item != 0
					})
					console.log(compositeArray, 'hhaahh')
					console.log(newCompositeArray, 'hhaahh')
					var newCompositeArrayLength = newCompositeArray.length

					if (newCompositeArrayLength && newCompositeArrayLength > 0) {
						composite = (this.scoreMajor + this.scoreProfession + this.scoreStudy + this.scoreCharacter + this
							.scoreOverall) / newCompositeArrayLength
					} else {
						composite = 0
					}
				}
				if (this.state == 1) { //1同学
					var studentArray = [this.scoreSex, this.scoreStudy, this.scoreCharacter, this.scoreOverall]
					var newStudentArray = studentArray.filter(item => {
						return item != 0
					})
					var newStudentArrayLength = newStudentArray.length
					if (newStudentArrayLength && newStudentArrayLength > 0) {
						composite = (this.scoreSex + this.scoreStudy + this.scoreCharacter + this.scoreOverall) /
							newStudentArrayLength
					} else {
						composite = 0
					}
				}
				if (this.state == 2 || this.state == 3) { //2战友 3亲属
					var characterArray = [this.scoreStudy, this.scoreCharacter, this.scoreOverall]
					var newCharacterArray = characterArray.filter(item => {
						return item != 0
					})
					var newCharacterArrayLength = newCharacterArray.length
					if (newCharacterArrayLength && newCharacterArrayLength > 0) {
						composite = (this.scoreStudy + this.scoreCharacter + this.scoreOverall) /
							newCharacterArrayLength
					} else {
						composite = 0
					}
				}
				if (this.state == 6 || this.state == 4) { //6其他 4群聊
					var otherArray = [this.scoreSex, this.scoreProfession, this.scoreMajor, this.scoreStudy, this
						.scoreCharacter, this.scoreOverall
					]
					var newOtherArray = otherArray.filter(item => {
						return item != 0
					})
					var newOtherArrayLength = newOtherArray.length
					if (newOtherArrayLength && newOtherArrayLength > 0) {
						composite = (this.scoreSex + this.scoreProfession + this.scoreMajor + this.scoreStudy + this
							.scoreCharacter + this.scoreOverall) / newOtherArrayLength
					} else {
						composite = 0
					}
				}
				this.compositeScore = Math.ceil(composite)
				if (this.compositeScore) {
					var numPercent = this.compositeScore / 100 * 70
					console.log(Canvas)
					Canvas.options.draw('runCanvas', numPercent, 500);
				} else {
					Canvas.options.draw('runCanvas', 1, 500);
				}
				console.log('拖动结束')
				this.sliderOverallBlockSize = '20'
			},

			// 学习能力
			sliderStudy(e) {
				var scoreStudyStart = e.detail.value

				// 处理背景加粗
				var widthValue2 = e.detail.value
				widthValue2 = 'width:' + widthValue2 + '%'
				this.widthValue2 = widthValue2

				if (scoreStudyStart > 4 && scoreStudyStart < 100) {
					scoreStudyStart = scoreStudyStart - 4
				}
				var scoreStudy = 0
				if (scoreStudyStart > 20) {
					var scoreStudy = (scoreStudyStart - 20) * 0.5 + 60
				}
				if (scoreStudyStart == 20) {
					var scoreStudy = 60
				}
				if (scoreStudyStart < 20) {
					var scoreStudy = scoreStudyStart * 3
				}

				scoreStudy = Math.ceil(scoreStudy)
				this.scoreStudy = scoreStudy

				let composite
				if (this.state == 0 || this.state == 5) { //0同事 5同行

					var compositeArray = [this.scoreMajor, this.scoreProfession, this.scoreStudy, this.scoreCharacter, this
						.scoreOverall
					]
					var newCompositeArray = compositeArray.filter(item => {
						return item != 0
					})
					console.log(compositeArray, 'compositeArray')
					console.log(newCompositeArray, 'newCompositeArray')
					var newCompositeArrayLength = newCompositeArray.length

					if (newCompositeArrayLength && newCompositeArrayLength > 0) {
						composite = (this.scoreMajor + this.scoreProfession + this.scoreStudy + this.scoreCharacter + this
							.scoreOverall) / newCompositeArrayLength
					} else {
						composite = 0
					}
				}
				if (this.state == 1) { //1同学
					var studentArray = [this.scoreSex, this.scoreStudy, this.scoreCharacter, this.scoreOverall]
					var newStudentArray = studentArray.filter(item => {
						return item != 0
					})
					var newStudentArrayLength = newStudentArray.length
					if (newStudentArrayLength && newStudentArrayLength > 0) {
						composite = (this.scoreSex + this.scoreStudy + this.scoreCharacter + this.scoreOverall) /
							newStudentArrayLength
					} else {
						composite = 0
					}
				}
				if (this.state == 2 || this.state == 3) { //2战友 3亲属
					var characterArray = [this.scoreStudy, this.scoreCharacter, this.scoreOverall]
					var newCharacterArray = characterArray.filter(item => {
						return item != 0
					})
					var newCharacterArrayLength = newCharacterArray.length
					if (newCharacterArrayLength && newCharacterArrayLength > 0) {
						composite = (this.scoreStudy + this.scoreCharacter + this.scoreOverall) / newCharacterArrayLength
					} else {
						composite = 0
					}
				}
				if (this.state == 6 || this.state == 4) { //6其他 4群聊
					var otherArray = [this.scoreSex, this.scoreProfession, this.scoreMajor, this.scoreStudy, this
						.scoreCharacter, this.scoreOverall
					]
					var newOtherArray = otherArray.filter(item => {
						return item != 0
					})
					var newOtherArrayLength = newOtherArray.length
					if (newOtherArrayLength && newOtherArrayLength > 0) {
						composite = (this.scoreSex + this.scoreProfession + this.scoreMajor + this.scoreStudy + this
							.scoreCharacter + this.scoreOverall) / newOtherArrayLength
					} else {
						composite = 0
					}
				}
				this.compositeScore = Math.ceil(composite)
				if (this.compositeScore) {
					var numPercent = this.compositeScore / 100 * 70
					Canvas.options.draw('runCanvas', numPercent, 500);
				} else {
					Canvas.options.draw('runCanvas', 1, 500);
				}
				console.log('拖动结束')
				this.sliderStudyBlockSize = '20'
			},

			// 人品指数
			sliderCharacter(e) {
				var scoreCharacterStart = e.detail.value

				// 处理背景加粗
				var widthValue3 = e.detail.value
				widthValue3 = 'width:' + widthValue3 + '%'
				this.widthValue3 = widthValue3

				if (scoreCharacterStart > 4 && scoreCharacterStart < 100) {
					scoreCharacterStart = scoreCharacterStart - 4
				}
				var scoreCharacter = 0
				if (scoreCharacterStart > 20) {
					var scoreCharacter = (scoreCharacterStart - 20) * 0.5 + 60
				}
				if (scoreCharacterStart == 20) {
					var scoreCharacter = 60
				}
				if (scoreCharacterStart < 20) {
					var scoreCharacter = scoreCharacterStart * 3
				}

				scoreCharacter = Math.ceil(scoreCharacter)
				this.scoreCharacter = scoreCharacter

				let composite
				if (this.state == 0 || this.state == 5) { //0同事 5同行

					var compositeArray = [this.scoreMajor, this.scoreProfession, this.scoreStudy, this.scoreCharacter, this
						.scoreOverall
					]
					var newCompositeArray = compositeArray.filter(item => {
						return item != 0
					})
					console.log(compositeArray, 'compositeArray')
					console.log(newCompositeArray, 'newCompositeArray')
					var newCompositeArrayLength = newCompositeArray.length

					if (newCompositeArrayLength && newCompositeArrayLength > 0) {
						composite = (this.scoreMajor + this.scoreProfession + this.scoreStudy + this.scoreCharacter + this
							.scoreOverall) / newCompositeArrayLength
					} else {
						composite = 0
					}
				}
				if (this.state == 1) { //1同学
					var studentArray = [this.scoreSex, this.scoreStudy, this.scoreCharacter, this.scoreOverall]
					var newStudentArray = studentArray.filter(item => {
						return item != 0
					})
					var newStudentArrayLength = newStudentArray.length
					if (newStudentArrayLength && newStudentArrayLength > 0) {
						composite = (this.scoreSex + this.scoreStudy + this.scoreCharacter + this.scoreOverall) /
							newStudentArrayLength
					} else {
						composite = 0
					}
				}
				if (this.state == 2 || this.state == 3) { //2战友 3亲属
					var characterArray = [this.scoreStudy, this.scoreCharacter, this.scoreOverall]
					var newCharacterArray = characterArray.filter(item => {
						return item != 0
					})
					var newCharacterArrayLength = newCharacterArray.length
					if (newCharacterArrayLength && newCharacterArrayLength > 0) {
						composite = (this.scoreStudy + this.scoreCharacter + this.scoreOverall) / newCharacterArrayLength
					} else {
						composite = 0
					}
				}
				if (this.state == 6 || this.state == 4) { //6其他 4群聊
					var otherArray = [this.scoreSex, this.scoreProfession, this.scoreMajor, this.scoreStudy, this
						.scoreCharacter, this.scoreOverall
					]
					var newOtherArray = otherArray.filter(item => {
						return item != 0
					})
					var newOtherArrayLength = newOtherArray.length
					if (newOtherArrayLength && newOtherArrayLength > 0) {
						composite = (this.scoreSex + this.scoreProfession + this.scoreMajor + this.scoreStudy + this
							.scoreCharacter + this.scoreOverall) / newOtherArrayLength
					} else {
						composite = 0
					}
				}
				this.compositeScore = Math.ceil(composite)
				if (this.compositeScore) {
					var numPercent = this.compositeScore / 100 * 70
					Canvas.options.draw('runCanvas', numPercent, 500);
				} else {
					Canvas.options.draw('runCanvas', 1, 500);
				}
				console.log('拖动结束')
				this.sliderCharacterBlockSize = '20'
			},

			// 异性缘
			sliderSex(e) {
				var scoreSexStart = e.detail.value

				// 处理背景加粗
				var widthValue4 = e.detail.value
				widthValue4 = 'width:' + widthValue4 + '%'
				this.widthValue4 = widthValue4

				if (scoreSexStart > 4 && scoreSexStart < 100) {
					scoreSexStart = scoreSexStart - 4
				}
				var scoreSex = 0
				if (scoreSexStart > 20) {
					var scoreSex = (scoreSexStart - 20) * 0.5 + 60
				}
				if (scoreSexStart == 20) {
					var scoreSex = 60
				}
				if (scoreSexStart < 20) {
					var scoreSex = scoreSexStart * 3
				}

				scoreSex = Math.ceil(scoreSex)
				this.scoreSex = scoreSex

				let composite
				if (this.state == 1) { //1同学
					var studentArray = [this.scoreSex, this.scoreStudy, this.scoreCharacter, this.scoreOverall]
					var newStudentArray = studentArray.filter(item => {
						return item != 0
					})
					var newStudentArrayLength = newStudentArray.length
					if (newStudentArrayLength && newStudentArrayLength > 0) {
						composite = (this.scoreSex + this.scoreStudy + this.scoreCharacter + this.scoreOverall) /
							newStudentArrayLength
					} else {
						composite = 0
					}
				}
				if (this.state == 6 || this.state == 4) { //6其他 4群聊
					var otherArray = [this.scoreSex, this.scoreProfession, this.scoreMajor, this.scoreStudy, this
						.scoreCharacter, this.scoreOverall
					]
					var newOtherArray = otherArray.filter(item => {
						return item != 0
					})
					var newOtherArrayLength = newOtherArray.length
					if (newOtherArrayLength && newOtherArrayLength > 0) {
						composite = (this.scoreSex + this.scoreProfession + this.scoreMajor + this.scoreStudy + this
							.scoreCharacter + this.scoreOverall) / newOtherArrayLength
					} else {
						composite = 0
					}
				}
				this.compositeScore = Math.ceil(composite)
				if (this.compositeScore) {
					var numPercent = this.compositeScore / 100 * 70
					Canvas.options.draw('runCanvas', numPercent, 500);
				} else {
					Canvas.options.draw('runCanvas', 1, 500);
				}
				console.log('拖动结束')
				this.sliderSexBlockSize = '20'
			},

			// 专业技能
			sliderMajor(e) {
				var scoreMajorStart = e.detail.value

				// 处理背景加粗
				var widthValue6 = e.detail.value
				widthValue6 = 'width:' + widthValue6 + '%'
				this.widthValue6 = widthValue6

				if (scoreMajorStart > 4 && scoreMajorStart < 100) {
					scoreMajorStart = scoreMajorStart - 4
				}
				var scoreMajor = 0
				if (scoreMajorStart > 20) {
					var scoreMajor = (scoreMajorStart - 20) * 0.5 + 60
				}
				if (scoreMajorStart == 20) {
					var scoreMajor = 60
				}
				if (scoreMajorStart < 20) {
					var scoreMajor = scoreMajorStart * 3
				}

				scoreMajor = Math.ceil(scoreMajor)
				this.scoreMajor = scoreMajor

				let composite
				if (this.state == 0 || this.state == 5) { //0同事 5同行

					var compositeArray = [this.scoreMajor, this.scoreProfession, this.scoreStudy, this.scoreCharacter, this
						.scoreOverall
					]
					var newCompositeArray = compositeArray.filter(item => {
						return item != 0
					})
					console.log(compositeArray, 'compositeArray')
					console.log(newCompositeArray, 'newCompositeArray')
					var newCompositeArrayLength = newCompositeArray.length

					if (newCompositeArrayLength && newCompositeArrayLength > 0) {
						composite = (this.scoreMajor + this.scoreProfession + this.scoreStudy + this.scoreCharacter + this
							.scoreOverall) / newCompositeArrayLength
					} else {
						composite = 0
					}
				}
				if (this.state == 6 || this.state == 4) { //6其他 4群聊
					var otherArray = [this.scoreSex, this.scoreProfession, this.scoreMajor, this.scoreStudy, this
						.scoreCharacter, this.scoreOverall
					]
					var newOtherArray = otherArray.filter(item => {
						return item != 0
					})
					var newOtherArrayLength = newOtherArray.length
					if (newOtherArrayLength && newOtherArrayLength > 0) {
						composite = (this.scoreSex + this.scoreProfession + this.scoreMajor + this.scoreStudy + this
							.scoreCharacter + this.scoreOverall) / newOtherArrayLength
					} else {
						composite = 0
					}
				}
				this.compositeScore = Math.ceil(composite)
				if (this.compositeScore) {
					var numPercent = this.compositeScore / 100 * 70
					Canvas.options.draw('runCanvas', numPercent, 500);
				} else {
					Canvas.options.draw('runCanvas', 1, 500);
				}
				console.log('拖动结束')
				this.sliderMajorBlockSize = '20'
			},

			// 职业技能
			sliderProfession(e) {
				var scoreProfessionStart = e.detail.value

				// 处理背景加粗
				var widthValue5 = e.detail.value
				widthValue5 = 'width:' + widthValue5 + '%'
				this.widthValue5 = widthValue5

				if (scoreProfessionStart > 4 && scoreProfessionStart < 100) {
					scoreProfessionStart = scoreProfessionStart - 4
				}
				var scoreProfession = 0
				if (scoreProfessionStart > 20) {
					var scoreProfession = (scoreProfessionStart - 20) * 0.5 + 60
				}
				if (scoreProfessionStart == 20) {
					var scoreProfession = 60
				}
				if (scoreProfessionStart < 20) {
					var scoreProfession = scoreProfessionStart * 3
				}

				scoreProfession = Math.ceil(scoreProfession)
				this.scoreProfession = scoreProfession

				let composite
				if (this.state == 0 || this.state == 5) { //0同事 5同行

					var compositeArray = [this.scoreMajor, this.scoreProfession, this.scoreStudy, this.scoreCharacter, this
						.scoreOverall
					]
					var newCompositeArray = compositeArray.filter(item => {
						return item != 0
					})
					console.log(compositeArray, 'hhaahh')
					console.log(newCompositeArray, 'hhaahh')
					var newCompositeArrayLength = newCompositeArray.length

					if (newCompositeArrayLength && newCompositeArrayLength > 0) {
						composite = (this.scoreMajor + this.scoreProfession + this.scoreStudy + this.scoreCharacter + this
							.scoreOverall) / newCompositeArrayLength
					} else {
						composite = 0
					}
				}
				if (this.state == 6 || this.state == 4) { //6其他 4群聊
					var otherArray = [this.scoreSex, this.scoreProfession, this.scoreMajor, this.scoreStudy, this
						.scoreCharacter, this.scoreOverall
					]
					var newOtherArray = otherArray.filter(item => {
						return item != 0
					})
					var newOtherArrayLength = newOtherArray.length
					if (newOtherArrayLength && newOtherArrayLength > 0) {
						composite = (this.scoreSex + this.scoreProfession + this.scoreMajor + this.scoreStudy + this
							.scoreCharacter + this.scoreOverall) / newOtherArrayLength
					} else {
						composite = 0
					}
				}
				this.compositeScore = Math.ceil(composite)
				if (this.compositeScore) {
					var numPercent = this.compositeScore / 100 * 70
					Canvas.options.draw('runCanvas', numPercent, 500);
				} else {
					Canvas.options.draw('runCanvas', 1, 500);
				}
				console.log('拖动结束')
				this.sliderProfessionBlockSize = '20'
			},

			// 拖动进行中的事件
			sliderOverallChanging: function(e) {
				console.log('拖动开始', e, '看下参数')
				if (e.target.dataset.flag == 'sliderOverall') {
					// 处理背景加粗
					var widthValue1 = e.detail.value
					widthValue1 = 'width:' + widthValue1 + '%'
					this.widthValue1 = widthValue1
					this.sliderOverallBlockSize = '28'
				}
				if (e.target.dataset.flag == 'sliderStudy') {
					// 处理背景加粗
					var widthValue2 = e.detail.value
					widthValue2 = 'width:' + widthValue2 + '%'
					this.widthValue2 = widthValue2
					this.sliderStudyBlockSize = '28'
				}
				if (e.target.dataset.flag == 'sliderCharacter') {
					// 处理背景加粗
					var widthValue3 = e.detail.value
					widthValue3 = 'width:' + widthValue3 + '%'
					this.widthValue3 = widthValue3
					this.sliderCharacterBlockSize = '28'
				}
				if (e.target.dataset.flag == 'sliderSex') {
					// 处理背景加粗
					var widthValue4 = e.detail.value
					widthValue4 = 'width:' + widthValue4 + '%'
					this.widthValue4 = widthValue4
					this.sliderSexBlockSize = '28'
				}
				if (e.target.dataset.flag == 'sliderProfession') {
					// 处理背景加粗
					var widthValue5 = e.detail.value
					widthValue5 = 'width:' + widthValue5 + '%'
					this.widthValue5 = widthValue5
					this.sliderProfessionBlockSize = '28'
				}
				if (e.target.dataset.flag == 'sliderMajor') {
					// 处理背景加粗
					var widthValue6 = e.detail.value
					widthValue6 = 'width:' + widthValue6 + '%'
					this.widthValue6 = widthValue6
					this.sliderMajorBlockSize = '28'
				}
			}
		},
	}
</script>

<style>
	page {
		width: 100%;
		padding-bottom: 20rpx;
		background: #fff;
	}
</style>

<style lang="scss" scoped>
	.main {
		box-sizing: border-box;
		/* padding: 0 24rpx 30rpx; */
	}

	.head {
		position: relative;
		width: 100%;
		/* height: 200rpx; */
		height: 578rpx;
		/* height: 512rpx; */
		background: #fff;
		box-sizing: border-box;
		padding-left: 40rpx;
		display: flex;
		flex-direction: row;
		align-items: center;
	}

	.headimg {
		width: 28px;
		height: 28px;
		border-radius: 50%;
		background: #fff;
	}

	.info {
		height: 30px;
		width: 80%;
		display: flex;
		align-items: center;
		margin-left: 24rpx;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}

	.name {
		font-size: 32rpx;
	}

	.company {
		font-size: 12px;
		text-align: center;
		margin-left: 10px;
	}

	.grade {
		width: 100%;
		height: 130rpx;
		background: #209072;
		border-radius: 0rpx 0rpx 48px 48px;
		box-sizing: border-box;
		padding: 10rpx 16rpx 0;
	}

	.grade-top {
		width: 100%;
		height: 24rpx;
		border-radius: 8px;
		background-color: rgba(102, 102, 102, 100);
		box-sizing: border-box;
		padding: 8rpx 8rpx 0;
	}

	.grade-info {
		width: 100%;
		height: 256rpx;
		background: #fff;
		border-radius: 16rpx;
		box-sizing: border-box;
		padding: 32rpx;
	}

	.grade-infotitle {
		color: rgba(102, 102, 102, 100);
		font-size: 32rpx;
		line-height: 32rpx;
	}

	.grade-infoborder {
		width: 600rpx;
		border-top: 2rpx dashed #ccc;
		margin: 24rpx auto 24rpx;
	}

	.grade-infonum {
		color: rgba(22, 145, 113, 100);
		font-size: 112rpx;
		text-align: center;
		line-height: 112rpx;
	}

	.tonext {
		width: 90%;
		height: 80rpx;
		border-radius: 26rpx;
		background-color: rgba(22, 145, 113, 1);
		color: rgba(255, 255, 255, 1);
		font-size: 32rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		margin: 0 auto 100rpx;
	}

	.sel-relation {
		width: 400rpx;
		height: 36rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
		flex-direction: row;
		margin: 170rpx auto 32rpx;
	}

	.sel-relation view {
		width: 80rpx;
		height: 4rpx;
		background: #209072;
	}

	.sel-relation text {
		color: rgba(22, 145, 113, 100);
		font-size: 36rpx;
		line-height: 36rpx;
	}

	.colleague {
		width: 100%;
		height: auto;
		/* border-radius: 16rpx; */
		// box-shadow: 0rpx 6rpx 16rpx 2rpx rgba(57, 57, 57, .1);
		background: #fff;
		box-sizing: border-box;
		padding: 1rpx 20rpx 50rpx;
	}

	.evaluate-slider {
		width: 86%;
		height: 28rpx;
		display: flex;
		flex-direction: column;
		align-items: flex-start;
		margin-top: 82rpx;
		justify-content: space-between;
		padding: 0 20px;
		margin-bottom: 72px;
	}

	.evaluate-slider-title {
		width: 190rpx;
		height: 28rpx;
		color: rgba(51, 51, 51, 100);
		box-sizing: border-box;
		padding-left: 10rpx;
		font-size: 32rpx;
		font-weight: 700;
		margin-bottom: 20px;
	}

	.evaluate-slider-main {
		position: relative;
		/* width: 480rpx; */
		width: 90%;
	}

	.evaluate-slider-main slider {
		margin: 0;
	}

	/* 新增样式 */
	.base_bg {
		position: absolute;
		left: 0;
		top: 0;
		/* height: 225px; */
		height: 250px;
		width: 100% !important;
	}

	.card-info {
		position: absolute;
		left: 50%;
		top: 59px;
		transform: translate(-50%);
		display: flex;
		justify-content: flex-start;
		padding: 12px;
		width: 86%;
		/* height: 193px; */
		height: 204px;
		z-index: 1;
		background-color: #fff;
		border-radius: 10px;
		overflow: hidden;
		box-shadow: 0px 0px 10px 4px rgba(0, 0, 0, 0.05);
	}

	.grade-new {
		position: absolute;
		left: 50%;
		bottom: 20px;
		transform: translate(-50%);
		width: 200px;
		height: 130px;
		background-color: pink;
		overflow: hidden;
	}

	.grade-image {
		position: absolute;
		left: 50%;
		bottom: -46px;
		transform: translate(-50%);
	}

	.big-circle {
		display: flex;
		justify-content: center;
		align-items: center;
		width: 150px;
		height: 150px;
		border-radius: 50%;
		background-color: #eee;
	}

	.small-circle {
		width: 126px;
		height: 126px;
		border-radius: 50%;
		background-color: #fff;
	}

	/* pages/canvasDemo/canvasDemo.wxss */
	.canvasBox {
		height: 380rpx;
		width: 80%;
		position: absolute;
		left: 50%;
		top: 60px;
		/* top: 36px; */
		transform: translate(-50%);
		background-color: #fff;
		border-radius: 10px;
	}

	.bigCircle {
		/* width: 420rpx;
	  height: 420rpx; */
		width: 380rpx;
		height: 380rpx;
		border-radius: 50%;
		position: absolute;
		top: 0;
		bottom: 0;
		left: 0;
		right: 0;
		margin: auto auto;
		background-color: #ddd;
	}

	.littleCircle {
		/* width: 356rpx;
	  height: 356rpx; */
		/* width: 320rpx;
	  height: 320rpx; */
		width: 318rpx;
		height: 320rpx;
		border-radius: 50%;
		position: absolute;
		top: 0;
		bottom: 0;
		left: 0;
		right: 0;
		margin: auto auto;
		background-color: #fff;
	}

	.canvas {
		width: 380rpx;
		height: 380rpx;
		position: absolute;
		left: 0;
		top: 0;
		bottom: 0;
		right: 0;
		margin: auto auto;
		z-index: 99;
	}

	.mask-fff {
		position: absolute;
		left: 50%;
		bottom: 0;
		transform: translate(-50%);
		/* width: 100%; */
		/* width: 50%; */
		width: 54%;
		height: 26px;
		background-color: #fff;
		/* background-color: red; */
		z-index: 100;
		/* border-radius: 16px; */
		border-radius: 20px;
		border-bottom-right-radius: 0;
		border-bottom-left-radius: 0;
	}

	.new-grade {
		position: absolute;
		left: 50%;
		/* bottom: 62px; */
		/* bottom: 86px; */
		bottom: 82px;
		transform: translate(-50%);
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
	}

	.grade-score {
		font-size: 40px;
		font-weight: 500;
		text-align: center;
	}

	.grade-tag {
		width: 50px;
		height: 16px;
		color: #F39E3F;
		text-align: center;
		font-size: 10px;
		background-color: #FFEFDA;
	}

	.progress-self {
		position: absolute;
		left: 0;
		top: 0;
		z-index: 10;
		width: 100%;
	}

	.progress-kedu {
		position: absolute;
		left: 0;
		top: 7px;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		width: 20px;
		height: 24px;
		z-index: 9;
		/* background-color: red; */
	}

	.progress-kedu60 {
		left: 20%;
	}

	.progress-kedu70 {
		left: 40%;
	}

	.progress-kedu80 {
		left: 60%;
	}

	.progress-kedu90 {
		left: 80%;
	}

	.kedu-dian {
		width: 4px;
		height: 4px;
		border-radius: 50%;
		background-color: #ccc;
	}

	.kedu-xian {
		height: 4px;
		width: 2px;
		background-color: #5FCCB7;
	}

	.kedu-num {
		font-size: 10px;
		color: #A5DCCD;
	}

	.evaluate-sum {
		position: absolute;
		right: -46px;
		top: -5px;
		font-size: 16px;
		color: #319D80;
		font-weight: 700;
	}

	/* .evaluate-sum1 {
	  font-size: 28px;
	  top: -14px;
	} */
	.zhanwei-view,
	.zhanwei-bgc-view {
		position: absolute;
		left: 0;
		top: 50%;
		transform: translate(0, -50%);
		width: 100%;
		height: 4px;
		background-color: #e9e9e9;
		z-index: -2;
	}

	.zhanwei-bgc-view {
		width: 0;
		background-color: #169171 !important;
		z-index: -1;
	}

	// 完成评价
	.thispage {
		display: flex;
		align-items: center;
		flex-direction: column;
		box-sizing: border-box;
		padding-top: 300rpx;
	}

	.successimage {
		width: 160rpx;
		height: 160rpx;
	}

	.tonext2 {
		font-size: 34rpx;
		font-weight: 400;
		color: #209072;
		line-height: 50rpx;
		text-align: center;
		margin-top: 94rpx;
	}

	.succes {
		color: #333;
		font-size: 48rpx;
		line-height: 48rpx;
		margin: 8rpx 0 32rpx;
	}

	.thanks {
		color: #aaa;
		font-size: 28rpx;
		line-height: 28rpx;
	}
</style>
