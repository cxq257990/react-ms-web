<template>
	<view>
		<view class="head">
			<image class="headimg" :src="avatar ? avatar : '../../static/img/anonymity.png'"></image>
			<view class="info">
				<view class="name">{{username}}</view>
				<view class="company">
					<template v-if="company">{{company}}</template>
					<template v-if="positionname"> - {{positionname}}</template>
				</view>
			</view>
		</view>

		<view class="list">
			<template v-if="evaluationlabel">
				<view class="title">大家对他的印象</view>
				<block v-for="(v,key) in evaluationlabel" :key="key">
					<view class="list-item" :class="[v.active ? 'selThis' : '' ]" :data-key="key" :data-item="v"
						@tap="isSelectGreat" :style="{'background-color':randomColorArr[key]}">{{v.label}}</view>
				</block>
			</template>
			<view class="title" style="margin-top:72rpx;">贴标签</view>
			<block v-for="(item,key) in canselList" :key="key">
				<view class="list-item" :class="[item.active ? 'selThis' : '' ]" :data-key="key" :data-item="item"
					@tap="isSelect" :style="{'background-color':randomColorArr2[key]}">{{item.label}}</view>
			</block>
		</view>
		<view class="change-it" @tap="changeIt">
			<image src="../../static/img/change-batch.svg"></image>
			<text>换一批</text>
		</view>
		<view class="tonext" @tap="upInfo">下一步</view>
	</view>

</template>

<script>
	/**
	 * 标签评价
	 */
	export default {
		data() {
			return {
				hisopenid: '', //邀请人的openid
				states: '', ////0同事 1同学 2战友 3亲属 5其他
				userevaluateid: '',
				avatar: '', //头像
				company: '', //公司
				positionname: '', //职位
				username: '', //姓名
				evaluationlabel: [], //大家对他的印象-接口返回
				canselList: [], //可选择标签列表-接口返回
				currentTab: -1, //点中 - 贴标签 - 标签下标
				currentTabevery: -1, //点中 - 大家对他的印象 - 标签下标
				colorArr: ["#E7F7FF", "#E6FFFB", "#F6FFED", "#FFF2E8", "#FFF0F6", "#E7F1FD", "#F9EEDE", "#EFFDEE",
					"#F9F0FF", "#FFF2E8", "#FFF0F6"
				], // 存储随机颜色
				randomColorArr: [], //大家对他的印象-背景色显示
				randomColorArr2: [], //可选择标签列表-背景色显示
				uplabelArr: [], //选中-贴标签-并要提交的标签
				uplabelArrevery: [], //选中-大家对他的印象-并要提交的标签

				nowpage: 1, //模拟页码
				allpage: 0, //总页数
				alldata: [], //总标签数

				source: 1, //来源 1一键点评  2卡片进入点评
				logEvaluate: null,
				hisphone: '', //
				outerid: '',
			}
		},
		onLoad(options) {
			this.outerid = options.outerid ? options.outerid : ''
			this.username = options.username ? options.username : ''
			this.logEvaluate = options.logEvaluate
			this.hisopenid = options.hisopenid ? options.hisopenid : ''
			this.hisphone = options.hisphone ? options.hisphone : ''
			this.state = options.state //0同事，1同学，2战友，3亲属，4群聊，5同行，6其他',
			this.userevaluateid = options.user_evaluate_id
			this.source = options.source
			this.getInfo()
			this.getlist()
			this.getSelLabelList()
		},
		methods: {
			// 选中 - 贴标签列表-标签 --- 多选功能
			isSelect(e) {
				console.log(e)
				let that = this;
				this.canselList[e.currentTarget.dataset.key].active = !this.canselList[e.currentTarget.dataset.key].active
				this.currentTab = e.currentTarget.dataset.key
				this.canselList = that.canselList
				//点击时 此标签-未被选中
				if (!e.currentTarget.dataset.item.active) {
					let son = e.currentTarget.dataset.item.label;
					if (that.uplabelArr.indexOf(son) > -1) {
						console.log('已存在')
					} else {
						console.log('不在')
						that.uplabelArr.push(son)
						that.uplabelArr = that.uplabelArr
					}
				}
				//点击时 此标签-已选中
				if (e.currentTarget.dataset.item.active) {
					let son2 = e.currentTarget.dataset.item.label;
					let ind = that.uplabelArr.indexOf(son2)
					that.uplabelArr.splice(ind, 1);
				}
			},

			// 选择 - 大家对他的的印象 - 标签列表
			isSelectGreat(e) {
				let that = this;
				this.evaluationlabel[e.currentTarget.dataset.key].active = !this.evaluationlabel[e.currentTarget.dataset
					.key].active;
				this.currentTabevery = e.currentTarget.dataset.key
				this.evaluationlabel = that.evaluationlabel
				//点击时 此标签-未被选中
				if (!e.currentTarget.dataset.item.active) {
					let son = e.currentTarget.dataset.item.label;
					if (that.uplabelArrevery.indexOf(son) > -1) {
						console.log('已存在')
					} else {
						console.log('不在')
						that.uplabelArrevery.push(son)
						that.uplabelArrevery = that.uplabelArrevery
					}
				}
				//点击时 此标签-已选中
				if (e.currentTarget.dataset.item.active) {
					let son2 = e.currentTarget.dataset.item.label;
					let ind = this.uplabelArrevery.indexOf(son2)
					that.uplabelArrevery.splice(ind, 1);
				}
			},

			// 换一批 --- 模拟分页
			changeIt() {
				if (this.nowpage >= this.allpage) {
					this.nowpage = 1
					let list = this.alldata.slice(0, 6)
					this.canselList = list
				} else {
					let nowpages = this.nowpage + 1
					this.nowpage = nowpages
					let list = this.alldata.slice(((nowpages - 1) * 6), nowpages * 6)
					this.canselList = list
				}
			},

			// 提交按钮
			async upInfo() {
				let that = this
				let openid = uni.getStorageSync("loginInfoObj").open_id //提交人openid
				let updataArr
				if (that.uplabelArrevery) {
					updataArr = that.uplabelArrevery.concat(that.uplabelArr)
				} else {
					updataArr = that.uplabelArr
				}
				let params = {
					user_evaluate_id: that.userevaluateid,
					label: updataArr,
					iopen_id: that.hisopenid,
					label_type: that.state,
					open_id: openid,
					phone: that.hisphone,
				}

				let res = await this.$http.postHasLoad('/zxxt/label/updateLabelByOpenId', params)
				if (res.code == 'success') {
					let userevaluateid = res.data
					uni.navigateTo({
						url: '/pages/evaluate/evaluationQA?hisopenid=' + that.hisopenid + '&state=' + that
							.state + '&user_evaluate_id=' + that.userevaluateid + '&source=' + that.source +
							'&logEvaluate=' + that.logEvaluate + '&hisphone=' + that.hisphone + '&username=' +
							that.username + '&outerid=' + that.outerid,
					})
				}

			},

			// 获取 - 大家对他的印象 - 标签列表
			async getlist() {
				let that = this
				let params = {
					openId: that.hisopenid,
					phone: that.hisphone
				}
				let res = await this.$http.getHasLoad('/zxxt/user/selectUserLabelByOpenId', params)
				if (res.code == 'success' && !!res.data) {
					that.evaluationlabel = res.data.evaluation_label.slice(0, 6)
					that.evaluationlabel.forEach(item => {
						item.active = false
					})
					if (that.evaluationlabel) {
						let labLen = that.evaluationlabel.length,
							colorArr = that.colorArr,
							colorLen = colorArr.length,
							randomColorArr = [];
						//判断执行 - 大家对他的印象
						do {
							let random = colorArr[Math.floor(Math.random() * colorLen)];
							randomColorArr.push(random);
							labLen--;
						} while (labLen > 0)
						that.randomColorArr = randomColorArr
					}
				}

			},

			// 获取 - 顶部头像昵称等 - 信息
			async getInfo() {
				let that = this
				let params = {
					openId: that.hisopenid,
					// phone:that.hisphone,
					// userName:that.username,
					outerId: that.outerid
				}
				let res = await this.$http.getHasLoad('/zxxt/user/listMessage', params)
				that.avatar = res.data.avatar
				that.company = res.data.company_name
				that.positionname = res.data.position_name
				that.username = res.data.user_name
			},

			// 获取 - 贴标签 - 列表数据
			async getSelLabelList() {
				let that = this
				let upstate
				if (that.state != 1) { //如果不是同学，则显示同事的可选标签
					upstate = 0
				} else {
					upstate = that.state
				}
				let params = {
					type: upstate,
				}
				let res = await this.$http.getHasLoad('/zxxt/label/selectLabelListByType', params)
				if (res.code == 'success') {
					let alldata = res.data.length;
					let allpages = Math.ceil(alldata / 6);
					let partlist = res.data.slice(0, 6);
					that.alldata = res.data;
					that.canselList = partlist;
					that.allpage = allpages;
					that.nowpage = 1;
					that.canselList.forEach(item => {
						item.active = false
					})
					that.canselList = that.canselList
					let canselListLen = that.canselList.length,
						colorArr = that.colorArr,
						colorLen = colorArr.length,
						randomColorArr2 = [];
					//判断执行 - 可选择的印象标签
					do {
						let random2 = colorArr[Math.floor(Math.random() * colorLen)];
						randomColorArr2.push(random2);
						canselListLen--;
					} while (canselListLen > 0)
					that.randomColorArr2 = randomColorArr2
				}

			},
		}
	}
</script>


<style lang="scss" scoped>
	.head {
		width: 100%;
		height: 200rpx;
		background: #209072;
		box-sizing: border-box;
		padding-left: 40rpx;
		display: flex;
		flex-direction: row;
		align-items: center;
	}

	.headimg {
		width: 128rpx;
		height: 128rpx;
		border-radius: 50%;
		background: #fff;
	}

	.info {
		height: 128rpx;
		display: flex;
		flex-direction: column;
		justify-content: space-around;
		margin-left: 24rpx;
	}

	.name {
		color: rgba(255, 255, 255, 100);
		font-size: 32rpx;
	}

	.company {
		color: rgba(255, 255, 255, 100);
		font-size: 28rpx
	}

	.sel-relation {
		width: 400rpx;
		height: 32rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
		flex-direction: row;
		margin: 96rpx auto 24rpx;
	}

	.sel-relation view {
		width: 80rpx;
		height: 4rpx;
		background: #209072;
	}

	.sel-relation text {
		color: rgba(22, 145, 113, 100);
		font-size: 36rpx;
		line-height: 32rpx;
	}

	.tips {
		color: rgba(153, 153, 153, 100);
		font-size: 24rpx;
		line-height: 24rpx;
		margin-bottom: 48rpx;
		text-align: center;
	}

	.change-it {
		display: flex;
		flex-direction: row;
		justify-content: flex-end;
		align-items: center;
		height: 32rpx;
		box-sizing: border-box;
		padding-right: 44rpx;
	}

	.change-it text {
		font-size: 24rpx;
		margin-left: 14rpx;
	}

	.change-it image {
		width: 28rpx;
		height: 28rpx;
	}

	.list {
		width: 100%;
		box-sizing: border-box;
		padding: 64rpx 0 0 40rpx;
		display: flex;
		flex-direction: row;
		flex-wrap: wrap
	}

	.list-item {
		width: 192rpx;
		height: 64rpx;
		border-radius: 32rpx;
		background-color: rgba(255, 255, 255, 1);
		color: rgba(102, 102, 102, 1);
		/* border: 2rpx solid rgba(153, 153, 153, 1); */
		font-size: 28rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		margin: 0 40rpx 40rpx 0;
	}

	.active {
		background-color: rgba(32, 144, 114, 1);
		color: rgba(255, 255, 255, 1);
		border: 0;
	}

	.tonext {
		width: 90%;
		height: 80rpx;
		border-radius: 26rpx;
		background-color: rgba(22, 145, 113, 1);
		color: rgba(255, 255, 255, 1);
		font-size: 32rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		margin: 200rpx auto 100rpx;
	}

	.title {
		width: 100%;
		height: 36rpx;
		color: rgba(51, 51, 51, 100);
		font-size: 36rpx;
		margin-bottom: 40rpx;
		line-height: 36rpx;
	}

	.selThis {
		background-color: #209072 !important;
		color: #fff !important;
	}
</style>
