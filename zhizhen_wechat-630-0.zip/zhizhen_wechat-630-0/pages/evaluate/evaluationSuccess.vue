<template>
	<view class="page">
		<image src="../../static/img/fillin-success.svg"></image>
		<view class="succes">评价成功</view>
		<view class="thanks">感谢您的评价</view>
		<view class="tonext" v-if="source == 2" @tap="upInfo">即将进入指真小程序~</view>
	</view>
</template>

<script>
	/**
	 * 评价成功
	 */
	export default {
		data() {
			return {
				source:1,//来源 1一键点评  2卡片进入点评
			}
		},
		onLoad(options) {
			let source = options.source
			setTimeout(() => {
				uni.switchTab({
					url: '/pages/contacts/contacts',
				})
			}, 2000);
		},
		methods: {
			// 跳转人脉页面
			upInfo() {
				uni.switchTab({
					url: '/pages/contacts/contacts',
				})
			}
		}
	}
</script>

<style>
	
</style>
<style lang="scss" scoped>
	.page {
		display: flex;
		align-items: center;
		flex-direction: column;
		box-sizing: border-box;
		padding-top: 300rpx;
		width: 100%;
	}
	image {
		width: 160rpx;
		height: 160rpx;
	}

	.tonext {		
		font-size: 34rpx;
		font-weight: 400;
		color: #209072;
		line-height: 50rpx;
		text-align: center;
		margin-top: 94rpx;
	}

	.succes {
		color: #333;
		font-size: 48rpx;
		line-height: 48rpx;
		margin: 8rpx 0 32rpx;
	}

	.thanks {
		color: #aaa;
		font-size: 28rpx;
		line-height: 28rpx;
	}
</style>
