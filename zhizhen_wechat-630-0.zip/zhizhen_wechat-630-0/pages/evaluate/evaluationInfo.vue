<template>
	<view>
		<view class="himimpress-container">
			<view class="base-info">
				<image :src="userInfo.avatar ? userInfo.avatar : '../../static/img/default-header2.png'"
					class="info-left"></image>
				<view class="info-right">
					<view class="name">{{userInfo.user_name ? userInfo.user_name : ''}}</view>
					<view class="company">
						<text style="margin-right: 15rpx;">{{userInfo.position_name ? userInfo.position_name : ''}}　</text>
						<text v-if="userInfo.company_name"
							class="company-name">{{userInfo.company_name ? userInfo.company_name : ''}}</text>
					</view>
				</view>
			</view>
			<view class="him-detail">
				<view class="dianping base-card">
					<view class="title">对TA的点评:</view>
					<view class="content">{{userInfo.text_evaluate?userInfo.text_evaluate:''}}</view>
				</view>
				<view class="impression base-card">
					<view class="title">对TA的印象:</view>
					<view v-for="(item,index) in userInfo.labels" :key="index" class="tag" :class="[item.colorItem]">
						{{item.text}}
					</view>
					<view class="clear-both"></view>
				</view>
				<view class="score base-card">
					<view class="title">对TA的评分:</view>
					<view class="content">综合印象评分：{{userInfo.total_score?userInfo.total_score:''}}</view>
				</view>
			</view>
			<view class="radio-group">
				<!-- 一 -->
				<view class="radio-item">
					<view class="item-left">有无职业操守和道德品质问题</view>
					<view class="item-right">
						<view class="radio-yes">
							<view class="cir">
								<view class="small" :class="[userInfo.if_morality == 1?'active':'']"></view>
							</view>
							<view class="txt">是</view>
						</view>
						<view class="radio-no">
							<view class="cir">
								<view class="small" :class="[userInfo.if_morality == 2?'active':'']"></view>
							</view>
							<view class="txt">否</view>
						</view>
					</view>
				</view>
				<!-- 二 -->
				<view class="radio-item">
					<view class="item-left">是否有违纪违规行为</view>
					<view class="item-right">
						<view class="radio-yes">
							<view class="cir">
								<view class="small" :class="[userInfo.if_violate == 1?'active':'']"></view>
							</view>
							<view class="txt">是</view>
						</view>
						<view class="radio-no">
							<view class="cir">
								<view class="small" :class="[userInfo.if_violate == 2?'active':'']"></view>
							</view>
							<view class="txt">否</view>
						</view>
					</view>
				</view>
				<!-- 三 -->
				<view class="radio-item">
					<view class="item-left">是否愿意再度共事</view>
					<view class="item-right">
						<view class="radio-yes">
							<view class="cir">
								<view class="small" :class="[userInfo.if_job == 1?'active':'']"></view>
							</view>
							<view class="txt">是</view>
						</view>
						<view class="radio-no">
							<view class="cir">
								<view class="small" :class="[userInfo.if_job == 2?'active':'']"></view>
							</view>
							<view class="txt">否</view>
						</view>
					</view>
				</view>
			</view>
			<view class="reason">
				<view class="reason-title">是否愿意再度共事，请说明理由。</view>
				<textarea placeholder="请输入理由" style="z-index: 0;" :value="userInfo.reason?userInfo.reason:''" :disabled='true' />
			</view>
			<view class="anonymous">
				<view class="radio-anonymous">
					<view class="cir">
						<view class="small" :class="[userInfo.if_anonymity == 1?'active':'']"></view>
					</view>
					<view class="txt">访客评价</view>
				</view>
			</view>
		</view>
		<view class="again" @tap="pingAgain">
			重新评价
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				hisopenid: '', //邀请人的openid
				openid: '',
				states: '', ////0同事 1同学 2战友 3亲属 5其他
				userInfo: {},
				lookUserId: "",
				openId: '',
				// 道德
				if_morality: 2,
				// 违规
				if_violate: 2,
				// 共事
				if_job: 2,
				// 原因
				reason: '',
				// 访客
				if_anonymity: 2,
				hisphone:'',
				outerid:'',
			}
		},
		onLoad(options) {
			this.outerid = options.outerid ? options.outerid : ''
			this.hisopenid = options.hisopenid ? options.hisopenid : ''
			this.hisphone = options.hisphone ? options.hisphone : ''
			this.openid = uni.getStorageSync("loginInfoObj").open_id //提交人openid
			this.getInfo()
		},
		methods: {
			// 重新评价
			async pingAgain() {
				let hisopenid = this.hisopenid
				let hisphone = this.hisphone
				let outerid = this.outerid
				let id = this.userInfo.id ? this.userInfo.id : 0
				// 先删除评价
				let obj = {
					id: id
				}
				let res = await this.$http.getHasLoad('/zxxt/user/delJobEvaluation', obj);
				if (res && res.code == 'success') {
					uni.navigateTo({
						url: '/pages/multiEntry/comment?hisopenid=' + hisopenid + '&hisphone=' + hisphone + '&outerid=' + outerid,
					})
				}
			},
			// 获取 - 页面所有信息
			async getInfo() {
				let that = this
				let params = {
					openId: that.openid,
					lookUserId: that.hisopenid,
					// phone:that.hisphone,
					outerId:that.outerid
				}
				let res = await this.$http.getHasLoad('/zxxt/user/review', params)
				if (res.code == 'success') {
					var userInfo = res.data
					var labels = JSON.parse(userInfo.labels)
					var newlabels = []
					if (labels && labels.length > 0) {
						labels.forEach(item => {
							// 随机生成颜色
							var colors = ['red', 'green', 'blue', 'yellow'];
							var colorItem = colors[Math.floor(Math.random() * colors.length)];
							newlabels.push({
								text: item,
								colorItem: colorItem
							})
						})
						userInfo.labels = newlabels
					}
					that.userInfo = userInfo
				}
			}
		},

	}
</script>

<style>
	page {
		color: #333;
		font-size: 14px;
		background-color: #F8F8F8;
	}
</style>
<style lang="scss" scoped>
	.base-card {
		margin-bottom: 8px;
		min-height: 46px;
		padding: 16px;
		background-color: #fff;
	}

	.dianping {
		margin-top: 8px;
	}

	.title {
		margin-bottom: 8px;
	}

	.base-info {
		display: flex;
		justify-content: flex-start;
		align-items: center;
		height: 62px;
		padding: 0 16px;
		background-color: #fff;
		margin-bottom: 8px;
	}

	.info-left {
		height: 32px;
		width: 32px;
		border-radius: 50%;
	}

	.info-right {
		color: #999999;
		font-size: 10px;
		margin-left: 8px;
	}

	.name {
		color: #666;
		font-size: 12px;
	}

	.radio-item {
		display: flex;
		justify-content: space-between;
		height: 46px;
		padding: 0 16px;
		text-align: left;
		line-height: 46px;
		color: #333333;
		font-size: 14px;
		background-color: #fff;
		margin-bottom: 8px;
	}

	.item-right {
		width: 30%;
		display: flex;
		align-items: center;
	}

	.radio-yes,
	.radio-no {
		display: flex;
		align-items: center;
	}

	.radio-no {
		margin-left: 16px;
	}

	.cir {
		display: flex;
		justify-content: center;
		align-items: center;
		width: 14px;
		height: 14px;
		border-radius: 50%;
		border: 1px solid #CDCDCD;
	}

	.small {
		width: 8px;
		height: 8px;
		border: 1px solid #fff;
		border-radius: 50%;
	}

	.active {
		background-color: #46A289;
	}

	.txt {
		margin-left: 4px;
	}

	.reason {
		min-height: 176px;
		background-color: #fff;
		padding: 12px;
	}

	.reason-title {
		margin-bottom: 16px;
	}

	.anonymous {
		display: flex;
		justify-content: flex-end;
		margin-top: 10px;
		padding-right: 12px;
		margin-bottom: 80px;
	}

	.radio-anonymous {
		display: flex;
		align-items: center;
	}

	.btn {
		position: fixed;
		left: 50%;
		bottom: 16px;
		transform: translate(-50%);
		width: 92%;
		height: 42px;
		line-height: 42px;
		text-align: center;
		color: #fff;
		font-size: 16px;
		border-radius: 4px;
		background-color: #46A289;
	}

	.tag {
		float: left;
		width: 60px;
		height: 24px;
		border-radius: 12px;
		background-color: #FFF2F2;
		color: #FF5A5A;
		font-size: 12px;
		line-height: 24px;
		text-align: center;
		margin-right: 8px;
		margin-bottom: 16px;
	}

	.clear-both {
		clear: both;
	}

	.red {
		color: #FF5A5A;
		background-color: #FFF2F2;
	}

	.yellow {
		color: #FFB309;
		background-color: #FFF9E8;
	}

	.blue {
		color: #5FA4FF;
		background-color: #F1F7FF;
	}

	.green {
		color: #67C059;
		background-color: #F2FDF0;
	}

	.title {
		font-weight: 700;
	}
	.again{
		width: 640rpx;
		height: 88rpx;
		margin-left: -320rpx;
		background: #209072;
		display: flex;
		justify-content: center;
		align-items: center;
		font-size: 34rpx;
		color: #fff;
		border-radius: 44rpx;
		position: fixed;bottom: 50rpx;left: 50%;z-index: 99;
	}
</style>
