<template>
	<view>
		<view class="himimpress-container">
			<view class="base-info">
				<image :src="avatar ? avatar : '../../static/img/anonymity.png'" class="info-left"></image>
				<view class="info-right">
					<view class="name">{{username ? username : ''}}</view>
					<view class="company">
						<text style="margin-right: 15rpx;">{{positionname ? positionname : ''}}</text>
						<text class="company-name">{{company ? company : ''}}</text>
					</view>
				</view>
			</view>
			<view class="radio-group">
				<!-- 有无职业操守和道德品质问题 -->
				<view class="radio-item">
					<view class="item-left">有无职业操守和道德品质问题</view>
					<view class="item-right">
						<view class="radio-yes" :data-morality-flag="true" @tap="isMorality">
							<view class="cir">
								<view class="small" :class="[if_morality == 1 ? 'active' : '']"></view>
							</view>
							<view class="txt">是</view>
						</view>
						<view class="radio-no" :data-morality-flag="false" @tap="isMorality">
							<view class="cir">
								<view class="small" :class="[if_morality == 2 ? 'active' : '']"></view>
							</view>
							<view class="txt">否</view>
						</view>
					</view>
				</view>
				<!-- 是否有违纪违规行为 -->
				<view class="radio-item">
					<view class="item-left">是否有违纪违规行为</view>
					<view class="item-right">
						<view class="radio-yes" :data-violate-flag="true" @tap="isViolate">
							<view class="cir">
								<view class="small" :class="[if_violate == 1 ? 'active' : '']"></view>
							</view>
							<view class="txt">是</view>
						</view>
						<view class="radio-no" :data-violate-flag="false" @tap="isViolate">
							<view class="cir">
								<view class="small" :class="[if_violate == 2 ? 'active' : '']"></view>
							</view>
							<view class="txt">否</view>
						</view>
					</view>
				</view>
				<!-- 是否愿意再度共事 -->
				<view class="radio-item">
					<view class="item-left">是否愿意再度共事</view>
					<view class="item-right">
						<view class="radio-yes" :data-job-flag="true" @tap="isJob">
							<view class="cir">
								<view class="small" :class="[if_job == 1 ? 'active' : '']"></view>
							</view>
							<view class="txt">是</view>
						</view>
						<view class="radio-no" :data-job-flag="false" @tap="isJob">
							<view class="cir">
								<view class="small" :class="[if_job == 2 ? 'active' : '']"></view>
							</view>
							<view class="txt">否</view>
						</view>
					</view>
				</view>
			</view>
			<!-- 如果不愿意再度共事，请说明理由。 -->
			<view class="reason">
				<view class="reason-title">如果不愿意再度共事，请说明理由。</view>
				<textarea placeholder="请输入理由" @input="textInput" />
			</view>
			<view class="anonymous">
				<view class="radio-anonymous" @tap="anonymousClick">
					<view class="cir">
						<view class="small" :class="[if_anonymity == 1 ? 'active' : '']"></view>
					</view>
					<view class="txt">访客评价</view>
				</view>
			</view>

			<view class="btn" @tap="dataSubmit">下一步</view>
		</view>

	</view>

</template>

<script>
	/**
	 * QA评价
	 */
	export default {
		data() {
			return {
				hisopenid: '', //邀请人的openid
				states: '', ////0同事 1同学 2战友 3亲属 5其他
				userevaluateid: '',
				avatar: '', //头像
				company: '', //公司
				positionname: '', //职位
				username: '', //姓名

				// 道德
				if_morality: null,
				// 违规
				if_violate: null,
				// 共事
				if_job: null,
				// 原因
				reason: '',
				// 访客
				if_anonymity: 2,
				
				source:1,//来源 1一键点评  2卡片进入点评
				logEvaluate:null,
				hisphone:'',
				outerid:'',
			}
		},
		onLoad(options) {
			console.log(options)
			this.outerid = options.outerid ? options.outerid : ''
			this.username = options.username ? options.username : ''
			this.hisphone = options.hisphone ? options.hisphone : ''
			this.logEvaluate = options.logEvaluate
			this.hisopenid = options.hisopenid ? options.hisopenid : ''
			this.state = options.state //0同事 1同学 2战友 3亲属 5其他
			this.userevaluateid = options.user_evaluate_id
			this.source = options.source
			this.getInfo()
		},
		methods: {
			isMorality: function(e) {
				if (e.currentTarget.dataset.moralityFlag == true) {
					this.if_morality = 1
				} else {
					this.if_morality = 2
				}
			},

			isViolate: function(e) {
				if (e.currentTarget.dataset.violateFlag == true) {
					this.if_violate = 1
				} else {
					this.if_violate = 2
				}
			},

			isJob: function(e) {
				if (e.currentTarget.dataset.jobFlag == true) {
					this.if_job = 1
				} else {
					this.if_job = 2
				}
			},

			textInput: function(e) {
				var reason = e.detail.value
				this.reason = reason
			},

			anonymousClick: function() {
				var if_anonymity = this.if_anonymity
				if (if_anonymity == 1) {
					this.if_anonymity = 2
				} else {
					this.if_anonymity = 1
				}
			},

			// 获取 - 顶部头像昵称等 - 信息
			async getInfo() {
				let that = this
				let params = {
					openId: that.hisopenid,
					// phone:that.hisphone,
					// userName:that.username,
					outerId:that.outerid
				}
				let res = await this.$http.getHasLoad('/zxxt/user/listMessage', params)
				if (res.code == 'success') {
					that.avatar = res.data.avatar
					that.company = res.data.company_name
					that.positionname = res.data.position_name
					that.username = res.data.user_name
				}
			},

			// 提交
			async dataSubmit() {
				let that = this
				let openid = uni.getStorageSync("loginInfoObj").open_id //提交人openid
				// let log_evaluate = app.globalData.log_evaluate ? app.globalData.log_evaluate : 1//区分点评通道1：邀请评价，2：一键点评
				var if_morality = this.if_morality
				var if_violate = this.if_violate
				var if_job = this.if_job
				console.log(if_morality, if_violate, if_job, 'if_morality, if_violate, if_job,')
				if (!if_morality) {
					return uni.showToast({
						title: '请选择有无职业操守和道德品质问题',
						icon: 'none',
						duration: 2000
					})
				}
				if (!if_violate) {
					return uni.showToast({
						title: '请选择是否有违纪违规行为',
						icon: 'none',
						duration: 2000
					})
				}
				if (!if_job) {
					return uni.showToast({
						title: '请选择是否愿意再度共事',
						icon: 'none',
						duration: 2000
					})
				}
				if (if_job == 2) {
					if (that.reason.length == 0) {
						return uni.showToast({
							title: '请输入理由',
							icon: 'none',
							duration: 2000
						})
					}
					if (that.reason.length > 20) {
						return uni.showToast({
							title: '理由字数不得大于20',
							icon: 'none',
							duration: 2000
						})
					}
				}
				let params = {
					// evaluate_id: that.data.id,//评价id
					// in_open_id: that.data.hisopenid,//邀请人的id
					// open_id: openid,//评价人的id

					if_anonymity: that.if_anonymity, //是否访客：1是，2否
					if_job: that.if_job, //是否愿意再度共事：1是，2否
					if_morality: that.if_morality, //有无职业操守和道德品质问题：1是，2否
					if_violate: that.if_violate, //是否有违纪违规行为：1是，2否
					reason: that.reason, //如果不愿意共事请说明理由
					log_evaluate:that.logEvaluate, //区分点评通道1：邀请评价，2：一键点评
					id: that.userevaluateid,
				}
				let res = await this.$http.postHasLoad('/zxxt/user/updatesQA', params)
				if (res.code == 'success') {
					uni.navigateTo({
						url: '/pages/evaluate/evaluationSuccess?source=' + that.source,
					})
				}
			},
		}
	}
</script>

<style>
	page {
		color: #333;
		font-size: 14px;
		background-color: #F8F8F8;
	}
</style>
<style lang="scss" scoped>
	.base-info {
		display: flex;
		justify-content: flex-start;
		align-items: center;
		height: 62px;
		padding: 0 16px;
		background-color: #fff;
		margin-bottom: 8px;
	}

	.info-left {
		height: 32px;
		width: 32px;
		border-radius: 50%;
	}

	.info-right {
		color: #999999;
		font-size: 10px;
		margin-left: 8px;
	}

	.name {
		color: #666;
		font-size: 12px;
	}

	.radio-item {
		display: flex;
		justify-content: space-between;
		height: 46px;
		padding: 0 16px;
		text-align: left;
		line-height: 46px;
		color: #333333;
		font-size: 14px;
		background-color: #fff;
		margin-bottom: 8px;
	}

	.item-right {
		width: 30%;
		display: flex;
		align-items: center;
	}

	.radio-yes,
	.radio-no {
		display: flex;
		align-items: center;
	}

	.radio-no {
		margin-left: 16px;
	}

	.cir {
		display: flex;
		justify-content: center;
		align-items: center;
		width: 14px;
		height: 14px;
		border-radius: 50%;
		border: 1px solid #CDCDCD;
	}

	.small {
		width: 8px;
		height: 8px;
		border: 1px solid #fff;
		border-radius: 50%;
	}

	.active {
		background-color: #46A289;
	}

	.txt {
		margin-left: 4px;
	}

	.reason {
		min-height: 176px;
		background-color: #fff;
		padding: 12px;
	}

	.reason-title {
		margin-bottom: 16px;
	}

	.anonymous {
		display: flex;
		justify-content: flex-end;
		margin-top: 16px;
		padding-right: 12px;
	}

	.radio-anonymous {
		display: flex;
		align-items: center;
	}

	.btn {
		position: fixed;
		left: 50%;
		bottom: 16px;
		transform: translate(-50%);
		width: 92%;
		height: 42px;
		line-height: 42px;
		text-align: center;
		color: #fff;
		font-size: 16px;
		border-radius: 4px;
		background-color: #46A289;

	}
</style>
