<template>
	<view class="body">
		<template v-if="noping">
			<view class="top1">
				推荐信
			</view>
			<view class="top3">
				<view class="top3l">
					<image class="pophead" :src="avatar ? avatar : '../../static/img/anonymity.png'" mode=""></image>
				</view>
				<view class="top3r">
					<view class="top3r1">
						{{name}}
					</view>
					<view class="top3r2">
						{{common}}
					</view>
					<view class="top3r3">
						您曾经是TA的{{['上级', '直属上司', '下属', '直属下属', '同事', '老师', '同学', '同行', '合作伙伴', '其他大咖'][restates]}}
					</view>
				</view>
			</view>
			<view class="info">
				<view class="infoitem">
					<textarea class="inptext" placeholder="给TA写推荐信"
						placeholder-style="color:#aaa;line-height: 45rpx;font-size: 26rpx;" v-model="wantsay"
						@input="inputWantsay" />
				</view>
			</view>
		</template>
		<view class="btn" @click="toNext" v-if="noping">
			发送
		</view>
	</view>
</template>

<script>
	/**
	 * 从分享卡片点击进来的 给别人写推荐信 或编辑推荐信
	 */
	export default {
		data() {
			return {
				id: '',
				hisopenid: '',
				restates: '',
				openid: '', //

				common: '', //
				name: '',
				avatar: '',

				wantsay: '', //推荐信内容
				noping: true, //不可以评论
				
				first:false,//onshow限制
			}
		},

		onLoad(options) {
			let that = this
			that.id = options.id ///zxxt/user/letter接口返回id
			that.hisopenid = options.hisopenid //被写人openid
			that.restates = options.re_states //与被写人关系
			// let info = uni.getStorageSync("userInfoObj")
			// let hasphone = uni.getStorageSync("userPhoneObj")
			// if (info || hasphone) {//先校验登录
				that.openid = uni.getStorageSync("loginInfoObj").open_id //提交人openid
				if (that.openid == that.hisopenid) {
					that.noping = false
					uni.showToast({
						title: '不能为自己写！',
						icon: 'none',
						duration: 4000
					})
					setTimeout(function() {
						uni.switchTab({
							url: '/pages/contacts/contacts',
						})
						return false
					}, 1500) //延迟时间 
				} else {
					that.getInfo()
				}
			// } else {
			// 	//无信息跳转登录
			// 	uni.navigateTo({
			// 		url: '/pages/login/login'
			// 	});
			// }
		},
		
		onShow() {
			if (this.first == true) {
				this.getInfo()
			}
		},

		methods: {
			//输入监听
			inputWantsay() {
				this.wantsay = e.target.value
			},

			// 获取页面信息
			async getInfo() {
				let that = this
				let params = {
					openId: that.hisopenid,
					id: that.id
				}
				let res = await this.$http.getHasLoad('/zxxt/user/updateRecord', params)
				that.first = true
				that.name = res.data.user_name ? res.data.user_name : res.data.nickname
				that.avatar = res.data.avatar
				that.common = res.data.common
				that.wantsay = res.data.emit_recommendation
			},

			// 保存
			async toNext() {
				let that = this
				let openid = uni.getStorageSync("loginInfoObj").open_id //提交人openid
				let params = {
					letter_open_id: openid,
					open_id:that.hisopenid,
					id: that.id,
					recommendations: that.wantsay,
					re_states: that.restates
				}
				let res = await this.$http.postHasLoad('/zxxt/user/finish', params)
				uni.showToast({
					title: '发送成功',
					icon: 'none',
					duration: 2000
				})
				setTimeout(function() {
					uni.switchTab({
						url: '/pages/contacts/contacts',
					})
					return false
				}, 1500) //延迟时间  
			},
		}
	}
</script>

<style>
	page {
		background: #F7F7F7;
	}
</style>

<style lang="scss" scoped>
	.top1 {
		font-size: 48rpx;
		margin: 30rpx 0 0 32rpx;
		line-height: 48rpx;
		font-weight: 400;
		color: #333333;
	}

	.top3 {
		display: flex;
		flex-direction: row;
		width: 100%;
		min-height: 180rpx;
		margin-top: 28rpx;
		box-sizing: border-box;
		padding-left: 24rpx;

		.top3l {
			width: 97rpx;
			height: 180rpx;
			display: flex;

			.pophead {
				width: 80rpx;
				height: 80rpx;
				border-radius: 50%;
			}
		}

		.top3r {
			width: 600rpx;
			overflow: hidden;
			min-height: 180rpx;
			box-sizing: border-box;padding-bottom: 30rpx;

			.top3r1 {
				padding-left: 3rpx;
				font-size: 34rpx;
				line-height: 46rpx;
				color: #333333;
			}

			.top3r2 {
				font-size: 28rpx;
				line-height: 56rpx;
				color: #999;
			}

			.top3r3 {
				font-size: 28rpx;
				line-height: 42rpx;
				color: #999;
			}
		}
	}

	.bor {
		border-top: 1rpx solid #E0E0E0;
	}

	.info {
		width: 100%;
		height: 400rpx;
		box-sizing: border-box;
		background-color: #fff;

		.infoitem {
			width: 100%;
			box-sizing: border-box;
			padding: 34rpx 36rpx;

			.inptext {
				color: #666;
				width: 100%;
				height: 336rpx;
				font-size: 32rpx;
				line-height: 40rpx;
			}
		}
	}

	.btn {
		width: 640rpx;
		height: 88rpx;
		margin: 60rpx auto;
		background: #209072;
		display: flex;
		justify-content: center;
		align-items: center;
		font-size: 34rpx;
		color: #fff;
		border-radius: 44rpx;
	}
</style>
