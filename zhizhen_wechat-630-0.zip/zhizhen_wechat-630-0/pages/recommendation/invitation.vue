<template>
	<view class="body">
		<!-- 完善履历弹层 -->
		<view class="pop" v-if="popval">
			<view class="popmain">
				<image class="popback" src="../../static/img/popback1.png" mode=""></image>
				<image class="pophead" :src="avatar ? avatar : '../../static/img/anonymity.png'" mode=""></image>
				<view class="popname">
					{{hisname}}
				</view>
				<view class="poptips">拜托帮我写一份珍贵的推荐信吧~</view>
				<view class="poptips">比心~ </view>
				<button class="popbtn" open-type="share">
					去微信分享
				</button>
			</view>
			<view class="iconfont icon-s-shanchutupian icon-delpop" @tap="delPop"></view>
		</view>

		<!-- 主体内容 -->
		<view class="top1">
			邀请
		</view>
		<view class="top2">
			{{type == 0 ? hisname : 'TA'}}为您写一封珍贵的推荐信
		</view>
		<view class="info">
			<view class="infoitem">
				<view class="inp">
					<picker class="pickf" @change="bindRelationChange" :value="relationindex" :range="relationarray">
						<view class="pickeritem">
							{{relationindex == null ? "TA是您的" : relationarray[relationindex]}}
							<view class="iconfont icon-s-xiangxia icon-xia"></view>
						</view>
					</picker>
				</view>
			</view>
			<view class="infoitem">
				<view class="inp bor"
					v-if="relationindex != null && (relationindex == 0 || relationindex == 1 || relationindex == 2 || relationindex == 3 || relationindex == 4)">
					<picker class="pickf" @change="bindCompanyChange" :value="companyindex" :range="companyarray"
						:range-key="'name'">
						<view class="pickeritem">
							{{companyindex == null ? "请选择共事公司" : companyarray[companyindex].name}}
							<view class="iconfont icon-s-xiangxia icon-xia"></view>
						</view>
					</picker>
				</view>
			</view>
			<view class="infoitem">
				<view class="inp bor" v-if="relationindex != null && (relationindex == 5 || relationindex == 6)">
					<picker class="pickf" @change="bindSchoolChange" :value="schoolindex" :range="schoolarray"
						:range-key="'school_name'">
						<view class="pickeritem">
							{{schoolindex == null ? "请选择共同院校" : schoolarray[schoolindex].school_name}}
							<view class="iconfont icon-s-xiangxia icon-xia"></view>
						</view>
					</picker>
				</view>
			</view>
			<view class="infoitem">
				<view class="inp bor"
					v-if="(companyarray[companyindex].name == '其他' && relationindex == 0) || (schoolarray[schoolindex].school_name == '其他' && relationindex == 1)"
					style="padding: 0 20rpx;box-sizing: border-box;">
					<view class="inpson" @tap="toAddInfo">
						<view class="inpson-l">
							<view class="iconfont icon-s-tianjia icon-add"></view>
							<view class="inpson-ltitle">
								添加{{(relationindex == 0 || relationindex == 1 || relationindex == 2 || relationindex == 3 || relationindex == 4) ? '工作' : (relationindex == 5 || relationindex == 6) ? '教育' : ''}}履历
							</view>
						</view>
						<view class="iconfont icon-s-xiangyou icon-r"></view>
					</view>
				</view>
			</view>
			<view class="infoitem">
				<view class="tex bor"
					v-if="(relationindex == 0 || relationindex == 1 || relationindex == 2 || relationindex == 3 || relationindex == 4)">
					<textarea class="inptext" placeholder="TA当时的职位"
						placeholder-style="color:#aaa;line-height: 45rpx;font-size: 26rpx;" v-model="position"
						@input="inputPosition" />
				</view>
			</view>
		</view>
		<view class="btn" @click="toNext">
			下一步
		</view>
		<view class="tips">
			<view>小提示：</view>
			<view>人脉关系选择为同事类人脉/老师/同学时，若无相应的公司/学校选项，请选择"其他"选项，并在出现的"添加共事职业履历"、"添加教育履历"栏，完善相应信息，新增信息将实时同步。</view>
		</view>
	</view>
</template>

<script>
	/**
	 * 邀请别人为自己写推荐信
	 */
	export default {
		data() {
			return {
				relationarray: ['上级', '直属上司', '下属', '直属下属', '同事', '老师', '同学', '同行', '合作伙伴', '其他'],
				relationindex: null, //
				companyarray: [],
				companyindex: null, //
				schoolarray: [],
				schoolindex: null, //
				position: '',
				openid: '', //本人openid
				hisopenid: '', //被评价人的openid
				popval: false, //弹窗
				hisname: '', //
				avatar: '',
				
				first: true, //用于限制onshow
				type:0,
			}
		},
		onLoad(options) {
			this.hisname = options.name //被写人姓名
			this.hisopenid = options.hisopenid //被写人openid
			this.avatar = options.avatar //被写人头像
			if(options.type){
				this.type = options.type
			}
			this.openid = uni.getStorageSync("loginInfoObj").open_id //提交人openid
		},
		onShow() {
			if (!this.first) {
				this.relationindex = null
				this.companyindex = null
				this.schoolindex = null
			}
		},
		methods: {
			//去添加信息
			toAddInfo(){
				this.first = false
				if (this.relationindex == 0 || this.relationindex == 1 || this.relationindex == 2 || this.relationindex ==
					3 || this.relationindex == 4) {
					uni.navigateTo({
						url: '/pages/my/myRecord/exerciseDetail'
					})
				}
				if (this.relationindex == 5 || this.relationindex == 6) {
					uni.navigateTo({
						url: '/pages/my/myRecord/exerciseDetail'
					})
				}
			},
			
			//为同事关系时，显示当前职位
			inputPosition(e) {
				this.position = e.target.value
			},

			// 监听 - 选择关系
			bindRelationChange: function(e) {
				this.relationindex = e.target.value
				this.getlist()
			},

			// 监听 - 共事公司
			bindCompanyChange: function(e) {
				this.companyindex = e.target.value
			},

			// 监听 - 共同院校
			bindSchoolChange: function(e) {
				this.schoolindex = e.target.value
			},

			// 获取 - 共同院校和公司列表数据
			async getlist() {
				let that = this
				let params = {
					openId: this.openid
				}
				let res = await this.$http.getHasLoad('/zxxt/user/inviteMessage', params)
				if (res.code == 'success') {
					that.companyarray = res.data.record_vo_list
					that.schoolarray = res.data.education_vo_list
				}
				that.companyarray.push({
					name: '其他'
				})
				that.schoolarray.push({
					school_name: '其他'
				})
			},
			
			delPop(){
				this.popval = !this.popval //弹层显示隐藏
			},

			// 下一步  唤起弹层
			async toNext() {
				let that = this
				let common = '' //共事单位或学校id
				// let re_states //0同事，1同学，2战友，3亲属，4群聊，5同行，6其他',
				// if ((that.relationindex == 0 || that.relationindex == 1 || that.relationindex == 2 || that
				// 		.relationindex ==
				// 		3 || that.relationindex == 4) && that.companyindex) { //同事
				// 	common = that.companyarray[that.companyindex].name
				// 	re_states = 0
				// }
				// if ((that.relationindex == 5 || that.relationindex == 6) && that.schoolindex) { //同学
				// 	common = that.schoolarray[that.schoolindex].school_name
				// 	re_states = 1
				// }
				// if (that.relationindex == 2) { //同行
				// 	re_states = 5
				// }
				// if (that.relationindex == 3) { //其他
				// 	re_states = 6
				// }
				if (!that.relationindex) {
					return uni.showToast({
						title: '请选择关系',
						icon: 'none',
						duration: 2000
					})
				}
				if (((that.relationindex == 0 || that.relationindex == 1 || that.relationindex == 2 || that
						.relationindex == 3 || that.relationindex == 4) && that.companyindex == null) || ((that
							.relationindex == 0 || that.relationindex == 1 || that.relationindex == 2 || that
							.relationindex == 3 || that.relationindex == 4) && that.companyarray[that.companyindex]
						.name ==
						'其他')) {
					return uni.showToast({
						title: '请选择共同公司',
						icon: 'none',
						duration: 2000
					})
				}
				if (((that.relationindex == 5 || that.relationindex == 6) && that.schoolindex == null) || ((that
							.relationindex == 5 || that.relationindex == 6) && that.schoolarray[that.schoolindex]
						.school_name == '其他')) {
					return uni.showToast({
						title: '请选择共同学校',
						icon: 'none',
						duration: 2000
					})
				}
				if (that.position.length == 0 && (that.relationindex == 0 || that.relationindex == 1 || that
						.relationindex == 2 || that.relationindex == 3 || that.relationindex == 4)) {
					return uni.showToast({
						title: '请填写Ta的职位',
						icon: 'none',
						duration: 2000
					})
				}
				let params = {
					open_id: that.openid,
					is_index: 0,
					common: common, //共事公司/共同学校/共同单位
					re_name: that.hisname, //他的姓名
					re_states: that.relationindex, //关系
					work_post: that.position, //工作岗位
				}
				let res = await this.$http.postHasLoad('/zxxt/user/letter', params)
				this.id = res.data.id
				this.popval = !this.popval //弹层显示
			},
		},
		onShareAppMessage(res) {
			let that = this
			let urldata = '/pages/recommendation/write?hisopenid=' + that.openid + '&id=' + that.id + '&re_states=' + that.relationindex
			return {
				title: '指真网 - 指向真实的你', // 转发标题
				path: urldata, // 必须是以 / 开头的完整路径
				imageUrl: '/static/img/forward_letter.png',
				success(res) {},
				fail(res) {}
			}
		},
	}
</script>

<style>
	page {
		background: #F7F7F7;
	}
</style>

<style lang="scss" scoped>
	.top1 {
		font-size: 48rpx;
		margin: 30rpx 0 0 32rpx;
		line-height: 48rpx;
		font-weight: 400;
		color: #333333;
	}

	.top2 {
		font-size: 28rpx;
		font-weight: 400;
		color: #333333;
		line-height: 28rpx;
		margin: 24rpx 0 42rpx 33rpx;
	}

	.bor {
		border-top: 1rpx solid #E0E0E0;
	}

	.info {
		width: 100%;
		min-height: 370rpx;
		box-sizing: border-box;

		.infoitem {
			width: 100%;
			box-sizing: border-box;
			padding: 0 34rpx;
			background-color: #fff;

			.inp {
				width: 100%;
				height: 89rpx;
				box-sizing: border-box;
				background-color: #fff;

				.pickf {
					width: 100%;
					height: 88rpx;
					box-sizing: border-box;
					font-size: 32rpx;
					color: #666;
					padding-right: 16rpx;

					.pickeritem {
						width: 100%;
						display: flex;
						justify-content: space-between;
						align-items: center;
						color: #666;
						height: 88rpx;

						.icon-xia {
							font-size: 26rpx;
							color: #aaa;
						}
					}
				}
			}

			.inpson {
				width: 100%;
				display: flex;
				justify-content: space-between;
				align-items: center;
				height: 88rpx;

				.inpson-l {
					display: flex;
					flex-direction: row;
					align-items: center;
					justify-content: flex-start;

					.icon-add {
						color: #209072;
						font-size: 26rpx;
					}

					.inpson-ltitle {
						font-size: 32rpx;
						color: #333333;
						margin-left: 12rpx;
					}
				}

				.icon-r {
					color: #AAAAAA;
					font-size: 26rpx;
				}
			}

			.tex {
				width: 100%;
				min-height: 170rpx;
				box-sizing: border-box;
				padding: 34rpx 0 0;
				background-color: #fff;

				.inptext {
					color: #666;
					width: 100%;
					height: 136rpx;
					font-size: 32rpx;
					line-height: 48rpx;
				}
			}
		}
	}

	.btn {
		width: 640rpx;
		height: 88rpx;
		margin: 60rpx auto;
		background: #209072;
		display: flex;
		justify-content: center;
		align-items: center;
		font-size: 34rpx;
		color: #fff;
		border-radius: 44rpx;
	}

	.tips {
		width: 100%;
		position: absolute;
		bottom: 62rpx;
		box-sizing: border-box;
		padding: 0 34rpx;
		font-size: 24rpx;
		text-align: justify;
		font-weight: 400;
		color: #666666;
		line-height: 45rpx;
	}

	.pop {
		width: 100%;
		height: 100%;
		position: fixed;
		top: 0;
		left: 0;
		bottom: 0;
		right: 0;
		background-color: rgba(0, 0, 0, 0.3);
		z-index: 99;

		.popmain {
			width: 540rpx;
			height: 640rpx;
			background: #FFFFFF;
			border-radius: 26rpx;
			position: absolute;
			left: 50%;
			margin-left: -270rpx;
			top: 20%;
			background: #fff;
			display: flex;
			flex-direction: column;
			align-items: center;
			overflow: hidden;

			.popback {
				width: 100%;
				height: 240rpx;
				position: absolute;
				top: 0;
				left: 0;
				z-index: 1;
			}

			.pophead {
				width: 160rpx;
				height: 160rpx;
				border-radius: 50%;
				z-index: 2;
				margin-top: 152rpx;
				margin-bottom: 43rpx;
			}

			.popname {
				width: 100%;
				text-align: center;
				position: absolute;
				top: 96rpx;
				color: #fff;
				height: 35px;
				z-index: 9;
				font-size: 36rpx;
				font-weright: 400;
				color: #FFFFFF;
				line-height: 35rpx;
			}

			.poptips {
				width: 100%;
				text-align: left;
				box-sizing: border-box;
				padding-left: 44rpx;
				font-size: 30rpx;
				font-weight: 400;
				color: #333333;
				line-height: 48rpx;
			}

			.popbtn {
				width: 100%;
				height: 88rpx;
				display: flex;
				justify-content: center;
				align-items: center;
				font-size: 30rpx;
				color: #209072;
				font-weight: 400;
				position: absolute;
				bottom: 0;
				box-sizing: border-box;
				border: 1rpx solid #E0E0E0;
			}
		}

		.icon-delpop {
			font-size: 90rpx;
			color: #0E1623;
			opacity: 0.5;
			position: absolute;
			left: 50%;
			margin-left: -45rpx;
			top: 76%;
		}
	}
</style>
