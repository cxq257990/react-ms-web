<template>
	<view class="body">
		<view class="top1">
			推荐信
		</view>
		<view class="top3">
			<view class="top3l">
				<image class="pophead" :src="avatar ? avatar : '../../static/img/anonymity.png'" mode=""></image>
			</view>
			<view class="top3r">
				<view class="top3r1">
					{{name}}
				</view>
				<view class="top3r2">
					{{common}}
				</view>
				<view class="top3r3">
					曾经是您的{{['上级', '直属上司', '下属', '直属下属', '同事', '老师', '同学', '同行', '合作伙伴', '其他大咖'][restates]}}
				</view>
			</view>
		</view>
		<view class="info">
			<view class="infoitem">
				<textarea class="inptext" placeholder="给TA写推荐信"
					placeholder-style="color:#aaa;line-height: 45rpx;font-size: 26rpx;" v-model="wantsay"
					@input="inputWantsay" />
			</view>
		</view>
		<view class="btn" @click="toNext">
			发送
		</view>
	</view>
</template>

<script>
	/**
	 * 给别人写推荐信 - 提交退啊继续您内容页面  
	 */
	export default {
		data() {
			return {
				id: '',
				name: '',
				hisopenid: '',
				restates: '',
				avatar: '',
				openid: '', //
				common: '',

				wantsay: '', //推荐信内容
			}
		},
		onLoad(options) {
			this.openid = uni.getStorageSync("loginInfoObj").open_id //提交人openid
			this.id = options.id ///zxxt/user/letter接口返回id
			this.name = options.name //被写人名字
			this.hisopenid = options.hisopenid //被写人openid
			this.restates = options.re_states //与被写人关系
			this.avatar = options.avatar //被写人头像
			this.common = options.common //与被写人共同单位名称
		},
		methods: {
			//输入监听
			inputWantsay() {
				this.wantsay = e.target.value
			},
			async toNext() {
				let that = this
				let params = {
					letter_open_id: that.openid,
					id: that.id,
					open_id:that.hisopenid,
					recommendations: that.wantsay,
					re_states: that.restates
				}
				let res = await this.$http.postHasLoad('/zxxt/user/finish', params)
				setTimeout(() => {
					uni.showToast({
						icon: 'success',
						title: '发送成功',
					});
					setTimeout(() => {
						uni.hideToast();
						// uni.switchTab({
						// 	url: '/pages/contacts/contacts'
						// });
						uni.navigateBack({
							delta: 2
						})
					}, 2000)
				}, 0);
				
			},
		}
	}
</script>

<style>
	page {
		background: #F7F7F7;
	}
</style>

<style lang="scss" scoped>
	.top1 {
		font-size: 48rpx;
		margin: 30rpx 0 0 32rpx;
		line-height: 48rpx;
		font-weight: 400;
		color: #333333;
	}

	.top3 {
		display: flex;
		flex-direction: row;
		width: 100%;
		min-height: 180rpx;
		margin-top: 28rpx;
		box-sizing: border-box;
		padding-left: 24rpx;

		.top3l {
			width: 97rpx;
			height: 180rpx;
			display: flex;

			.pophead {
				width: 80rpx;
				height: 80rpx;
				border-radius: 50%;
			}
		}

		.top3r {
			width: 600rpx;
			overflow: hidden;
			min-height: 180rpx;
			box-sizing: border-box;padding-bottom: 30rpx;

			.top3r1 {
				padding-left: 3rpx;
				font-size: 34rpx;
				line-height: 46rpx;
				color: #333333;
			}

			.top3r2 {
				font-size: 28rpx;
				line-height: 56rpx;
				color: #999;
			}

			.top3r3 {
				font-size: 28rpx;
				line-height: 42rpx;
				color: #999;
			}
		}
	}

	.bor {
		border-top: 1rpx solid #E0E0E0;
	}

	.info {
		width: 100%;
		height: 400rpx;
		box-sizing: border-box;
		background-color: #fff;

		.infoitem {
			width: 100%;
			box-sizing: border-box;
			padding: 34rpx 36rpx;

			.inptext {
				color: #666;
				width: 100%;
				height: 336rpx;
				font-size: 32rpx;
				line-height: 40rpx;
			}
		}
	}

	.btn {
		width: 640rpx;
		height: 88rpx;
		margin: 60rpx auto;
		background: #209072;
		display: flex;
		justify-content: center;
		align-items: center;
		font-size: 34rpx;
		color: #fff;
		border-radius: 44rpx;
	}
</style>
