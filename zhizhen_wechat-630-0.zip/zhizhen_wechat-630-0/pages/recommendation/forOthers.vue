<template>
	<view class="body">
		<view class="top1">
			推荐信
		</view>
		<view class="top2">
			您如何结识{{name}}？
		</view>
		<view class="info">
			<view class="infoitem">
				<view class="inp">
					<picker class="pickf" @change="bindRelationChange" :value="relationindex" :range="relationarray">
						<view class="pickeritem">
							{{relationindex == null ? "TA是您的" : relationarray[relationindex]}}
							<view class="iconfont icon-s-xiangxia icon-xia"></view>
						</view>
					</picker>
				</view>
			</view>
			<view class="infoitem">
				<view class="inp bor"
					v-if="relationindex != null && (relationindex == 0 || relationindex == 1 || relationindex == 2 || relationindex == 3 || relationindex == 4)">
					<picker class="pickf" @change="bindCompanyChange" :value="companyindex" :range="companyarray"
						:range-key="'name'">
						<view class="pickeritem">
							{{companyindex == null ? "请选择共事公司" : companyarray[companyindex].name}}
							<view class="iconfont icon-s-xiangxia icon-xia"></view>
						</view>
					</picker>
				</view>
			</view>
			<view class="infoitem">
				<view class="inp bor" v-if="relationindex != null && (relationindex == 5 || relationindex == 6)">
					<picker class="pickf" @change="bindSchoolChange" :value="schoolindex" :range="schoolarray"
						:range-key="'school_name'">
						<view class="pickeritem">
							{{schoolindex == null ? "请选择共同院校" : schoolarray[schoolindex].school_name}}
							<view class="iconfont icon-s-xiangxia icon-xia"></view>
						</view>
					</picker>
				</view>
			</view>
			<view class="infoitem">
				<view class="inp bor"
					v-if="(companyarray[companyindex].name == '其他' && relationindex == 0) || (schoolarray[schoolindex].school_name == '其他' && relationindex == 1)"
					style="padding: 0 20rpx;box-sizing: border-box;">
					<view class="inpson" @tap="toAddInfo">
						<view class="inpson-l">
							<view class="iconfont icon-s-tianjia icon-add"></view>
							<view class="inpson-ltitle">
								添加{{(relationindex == 0 || relationindex == 1 || relationindex == 2 || relationindex == 3 || relationindex == 4) ? '工作' : (relationindex == 5 || relationindex == 6) ? '教育' : ''}}履历
							</view>
						</view>
						<view class="iconfont icon-s-xiangyou icon-r"></view>
					</view>
				</view>
			</view>
			<view class="infoitem">
				<view class="tex bor"
					v-if="(relationindex == 0 || relationindex == 1 || relationindex == 2 || relationindex == 3 || relationindex == 4)">
					<textarea class="inptext" placeholder="TA当时的职位"
						placeholder-style="color:#aaa;line-height: 45rpx;font-size: 26rpx;" v-model="position"
						@input="inputPosition" />
				</view>
			</view>
		</view>
		<view class="btn" @click="toNext">
			下一步
		</view>
		<view class="tips">
			<view>小提示：</view>
			<view>人脉关系选择为同事类人脉/老师/同学时，若无相应的公司/学校选项，请选择"其他"选项，并在出现的"添加共事职业履历"、"添加教育履历"栏，完善相应信息，新增信息将实时同步。</view>
		</view>
	</view>
</template>

<script>
	/**
	 * 给别人写推荐信 - 选择与别人关系
	 */
	export default {
		data() {
			return {
				relationarray: ['上级', '直属上司', '下属', '直属下属', '同事', '老师', '同学', '同行', '合作伙伴', '其他'],
				relationindex: null, //
				companyarray: [],
				companyindex: null, //
				schoolarray: [],
				schoolindex: null, //
				position: '',
				openid: '', //本人openid
				hisopenid: '', //被评价人的openid

				name: '', //被写邀请信的名字
				avatar: '', //被写邀请信头像
				first: true, //用于限制onshow
			}
		},
		onLoad(options) {
			this.hisopenid = options.hisopenid //被写人openid
			this.name = options.name //被写人姓名，用于下个页面
			this.avatar = options.avatar //被写人头像，用于下个页面

			this.openid = uni.getStorageSync("loginInfoObj").open_id //提交人openid
		},
		onShow() {
			if (!this.first) {
				this.relationindex = null
				this.companyindex = null
				this.schoolindex = null
			}
		},
		methods: {
			//为同事关系时，显示当前职位
			inputPosition(e) {
				this.position = e.target.value
			},

			//去添加信息
			toAddInfo() {
				this.first = false
				if (this.relationindex == 0 || this.relationindex == 1 || this.relationindex == 2 || this.relationindex ==
					3 || this.relationindex == 4) {
					uni.navigateTo({
						url: '/pages/my/myRecord/exerciseDetail'
					})
				}
				if (this.relationindex == 5 || this.relationindex == 6) {
					uni.navigateTo({
						url: '/pages/my/myRecord/exerciseDetail'
					})
				}
			},

			// 监听 - 选择关系
			bindRelationChange: function(e) {
				this.relationindex = e.target.value
				this.getlist()
			},

			// 监听 - 共事公司
			bindCompanyChange: function(e) {
				this.companyindex = e.target.value
			},

			// 监听 - 共同院校
			bindSchoolChange: function(e) {
				this.schoolindex = e.target.value
			},

			// 获取 - 共同院校和公司列表数据
			async getlist() {
				let that = this
				let params = {
					openId: this.openid
				}
				let res = await this.$http.getHasLoad('/zxxt/user/inviteMessage', params)
				if (res.code == 'success') {
					that.companyarray = res.data.record_vo_list
					that.schoolarray = res.data.education_vo_list
				}
				that.companyarray.push({
					name: '其他'
				})
				that.schoolarray.push({
					school_name: '其他'
				})
			},

			//下一步
			async toNext() {
				let that = this
				let common = '' //共事单位或学校id
				let re_states //0同事，1同学，2战友，3亲属，4群聊，5同行，6其他',
				if ((that.relationindex == 0 || that.relationindex == 1 || that.relationindex == 2 || that
						.relationindex ==
						3 || that.relationindex == 4) && that.companyindex) { //同事
					common = that.companyarray[that.companyindex].name
					re_states = 0
				}
				if ((that.relationindex == 5 || that.relationindex == 6) && that.schoolindex) { //同学
					common = that.schoolarray[that.schoolindex].school_name
					re_states = 1
				}
				if (that.relationindex == 2) { //同行
					re_states = 5
				}
				if (that.relationindex == 3) { //其他
					re_states = 6
				}
				// 以下为信息空判断
				if (!that.relationindex) {
					return uni.showToast({
						title: '请选择关系',
						icon: 'none',
						duration: 2000
					})
				}
				if (((that.relationindex == 0 || that.relationindex == 1 || that.relationindex == 2 || that
						.relationindex == 3 || that.relationindex == 4) && that.companyindex == null) || ((that
							.relationindex == 0 || that.relationindex == 1 || that.relationindex == 2 || that
							.relationindex == 3 || that.relationindex == 4) && that.companyarray[that.companyindex]
						.name ==
						'其他')) {
					return uni.showToast({
						title: '请选择共同公司',
						icon: 'none',
						duration: 2000
					})
				}
				if (((that.relationindex == 5 || that.relationindex == 6) && that.schoolindex == null) || ((that
							.relationindex == 5 || that.relationindex == 6) && that.schoolarray[that.schoolindex]
						.school_name == '其他')) {
					return uni.showToast({
						title: '请选择共同学校',
						icon: 'none',
						duration: 2000
					})
				}
				if (that.position.length == 0 && (that.relationindex == 0 || that.relationindex == 1 || that
						.relationindex == 2 || that.relationindex == 3 || that.relationindex == 4)) {
					return uni.showToast({
						title: '请填写他的职位',
						icon: 'none',
						duration: 2000
					})
				}
				let params = {
					open_id: that.hisopenid,
					is_index: 0,
					common: common, //共事公司/共同学校/共同单位
					re_states: that.relationindex, //关系
					work_post: that.position, //工作岗位
				}
				let res = await this.$http.postHasLoad('/zxxt/user/letter', params)
				let id = res.data.id,
					restates = res.data.re_states
				uni.navigateTo({
					url: '/pages/recommendation/forOthersOver?name=' + that.name + '&avatar=' + that.avatar +
						'&hisopenid=' + that.hisopenid + '&re_states=' + restates + '&id=' + id + '&common=' +
						common,
				})
			},
		}
	}
</script>

<style>
	page {
		background: #F7F7F7;
	}
</style>

<style lang="scss" scoped>
	.top1 {
		font-size: 48rpx;
		margin: 30rpx 0 0 32rpx;
		line-height: 48rpx;
		font-weight: 400;
		color: #333333;
	}

	.top2 {
		font-size: 28rpx;
		font-weight: 400;
		color: #333333;
		line-height: 28rpx;
		margin: 24rpx 0 42rpx 33rpx;
	}

	.bor {
		border-top: 1rpx solid #E0E0E0;
	}

	.info {
		width: 100%;
		min-height: 370rpx;
		box-sizing: border-box;

		.infoitem {
			width: 100%;
			box-sizing: border-box;
			padding: 0 34rpx;
			background-color: #fff;

			.inp {
				width: 100%;
				height: 89rpx;
				box-sizing: border-box;
				background-color: #fff;

				.pickf {
					width: 100%;
					height: 88rpx;
					box-sizing: border-box;
					font-size: 32rpx;
					color: #666;
					padding-right: 16rpx;

					.pickeritem {
						width: 100%;
						display: flex;
						justify-content: space-between;
						align-items: center;
						color: #666;
						height: 88rpx;

						.icon-xia {
							font-size: 26rpx;
							color: #aaa;
						}
					}
				}
			}

			.inpson {
				width: 100%;
				display: flex;
				justify-content: space-between;
				align-items: center;
				height: 88rpx;

				.inpson-l {
					display: flex;
					flex-direction: row;
					align-items: center;
					justify-content: flex-start;

					.icon-add {
						color: #209072;
						font-size: 26rpx;
					}

					.inpson-ltitle {
						font-size: 32rpx;
						color: #333333;
						margin-left: 12rpx;
					}
				}

				.icon-r {
					color: #AAAAAA;
					font-size: 26rpx;
				}
			}

			.tex {
				width: 100%;
				min-height: 170rpx;
				box-sizing: border-box;
				padding: 34rpx 0 0;
				background-color: #fff;

				.inptext {
					color: #666;
					width: 100%;
					height: 136rpx;
					font-size: 32rpx;
					line-height: 48rpx;
				}
			}
		}
	}

	.btn {
		width: 640rpx;
		height: 88rpx;
		margin: 60rpx auto;
		background: #209072;
		display: flex;
		justify-content: center;
		align-items: center;
		font-size: 34rpx;
		color: #fff;
		border-radius: 44rpx;
	}

	.tips {
		width: 100%;
		position: absolute;
		bottom: 62rpx;
		box-sizing: border-box;
		padding: 0 34rpx;
		font-size: 24rpx;
		text-align: justify;
		font-weight: 400;
		color: #666666;
		line-height: 45rpx;
	}
</style>
