<template>
	<view class="speedRank">
		<view class="bg">
			<view class="rectangle"></view>
			<view class="arc"></view>
		</view>
		<view class="container">
			<view class="item" v-for="(item,index) in list" :key="index">
				<view class="index" :class="{topThree:index<3}">{{index+1}}</view>
				<image class="avatar" :src="item.avatar?item.avatar:defaultHeadimg" mode=""></image>
				<view class="name">{{item.user_name}}</view>
				<view class="desc">
					<view class="up">成功邀请{{item.invite_sum}}人，</view>
					<view class="down">背调耗时{{item.elapsed}}天！</view>
				</view>
			</view>
			<!-- <view class="over">下拉加载更多</view> -->
		</view>
		<view class="bottom">© 2019指真.com 版权所有</view>
	</view>
</template>

<script>
	import {
		mapState
	} from "vuex";
	export default {
		data() {
			return {
				defaultHeadimg: this.$defaultHeadimg,
				list: []
			}
		},
		computed: {
			...mapState(['userPhone', 'userInfoObj', 'loginInfoObj'])
		},
		async onLoad() {
			let data = {
				openId: ""
			}
			let res = await this.$http.getHasLoad("/zxxt/user/speed");
			if (res) {
				this.list = res.data
			}
		},
		methods: {

		}
	}
</script>

<style lang="scss" scoped>
	.speedRank {
		width: 100%;
		min-height: 100vh;
		padding: 26rpx 30rpx;
		box-sizing: border-box;
		background-color: #f7f7f7;

		.bg {
			position: fixed;
			top: 0;
			left: 0;
			z-index: 0;
			width: 100%;

			.rectangle {
				height: 330rpx;
				background-color: $uni-color-active;
			}

			.arc {
				position: absolute;
				top: 175rpx;
				left: -5%;
				z-index: -1;

				width: 110%;
				height: 236rpx;
				background-color: $uni-color-active;

				clip-path: ellipse(50% 40% at 50% 50%);
			}

		}

		.container {
			position: relative;
			z-index: 2;
			width: 100%;
			height: calc(100vh - 230rpx);
			overflow-y: auto;
			padding: 0 38rpx;
			box-sizing: border-box;
			background: #FFFFFF;
			border-radius: 30rpx;

			.item {
				border-bottom: 1rpx solid $uni-border-color;
				height: 120rpx;
				display: flex;
				align-items: center;

				.index {
					font-size: 28rpx;
					color: $uni-text-color;
					width: 46rpx;
					margin-left: 4rpx;
				}

				.topThree {
					font-weight: bold;
					color: #C82C2C;
				}

				.avatar {
					width: 80rpx;
					height: 80rpx;
					border-radius: 100rpx;
					margin-right: 30rpx;
				}

				.name {
					font-size: 32rpx;
					color: $uni-text-color;
					flex: 1;
				}

				.desc {
					width: 256rpx;
					font-size: 24rpx;
					color: $uni-text-color;

					.up {}

					.down {}
				}

			}

			.item:last-of-type {
				border: none;
			}

			// .over {
			// 	width: 100%;
			// 	height: 130rpx;
			// 	line-height: 130rpx;
			// 	text-align: center;

			// 	font-size: 28rpx;
			// 	color: $uni-text-color-greyA;
			// }
		}

		.bottom {
			width: 100%;
			text-align: center;
			position: fixed;
			left: 0;
			bottom: 60rpx;

			font-size: 24rpx;
			color: $uni-text-color-grey;
		}

	}
</style>
