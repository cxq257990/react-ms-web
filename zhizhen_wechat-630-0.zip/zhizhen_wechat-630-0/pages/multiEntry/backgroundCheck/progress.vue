<template>
	<view class="backgroundSchedule">
		<view class="info-container">
			<view class="first-item">
				<view class="avatar-name">
					<image class="avatar" :src="userInfoObj.avatarUrl" mode=""></image>
					<view class="name">{{peopleInfoOnj.canName}}</view>
				</view>
				<view class="setMeal ">{{peopleInfoOnj.reportVersion}}</view>
			</view>
			<view class="item">
				<view class="lable">开始时间</view>：
				<view class="val">
					{{peopleInfoOnj.year}}年{{peopleInfoOnj.month}}月{{peopleInfoOnj.day}}日
				</view>
			</view>
			<view class="item">
				<view class="lable">委托方</view>：
				<view class="val">{{peopleInfoOnj.canCompany}}</view>
			</view>
			<view class="item">
				<view class="lable">受委托方</view>：
				<view class="val">杭州轩宇人力资有限公司</view>
			</view>
		</view>
		<view class="arc"></view>
		<view class="invite-container">
			<view class="explanation">背调一般在14天内完成，邀请成功可加速1天</view>
			<view class="img-wrapper">
				<view class="list" :style="{width:104*friendList.length+'rpx'}">
					<view class="item" v-for="(item,index) in friendList" :key="item.open_id" @click="onGoFriend(item)">
						<image class="img" :src="item.avatar" mode=""></image>
					</view>
				</view>
			</view>
			<view class="invite-btn" @click="onGoto('invite')">去邀请</view>
			<view class="ranking-btn" @click="onGoto('speedRank')">加速风云榜>></view>
		</view>
		<view class="schedule-container">
			<view class="title">报告进度</view>
			<view class="propress-container">
				<view class="already" :style="{width:rate}"></view>
				<view class="sign-container" :style="{left:rate}">
					<view class="txt">{{rate}}</view>
					<view class="sign-wrapper">
						<view class="triangle "></view>
						<view class="circle "></view>
					</view>
				</view>

			</view>
			<view class="list">
				<view class="line"></view>
				<view class="item" v-for="(item,index) in propressList" :key="index">
					<view class="circle-container iconfont icon-jindubiaodian"
						:class="[step+1>=index?'circle-active':'circle-grey']">
						<view class="circle-above"></view>
					</view>
					<view class="column-1" :class="(step+1>index?'active':(step+1==index?'processing':''))">
						{{item}}
					</view>
					<view class="column-2" :class="(step+1>index?'active':(step+1==index?'processing':''))">
						{{step+1>index?'完成':(step==index?'进行中':'预计')}}
					</view>
					<view class="column-3">{{step+1>index?timeList[index]:(step+1==index?'':'1天')}}</view>
				</view>
			</view>
		</view>
		<view class="FAQ-container">
			<view class="title">答疑解惑</view>
			<textarea class="textarea" :value="val" @input="onInput" placeholder-class="textarea-placeholder"
				placeholder="有任何疑问都可对我留言哟～" />
			<view class="submit-btn" @click="postAsk">提交</view>
			<view class="wechat-list">
				<view class="item" v-for="(item,index) in questionList" :key="index">
					<view class="self" v-if="item.is_official == 0">
						<view class="main">
							<view class="content">
								<view class="txt">{{item.content}}</view>
								<view class="triangle-right"></view>
							</view>
							<image class="avatar" :src="userInfoObj.avatarUrl"></image>
						</view>
						<view class="name-time">{{$util.formatTime(item.create_time)}} {{userInfoObj.nickName}}</view>
					</view>
					<view class="other" v-else>
						<view class="main">
							<image class="avatar" src="/static/img/zhizhen_help.png"></image>
							<view class="content">
								<view class="triangle-left"></view>
								<view class="txt">{{item.content}}</view>

							</view>
						</view>
						<view class="name-time">指真小助手 {{$util.formatTime(item.create_time)}}</view>

					</view>
				</view>

			</view>
		</view>



	</view>
</template>

<script>
	import {
		mapState
	} from "vuex";
	export default {
		data() {
			return {
				peopleInfoOnj: {
					canName: "",
					reportVersion: "",
					canCompany: "",
					year: "",
					month: "",
					day: ""

				},
				friendList: [],
				propressList: ["授权完成", "信息确认", "背景核实", "报告发布", "委托方确认"],
				step: -1,
				timeList: [],
				rate: '0%',
				val: "",
				questionList: []
			}
		},
		computed: {
			...mapState(['userPhone', 'userInfoObj', 'loginInfoObj'])
		},
		onLoad() {
			this.getInfo();
			this.getInviteList();
			this.getProgress();
			this.getQuestionList();

		},
		methods: {
			onGoFriend(item) {
				uni.navigateTo({
					url: `/pages/multiEntry/information?openId=${item.open_id}`
				});
			},
			onGoto(type) {
				if (type == 'speedRank') {
					uni.navigateTo({
						url: '/pages/multiEntry/backgroundCheck/speedRank'
					});
				} else {
					uni.navigateTo({
						url: '/pages/contacts/inviteComments'
					});
				}

			},
			onInput(e) {
				this.val = e.target.value;
			},
			async getInfo() {
				let data = {
					openId: this.loginInfoObj.open_id
				}
				let res = await this.$http.getHasLoad(`/zxxt/issue/getOrderDetail/${this.loginInfoObj.issue_id}`,
					data);
				if (res) {
					//console.log("getInfo:", res)
					let date = new Date(res.data.createDate.time)
					this.peopleInfoOnj = {
						canName: res.data.canName,
						reportVersion: res.data.reportVersion,
						canCompany: res.data.canCompany,
						year: date.getFullYear(),
						month: date.getMonth() + 1,
						day: date.getDate()

					}
				}

			},
			async getInviteList() {
				let data = {
					openId: this.loginInfoObj.open_id
				}
				let res = await this.$http.getHasLoad('/zxxt/user/inviteCertifier', data);
				if (res) {
					console.log('friendList:', res.data)
					this.friendList = res.data;
				}
			},
			async getProgress() {
				let res = await this.$http.getHasLoad(`/zxxt/issue/node/${this.loginInfoObj.issue_id}`);
				//let res = await this.$http.getHasLoad(`/zxxt/issue/node/7552`);
				if (res) {
					console.log("getProgress:", res)
					this.step = Number(res.data.issue_status);
					this.timeList = res.data.task_date_list;

					if (this.step > 2) {
						//console.log("this.step:", this.step)
						this.step = this.step - 1;
						this.timeList.splice(2, 1);
						//console.log("this.step:", this.step)
					}
					switch (this.step) {
						case -1:
							this.rate = "0%";
							break;
						case 0:
							this.rate = "20%";
							break;
						case 1:
							this.rate = "40%";
							break;
						case 2:
							this.rate = "60%";
							break;
						case 3:
							this.rate = "80%";
							break;
						case 4:
							this.rate = "100%";
							break;
						default:
							break;
					}
					this.timeList = this.timeList.slice(0, this.step + 1);
					this.timeList = this.timeList.map(item => {
						return this.$util.formatTime(Number(item) * 1000)
					})
				}
			},
			async postAsk() {
				if (!!this.val) {
					let data = {
						content: this.val,
						member_id: this.loginInfoObj.id
					}
					let res = await this.$http.postHasLoad("/zxxt/inq/addInq", data);
					if (res) {
						this.val = "";
						this.$util.toast("提交成功！");
						this.getQuestionList();

					}
				}
			},
			async getQuestionList() {
				let data = {
					memberId: this.loginInfoObj.id
				}

				let res = await this.$http.getHasLoad('/zxxt/inq/myList', data);
				if (res) {
					this.questionList = res.data.inq_info_vos;
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	.backgroundSchedule {
		position: relative;
		width: 100%;
		overflow: hidden;

		.info-container {
			padding: 0 70rpx;
			color: #FFFFFF;
			height: 450rpx;
			background-color: $uni-color-active;

			.first-item {
				margin-bottom: 40rpx;
				display: flex;
				align-items: flex-end;

				.avatar-name {
					display: flex;
					align-items: center;

					.avatar {
						margin-right: 30rpx;
						width: 80rpx;
						height: 80rpx;
						border-radius: 100rpx;
					}

					.name {
						margin-right: 26rpx;
						font-size: 52rpx;
					}
				}

				.setMeal {
					font-size: 28rpx;
				}
			}

			.item {
				font-size: 28rpx;
				margin-bottom: 10rpx;
				display: flex;
				align-items: center;

				.lable {
					width: 114rpx;
					text-align: justify;
					text-align-last: justify;
				}

				.val {}
			}
		}

		.arc {
			position: absolute;
			top: 335rpx;
			left: -5%;
			z-index: -1;

			width: 110%;
			height: 236rpx;
			background-color: $uni-color-active;

			clip-path: ellipse(50% 40% at 50% 50%);
		}

		.invite-container {
			position: relative;
			top: -150rpx;
			margin: 0 30rpx;
			width: calc(100% - 60rpx);

			background: #FFFFFF;
			box-shadow: 0px 12px 28px 0px rgba(0, 0, 0, 0.2);
			border-radius: 30px;
			padding: 46rpx 40rpx;
			box-sizing: border-box;

			.explanation {
				font-size: 28rpx;
				font-family: Microsoft YaHei;
				font-weight: 400;
				color: $uni-text-color;
				margin-bottom: 36rpx;
				padding: 0 10rpx;
			}

			.img-wrapper {
				width: 100%;
				padding-bottom: 12rpx;
				overflow-x: auto;
				margin-bottom: 30rpx;

				.list {
					display: flex;
					align-items: center;

					.item {
						width: 80rpx;
						height: 80rpx;
						border-radius: 200rpx;
						border: 1rpx dashed $uni-text-color-greyA;
						margin-right: 22rpx;

						.img {
							width: 80rpx;
							height: 80rpx;
							border-radius: 200rpx;

						}
					}
				}
			}

			.invite-btn {
				width: 200rpx;
				height: 60rpx;
				line-height: 60rpx;
				text-align: center;
				background: $uni-color-active;
				border-radius: 30rpx;
				font-size: 28rpx;
				font-family: Microsoft YaHei;
				font-weight: 400;
				color: #FFFFFF;
				margin: 0rpx auto 30rpx;

			}

			.ranking-btn {
				text-align: center;
				font-size: 28rpx;
				font-family: Microsoft YaHei;
				font-weight: 400;
				color: $uni-color-active;
			}
		}

		.schedule-container {
			margin-top: -94rpx;
			padding: 0 30rpx;


			.title {
				margin-bottom: 42rpx;
				font-size: 30rpx;
				color: $uni-color-active;
			}

			.propress-container {
				margin-bottom: 40rpx;
				width: 100%;
				height: 20rpx;
				padding: 6rpx;
				box-sizing: border-box;
				background: #EEEEEE;
				border-radius: 10rpx;
				position: relative;

				.sign-container {
					position: absolute;
					top: -46rpx;
					margin-left: -10rpx;

					.txt {
						margin-left: -14rpx;
						margin-bottom: 6rpx;
						font-size: 20rpx;
						color: $uni-color-active;
					}

					.sign-wrapper {
						.triangle {
							margin-left: 6rpx;
							margin-bottom: -6rpx;
							width: 0;
							height: 0;
							border-left: 8rpx solid transparent;
							border-right: 8rpx solid transparent;
							border-bottom: 16rpx solid $uni-color-active;
						}

						.circle {
							width: 26rpx;
							height: 26rpx;
							background: $uni-color-active;
							border-radius: 100rpx;
						}
					}


				}

				.already {
					height: 8rpx;
					background: $uni-color-active;
					border-radius: 3rpx;
				}
			}

			.list {
				position: relative;

				.line {
					height: 90%;
					position: absolute;
					top: 5%;
					left: 10rpx;
					z-index: 0;
					width: 2rpx;
					background: #EEEEEE;
					;
				}

				.item {
					font-size: 24rpx;
					color: $uni-text-color-greyA;
					margin-bottom: 30rpx;
					display: flex;
					align-items: center;

					.circle-container {
						font-size: 20rpx;
						margin-right: 42rpx;
						position: relative;

						.circle-above {
							position: absolute;
							left: 50%;
							top: 50%;
							transform: translate(-50%, -50%);
							width: 50%;
							height: 50%;
							background: #fff;
							border-radius: 100rpx;
						}
					}

					.circle-grey {
						color: $uni-text-color-greyA;
					}

					.circle-active {
						color: $uni-color-active;
					}

					.column-1 {
						width: 240rpx;
						text-align: left;
					}

					.column-1.active {
						color: $uni-color-active;
					}

					.column-1.processing {
						color: $uni-text-color;
					}

					.column-2 {
						width: 160rpx;
						text-align: left;
					}

					.column-2.active {
						color: $uni-color-active;
					}

					.column-2.processing {
						color: $uni-color-search-match;
					}



					.column-3 {
						flex: 1;
						text-align: center;
					}
				}
			}
		}


		.FAQ-container {
			margin-top: 60rpx;
			border-top: 1rpx solid $uni-border-color;
			padding: 35rpx 30rpx;

			.title {
				font-size: 30rpx;
				color: $uni-color-active;
			}

			.textarea {
				width: 100%;
				height: 200rpx;
				font-size: 24rpx;
				margin-top: 30rpx;
				background-color: #F7F7F7;
				color: $uni-text-color;
				padding: 24rpx 20rpx;
				box-sizing: border-box;
			}

			.textarea-placeholder {
				color: $uni-text-color-greyA;
			}

			.submit-btn {
				width: 200rpx;
				height: 60rpx;
				border-radius: 30rpx;
				background-color: $uni-color-active;
				font-size: 28rpx;
				color: #fff;
				text-align: center;
				line-height: 60rpx;
				margin: 35rpx auto 84rpx;
			}

			.wechat-list {
				.item {
					margin-bottom: 20rpx;

					.self {
						margin-bottom: 5rpx;

						.main {
							display: flex;
							align-items: center;
							justify-content: flex-end;

							.content {
								margin-right: 10rpx;
								display: flex;
								align-items: center;

								.txt {
									padding: 28rpx;
									border-radius: 12rpx;
									background-color: #65E6C7;
									color: #333;
									word-break: break-word;
								}

								.triangle-right {
									width: 0;
									height: 0;
									border-top: 10rpx solid transparent;
									border-left: 15rpx solid #65E6C7;
									border-bottom: 10rpx solid transparent;
								}
							}
						}

						.name-time {
							font-size: 24rpx;
							text-align: right;
							color: $uni-text-color-greyA;
						}

					}

					.other {
						margin-bottom: 5rpx;

						.main {
							display: flex;
							align-items: center;
							justify-content: flex-start;

							.content {
								margin-left: 10rpx;
								display: flex;
								align-items: center;

								.txt {
									padding: 28rpx;
									border-radius: 12rpx;
									background-color: #EAEAEA;
									color: #333;
									word-break: break-word;
								}

								.triangle-left {
									width: 0;
									height: 0;
									border-top: 10rpx solid transparent;
									border-right: 15rpx solid #EAEAEA;
									border-bottom: 10rpx solid transparent;
								}
							}

						}

						.name-time {
							font-size: 24rpx;
							text-align: left;
							color: $uni-text-color-greyA;
						}
					}

					.avatar {
						width: 80rpx;
						height: 80rpx;
						min-width: 80rpx;
						border-radius: 200rpx;
					}
				}

			}
		}

	}
</style>
