<template>
	<view>
		<view class="main">
			<view class="top">
				<image :src="friendDetail.avatar ? friendDetail.avatar : '/static/img/anonymity.png'" class="headimg"
					mode="widthFix"></image>
			</view>
			<view class="name">
				{{friendDetail.user_name ? friendDetail.user_name : ''}}
				<!-- <text class="nametext">{{friendDetail.area}}</text> -->
			</view>
			<view class="position" v-if="friendDetail.area">
				{{friendDetail.area}}
			</view>
			<view class="company" v-if="friendDetail.company_name">
				{{friendDetail.company_name}}
			</view>
			<view class="position" v-if="friendDetail.position_name">
				{{friendDetail.position_name}}
			</view>
			<view class="friend" v-if="friendDetail.div == 2 || friendDetail.div == 3">
				<!-- {{friendDetail.common_friends ? friendDetail.common_friends : '0'}}位共同朋友 -->
				{{friendDetail.div == 2 ? ('二度人脉'+friendDetail.div_count+'人') : (friendDetail.div == 3 ? '三度人脉' : '')}}
			</view>
			<template v-if="operation == 2">
				<view class="btn">
					<view class="delhe" @click="deleteRequest">
						忽略
					</view>
					<view class="addhe" @click="addThisfriend2">
						加好友
					</view>
				</view>
			</template>
			<template v-if="operation == 3">
				<view class="btn" style="justify-content: center">
					<view class="operation">已忽略</view>
				</view>
			</template>
			<template v-if="operation == 0">
				<view class="btn" style="justify-content: center">
					<view class="operation">已申请</view>
				</view>
			</template>
			<view class="top-tab">
				<view class="tabson">
					<view class="tabsons">
						<view class="tabitem">
							<view :class="tapFlag == 0 ? 'tabitemname actcol' : 'tabitemname'" @click="personalInfo">
								个人信息
							</view>
							<view class="actbor" v-if="tapFlag == 0"></view>
						</view>
						<view class="tabitem">
							<view :class="tapFlag == 1 ? 'tabitemname actcol' : 'tabitemname'" @click="friendEvaluate">
								好友评价
							</view>
							<view class="actbor" v-if="tapFlag == 1"></view>
						</view>
					</view>
				</view>
			</view>
			<view class="info">
				<!-- 工作教育经历 -->
				<view class="exAndedu" v-if="tapFlag == 0">
					<view class="exercise">
						<view class="title">工作经历</view>
						<view class="content" v-for="(item,index) in friendDetail.record_vo_list" :key="index">
							<view class="content_company">{{item.name?item.name:''}}</view>
							<view class="base_content content_position">{{item.position?item.position:''}}</view>
						</view>
					</view>
					<view class="education">
						<view class="title">教育经历</view>
						<view class="content" v-for="(item,index) in friendDetail.education_vo_list" :key="index">
							<view class="base_content content_shool" style="color: #000;">
								{{item.school_name?item.school_name:''}}
							</view>
							<view class="content_major" style="color: #999;">
								{{item.education?item.education:item.major}}
							</view>
						</view>
					</view>
					<view v-if="friendDetail.log_evaluate == 1" class="dianping" @tap="toPing">
						一键点评
					</view>
					<view v-if="friendDetail.log_evaluate == 2" class="dianping" @tap="toseePing">
						查看评价
					</view>
				</view>

				<view class="friend-evaluate" v-else>
					<!-- 点评 -->
					<view class="friend-commend">
						<view class="commend-header">
							<view class="header-left">
								<view class="left-text">TA被点评</view>
							</view>
							<view class="header-right" @tap="goEvaluate">
								<view class="right-text">{{friendDetail.user_text_evaluate.length}}</view>
								<image src="../../static/img/link-right.svg" class="link-right"></image>
							</view>
						</view>
						<view v-if="friendDetail.user_text_evaluate.length > 0" class="commend-body">
							<image v-if="friendDetail.user_text_evaluate[0].if_anonymity == 1"
								src="../../static/img/head_man.svg" class="commend-avatar"></image>
							<image v-if="friendDetail.user_text_evaluate[0].if_anonymity != 1"
								:src="friendDetail.user_text_evaluate[0].avatar?friendDetail.user_text_evaluate[0].avatar:''"
								class="commend-avatar"></image>
							<view class="company-info">
								<view class="commend-detail">
									<text v-if="friendDetail.user_text_evaluate[0].if_anonymity != 1"
										class="commend_name">{{friendDetail.user_text_evaluate[0].user_name?friendDetail.user_text_evaluate[0].user_name:''}}</text>
									<text v-if="friendDetail.user_text_evaluate[0].if_anonymity == 1"
										class="commend_name">访客</text>
									<text v-if="friendDetail.user_text_evaluate[0].if_anonymity != 1"
										class="commend_position">{{friendDetail.user_text_evaluate[0].position_name?friendDetail.user_text_evaluate[0].position_name:''}}</text>
								</view>
								<view v-if="friendDetail.user_text_evaluate[0].if_anonymity != 1"
									class="commend-company">
									{{friendDetail.user_text_evaluate[0].company_name?(friendDetail.user_text_evaluate[0].company_name):''}}
								</view>
							</view>
						</view>
						<view class="commend-foot">
							{{friendDetail.user_text_evaluate[0].text_evaluate?friendDetail.user_text_evaluate[0].text_evaluate:''}}
						</view>
					</view>
					<!-- 印象 -->
					<view class="friend-impression">
						<view class="impression-header">
							<view class="header-left">
								<view class="left-text">TA的印象</view>
							</view>
							<view class="header-right" @tap="goImpression">
								<view class="right-text">{{friendDetail.user_labels.length}}</view>
								<image src="../../static/img/link-right.svg" class="link-right"></image>
							</view>
						</view>
						<!-- <view v-if="friendDetail.user_labels && (friendDetail.user_labels.length > 0)"
							class="impression-body">
							<block v-for="(item,index) in friendDetail.user_labels" :key="index">
							<view v-if="JSON.parse(item.labels)[0]" class="impression-item">
								{{JSON.parse(item.labels)[0] ? JSON.parse(item.labels)[0] : ""}}
								<view class="bradge" v-if="item.num >= 2">{{item.num}}</view>
							</view>
							</block>
						</view> -->
						<view class="impression-body" v-if="newMyUserLabels.length > 0">
							<view v-for="(item,index) in newMyUserLabels" :key="index" class="impression-item">
								{{item.label}}
								<view class="bradge" v-if="item.num >= 2">{{item.num}}</view>
							</view>
						</view>
					</view>
					<!-- 评分 -->
					<view class="friend-score">
						<view class="commend-header">
							<view class="header-left">
								<view class="left-text">TA的评分</view>
							</view>
							<view class="header-right" @tap="goScore">
								<view class="right-text">{{friendDetail.user_total_score.length}}</view>
								<image src="../../static/img/link-right.svg" class="link-right"></image>
							</view>
						</view>
						<view class="commend-body"
							v-if="friendDetail.user_total_score && friendDetail.user_total_score.length > 0">
							<image v-if="friendDetail.user_total_score[0].if_anonymity == 1"
								src="../../static/img/head_man.svg" class="commend-avatar" mode="aspectFit"></image>
							<image v-if="friendDetail.user_total_score[0].if_anonymity != 1" mode="aspectFit"
								:src="friendDetail.user_total_score[0].avatar?friendDetail.user_total_score[0].avatar:''"
								class="commend-avatar"></image>
							<view class="company-info" style="width: 240rpx;">
								<view class="commend-detail">
									<text v-if="friendDetail.user_total_score[0].if_anonymity != 1"
										class="commend_name name_limit">{{friendDetail.user_total_score[0].user_name?friendDetail.user_total_score[0].user_name:''}}</text>
									<text v-if="friendDetail.user_total_score[0].if_anonymity == 1"
										class="commend_name name_limit">访客</text>
									<text v-if="friendDetail.user_total_score[0].if_anonymity != 1"
										class="commend_position position_limit">{{friendDetail.user_total_score[0].position_name?friendDetail.user_total_score[0].position_name:''}}</text>
								</view>
								<view v-if="friendDetail.user_total_score[0].if_anonymity != 1"
									class="commend-company company_limit">
									{{friendDetail.user_total_score[0].company_name?friendDetail.user_total_score[0].company_name:''}}
								</view>
							</view>
							<view class="commend-foot" style="width: 200rpx;">
								<view class="score-num">
									{{friendDetail.user_total_score[0].total_score?friendDetail.user_total_score[0].total_score:'0'}}
								</view>
								<view class="score-text">综合评分</view>
							</view>
						</view>
					</view>
					<view v-if="friendDetail.log_evaluate == 1" class="dianping" @tap="toPing">
						一键点评
					</view>
					<view v-if="friendDetail.log_evaluate == 2" class="dianping" @tap="toseePing">
						查看评价
					</view>
				</view>

			</view>
		</view>
		<vWantToKnow :outId="outerid ? outerid : hisopenid"></vWantToKnow>
	</view>
</template>

<script>
	/**
	 * 猜你认识  
	 */
	import vWantToKnow from "components/common/vWantToKnow"
	import {
		mapState
	} from "vuex";
	export default {
		components: {
			vWantToKnow
		},
		data() {
			return {
				tapFlag: 0, // tap显示
				relationstates: 1, //是否是好友，1是 2否
				friendDetail: {}, //好友详情对象

				hisphone: '', //手机号
				operation: 0, //操作关系 2已忽略 1已申请
				hisopenid: '', //
				flag: 0, //被查看人属于哪一类别，0推荐 1同事 2同学 5同行，用于从人脉页进入

				username: '', //人脉搜索页面接受用户名
				newMyUserLabels: [],
				outerid: '', //
				onshowFlag: 0,
			}
		},

		computed: {
			...mapState(['loginInfoObj'])
		},

		mounted() {
			this.getFriendDetail()
		},

		onLoad(options) {
			//  options={
			//   	outerid:征信过来数据库id;被查看人的outerid，用于获取页面详细信息
			//   	phone:被查看人手机号，用于添加好友
			//   	hisopenid:被查看人openid，用于添加好友，获取详情
			// }   
			  options.outerid == "''"?options.outerid ="":options.outerid;
			
			this.outerid = options.outerid ? options.outerid :''//被查看人的outerid，用于获取页面详细信息
			this.hisphone = !!options.phone ? options.phone : '' //被查看人手机号，用于添加好友
			if (options.hisopenid) { //被查看人openid，用于添加好友，获取详情
				if (options.hisopenid == "null") {
					this.hisopenid = ''
				} else {
					this.hisopenid = options.hisopenid
				}
			}
		},

		onShow() {
			this.onshowFlag++
			// 重新获取猜你认识列表
			if (this.onshowFlag != 1) {}
		},

		methods: {
			// 去一键点评
			toPing() {
				console.log('this.hisphone = ', this.hisphone)
				let hisopenid = this.hisopenid
				let phone = this.hisphone
				let username = this.friendDetail.user_name
				let outerid = this.outerid
				uni.navigateTo({
					url: '/pages/multiEntry/comment?hisopenid=' + hisopenid + '&hisphone=' + phone + '&username=' +
						username + '&outerid=' + outerid,
				})
			},
			// 去查看评价
			toseePing() {
				let hisopenid = this.hisopenid
				let phone = this.hisphone
				let outerid = this.outerid
				wx.navigateTo({
					url: '/pages/evaluate/evaluationInfo?hisopenid=' + hisopenid + '&hisphone=' + phone +
						'&outerid=' + outerid,
				})
			},
			// 个人信息按钮
			personalInfo() {
				this.tapFlag = 0
			},

			//好友评价按钮
			friendEvaluate() {
				this.tapFlag = 1
			},

			// 忽略
			async deleteRequest() {
				let params = {
					open_id: this.loginInfoObj.open_id,
					can_phone: this.hisphone,
				}
				
				let res = await this.$http.postHasLoad('/zxxt/user/neglectRecommend', params);
				uni.showToast({
					title: '已忽略',
					icon: 'none',
					duration: 2000
				})
				this.operation = 3
			},

			// 添加好友
			async addThisfriend2() {
				let params = {
					open_id: this.loginInfoObj.open_id,
					can_phone: this.hisphone != "null" ? this.hisphone : '',
					re_open_id: this.hisopenid
				}
				let res = await this.$http.postHasLoad('/zxxt/user/addFriend', params);
				uni.showToast({
					title: '请求已发送',
					icon: 'none',
					duration: 2000
				})
				this.operation = 0
			},

			// 获取好友详情信息
			async getFriendDetail() {
				if (!this.hisopenid && !this.outerid) {
					this.$util.toast("opent或outerID 必传")
					return
				}
				let params = {
					openId: this.loginInfoObj.open_id,
					// phone: this.hisphone ? this.hisphone : '',
					lookUserId: this.hisopenid,
					// flag:this.flag ? this.flag : '',
					// userName:this.username ? this.username : '',
					outerId: this.outerid ? this.outerid : ''
				}
				let res = await this.$http.getHasLoad('/zxxt/user/friendMessage', params);
				this.operation = res.data.states

				var friendDetail = res.data
				if (friendDetail.area) { // 处理地区
					friendDetail.area = friendDetail.area.split(',').join(' ')
				}
				if (friendDetail.user_labels && friendDetail.user_labels.length > 6) { // 处理印象标签
					friendDetail.user_labels = friendDetail.user_labels.splice(0, 6)
				}

				// 处理标签为空的情况
				friendDetail.user_labels = friendDetail.user_labels.filter((item, index) => {
					return JSON.parse(item.labels).length != 0
				})
				// 处理外层标签重复问题
				var myUserLabels = friendDetail.user_labels
				var tempArr = []
				var newMyUserLabels = []
				myUserLabels.forEach((item, index) => {
					if (item.labels && (tempArr.indexOf(JSON.parse(item.labels)[0]) == -1)) {
						// 不包含
						newMyUserLabels.push({
							label: JSON.parse(item.labels)[0],
							num: 1
						})
						tempArr.push(JSON.parse(item.labels)[0])
					} else if (item.labels && (tempArr.indexOf(JSON.parse(item.labels)[0]) > -1)) {
						// 包含
						newMyUserLabels[tempArr.indexOf(JSON.parse(item.labels)[0])].num++
					}
				})
				this.newMyUserLabels = newMyUserLabels

				uni.setStorageSync('receivebaseInfo', friendDetail) // 缓存中存入信息,以便会话时信息展示
				this.friendDetail = friendDetail
				if (!!this.friendDetail.can_phone) {
					this.hisphone = this.friendDetail.can_phone
				}
			},

			// 点击返回
			goBack() {
				uni.navigateBack({
					delta: 1
				});
			},

			// 去点评
			goEvaluate() {
				var evaluateInfo = this.friendDetail.user_text_evaluate
				if (evaluateInfo) {
					this.$store.commit('submitvaluateDetail', this.friendDetail)
					uni.navigateTo({
						url: '/pages/multiEntry/evaluatedetail?tapFlag=0',
					})
				}
			},

			// 去印象
			goImpression() {
				var impressionInfo = this.friendDetail.user_labels
				if (impressionInfo) {
					// app.globalData.impressionInfo = impressionInfo
					this.$store.commit('submitvaluateDetail', this.friendDetail)
					wx.navigateTo({
						url: '/pages/multiEntry/evaluatedetail?tapFlag=1',
					})
				}
			},

			// 去评分
			goScore() {
				var scoreInfo = this.friendDetail.user_total_score
				if (scoreInfo) {
					this.$store.commit('submitvaluateDetail', this.friendDetail)
					wx.navigateTo({
						url: '/pages/multiEntry/evaluatedetail?tapFlag=2',
					})
				}
			}

		}
	}
</script>
<style>
	page {
		background-color: #f3f3f3;
		box-sizing: border-box;
		padding: 50rpx 55rpx;
	}
</style>
<style lang="scss" scoped>
	.main {
		width: 640rpx;
		height: auto;
		background: #FFFFFF;
		border-radius: 20rpx;
		overflow: hidden;
	}

	.top {
		width: 100%;
		height: 130rpx;
		background-color: #209072;
		box-sizing: border-box;
		padding-top: 51rpx;
		text-align: center;

		.headimg {
			width: 158rpx !important;
			height: 158rpx !important;
			border-radius: 50%;
		}
	}

	.name {
		width: 100%;
		height: 35rpx;
		text-align: center;
		line-height: 35rpx;
		font-size: 35rpx;
		color: #333;
		margin-top: 107rpx;
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;

		.nametext {
			color: #aaa;
			font-size: 24rpx;
			margin-left: 15rpx;
		}
	}

	.company {
		width: 100%;
		height: 25rpx;
		font-size: 24rpx;
		font-weight: 400;
		color: #333333;
		text-align: center;
		line-height: 25rpx;
		margin-top: 24rpx;
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
	}

	.position {
		width: 100%;
		height: 24rpx;
		font-size: 24rpx;
		font-weight: 400;
		color: #aaa;
		text-align: center;
		line-height: 24rpx;
		margin-top: 12rpx;
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
	}

	.friend {
		width: 100%;
		height: 24rpx;
		font-size: 24rpx;
		font-weight: 400;
		color: #aaa;
		text-align: center;
		line-height: 24rpx;
		margin-top: 29rpx;
	}

	.btn {
		width: 100%;
		height: 60rpx;
		margin-top: 50rpx;
		box-sizing: border-box;
		padding: 0 100rpx;
		display: flex;
		justify-content: space-between;
		align-items: center;

		.delhe {
			width: 200rpx;
			height: 60rpx;
			border: 2rpx solid #209072;
			color: #209072;
			font-size: 28rpx;
			border-radius: 30rpx;
			display: flex;
			justify-content: center;
			align-items: center;
		}

		.addhe {
			width: 200rpx;
			height: 60rpx;
			background: #209072;
			color: #fff;
			font-size: 28rpx;
			border-radius: 30rpx;
			display: flex;
			justify-content: center;
			align-items: center;
		}

		.operation {
			width: 200rpx;
			height: 60rpx;
			border: 2rpx solid #999;
			color: #999;
			font-size: 28rpx;
			border-radius: 30rpx;
			display: flex;
			justify-content: center;
			align-items: center;
		}
	}

	.top-tab {
		width: 100%;
		height: 105rpx;
		box-sizing: border-box;
		padding: 0 60rpx;

		.tabson {
			width: 100%;
			height: 105rpx;
			box-sizing: border-box;
			display: flex;
			justify-content: flex-start;
			padding-top: 63rpx;

			.tabsons {
				display: flex;
				justify-content: flex-start;
				flex-direction: row;

				.tabitem {
					width: 120rpx;
					height: 52rpx;
					display: flex;
					flex-direction: column;
					justify-content: flex-start;
					align-items: center;
					margin-right: 87rpx;

					.tabitemname {
						font-size: 30rpx;
						line-height: 30rpx;
						color: #333;
						margin-bottom: 12rpx;
					}

					.actbor {
						width: 40rpx;
						height: 4rpx;
						background: #209072;
						border-radius: 2rpx;
					}

					.actcol {
						color: #209072 !important;
					}
				}
			}
		}
	}

	.info {
		width: 100%;
		box-sizing: border-box;
		padding: 0 50rpx;
		height: auto;

		.exercise {
			padding: 42rpx 0;
			border-bottom: 1px solid #209072;

			.content {
				display: flex;
				flex-direction: column;
				justify-content: space-around;
				box-sizing: border-box;
				padding: 20rpx 0;
				border-bottom: 1rpx solid #e1e1e1;
				min-height: 140rpx;

				.base_content {
					color: #999;
				}
			}

			.content:last-child {
				border: 0;
			}
		}

		.education {
			padding: 42rpx 0;

			// border-bottom: 1px solid #ccc;
			.content {
				display: flex;
				flex-direction: column;
				justify-content: space-around;
				box-sizing: border-box;
				padding: 20rpx 0;
				border-bottom: 1rpx solid #e1e1e1;
				min-height: 140rpx;

				.base_content {
					color: #999;
				}
			}

			.content:last-child {
				border: 0;
			}
		}

		.title {
			font-size: 32rpx;
			color: #209072;
			font-weight: bold;
		}

		.base_content {
			// margin: 28rpx 0;
		}

		.btnArea {
			position: fixed;
			left: 0;
			bottom: 25rpx;
			display: flex;
			justify-content: center;
			align-items: center;
			width: 100%;
			height: 80rpx;
			background-color: #fff;

			.base_btn {
				height: 72rpx;
				width: 260rpx;
				border: 2px solid #209072;
				border-radius: 36rpx;
			}

			.sendMessage {
				text-align: center;
				line-height: 72rpx;
				margin-right: 60rpx;
				background-color: #209072;
				color: #fff;
			}

			.moreOption {
				text-align: center;
				line-height: 72rpx;
				color: #209072;
			}
		}

		// 好友评价
		.friend-evaluate {
			border-radius: 6px;
			padding: 16px 0;
			background-color: #fff;
			min-height: 120px;
		}

		.friend-commend {
			padding-bottom: 10px;
			border-bottom: 1px solid #e0e0e0;
		}

		.link-right {
			width: 20px;
			height: 20px;
		}

		.commend-header {
			width: 100%;
			display: flex;
			justify-content: space-between;
			align-items: center;
		}

		.header-left {
			width: 50%;
			height: 26px;
			position: relative;
			display: flex;
			align-items: center;
		}

		.left-text {
			position: absolute;
			left: 0;
			top: 0;
			font-size: 30rpx;
			font-weight: bold;
			color: #209072;
			z-index: 1;
		}

		.left-bg {
			position: absolute;
			right: 0;
			bottom: 0;
			width: 60px;
			height: 12px;
			background-color: #DDF3ED;
		}

		.right-text {
			color: #999;
			font-size: 12px;
		}

		.header-right {
			display: flex;
			justify-content: space-between;
			align-items: center;
		}

		.commend-body {
			display: flex;
			align-items: center;
			margin: 8px 0;

			.commend-avatar {
				width: 80rpx;
				height: 80rpx;
				border-radius: 50%;
			}

			.company-info {
				margin-left: 16rpx;

				.commend-detail {
					margin-bottom: 19rpx;
				}

				.commend_name {
					font-size: 34rpx;
					color: #209072;
				}

				.commend_position {
					color: #AAAAAA;
					font-size: 24rpx;
					margin-left: 17rpx;
				}

				.commend-company {
					font-size: 28rpx;
					color: #999999;
				}
			}
		}

		// 印象
		.friend-impression {
			// min-height: 92px;
			padding-bottom: 10px;
			margin: 12px 0;
			border-bottom: 1px solid #e0e0e0;
		}

		.impression-header {
			display: flex;
			justify-content: space-between;
			align-items: center;
		}

		.impression-body {
			padding: 10px 0;
			height: 156rpx;
		}

		.impression-item {
			position: relative;
			float: left;
			width: 150rpx;
			height: 60rpx;
			font-size: 26rpx;
			color: #4A9163;
			border: 2px solid #CEE3D5;
			border-radius: 30rpx;
			text-align: center;
			line-height: 60rpx;
			margin: 0 10px 10px 0;

			.bradge {
				position: absolute;
				right: 0;
				top: -10rpx;
				width: 30rpx;
				height: 30rpx;
				line-height: 30rpx;
				text-align: center;
				font-size: 20rpx;
				color: #fff;
				border-radius: 50%;
				background-color: #209072;
			}
		}

		// 评分
		.friend-score {
			border-bottom: 1px solid #e0e0e0;
			padding-bottom: 22rpx;

			.name_limit {
				max-width: 52rpx;
				white-space: nowrap;
				overflow: hidden;
				text-overflow: ellipsis;
			}

			.position_limit {
				max-width: 96rpx;
				white-space: nowrap;
				overflow: hidden;
				text-overflow: ellipsis;
			}

			.company_limit {
				max-width: 226rpx;
				white-space: nowrap;
				overflow: hidden;
				text-overflow: ellipsis;
			}

			.commend-foot {
				display: flex;
				flex-direction: column;
				justify-content: center;
				align-items: center;
				// padding-left: 90rpx;
				// margin-left: 90rpx;
				border-left: 1px solid #bbb;

				.score-num {
					font-size: 60rpx;
					font-weight: bold;
					color: #333333;
					margin-bottom: 10rpx;
				}

				.score-text {
					font-size: 24rpx;
					color: #AAAAAA;
				}
			}
		}
	}

	.dianping {
		width: 200rpx;
		height: 60rpx;
		display: flex;
		align-items: center;
		justify-content: center;
		color: #fff;
		font-size: 28rpx;
		background: #209072;
		border-radius: 30rpx;
		margin: 70rpx 0 70rpx 33%;
	}
</style>
