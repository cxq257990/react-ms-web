<template>
	<view class="body">
		<view class="top1">
			综合评价
		</view>
		<view class="info">
			<view class="infoitem">
				<view class="inp">
					<picker class="pickf" @change="bindRelationChange" :value="relationindex" :range="relationarray">
						<view class="pickeritem">
							{{relationindex == null ? "您和TA的关系" : relationarray[relationindex]}}
							<view class="iconfont icon-s-xiangxia icon-xia"></view>
						</view>
					</picker>
				</view>
			</view>
			<view class="infoitem">
				<view class="inp bor" v-if="relationindex != null && relationindex == 0">
					<picker class="pickf" @change="bindCompanyChange" :value="companyindex" :range="companyarray"
						:range-key="'name'">
						<view class="pickeritem">
							{{companyindex == null ? "请选择共事公司" : companyarray[companyindex].name}}
							<view class="iconfont icon-s-xiangxia icon-xia"></view>
						</view>
					</picker>
				</view>
			</view>
			<view class="infoitem">
				<view class="inp bor" v-if="relationindex != null && relationindex == 1">
					<picker class="pickf" @change="bindSchoolChange" :value="schoolindex" :range="schoolarray"
						:range-key="'school_name'">
						<view class="pickeritem">
							{{schoolindex == null ? "请选择共同院校" : schoolarray[schoolindex].school_name}}
							<view class="iconfont icon-s-xiangxia icon-xia"></view>
						</view>
					</picker>
				</view>
			</view>
			<view class="infoitem">
				<view class="inp bor"
					v-if="(companyarray[companyindex].name == '其他' && relationindex == 0) || (schoolarray[schoolindex].school_name == '其他' && relationindex == 1)"
					style="padding: 0 20rpx;box-sizing: border-box;">
					<view class="inpson" @tap="toAddInfo">
						<view class="inpson-l">
							<view class="iconfont icon-s-tianjia icon-add"></view>
							<view class="inpson-ltitle">
								添加{{relationindex == 0 ? '工作' : relationindex == 1 ? '教育' : ''}}履历</view>
						</view>
						<view class="iconfont icon-s-xiangyou icon-r"></view>
					</view>
				</view>
			</view>
			<view class="infoitem">
				<view class="tex bor">
					<textarea class="inptext" placeholder="您可以从TA的人品、专业、相处感觉等多方面进行点评，建议结合具体事迹。(字数大于8个字)"
						placeholder-style="color:#aaa;line-height: 45rpx;font-size: 26rpx;" v-model="wantsay"
						@input="inputWantsay" />
				</view>
			</view>
		</view>
		<view class="btn" @click="toNext">
			下一步
		</view>
		<view class="tips">
			<view>小提示：</view>
			<view>人脉关系选择为同事类人脉/老师/同学时，若无相应的公司/学校选项，请选择"其他"选项，并在出现的"添加共事职业履历"、"添加教育履历"栏，完善相应信息，新增信息将实时同步。</view>
		</view>
	</view>
</template>

<script>
	/**
	 * 一键点评
	 */
	export default {
		data() {
			return {
				relationarray: ['同事', '同学', '同行', '其他'],
				relationindex: null, //
				companyarray: [],
				companyindex: null, //
				schoolarray: [],
				schoolindex: null, //
				wantsay: '',
				openid: '', //本人openid
				hisopenid: '', //被评价人的openid

				first: true, //用于限制onshow
				hisphone: '',
				username: '',
				outerid: '',
			}
		},
		onLoad(options) {
			this.outerid = options.outerid ? options.outerid : "";
			this.hisopenid = options.hisopenid
			this.hisphone = options.hisphone ? options.hisphone : ''
			this.username = options.username
			this.openid = uni.getStorageSync("loginInfoObj").open_id //提交人openid
		},
		onShow() {
			if (!this.first) {
				this.relationindex = null
				this.companyindex = null
				this.schoolindex = null
			}
		},
		methods: {
			//去添加信息
			toAddInfo() {
				this.first = false
				if (this.relationindex == 0) {
					uni.navigateTo({
						url: '/pages/my/myRecord/exerciseDetail'
					})
				}
				if (this.relationindex == 1) {
					uni.navigateTo({
						url: '/pages/my/myRecord/exerciseDetail'
					})
				}
			},

			//综合评价内容
			inputWantsay(e) {
				this.wantsay = e.target.value
			},

			// 监听  选择关系
			bindRelationChange: function(e) {
				this.relationindex = e.target.value
				this.getlist()
			},

			// 监听 - 共事公司
			bindCompanyChange: function(e) {
				this.companyindex = e.target.value
			},

			// 监听 - 共同院校
			bindSchoolChange: function(e) {
				this.schoolindex = e.target.value
			},

			// 获取 - 共同院校和公司列表数据
			async getlist() {
				let that = this
				let params = {
					openId: this.openid,
					iphone: this.hisphone
				}
				let res = await this.$http.getHasLoad('/zxxt/user/inviteMessage', params)
				if (res.code == 'success') {
					that.companyarray = res.data.record_vo_list
					that.schoolarray = res.data.education_vo_list
				}
				that.companyarray.push({
					name: '其他'
				})
				that.schoolarray.push({
					school_name: '其他'
				})
			},

			//下一步
			toNext() {
				let that = this
				let commonid = 0 //共事单位或学校id
				let re_states //0同事，1同学，2战友，3亲属，4群聊，5同行，6其他',
				if (that.relationindex == 0 && that.companyindex) { //同事
					commonid = that.companyarray[that.companyindex].id
					re_states = 0
				}
				if (that.relationindex == 1 && that.schoolindex) { //同学
					commonid = that.schoolarray[that.schoolindex].id
					re_states = 1
				}
				if (that.relationindex == 2) { //同行
					re_states = 5
				}
				if (that.relationindex == 3) { //其他
					re_states = 6
				}
				if (!that.relationindex) {
					return uni.showToast({
						title: '请选择关系',
						icon: 'none',
						duration: 2000
					})
				}
				if ((that.relationindex == 0 && that.companyindex == null) || (that.relationindex == 0 && that
						.companyarray[that.companyindex].name == '其他')) {
					return uni.showToast({
						title: '请选择共同公司',
						icon: 'none',
						duration: 2000
					})
				}
				if ((that.relationindex == 1 && that.schoolindex == null) || (that.relationindex == 1 && that.schoolarray[
						that.schoolindex].school_name == '其他')) {
					return uni.showToast({
						title: '请选择共同学校',
						icon: 'none',
						duration: 2000
					})
				}
				console.log(that.wantsay.length)
				if (that.wantsay == '') {
					return uni.showToast({
						title: '请填写综合评价',
						icon: 'none',
						duration: 2000
					})
				}
				if (0 < that.wantsay.length && that.wantsay.length < 8) {
					return uni.showToast({
						title: '综合评价字数需大于8个字',
						icon: 'none',
						duration: 2000
					})
				}
				if (that.wantsay.length > 50) {
					return uni.showToast({
						title: '综合评价字数不得大于50字',
						icon: 'none',
						duration: 2000
					})
				}
				console.log(that.hisphone)
				uni.navigateTo({
					url: '/pages/evaluate/evaluationScore?openid=' + that.hisopenid + '&states=' + re_states +
						'&commonid=' + commonid + '&textevaluate=' + that.wantsay + '&logEvaluate=2&hisphone=' +
						that.hisphone + '&username=' + that.username + '&outerid=' + that.outerid
				})
			},
		}
	}
</script>

<style>
	page {
		background: #F7F7F7;
	}
</style>

<style lang="scss" scoped>
	.top1 {
		font-size: 48rpx;
		margin: 36rpx 0 38rpx 32rpx;
		line-height: 48rpx;
		font-weight: 400;
		color: #333333;
	}

	.top2 {
		font-size: 28rpx;
		font-weight: 400;
		color: #333333;
		line-height: 28rpx;
		margin: 24rpx 0 42rpx 33rpx;
	}

	.bor {
		border-top: 1rpx solid #E0E0E0;
	}

	.info {
		width: 100%;
		height: 672rpx;
		box-sizing: border-box;
		background-color: #fff;

		.infoitem {
			width: 100%;
			box-sizing: border-box;
			padding: 0 34rpx;
			background-color: #fff;

			.inp {
				width: 100%;
				height: 89rpx;
				box-sizing: border-box;
				background-color: #fff;

				.pickf {
					width: 100%;
					height: 88rpx;
					box-sizing: border-box;
					font-size: 32rpx;
					color: #666;
					padding-right: 16rpx;

					.pickeritem {
						width: 100%;
						display: flex;
						justify-content: space-between;
						align-items: center;
						color: #666;
						height: 88rpx;

						.icon-xia {
							font-size: 26rpx;
							color: #aaa;
						}
					}
				}

				.inpson {
					width: 100%;
					display: flex;
					justify-content: space-between;
					align-items: center;
					height: 88rpx;

					.inpson-l {
						display: flex;
						flex-direction: row;
						align-items: center;
						justify-content: flex-start;

						.icon-add {
							color: #209072;
							font-size: 26rpx;
						}

						.inpson-ltitle {
							font-size: 32rpx;
							color: #333333;
							margin-left: 12rpx;
						}
					}

					.icon-r {
						color: #AAAAAA;
						font-size: 26rpx;
					}
				}
			}

			.tex {
				width: 100%;
				min-height: 170rpx;
				box-sizing: border-box;
				padding: 34rpx 0 0;
				background-color: #fff;

				.inptext {
					color: #666;
					width: 100%;
					height: 136rpx;
					font-size: 26rpx;
					line-height: 45rpx;
				}
			}
		}
	}

	.btn {
		width: 640rpx;
		height: 88rpx;
		margin: 60rpx auto;
		background: #209072;
		display: flex;
		justify-content: center;
		align-items: center;
		font-size: 34rpx;
		color: #fff;
		border-radius: 44rpx;
	}

	.tips {
		width: 100%;
		position: absolute;
		bottom: 62rpx;
		box-sizing: border-box;
		padding: 0 34rpx;
		font-size: 24rpx;
		text-align: justify;
		font-weight: 400;
		color: #666666;
		line-height: 45rpx;
	}
</style>
