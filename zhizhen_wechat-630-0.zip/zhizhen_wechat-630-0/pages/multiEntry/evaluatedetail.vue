<template>
	<view class="evaluate-container">
		<!-- tap -->
		<view class="tpas">
			<view class="tap-item" @click="tapClick(0)">
				<view :class="tapFlag == 0 ? 'text tap-active': 'text'">TA被点评</view>
				<view class="line" v-if="tapFlag == 0"></view>
			</view>
			<view class="tap-item" @click="tapClick(1)">
				<view :class="tapFlag == 1 ? 'text tap-active': 'text'">TA的印象</view>
				<view class="line" v-if="tapFlag == 1"></view>
			</view>
			<view class="tap-item" @click="tapClick(2)">
				<view :class="tapFlag == 2 ? 'text tap-active': 'text'">TA的评分</view>
				<view class="line" v-if="tapFlag == 2"></view>
			</view>
		</view>
		<!-- frienddetail -->
		<view class="friend-detail" v-if="tapFlag == 0">
			<view class="friend-item" v-for="(item,index) in evaluateInfo" :key="index">
				<view class="detail">
					<image v-if="item.if_anonymity == 1" src="../../static/img/anonymity.png" class="left" mode="aspectFill"></image>
					<image v-if="item.if_anonymity != 1" :src="item.avatar?item.avatar:'../../static/img/default-header2.png'" class="left" mode="aspectFill"></image>
					<view class="right" v-if="item.if_anonymity != 1">
						<view class="name">{{item.user_name?item.user_name:""}}</view>
						<view v-if="item.company_name" class="company">共事公司 : {{item.company_name}}</view>
					</view>
					<view v-if="item.if_anonymity == 1" class="anonymity">访客</view>
				</view>
				<view class="content" @tap="goCommentDetail(item.id)">{{item.text_evaluate?item.text_evaluate:''}}</view>
				<view class="time">{{item.create_time?item.create_time:''}}</view>
				<view class="opration">
					<view class="opration-item">
						<view class="iconfont icon-i-zhuanfa" @tap="goCommentDetail(item.id)"></view>
						<!-- <button class="share" :data-obj="item" open-type="share">
							<view class="iconfont icon-i-zhuanfa"></view>
						</button> -->
						<view class="num">{{item.forward_count}}</view>
					</view>
					<view class="opration-item">
						<view class="iconfont icon-msg-pinglun" @tap="goCommentDetail(item.id)"></view>
						<view class="num">{{item.comment_count}}</view>
					</view>
					<view class="opration-item">
						<view v-if="!item.isDz" class="iconfont icon-zan" @tap="dzChange(true,index,item.id)"></view>
						<view v-else class="iconfont icon-msg-zan-xuanzhong iconfont-color " @tap="dzChange(false,index,item.id)"></view>
						<view class="num">{{item.fabu_count}}</view>
					</view>
					<view class="opration-item">
						<view v-if="!item.isCai" class="iconfont icon-cai" @tap="caiChange(true,index,item.id)"></view>
						<view v-else class="iconfont icon-msg-cai-xuanzhong iconfont-color " @tap="caiChange(false,index,item.id)"></view>
						<view class="num">{{item.step_count}}</view>
					</view>
				</view>
			</view>
		</view>
		<!-- impression -->
		<view class="impress" v-if="tapFlag == 1">
			<view class="impress-item" v-for="(item,index) in impressionInfo" :key="index">
				<view class="detail">
					<image v-if="item.if_anonymity == 1" src="../../static/img/anonymity.png" class="avatar" mode="aspectFill"></image>
					<image v-if="item.if_anonymity != 1" :src="item.avatar?item.avatar:'../../static/img/anonymity.png'" class="avatar" mode="aspectFill"></image>
					<view v-if="item.if_anonymity != 1" class="company-detail">
						<view class="namePosition">
							<view class="name">{{item.user_name?item.user_name:""}}</view>
							<view class="position">{{item.position_name?item.position_name:''}}</view>
						</view>
						<view v-if="item.company_name" class="company">共事公司 : {{item.company_name}}</view>
					</view>
					<view v-if="item.if_anonymity == 1" class="anonymity">访客</view>
				</view>
				<view class="tag">
					<view v-for="(items,indexs) in JSON.parse(item.labels || '[]')" :key="indexs" class="tag-item">{{items}}</view>
					<!-- <view v-for="(items,indexs) in newImpressionInfo[index]" :key="indexs" class="tag-item">{{items}}</view> -->
				</view>
				<view class="time">{{item.create_time?item.create_time:''}}</view>
			</view>
		</view>

		<!-- score -->
		<view class="score" v-if="tapFlag == 2">
			<view class="score-list">
				<view v-for="(item,index) in scoreInfo" :key="index" class="score-item">
					<view class="left">
						<image v-if="item.if_anonymity == 1" src="../../static/img/anonymity.png" class="avatar"></image>
						<image v-if="item.if_anonymity != 1" :src="item.avatar?item.avatar:'../../static/img/default-header2.png'" class="avatar"></image>
						<view v-if="item.if_anonymity != 1" class="detail">
							<view class="namePosition">
								<view class="name">{{item.user_name?item.user_name:""}}</view>
								<view class="position">{{item.position_name?item.position_name:''}}</view>
							</view>
							<view v-if="item.company_name" class="company">共事公司 : {{item.company_name}}</view>
						</view>
						<view v-if="item.if_anonymity == 1" class="anonymity">访客</view>
					</view>
					<view class="right">
						<view class="num">{{item.total_score?item.total_score:'0'}}</view>
						<view class="text">综合评分</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {
		mapState
	} from "vuex";
	export default {
		data() {
			return {
				tapFlag: 0, //tap标识
				evaluateInfo: [], //点评数据
				impressionInfo: [], //印象数据
				scoreInfo: [], //评分数据
				// newImpressionInfo: [],	//印象标签去重
			}
		},
		onLoad(options) {
			let tapFlag = options.tapFlag
			this.tapFlag = tapFlag * 1
		},
		//--------分享-----------
		onShareAppMessage(res) {
			console.log('onShareAppMessage:', res)
			var itemInfo = res.target.dataset.obj
			console.log(itemInfo,'传过来的每一项的info')
			//获取存储信息
			uni.getStorage({
				key: 'receivebaseInfo',
				success: (res) => {
					var receivebaseInfo = res.data
				}
			})
			
			console.log(receivebaseInfo,'看下能不能拿到信息')
			// return {
			// 	title: `${this.commentData.role_type=="1"?"访客好友":this.commentData.open_id_name} 对 ${this.commentData.in_open_id_name} 的评价详情`,
			// 	path: `/pages/index/commentDetails?id=${res.target.dataset.id}`,
			// 	imageUrl: '/static/img/forward_details.png',
			// 	success(res) {
			// 		let data = {
			// 			"parent_id": res.target.dataset.id,
			// 			"comment_type": "1",
			// 			"oper_type": "1",
			// 			"show_name": this.userInfoObj.nickName,
			// 			"open_id": this.loginInfoObj.open_id
			// 		}
			// 		this.$http.postHasLoad('/zxxt/careerEvalu/operComment', data);
			// 	},
			// 	fail(res) {}
			// }
			return {
				title: `${itemInfo.if_anonymity==1?"访客好友":itemInfo.user_name} 对 ${this.commentData.in_open_id_name} 的评价详情`,
				path: `/pages/index/commentDetails`,
				imageUrl: '/static/img/forward_details.png',
				success(res) {
					
				},
				fail(res) {}
			}
		},
		computed: {
			...mapState(['evaluateDetail','loginInfoObj','userInfoObj'])
		},
		mounted() {
			console.log("----:",this.loginInfoObj,'看下领个参数:',this.userInfoObj)
			var evaluateInfo = this.evaluateDetail.user_text_evaluate || []
			if(evaluateInfo.length > 0) {
				evaluateInfo.forEach((item,index)=>{
					item.isDz = false
					item.isCai = false
				})
			}
			this.evaluateInfo = evaluateInfo 
			
			this.impressionInfo = this.evaluateDetail.user_labels || []
			
			// var impressionInfo = this.evaluateDetail.user_labels || []
			// var finImpressionInfo = []
			// impressionInfo.forEach((item,index) => {	
			// 	var newLabels = JSON.parse(item.labels);
			// 	var newImpressionInfo = []
			// 	if(newLabels.length > 0) {
			// 		newLabels.forEach(items=>{
			// 			if(newImpressionInfo.indexOf(items) == -1) {
			// 				newImpressionInfo.push(items)
			// 			}
			// 		})
			// 	}
			// 	// item.labels = newImpressionInfo
			// 	finImpressionInfo[index] = newImpressionInfo
			// })
			// console.log(finImpressionInfo,'hahah')
			// this.newImpressionInfo = finImpressionInfo
			// this.impressionInfo = impressionInfo
			
			this.scoreInfo = this.evaluateDetail.user_total_score || []
		},
		methods: {
			tapClick(tapFlag) {
				this.tapFlag = tapFlag
			},
			// 点击列表跳转点评详情
			goCommentDetail(id) {
				uni.redirectTo({
					url: '/pages/index/commentDetails?id=' + id,
				})
			},
			dzChange(flag,index,id) {
				var evaluateInfo = this.evaluateInfo
				evaluateInfo[index].isDz = flag
				// 2-点赞	3-取消点赞
				if (flag) {
					evaluateInfo[index].fabu_count ++
					var oper_type = '2'
				}else {
					if(evaluateInfo[index].fabu_count > 0) {
						evaluateInfo[index].fabu_count --
					} 
					var oper_type = '3'
				}
				this.evaluateInfo = evaluateInfo
				this.operationClick(id,oper_type)
			},
			caiChange(flag,index,id) {
				var evaluateInfo = this.evaluateInfo
				evaluateInfo[index].isCai = flag
				// 4-踩	5-取消踩
				if (flag) {
					evaluateInfo[index].step_count ++
					var oper_type = '4'
				}else {
					if(evaluateInfo[index].step_count > 0) {
						evaluateInfo[index].step_count --
					} 
					var oper_type = '5'
				}
				this.evaluateInfo = evaluateInfo
				this.operationClick(id,oper_type)
			},
			async operationClick(parent_id,oper_type) {
				let data = {
					'parent_id': parent_id,
					'comment_type': 1,
					'oper_type': oper_type,
					'show_name': this.userInfoObj.nickName,
					'open_id': this.loginInfoObj.open_id
				}
				let res = await this.$http.postHasLoad('/zxxt/careerEvalu/operComment', data);
			}
			
		}
	}
</script>

<style lang="scss" scoped>
	.evaluate-container {
		padding: 0 32rpx;
		
		.anonymity {
			text-align: center;
			line-height: 80rpx;
			margin-left: 19rpx;
		}

		// tap
		.tpas {
			display: flex;
			padding: 17rpx 11rpx;
			border-bottom: 1px solid #E0E0E0;

			.tap-item {
				display: flex;
				flex-direction: column;
				justify-content: flex-start;
				align-items: center;
				font-size: 30rpx;
				color: #333333;
				margin-right: 52rpx;
			}

			.tap-active {
				color: #209072;
			}

			.text {
				margin-bottom: 13rpx;
			}

			.line {
				width: 40rpx;
				height: 4rpx;
				background-color: #209072;
			}
		}

		// frienddetail
		.friend-detail {
			.detail {
				display: flex;
				justify-content: flex-start;
				align-items: center;
				margin: 32rpx 0;
			}

			.left {
				width: 80rpx;
				height: 80rpx;
				border-radius: 50%;
				margin-right: 20rpx;
			}

			.right {
				.name {
					font-size: 34rpx;
					color: #209072;
					margin-bottom: 20rpx;
				}

				.company {
					font-size: 28rpx;
					color: #999999;
				}
			}

			.time {
				font-size: 24rpx;
				color: #AAAAAA;
				margin: 59rpx 0 40rpx 0;
			}

			.opration {
				display: flex;
				justify-content: space-between;
				align-items: center;
				height: 84rpx;
				padding: 0 20rpx;
				border-top: 1px solid #E0E0E0;
				border-bottom: 1px solid #E0E0E0;

				.opration-item {
					display: flex;
					justify-content: flex-start;

					image {
						width: 36rpx;
						height: 36rpx;
					}
					.iconfont-color {
						color: #209072;
					}
					.num {
						color: #AAAAAA;
						font-size: 24rpx;
						margin-left: 22rpx;
					}
					
					.share {
						line-height: 1;
						background-color: #fff;
						border: none;
					
						display: flex;
						align-items: center;
					}
					
					.share::after {
						border: none;
					}
				}
			}
		}

		// impression
		.impress {
			.impress-item {
				border-bottom: 1px solid #E2E2E2;
				padding: 40rpx 0;

				.detail {
					display: flex;
					justify-content: flex-start;

					.avatar {
						width: 80rpx;
						height: 80rpx;
						border-radius: 50%;
					}

					.company-detail {
						margin-left: 20rpx;
						color: #999999;
						font-size: 28rpx;

						.namePosition {
							display: flex;
							justify-content: flex-start;
							align-items: center;

							.name {
								width: 110rpx;
								white-space: nowrap;
								overflow: hidden;
								text-overflow: ellipsis;
								font-size: 34rpx;
								color: #209072;
							}

							.position {
								margin-left: 17rpx;
								width: 222rpx;
								white-space: nowrap;
								overflow: hidden;
								text-overflow: ellipsis;
							}
						}

						.company {
							max-width: 521rpx;
							white-space: nowrap;
							overflow: hidden;
							text-overflow: ellipsis;
						}
					}
				}

				.tag {

					padding-left: 86rpx;
					margin: 30rpx 0 42rpx 0;

					.tag-item {
						display: inline-block;
						width: 150rpx;
						height: 60rpx;
						line-height: 60rpx;
						text-align: center;
						font-size: 26rpx;
						color: #4A9163;
						border: 2px solid #CEE3D5;
						border-radius: 30rpx;
						margin-right: 13rpx;
						margin-bottom: 12rpx;
					}
				}

				.time {
					font-size: 24rpx;
					color: #AAAAAA;
				}
			}
		}

		// score
		.score {
			.score-list {
				.score-item {
					display: flex;
					justify-content: flex-start;
					width: 100%;
					padding: 30rpx 0;
					border-bottom: 1px solid #E2E2E2;

					.left {
						width: 316rpx;
						display: flex;
						justify-content: flex-start;
					}

					.avatar {
						width: 80rpx;
						height: 80rpx;
						border-radius: 50%;
					}

					.detail {
						margin-left: 12rpx;

						.namePosition {
							display: flex;
							justify-content: flex-start;
							align-items: center;

							.name {
								width: 110rpx;
								white-space: nowrap;
								overflow: hidden;
								text-overflow: ellipsis;
								font-size: 34rpx;
								color: #209072;
							}

							.position {
								width: 100rpx;
								white-space: nowrap;
								overflow: hidden;
								text-overflow: ellipsis;
								color: #AAAAAA;
								font-size: 24rpx;
								margin-left: 17rpx;
							}
						}

						.company {
							width: 226rpx;
							white-space: nowrap;
							overflow: hidden;
							text-overflow: ellipsis;
							font-size: 28rpx;
							color: #999999;
						}
					}

					.right {
						display: flex;
						flex-direction: column;
						justify-content: center;
						align-items: center;
						padding-left: 90rpx;
						margin-left: 90rpx;
						border-left: 1px solid #BBBBBB;
					}
				}
			}
		}
	}
</style>
