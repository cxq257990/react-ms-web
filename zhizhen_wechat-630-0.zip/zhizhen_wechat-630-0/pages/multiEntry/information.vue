<template>
	<view class="wechatBox">
		<!-- header -->
		<view class="wechat-header">
			<view class="pageBack" @tap="goBack" style='bomttom: 123rpx;'>
				<image src="../../static/img/wechat_back_white.svg"></image>
			</view>
			<image :src="friendDetail.avatar?friendDetail.avatar:'../../static/img/anonymity.png'" class="filterBlurImage"></image>
			<view class="wechat-header-mask"></view>
		</view>
		<!-- body -->
		<view class="wechat-body">
			<view class="wechat-body-content">
				<view class="content-top">
					<view class="image-box">
						<image :src="friendDetail.avatar?friendDetail.avatar:'../../static/img/anonymity.png'"
							mode="aspectFill"></image>
					</view>
					<view class="nameArea">
						<view class="name">{{friendDetail.user_name?friendDetail.user_name:''}}</view>
						<view class="area">{{friendDetail.area?friendDetail.area:''}}</view>
					</view>
					<view class="positionOnclik">
						<view class="positionOnclik_left">
							<view class="company">{{friendDetail.company_name?friendDetail.company_name:''}}</view>
							<view class="position">{{friendDetail.position_name?friendDetail.position_name:''}}</view>
						</view>
						<view @tap="queryDetail" class="positionOnclik_right">
							<view class="circle">
								{{btnText}}
							</view>
						</view>
					</view>
				</view>
			</view>

			<!-- taps -->
			<view class="allInfo">
				<!-- taps -->
				<view class="taps">
					<view class="base-tap tap_info" @click="personalInfo">
						<text :class="tapFlag == 0 ? 'tap-active tap_text ':'tap_text'">个人信息</text>
						<view class="tap_line" v-if="tapFlag == 0"></view>
					</view>
					<view class="base-tap tap_evaluate" @click="friendEvaluate">
						<text :class="tapFlag == 1 ? 'tap-active tap_text ':'tap_text'">好友评价</text>
						<view class="tap_line" v-if="tapFlag == 1"></view>
					</view>
				</view>
				<!-- 工作教育经历 -->
				<view class="exAndedu" v-if="tapFlag == 0">
					<view class="exercise">
						<view class="title">工作经历</view>
						<view class="content" v-for="(item,index) in friendDetail.record_vo_list" :key="index">
							<view class="base_content content_company">{{item.name?item.name:''}}</view>
							<view class="content_position">{{item.position?item.position:''}}</view>
						</view>
					</view>
					<view class="education">
						<view class="title">教育经历</view>
						<view class="content" v-for="(item,index) in friendDetail.education_vo_list" :key="index">
							<view class="base_content content_shool">{{item.school_name?item.school_name:''}}</view>
							<view class="content_major">{{item.education?item.education:''}}</view>
						</view>
					</view>
				</view>

				<view class="friend-evaluate" v-if="tapFlag == 1">
					<!-- 点评 -->
					<view class="friend-commend">
						<view class="commend-header">
							<view class="header-left">
								<view class="left-text">TA被点评</view>
							</view>
							<view v-if="friendDetail.user_text_evaluate && (friendDetail.user_text_evaluate.length > 0)"
								class="header-right" @tap="goEvaluate">
								<view class="right-text">{{friendDetail.user_text_evaluate.length}}</view>
								<image src="../../static/img/link-right.svg" class="link-right"></image>
							</view>
						</view>
						<view v-if="friendDetail.user_text_evaluate && friendDetail.user_text_evaluate.length > 0" class="commend-body">
							<image v-if="friendDetail.user_text_evaluate[0].if_anonymity == 1"
								src="../../static/img/head_man.svg" class="commend-avatar"></image>
							<image v-if="friendDetail.user_text_evaluate[0].if_anonymity != 1"
								:src="friendDetail.user_text_evaluate[0].avatar?friendDetail.user_text_evaluate[0].avatar:''"
								class="commend-avatar"></image>
							<view class="company-info">
								<view class="commend-detail">
									<text v-if="friendDetail.user_text_evaluate[0].if_anonymity != 1"
										class="commend_name">{{friendDetail.user_text_evaluate[0].user_name?friendDetail.user_text_evaluate[0].user_name:''}}</text>
									<text v-if="friendDetail.user_text_evaluate[0].if_anonymity == 1"
										class="commend_name">访客</text>
									<text v-if="friendDetail.user_text_evaluate[0].if_anonymity != 1"
										class="commend_position">{{friendDetail.user_text_evaluate[0].position_name?friendDetail.user_text_evaluate[0].position_name:''}}</text>
								</view>
								<view v-if="friendDetail.user_text_evaluate[0].if_anonymity != 1 && friendDetail.user_text_evaluate[0].company_name"
									class="commend-company">
									{{friendDetail.user_text_evaluate[0].company_name}}
								</view>
							</view>
						</view>
						<view v-if="friendDetail.user_text_evaluate[0].text_evaluate" class="commend-foot">
							{{friendDetail.user_text_evaluate[0].text_evaluate}}
						</view>
					</view>
					<!-- 印象 -->
					<view class="friend-impression">
						<view class="impression-header">
							<view class="header-left">
								<view class="left-text">TA的印象</view>
							</view>
							<view v-if="friendDetail.user_labels && friendDetail.user_labels.length > 0"
								class="header-right" @tap="goImpression">
								<view class="right-text">{{friendDetail.user_labels.length}}</view>
								<image src="../../static/img/link-right.svg" class="link-right"></image>
							</view>
						</view>
						<!-- <view v-if="friendDetail.user_labels && (friendDetail.user_labels.length > 0)"
							class="impression-body"> -->
						<view class="impression-body" v-if="newMyUserLabels.length > 0">
							<view v-for="(item,index) in newMyUserLabels" :key="index"
								class="impression-item">
								{{item.label}}
								<view class="bradge" v-if="item.num >= 2">{{item.num}}</view>
							</view>
						</view>
					</view>
					<!-- 评分 -->
					<view class="friend-score">
						<view class="commend-header">
							<view class="header-left">
								<view class="left-text">TA的评分</view>
							</view>
							<view v-if="friendDetail.user_total_score && friendDetail.user_total_score.length > 0"
								class="header-right" @tap="goScore">
								<view class="right-text">{{friendDetail.user_total_score.length}}</view>
								<image src="../../static/img/link-right.svg" class="link-right"></image>
							</view>
						</view>
						<view class="commend-body" v-if="friendDetail.user_total_score && friendDetail.user_total_score.length > 0">
							<image v-if="friendDetail.user_total_score[0].if_anonymity == 1"
								src="../../static/img/head_man.svg" class="commend-avatar"></image>
							<image v-if="friendDetail.user_total_score[0].if_anonymity != 1"
								:src="friendDetail.user_total_score[0].avatar?friendDetail.user_total_score[0].avatar:''"
								class="commend-avatar"></image>
							<view class="company-info">
								<view class="commend-detail">
									<text v-if="friendDetail.user_total_score[0].if_anonymity != 1"
										class="commend_name name_limit">{{friendDetail.user_total_score[0].user_name?friendDetail.user_total_score[0].user_name:''}}</text>
									<text v-if="friendDetail.user_total_score[0].if_anonymity == 1"
										class="commend_name name_limit">访客</text>
									<text v-if="friendDetail.user_total_score[0].if_anonymity != 1"
										class="commend_position position_limit">{{friendDetail.user_total_score[0].position_name?friendDetail.user_total_score[0].position_name:''}}</text>
								</view>
								<view v-if="friendDetail.user_total_score[0].if_anonymity != 1"
									class="commend-company company_limit">
									{{friendDetail.user_total_score[0].company_name?friendDetail.user_total_score[0].company_name:''}}
								</view>
							</view>
							<view class="commend-foot">
								<view class="score-num">
									{{friendDetail.user_total_score[0].total_score?friendDetail.user_total_score[0].total_score:'0'}}
								</view>
								<view class="score-text">综合评分</view>
							</view>
						</view>
					</view>
				</view>
			</view>
			
			<!-- 猜您可能还想认识	states 0:申请中，1：同意，2：忽略(未添加) -->
			<vWantToKnow v-if="tapFlag == 0" :outId="lookUserId"></vWantToKnow>

			<!-- btn -->
			<view class="btnArea">
				<view v-if="relationstates == 1" class="base_btn sendMessage" @tap="sendMessage">发送消息</view>
				<view v-if="relationstates == 2" class="base_btn sendMessage" @tap="addThisfriend(lookUserId)">添加好友</view>
				<view class="base_btn moreOption" @click="moreOpration">更多操作</view>
			</view>

		</view>
		<!-- Dialog -->
		<view class="dialog" v-if="dialogVisible">
			<view class="dialog-content">确定要删除该好友吗？</view>
			<view class="dialog-btn">
				<view class="basebtn cancle" @click="dialogOpration('cancle')">取消</view>
				<view class="basebtn confirm" @click="dialogOpration('confirm')">确定</view>
			</view>
		</view>
		<!-- messageSheet -->
		<view class="messageSheet" v-if="messageSheetVisible">
			<view v-if="relationstates == 1" class="message-item" @click="deleteFriend">删除好友</view>
			<view v-else class="message-item" @click="addThisfriend(lookUserId)">添加好友</view>
			<view class="message-item" @tap="writeLetter">写推荐信</view>
			<view class="message-item" @tap="invitewriteLetter">邀请写推荐信</view>
			<view class="message-cancle" @click="cancleSheet">取消</view>
		</view>
		<!-- mask -->
		<view class="dialog-mask" v-if="maskVisible"></view>
	</view>
</template>

<script>
	/**
	 * 查看别人的 个人信息页面
	 */
	import vWantToKnow from "components/common/vWantToKnow"
	import {
		mapState
	} from "vuex";
	export default {
		components: {
			vWantToKnow
		},
		data() {
			return {
				// tap显示
				tapFlag: 0,
				// 弹框
				dialogVisible: false,
				// 选择面板
				messageSheetVisible: false,
				// 遮罩
				maskVisible: false,
				// 看我详情人的openid
				// lookUserId: 'oNIYe5P4u7te-cKU0vZS81Sc_MiA',
				lookUserId: '',
				relationstates: 1, //是否是好友，1是 2否
				btnText: '一键点评', //查看评价2,	一键点评1
				friendDetail: {}, //好友详情对象
				newMyUserLabels: [], //外层标签去重+小数字
				pageNo: 1,	//猜你认识列表起始页
				pageSize: 10,	//每页多少条
				onshowFlag:0,
			}
		},
		computed: {
			...mapState(['loginInfoObj'])
		},
		mounted() {
			this.getFriendDetail()
		},
		onLoad(options) {
			let lookUserId = options.openId
			if (!lookUserId) {
				return uni.showToast({
					title: '好友ID缺失',
					icon: 'none',
					duration: 2000
				})
			}
			this.lookUserId = lookUserId
		},
		onShow() {
			this.onshowFlag ++
			// 重新获取猜你认识列表
			if(this.onshowFlag != 1) {
				// this.getWantToKnowList()
			}
		},
		methods: {
			personalInfo() {
				this.tapFlag = 0
			},
			friendEvaluate() {
				this.tapFlag = 1
			},
			moreOpration() {
				this.messageSheetVisible = this.maskVisible = true
			},
			cancleSheet() {
				this.messageSheetVisible = this.maskVisible = this.dialogVisible = false
			},
			// 删除好友按钮事件
			deleteFriend() {
				this.dialogVisible = true
			},
			// 确认删除,取消删除
			dialogOpration(flag) {
				this.dialogVisible = false
				if (flag == 'confirm') {
					//删除好友逻辑
					this.deleteRequest()
				}

			},
			// 删除好友的实际请求
			async deleteRequest() {
				let params = {
					openId: this.loginInfoObj.open_id,
					reOpenId: this.lookUserId
				}
				let res = await this.$http.getHasLoad('/zxxt/user/deleteFriend', params);
				uni.showToast({
					title: '删除成功',
					icon: 'none',
					duration: 2000
				})
				// 重新获取好友详情
				this.getFriendDetail()
			},
			// 添加好友
			async addThisfriend(lookUserId) {
				
				var params = {
					open_id: this.loginInfoObj.open_id,
					re_open_id: lookUserId
				}
				
				if ((!params.re_open_id) && (!params.can_phone)) {
					return uni.showToast({
								title: '添加好友缺少手机号码或者id',
								icon: 'none',
								duration: 2000
							})
				} 
				let res = await this.$http.postHasLoad('/zxxt/user/addFriend', params);
				// 判断是列表中的好友添加
				if (params.can_phone && (params.re_open_id != this.lookUserId)) {
					this.wantToKnowList.forEach(item =>{
						if(params.can_phone == item.can_phone) {
							item.states = 0
						}
					})
				}
				uni.showToast({
					title: '请求已发送',
					icon: 'none',
					duration: 2000
				})
				this.messageSheetVisible = false
				this.maskVisible = false
			},
			// 跳转到写推荐信
			writeLetter() {
				uni.navigateTo({
					url: '/pages/recommendation/forOthers?name=' + this.friendDetail.user_name + '&avatar=' +
						this.friendDetail.avatar + '&hisopenid=' + this.lookUserId,
				})
			},
			// 邀请写推荐信
			invitewriteLetter() {
				uni.navigateTo({
					url: '/pages/recommendation/invitation?name=' + this.friendDetail.user_name + '&avatar=' +
						this.friendDetail.avatar + '&hisopenid=' + this.lookUserId,
				})
			},
			// 获取好友详情信息
			async getFriendDetail() {
				let params = {
					openId: this.loginInfoObj.open_id,
					lookUserId: this.lookUserId
				}
				let res = await this.$http.getHasLoad('/zxxt/user/friendMessage', params);
				
				// 成功之后再请求猜你认识列表
				// this.getWantToKnowList()
				
				this.relationstates = res.data.states
				var friendDetail = res.data
				// 处理地区
				if (friendDetail.area) {
					friendDetail.area = friendDetail.area.split(',').join(' ')
				}
				// 处理印象标签
				if (friendDetail.user_labels && friendDetail.user_labels.length > 8) {
					friendDetail.user_labels = friendDetail.user_labels.splice(0, 8)
				}
				// 处理标签为空的情况
				friendDetail.user_labels = friendDetail.user_labels.filter((item,index)=>{
					return JSON.parse(item.labels).length != 0
				})
				// 处理外层标签重复问题
				var myUserLabels = friendDetail.user_labels
				var tempArr = [] 
				var newMyUserLabels = []
				myUserLabels.forEach((item,index)=>{
					if (item.labels && (tempArr.indexOf(JSON.parse(item.labels)[0]) == -1)) {
						// 不包含
						newMyUserLabels.push({
							label:JSON.parse(item.labels)[0],
							num : 1
						})
						tempArr.push(JSON.parse(item.labels)[0])
					}else if (item.labels && (tempArr.indexOf(JSON.parse(item.labels)[0]) > -1)) {
						// 包含
						newMyUserLabels[tempArr.indexOf(JSON.parse(item.labels)[0])].num ++
					}
				})
				this.newMyUserLabels = newMyUserLabels

				// 缓存中存入信息,以便会话时信息展示
				uni.setStorageSync('receivebaseInfo', friendDetail)
				// 处理底部按钮文字显示
				if (friendDetail.log_evaluate == 2) {
					this.btnText = '查看评价'
				}
				this.friendDetail = friendDetail
				console.log(friendDetail)
			},
			// 点击返回到聊天界面
			goBack() {
				uni.navigateBack({
					delta: 1
				});
			},
			// 点击一键评价或者是点击查看评价详情
			queryDetail() {
				let {
					lookUserId,
					friendDetail
				} = this
				if (friendDetail.log_evaluate == 2) { //查看评价
					wx.navigateTo({
						url: '/pages/evaluate/evaluationInfo?hisopenid=' + lookUserId,
					})
				}
				if (friendDetail.log_evaluate == 1) { //一键点评
					// app.globalData.oneClickName = friendDetail.user_name ? friendDetail.user_name : ""
					uni.navigateTo({
						url: '/pages/multiEntry/comment?hisopenid=' + lookUserId,
					})
				}
			},
			// 发送消息
			async sendMessage() {
				let params = {
					re_open_id: this.lookUserId,
					open_id: this.loginInfoObj.open_id
				}
				let res = await this.$http.postHasLoad('/zxxt/chat/readMsg', params);
				uni.redirectTo({
					url: '/pages/news/chart?receiveMemberId=' + this.lookUserId,
				})
			},
			// 去点评
			goEvaluate() {
				var evaluateInfo = this.friendDetail.user_text_evaluate
				if (evaluateInfo) {
					this.$store.commit('submitvaluateDetail', this.friendDetail)
					uni.navigateTo({
						url: '/pages/multiEntry/evaluatedetail?tapFlag=0',
					})
				}
			},
			// 去印象
			goImpression() {
				console.log("====:",this.friendDetail)
				var impressionInfo = this.friendDetail.user_labels
				if (impressionInfo) {
					// app.globalData.impressionInfo = impressionInfo
					this.$store.commit('submitvaluateDetail', this.friendDetail)
					wx.navigateTo({
						url: '/pages/multiEntry/evaluatedetail?tapFlag=1',
					})
				}
			},

			// 去评分
			goScore() {
				var scoreInfo = this.friendDetail.user_total_score
				if (scoreInfo) {
					// app.globalData.scoreInfo = scoreInfo
					this.$store.commit('submitvaluateDetail', this.friendDetail)
					wx.navigateTo({
						url: '/pages/multiEntry/evaluatedetail?tapFlag=2',
					})
				}
			},
		}
	}
</script>


<style lang="scss" scoped>
	.wechatBox {
		background-color: #F3F3F3;
	}

	.wechat-header {
		position: relative;
		display: flex;
		justify-content: flex-start;
		align-items: center;
		height: 225rpx;
		background-color: #ccc;
	}

	.filterBlurImage {
		width: 60%;
		height: 100%;
		filter: blur(6px);
		margin: 0 auto;
	}

	.pageBack {
		position: absolute;
		left: 18px;
		// top: 34px;
		display: flex;
		justify-content: center;
		align-items: center;
		width: 20px;
		height: 20px;
		z-index: 9;
	}

	.wechat-header .pageBack image {
		width: 100%;
		height: 100%;
	}

	.wechat-header-mask {
		position: absolute;
		left: 0;
		top: 0;
		width: 100%;
		height: 100%;
		background-color: rgba(0, 0, 0, 0.5);
	}

	.wechat-body-content {
		position: relative;
		height: 166px;
		background-color: #fff;
		border-radius: 6px;
	}

	.content-top {
		position: absolute;
		left: 50%;
		top: -78rpx;
		transform: translate(-50%);
		width: 100%;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
		margin-bottom: 16rpx;
		padding-bottom: 36rpx;
	}

	.content-top image {
		width: 156rpx;
		height: 156rpx;
		border-radius: 50%;
	}

	.nameArea {
		display: flex;
		justify-content: center;
		align-items: center;
		margin-top: 30rpx;
		// padding-left: 116rpx;
	}

	.name {
		max-width: 160rpx;
		font-size: 20px;
		font-weight: 700;
		margin-right: 16rpx;
		color: #333333;
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
	}

	.area {
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
		font-size: 12px;
		color: #AAAAAA;
		text-align: center;
	}

	.positionOnclik {
		display: flex;
		justify-content: space-between;
		width: 100%;
		margin-top: 45rpx;
	}

	.positionOnclik_left {
		width: 70%;
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
		margin-left: 50rpx;
		font-size: 28rpx;
		color: #333333;

		.company {
			width: 100%;
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
		}

		.position {
			width: 100%;
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
		}
	}

	.positionOnclik_right {
		display: flex;
		justify-content: flex-end;align-items: center;
		width: 30%;
		margin-right: 50rpx;
		font-size: 28rpx;
		color: #209072;

		.circle {
			width: 160rpx;
			height: 60rpx;
			line-height: 60rpx;
			text-align: center;
			border: 2rpx solid #209072;
			border-radius: 30rpx;
		}
	}

	.left {
		width: 80%;
	}

	.line {
		color: #a8a8a8;
	}

	.right {
		display: flex;
		justify-content: center;
		align-items: center;
		width: 20%;
		border-radius: 50%;
		background-color: #fff;
	}

	.right image {
		width: 68px;
		height: 68px;
		border-radius: 50%;
	}

	.taps_box {
		padding: 0 32rpx;
	}

	.allInfo {
		margin-top: 32rpx;
		padding: 32rpx;
		background-color: #fff;
		// padding-bottom: 252rpx;
	}

	.taps {
		display: flex;
		justify-content: flex-start;
		height: 90rpx;
		border-bottom: 1px solid #E0E0E0;
		background-color: #fff;
	}

	.tap_info {
		margin-right: 88rpx;
	}

	.tap-active {
		color: #209072 !important;
	}

	.base-tap {
		display: flex;
		flex-direction: column;
		justify-content: flex-start;
		align-items: center;
	}

	.tap_text {
		font-size: 30rpx;
	}

	.tap_line {
		width: 40rpx;
		height: 4rpx;
		background-color: #209072;
		border-radius: 2rpx;
		margin-top: 12rpx;
	}

	.exercise {
		padding: 42rpx 0;
		.content {
			padding-bottom: 20rpx;
			border-bottom: 1px solid #ccc;
		}
	}
	
	.content_position {
		font-size: 28rpx;
		color: #999;
	}

	.education {
		// padding: 42rpx 0;
		padding: 42rpx 0 0 0;
		.content {
			padding-bottom: 20rpx;
			// border-bottom: 1px solid #ccc;
		}
	}
	
	.content_major {
		font-size: 28rpx;
		color: #999;
	}

	.title {
		font-size: 34rpx;
		color: #209072;
		font-weight: bold;
	}

	.base_content {
		margin: 32rpx 0;
	}

	.btnArea {
		position: fixed;
		left: 0;
		bottom: 0;
		display: flex;
		justify-content: center;
		align-items: center;
		width: 100%;
		height: 132rpx;
		background-color: #fff;

		.base_btn {
			height: 72rpx;
			width: 260rpx;
			border: 2px solid #209072;
			border-radius: 36rpx;
		}

		.sendMessage {
			text-align: center;
			line-height: 72rpx;
			margin-right: 60rpx;
			background-color: #209072;
			color: #fff;
		}

		.moreOption {
			text-align: center;
			line-height: 72rpx;
			color: #209072;
		}
	}

	// 好友评价
	.friend-evaluate {
		border-radius: 6px;
		padding: 16px 0;
		background-color: #fff;
		min-height: 120px;
		margin-bottom: 118rpx;
	}

	.friend-commend {
		padding-bottom: 18px;
		border-bottom: 1px solid #e0e0e0;
	}

	.link-right {
		width: 20px;
		height: 20px;
	}

	.commend-header {
		width: 100%;
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	.header-left {
		width: 24%;
		height: 26px;
		position: relative;
	}

	.left-text {
		position: absolute;
		left: 0;
		top: 0;
		font-size: 30rpx;
		font-weight: 700;
		color: #209072;
		z-index: 1;
	}

	.left-bg {
		position: absolute;
		right: 0;
		bottom: 0;
		width: 60px;
		height: 12px;
		background-color: #DDF3ED;
	}

	.right-text {
		color: #999;
		font-size: 12px;
	}

	.header-right {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	.commend-body {
		display: flex;
		align-items: center;
		margin: 8px 0;

		.commend-avatar {
			width: 80rpx;
			height: 80rpx;
			border-radius: 50%;
		}

		.company-info {
			margin-left: 16rpx;

			.commend-detail {
				margin-bottom: 19rpx;
			}

			.commend_name {
				font-size: 34rpx;
				color: #209072;
			}

			.commend_position {
				color: #AAAAAA;
				font-size: 24rpx;
				margin-left: 17rpx;
			}

			.commend-company {
				font-size: 28rpx;
				color: #999999;
			}
		}
	}

	// 印象
	.friend-impression {
		// min-height: 92px;
		padding-bottom: 18px;
		margin: 12px 0;
		border-bottom: 1px solid #e0e0e0;
	}

	.impression-header {
		display: flex;
		justify-content: space-between;
		align-items: center;
	}

	.impression-body {
		padding: 10px 0;
		height: 156rpx;
	}

	.impression-item {
		position: relative;
		float: left;
		width: 150rpx;
		height: 60rpx;
		font-size: 26rpx;
		color: #4A9163;
		border: 2px solid #CEE3D5;
		border-radius: 30rpx;
		text-align: center;
		line-height: 60rpx;
		margin: 0 4px 10px 0;
		.bradge {
			position: absolute;
			right: 0;
			top: -10rpx;
			width: 30rpx;
			height: 30rpx;
			line-height: 30rpx;
			text-align: center;
			font-size: 20rpx;
			color: #fff;
			border-radius: 50%;
			background-color: #209072;
		}
	}

	// 评分
	.friend-score {
		border-bottom: 1px solid #e0e0e0;
		padding-bottom: 30rpx;

		.name_limit {
			max-width: 52rpx;
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
		}

		.position_limit {
			max-width: 96rpx;
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
		}

		.company_limit {
			max-width: 226rpx;
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
		}

		.commend-foot {
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;
			padding-left: 90rpx;
			margin-left: 90rpx;
			border-left: 1px solid #bbb;

			.score-num {
				font-size: 60rpx;
				font-weight: bold;
				color: #333333;
				margin-bottom: 10rpx;
			}

			.score-text {
				font-size: 24rpx;
				color: #AAAAAA;
			}
		}
	}

	// 对话框
	.dialog {
		position: fixed;
		left: 50%;
		top: 50%;
		transform: translate(-50%, -50%);
		width: 540rpx;
		height: 312rpx;
		background-color: #fff;
		border-radius: 26rpx;
		z-index: 8;

		.dialog-content {
			text-align: center;
			height: 223rpx;
			line-height: 223rpx;
			width: 100%;
			font-size: 34rpx;
		}

		.dialog-btn {
			display: flex;
			justify-content: flex-start;
			border-top: 1px solid #e0e0e0;
		}

		.basebtn {
			text-align: center;
			width: 48%;
			height: 88rpx;
			line-height: 88rpx;
			font-size: 30rpx;
			color: #333333;
		}

		.cancle {
			border-right: 2rpx solid $uni-border-color;
		}

		.confirm {
			color: #209072;
		}

		.btn-line {
			width: 2%;
			height: 100%;
			background-color: #e0e0e0;
		}
	}

	// 遮罩
	.dialog-mask {
		position: fixed;
		left: 0;
		top: 0;
		width: 100%;
		height: 100%;
		background-color: rgba(0, 0, 0, .3);
		z-index: 7;
	}

	// 选择面板
	.messageSheet {
		position: fixed;
		left: 0;
		bottom: 0;
		width: 100%;
		box-sizing: border-box;
		height: 425rpx;
		background-color: #fff;
		padding: 0 44rpx;
		z-index: 9;

		view {
			display: flex;
			justify-content: center;
			align-items: center;
			font-size: 34rpx;
			height: 100rpx;
		}

		.message-item {
			border-bottom: 1px solid #e2e2e2;
			color: #333333;
		}

		.message-cancle {
			color: #209072;
		}
	}
	
	// 猜你认识样式
	.wantToKnow {
		width: 100%;
		padding-bottom: 188rpx;
		background-color: #fff;
		.gap {
			height: 32rpx;
			background-color: #f3f3f3;
		}
		.wantToKnow-header {
			padding: 34rpx 0;
			color: #209072;
			font-size: 34rpx;
			background-color: #fff;
		}
		.wantToknow-line {
			height: 1rpx;
			margin:  0 32rpx;
			background-color: #e0e0e0;
		}
		.padding-aside {
			padding-left: 32rpx;
			padding-right: 32rpx;
		}
		.wantToKnow-list  {
			padding: 36rpx 0 0 0;
			.icon-color {
				color: #209072;
				font-size: 50rpx;
			}
			.self-color {
				font-size: 40rpx;
			}
			.info-box {
				display: flex;
				justify-content: space-between;
				align-items: center;
				padding: 0 32rpx;
				.icon-box {
					display: flex;
					justify-content: flex-start;
					align-items: center;
					.avatar {
						position: relative;
						.unread-icon {
							width: 51rpx;
							position: absolute;
							top: 2rpx;
							right: -12rpx;
							background-color: #F64135;
							line-height: 18rpx;
							height: 24rpx;
							box-sizing: border-box;
							border-radius: 12rpx;
							border: 2rpx solid #fff;
							display: flex;
							align-items: center;
							justify-content: center;
							font-size: 18rpx;
							color: #fff;
						}
						.left {
							width: 80rpx !important;
							height: 80rpx;
							border-radius: 50%;
						}
					}
					.info {
						margin-left: 20rpx;
						.nameAndPosition {
							display: flex;
							justify-content: flex-start;
							align-items: center;
							.name {
								font-size: 34rpx;
							}
							.position {
								max-width: 336rpx;
								font-size: 24rpx;
								color: #999999;
								overflow: hidden;
								white-space: nowrap;
								text-overflow: ellipsis;
							}
						}
						.company {
							max-width: 458rpx;
							font-size: 28rpx;
							color: #999999;
							overflow: hidden;
							white-space: nowrap;
							text-overflow: ellipsis;
						}
					}
				}
			}
			.together-friend {
				padding: 0 130rpx;
				display: flex;
				justify-content: flex-start;
				align-items: center;
				margin-top: 14rpx;
				.together-num {
					font-size: 28rpx;
					color: #999999;
					margin-left: 12rpx;
				}
			}
			.border-bottom {
				height: 1rpx;
				margin: 0 32rpx;
				background-color: #e0e0e0;
				margin-top: 36rpx;
			}
		}
	}
</style>
