<template>
	<view class="message-container"
		:style="{'padding-top':statusBarHeight+'px', height: `calc(100vh - ${statusBarHeight}px)`}">
		<vStatusbar txt="消息"></vStatusbar>
		<view class="search-box">
			<vSearch class="vserch"></vSearch>
			<view class="input-mask" @click="goSearch"></view>
		</view>
		<view class="message-list">
			<scroll-view scroll-y="true" class="scroll-list">
				<view class="ststem-list">
					<view class="list-item" @tap="systemMessage(0)">
						<view class="icon-box">
							<image src="../../static/img/request_img.png" class="mes-img"></image>
							<view class="brage" v-if="friend_request.count">
								{{friend_request.count > 99 ? 99:friend_request.count}}
								<view v-if="friend_request.count > 99" class="more">+</view>
							</view>
						</view>
						<view class="right">
							<view class="titleTime">
								<view class="title">好友请求</view>
								<view class="time">{{friend_request.date?friend_request.date:''}}</view>
							</view>
							<view class="text">您又有新的好友！快去看看吧~</view>
						</view>
					</view>
					<view class="list-item" @tap="systemMessage(1)">
						<view class="icon-box">
							<image src="../../static/img/active_flag.png" class="mes-img"></image>
							<view class="brage" v-if="interactive_msg.count">
								{{interactive_msg.count > 99 ? 99:interactive_msg.count}}
								<view v-if="interactive_msg.count > 99" class="more">+</view>
							</view>
						</view>
						<view class="right">
							<view class="titleTime">
								<view class="title">互动消息</view>
								<view class="time">{{interactive_msg.date?interactive_msg.date:''}}</view>
							</view>
							<view class="text">您又收到了新的评论/赞/推荐信了！快去看...</view>
						</view>
					</view>
					<view class="list-item" @tap="systemMessage(2)">
						<view class="icon-box">
							<image src="../../static/img/zhizhen_help.png" class="mes-img"></image>
							<view class="brage" v-if="official.count">
								{{official.count > 99 ? 99:official.count}}
								<view v-if="official.count > 99" class="more">+</view>
							</view>
						</view>
						<view class="right">
							<view class="titleTime">
								<view class="title">指真小助手</view>
								<view class="time">{{official.date?official.date:''}}</view>
							</view>
							<view class="text">{{official.content?official.content:'Hi，欢迎加入指真！快去完善个人信息。'}}</view>
						</view>
					</view>
				</view>
				<view class="friend-list">
					<van-swipe-cell right-width="65" v-for="(item,index) in messageList" :key="index">
						<view class="list-item" @tap="goWechat(item)">
							<view class="icon-box">
								<image :src="item.avatar?item.avatar:'../../static/img/anonymity.png'" mode="widthFix"
									class="left"></image>
								<view class="brage" v-if="item.unread">
									{{item.unread > 99 ? 99:item.unread}}
									<view v-if="item.unread > 99" class="more">+</view>
								</view>
								<view v-if="item.online_flag != 1" class="imgMask"></view>
							</view>
							<view class="right">
								<view class="titleTime">
									<view class="title">
										{{item.user_name ? item.user_name : item.nickname ? item.nickname : ''}}
									</view>
									<view class="time">{{item.create_time?item.create_time:''}}</view>
								</view>
								<view class="text">{{item.content_msg}}</view>
							</view>
						</view>
						<view slot="right" @click="deleteClick(item.open_id)" class="delete-new">删除</view>
					</van-swipe-cell>
				</view>
			</scroll-view>
		</view>

	</view>
</template>

<script>
	import vSearch from "components/common/vSearch"
	import vStatusbar from "components/common/vStatusbar.vue"
	import {
		mapState
	} from "vuex";
	export default {
		components: {
			vSearch,
			vStatusbar
		},
		data() {
			return {
				statusBarHeight: 0,
				openId: '',
				searchIptValue: "", //搜索框内容
				messageList: [], //消息列表
				pageNo: 1, //当前页码
				pageSize: 30, //每页数量
				dataTotal: 0, //总条数
				friend_request: 0, //好友请求的数量
				interactive_msg: 0, //互动消息的数量
				official: 0, //指真小助手的数量
				timeId: null, //定时器标识
				isScroll: false, //是否滚动标识
				onshowFlag: 0,	//onshow标识
			}
		},
		onShareAppMessage(res) {
			if (res.from == "menu") {
				return {
					title: `欢迎进入指真小程序！`,
					path: "/pages/index/index",
					imageUrl: '/static/img/forward_details.png'
				}
			} 
		},
		computed: {
			...mapState(['loginInfoObj'])
		},
		mounted() {
			// 消息主模块添加判断是否授权
			// this.$util.checkIslogin(() => {})
			// 获取用户登陆信息
			this.getOpenId()
			// 获取消息列表
			this.getmessageList()
		},
		onLoad() {
			let res = uni.getSystemInfoSync();
			let menu = wx.getMenuButtonBoundingClientRect();
			this.statusBarHeight = (menu.top - res.statusBarHeight) * 2 + menu.height + res.statusBarHeight;
			if (res.model.indexOf('iPhone') > -1) {
				this.statusBarHeight += 4
			}
		},
		async onShow() {
			console.log(111111111)
			this.isScroll = false
			this.pageNo = 1
			
			this.onshowFlag ++

			// 重新获取列表
			if(this.onshowFlag != 1) {
				this.getmessageList()
			}
			
		},
		/**
		 * 生命周期函数--监听页面隐藏
		 */
		onHide() {
			// if (this.timeId) {
			// 	clearTimeout(this.timeId)
			// }
		},
		onUnload() {
			if (this.timeId) {
				clearTimeout(this.timeId)
			}
		},
		beforeDestroy() {
			if (this.timeId) {
				clearTimeout(this.timeId)
			}
		},
		methods: {
			// 获取用户openId
			getOpenId() {
				this.openId = this.loginInfoObj.open_id
			},
			// 子组件输入框值获取
			// emitSearch(data) {
			// 	this.searchIptValue = data.val

			// },
			async getBarMsg() {
				// bar未读消息
				let params = {
					openId: this.loginInfoObj.open_id
				}
				let res = await this.$http.getNoLoad('/zxxt/msg/count', params);
				if (res.data) {
					let text = res.data + ''
					uni.setTabBarBadge({
						index: 2,
						text
					})
				} else {
					uni.removeTabBarBadge({
						index: 2
					})
				}
			},
			// 获取消息列表
			async getmessageList() {
				if (this.timeId) {
					clearTimeout(this.timeId)
				}
				// 参数准备
				var {
					openId,
					pageNo,
					pageSize
				} = this
				var data = {
					openId,
					pageNo,
					pageSize
				}
				var res = await this.$http.getNoLoad('/zxxt/user/message', data);
				var messageList = res.data.message_vos
				var friend_request = res.data.friend_request
				var interactive_msg = res.data.interactive_msg
				var official = res.data.official
				if (this.isScroll) {
					if (messageList) {
						messageList = [...this.messageList, ...messageList]
						var newMessageList = [];
						var arryObj = {};
						for (var i = 0; i < messageList.length; i++) {
							if (!arryObj[messageList[i].open_id]) {
								newMessageList.push(messageList[i])
								arryObj[messageList[i].open_id] = true
							}
						}
						this.messageList = newMessageList
					}
				} else {
					this.messageList = messageList
				}

				if (friend_request) {
					this.friend_request = friend_request
				}
				if (interactive_msg) {
					this.interactive_msg = interactive_msg
				}
				if (official) {
					this.official = official
				}
				this.dataTotal = res.data.data_total || 0

				this.getBarMsg()

				this.timeId = setTimeout(() => {
					this.getmessageList()
				}, 1000 * 15)
			},
			// 系统消息
			systemMessage(flag) {
				if (this.timeId) {
					clearTimeout(this.timeId)
				}
				// 0-好友请求；1-互动消息；2-指真小助手
				if (flag == 0) {
					uni.navigateTo({
						url: '/pages/news/friendRequest',
					});
				} else if (flag == 1) {
					uni.navigateTo({
						url: '/pages/news/activeNews',
					});
				} else {
					let receivebaseInfo = {
						avatar: '../../static/img/zhizhen_help.png',
						user_name: '指真小助手',
						company_name: '指向真实的你',
						open_id: 'zx'
					}
					uni.setStorageSync('receivebaseInfo', receivebaseInfo);
					uni.navigateTo({
						url: '/pages/news/chart?receiveMemberId=' + 'zx',
					});
				}
			},
			// 点击滑动删除监听
			deleteClick(re_open_id) {
				this.deleteMsg(re_open_id)
			},
			// 具体的删除逻辑
			async deleteMsg(re_open_id) {
				// 参数准备
				var open_id = this.openId
				var data = {
					open_id,
					re_open_id
				}
				// 删除请求
				var res = await this.$http.postHasLoad('/zxxt/chat/delMsg', data);
				this.getmessageList()
				if (res.code == 'success') {
					return uni.showToast({
						title: '删除成功',
						icon: 'none',
						duration: 2000
					})
				}
			},
			// 点击好友列表项,进入会话
			async goWechat(receivebaseInfo) {
				// 存入缓存信息
				uni.setStorageSync('receivebaseInfo', receivebaseInfo)
				// 埋点请求
				let open_id = this.openId
				let re_open_id = receivebaseInfo.open_id
				let data = {
					open_id,
					re_open_id
				}
				var res = await this.$http.postHasLoad('/zxxt/chat/readMsg', data);
				if (res.code == 'success') {
					// 跳转会话页面
					uni.navigateTo({
						url: '/pages/news/chart?receiveMemberId=' + re_open_id,
					});
				}

			},
			// 前往消息搜索结果页面
			goSearch() {
				if (this.timeId) {
					clearTimeout(this.timeId)
				}
				uni.navigateTo({
					url: '/pages/news/searchNews',
				});
			},
			// 上拉加载更多
			onReachBottom() {
				this.isScroll = true
				if (!(this.pageNo * this.pageSize >= this.dataTotal)) {
					this.pageNo = this.pageNo + 1
					this.getmessageList()
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	.message-container {

		// padding: 0 32rpx;
		.search-box {
			position: relative;
			padding: 0 32rpx;
			padding-bottom: 33rpx;
			border-bottom: 1px solid #E0E0E0;

			.input-mask {
				position: absolute;
				left: 0;
				top: 0;
				width: 100%;
				height: 88rpx;
				background-color: transparent;
				z-index: 6;
			}
		}

		.message-list {
			height: calc(100% - 134rpx);
			// padding: 0 32rpx;
			
			.scroll-list {
				height: 100%;
			}

			.list-item {
				display: flex;
				justify-content: flex-start;
				align-items: center;
				padding: 29rpx 0 31rpx 0;
				border-bottom: 1px solid #E0E0E0;

				.icon-box {
					position: relative;

					.imgMask {
						position: absolute;
						left: 0;
						top: 0;
						width: 80rpx;
						height: 80rpx;
						background-color: #fff;
						opacity: 0.5;
					}
				}

				.iconfont {
					font-size: 90rpx;
				}

				.mes-img {
					width: 90rpx;
					height: 90rpx;
					border-radius: 50%;
				}

				.brage {
					position: absolute;
					top: 0;
					right: 0;
					width: 30rpx;
					height: 30rpx;
					display: flex;
					justify-content: center;
					align-items: center;
					font-size: 20rpx;
					color: #fff;
					background-color: #F64135;
					border-radius: 50%;

					.more {
						position: absolute;
						top: -50%;
						right: -50%;
						font-size: 20rpx;
						font-weight: 700;
						color: #F64135;
					}
				}

				.brage-padding {
					padding-left: 12rpx;
					padding-right: 12rpx;
				}

				.left {
					width: 80rpx !important;
					height: 80rpx;
					border-radius: 50%;
				}

				.right {
					// width: 100%;
					width: 82%;
					margin-left: 24rpx;

					.titleTime {
						display: flex;
						justify-content: space-between;
						align-items: center;
						margin-bottom: 19rpx;

						.title {
							color: #333333;
							font-size: 28rpx;
						}

						.time {
							font-size: 24rpx;
							color: #AAAAAA;
						}
					}

					.text {
						width: 540rpx;
						font-size: 28rpx;
						color: #999999;
						white-space: nowrap;
						overflow: hidden;
						text-overflow: ellipsis;
					}
				}
			}

			.ststem-list {
				padding: 0 32rpx;
				.right {}
			}

			.friend-list {
				padding: 0 32rpx;
				.delete-new {
					display: flex;
					justify-content: center;
					align-items: center;
					width: 200%;
					height: 100%;
					color: #fff;
					font-size: 16px;
					background-color: #F15757;
				}
			}
		}
	}
</style>
