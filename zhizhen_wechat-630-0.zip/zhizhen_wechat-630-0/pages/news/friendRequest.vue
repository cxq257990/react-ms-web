<template>
	<view class="request-list">
		<view class="list-item" v-for="(item,index) in messageList" :key="index">
			<view class="left-info">
				<image v-if="item.avatar" :src="item.avatar" mode="widthFix" class="avatar"></image>
				<image v-else src="../../static/img/head_man.svg" mode="widthFix" class="avatar"></image>
				<view class="info">
					<view class="name">{{item.user_name?item.user_name:""}}</view>
					<view class="company-box">
						<view class="company">{{item.company_name?item.company_name:""}}</view>
						<view class="position">{{item.position_name?item.position_name:''}}</view>
					</view>
				</view>
			</view>
			<view class="right-oprate">
				<view v-if="item.states == 0" class="iconfont icon-tianjiahaoyou1" @tap="aggreApplay(item.open_id,item.can_phone)"></view>
				<view v-if="item.states == 0" class="iconfont icon-shanchu" @tap="ignorApplay(item.open_id,item.can_phone)"></view>
				<view v-if="item.states == 1" class="states-style">已同意</view>
				<view v-if="item.states == 2" class="states-style">已忽略</view>
			</view>
		</view>
		<vNoResult v-if="messageList.length == 0" :txt="txt"></vNoResult>
	</view>
</template>

<script>
	import vNoResult from "components/common/vNoResult"
	import {
		mapState
	} from "vuex";
	export default {
		components: {
			vNoResult
		},
		data() {
			return {
				txt: '暂无好友请求',		//noresult
				pageNo:1,
				pageSize:30,
				messageList:[],//好友申请列表
				dataTotal: 0,	//总条数
				isScroll: false,	//是否是滚动中的标识
			}
		},
		computed: {
			...mapState(['loginInfoObj'])
		},
		mounted() {
			this.getfriendList()
		},
		methods: {
			async getfriendList() {
				let params = {
					openId: this.loginInfoObj.open_id,
					pageNo: this.pageNo,
					pageSize: this.pageSize
				}
				let res = await this.$http.getHasLoad('/zxxt/user/selectOaFriendList', params);
				var messageList = res.data.data
				if (this.isScroll) {
					// 滚动中的请求
					var _thisMessage = this.messageList
					this.messageList = [..._thisMessage,...messageList]
				}else {
					// 普通触发后请求
					this.messageList = messageList
				}
				this.dataTotal = res.data.data_total || 0
			},
			async aggreApplay(re_open_id='',can_phone='') {
				// 是否是滚动标识
				this.isScroll = false
				let params = {
					open_id: this.loginInfoObj.open_id,
					re_open_id,
					can_phone
				}
				let res = await this.$http.postHasLoad('/zxxt/user/agreeFriend', params);
				this.getfriendList()
				uni.showToast({
					title: '添加成功',
					icon: 'none',
					duration: 2000
				})
			},
			async ignorApplay(re_open_id='',can_phone='') {
				// 是否是滚动标识
				this.isScroll = false
				let params = {
					open_id: this.loginInfoObj.open_id,
					re_open_id,
					can_phone
				}
				let res = await this.$http.postHasLoad('/zxxt/user/neglectFriend', params);
				this.getfriendList()
				uni.showToast({
					title: '已忽略',
					icon: 'none',
					duration: 2000
				})
			},
			// 上拉加载更多
			onReachBottom() {
				// 是否是滚动标识
				this.isScroll = true
				if(!(this.pageNo * this.pageSize >= this.dataTotal)) {
					this.pageNo = this.pageNo + 1
					this.getfriendList()
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	.request-list {
		padding: 0 32rpx;
		.list-item {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 34rpx 0 46rpx 0;
			border-bottom: 1px solid #E0E0E0;
			.left-info {
				display: flex;
				.avatar {
					width: 80rpx;
					height: 80rpx;
					border-radius: 50%;
				}
				.info {
					margin-left: 19rpx;
					.name {
						width: 110rpx;
						font-size: 34rpx;
						color: #333333;
						margin-bottom: 12rpx;
						white-space: nowrap;
						overflow: hidden;
						text-overflow: ellipsis;
					}
					.company-box {
						display: flex;
						justify-content: flex-start;
						font-size: 28rpx;
						color: #999999;
						.company {
							width: 226rpx;
							white-space: nowrap;
							overflow: hidden;
							text-overflow: ellipsis;
						}
						.position {
							width: 112rpx;
							margin-left: 28rpx;
							white-space: nowrap;
							overflow: hidden;
							text-overflow: ellipsis;
						}
					}
				}
			}
			.right-oprate {
				display: flex;
				justify-content: space-between;
				align-items: center;
				.iconfont {
					font-size: 52rpx;
					color: #209072;
				}
				.icon-tianjiahaoyou1 {
					margin-right: 52rpx;
				}
				.icon-shanchu {
					font-size: 30rpx;
				}
				.states-style {
					color: #ccc;
				}
			}
		}
	}
</style>
