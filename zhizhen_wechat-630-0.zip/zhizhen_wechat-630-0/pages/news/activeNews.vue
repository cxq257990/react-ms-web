<template>
	<view class="active-container">
		<!-- tap -->
		<view class="tpas">
			<view class="tap-item" @click="tapClick(0)">
				<view class="bradge" v-if="unReadMsg.evaluation_count">
					{{unReadMsg.evaluation_count > 99 ? 99:unReadMsg.evaluation_count}}
					<view v-if="unReadMsg.evaluation_count > 99" class="more">+</view>
				</view>
				<view :class="tapFlag == 0 ? 'text tap-active': 'text'">点评</view>
				<view class="line" v-if="tapFlag == 0"></view>
			</view>
			<view class="tap-item" @click="tapClick(1)">
				<view class="bradge" v-if="unReadMsg.praise_count">
					{{unReadMsg.praise_count > 99 ? 99:unReadMsg.praise_count}}
					<view v-if="unReadMsg.praise_count > 99" class="more">+</view>
				</view>
				<view :class="tapFlag == 1 ? 'text tap-active': 'text'">赞</view>
				<view class="line" v-if="tapFlag == 1"></view>
			</view>
			<view class="tap-item" @click="tapClick(2)">
				<view class="bradge" v-if="unReadMsg.step_count">
					{{unReadMsg.step_count > 99 ? 99:unReadMsg.step_count}}
					<view v-if="unReadMsg.step_count > 99" class="more">+</view>
				</view>
				<view :class="tapFlag == 2 ? 'text tap-active': 'text'">踩</view>
				<view class="line" v-if="tapFlag == 2"></view>
			</view>
			<view class="tap-item" @click="tapClick(3)">
				<view class="bradge" v-if="unReadMsg.rec_count">
					{{unReadMsg.rec_count > 99 ? 99:unReadMsg.rec_count}}
					<view v-if="unReadMsg.rec_count > 99" class="more">+</view>
				</view>
				<view :class="tapFlag == 3 ? 'text tap-active': 'text'">推荐信</view>
				<view class="line" v-if="tapFlag == 3"></view>
			</view>
		</view>
		<!-- evaluate -->
		<view class="evaluate-list" v-if="activeMsgList && (activeMsgList.length > 0)">
			<view class="list-item" v-for="(item,index) in activeMsgList" :key="item.id"
				@tap="goCommentDetail(item.content_id,item.id,item.type,item.open_id)">
				<view class="icon-box">
					<view v-if="item.read_flag == 0" class="unread-icon">new</view>
					<image v-if="item.role_type == '1' && (tapFlag == 0)" :src="item.avatar?item.avatar:'../../static/img/anonymity.png'" mode="widthFix" class="left"></image>
					<image v-else-if="item.role_type == '2' && (tapFlag == 0)" src="../../static/img/anonymity.png" mode="widthFix" class="left"></image>
					<image v-else-if="item.role_type == '3' && (tapFlag == 0)" src="../../static/img/company.jpg" mode="widthFix" class="left"></image>
					<image v-else :src="item.avatar?item.avatar:'../../static/img/anonymity.png'" mode="widthFix" class="left"></image>
				</view>
				<view class="right">
					<view class="titleTime">
						<view class="title">{{item.user_name}}</view>
						<view class="time">{{item.create_time}}</view>
					</view>
					<view class="text">{{textContent[tapFlag]}}</view>
				</view>
			</view>
		</view>
		<vNoResult v-else :txt='txt'></vNoResult>
	</view>
</template>

<script>
	import vNoResult from "components/common/vNoResult"
	import {
		mapState
	} from "vuex"
	export default {
		components: {
			vNoResult
		},
		data() {
			return {
				txt: '暂无数据',
				tapFlag: 0,
				textContent: ['刚给您添加了一条新点评~', '我刚给您点了赞~', '悄悄踩一踩', '我刚给您写了一封推荐信~'],
				activeMsgList: [], //互动消息列表
				unReadMsg: {
					evaluation_count: null
				}, //未读消息对象
				pageNo: 1, //当前页码
				pageSize: 50, //每页数量
				dataTotal: 0, //总条数
				isScroll: false,	//是否滚动
			}
		},
		computed: {
			...mapState(['loginInfoObj'])
		},
		onShow() {
			this.isScroll = false
			this.pageNo = 1
			this.getActiveMsgList(this.tapFlag)
			this.getAllUnread()
		},
		mounted() {
			this.getActiveMsgList(0)
			this.getAllUnread()
		},
		methods: {
			// 获取动态消息列表
			async getActiveMsgList(tapFlag) {
				let openId = this.loginInfoObj.open_id
				let pluginId = tapFlag
				let data = {
					openId,
					pluginId,
					pageNo: this.pageNo,
					pageSize: this.pageSize
				}
				let res = await this.$http.getHasLoad('/zxxt/msg/listByType', data);
				var activeMsgList = res.data.data
				
				if (this.isScroll) {
					activeMsgList = [...this.activeMsgList, ...activeMsgList]
					var newMessageList = [];
					var arryObj = {};
					for (var i = 0; i < activeMsgList.length; i++) {
						if (!arryObj[activeMsgList[i].id]) {
							newMessageList.push(activeMsgList[i])
							arryObj[activeMsgList[i].id] = true
						}
					}		
					this.activeMsgList = newMessageList
				}else {
					this.activeMsgList = activeMsgList
				}
				
				this.dataTotal = res.data.data_total || 0
			},
			// 获取各列表未读消息数量
			async getAllUnread() {
				let data = {
					openId: this.loginInfoObj.open_id
				}
				let res = await this.$http.getHasLoad('/zxxt/msg/noReadCount', data);
				this.unReadMsg = res.data
				// count-未读消息总数量
				//evaluation_count-评论未读消息总数量
				//praise_count-点赞未读消息总数量
				//rec_count-推荐信未读消息总数量
				//step_count-踩未读消息总数量
			},
			// tap切换
			tapClick(tapFlag) {
				// tap切换初始化
				this.activeMsgList = []
				this.pageNo = 1
				this.isScroll = false

				// 切换后的更新
				this.tapFlag = tapFlag
				this.getActiveMsgList(tapFlag)
				this.getAllUnread()
			},
			// 前往点评详情
			async goCommentDetail(content_id, id, type,open_id) {
				
				if (this.tapFlag == 0 || this.tapFlag == 1 || this.tapFlag == 2) {
					// 参数说明content_id-消息id;id列表id;type-跳转至职评圈或者问员工标识
					var data = {
						openId: this.loginInfoObj.open_id,
						id,
						pluginId: this.tapFlag
					}
					let res = await this.$http.getHasLoad('/zxxt/msg/updateReadById', data);
					// 职评圈详情
					if (type == 0) {
						uni.navigateTo({
							url: '/pages/index/commentDetails?id=' + content_id,
						});
					} else {
						// 问员工详情
						uni.navigateTo({
							url: '/pages/index/askDetails?id=' + content_id,
						});
					}
				}else {
					// 推荐信详情
					var data = {
						openId: this.loginInfoObj.open_id,
						id,
						pluginId: this.tapFlag
					}
					let res = await this.$http.getHasLoad('/zxxt/msg/updateReadById', data);
					uni.navigateTo({
						url: '/pages/my/myRecommendLetter/recommendLetterDetail?type=1&id=' + content_id + "&letteropenId=" + open_id,
					});
				}
				
			},
			// 上拉加载更多
			onReachBottom() {
				this.isScroll = true
				if (!(this.pageNo * this.pageSize >= this.dataTotal)) {
					this.pageNo = this.pageNo + 1
					this.getActiveMsgList()
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	.active-container {
		padding: 0 32rpx;

		// tap
		.tpas {
			display: flex;
			padding: 17rpx 11rpx;
			border-bottom: 1px solid #E0E0E0;

			.tap-item {
				position: relative;
				display: flex;
				flex-direction: column;
				justify-content: flex-start;
				align-items: center;
				font-size: 30rpx;
				color: #333333;
				margin-right: 78rpx;

				.bradge {
					position: absolute;
					top: 38%;
					right: 0;
					transform: translate(100%, -42%);
					display: flex;
					justify-content: center;
					align-items: center;
					width: 30rpx;
					height: 30rpx;
					font-size: 18rpx;
					border-radius: 50%;
					color: #fff;
					background-color: #F64135;

					.more {
						position: absolute;
						top: -50%;
						right: -50%;
						font-size: 20rpx;
						font-weight: 700;
						color: #F64135;
					}
				}

				.brage-padding {
					padding-left: 12rpx;
					padding-right: 12rpx;
				}
			}

			.tap-active {
				color: #209072;
			}

			.text {
				margin-bottom: 13rpx;
			}

			.line {
				width: 40rpx;
				height: 4rpx;
				background-color: #209072;
			}
		}

		.list-item {
			display: flex;
			justify-content: flex-start;
			align-items: center;
			padding: 29rpx 0 31rpx 0;
			border-bottom: 1px solid #E0E0E0;

			.icon-box {
				position: relative;
				.unread-icon {
					width: 51rpx;
					position: absolute;
					top: 2rpx;
					right: -14rpx;
					background-color: #F64135;
					line-height: 18rpx;
					height: 24rpx;
					box-sizing: border-box;
					border-radius: 12rpx;
					border: 2rpx solid #fff;
					display: flex;
					align-items: center;
					justify-content: center;
					font-size: 18rpx;
					color: #fff;
				}
			}

			.iconfont {
				font-size: 90rpx;
			}

			.brage {
				position: absolute;
				top: 0;
				right: 0;
				width: 30rpx;
				height: 30rpx;
				font-size: 20rpx;
				color: #fff;
				background-color: #F64135;
				border-radius: 50%;
			}

			.left {
				width: 80rpx !important;
				height: 80rpx;
				border-radius: 50%;
			}

			.right {
				width: 100%;
				margin-left: 24rpx;

				.titleTime {
					display: flex;
					justify-content: space-between;
					align-items: center;
					margin-bottom: 19rpx;

					.title {
						width: 420rpx;
						color: #333333;
						font-size: 28rpx;
						white-space: nowrap;
						overflow: hidden;
						text-overflow: ellipsis;
					}

					.time {
						font-size: 24rpx;
						color: #AAAAAA;
					}
				}

				.text {
					width: 540rpx;
					font-size: 28rpx;
					color: #999999;
					white-space: nowrap;
					overflow: hidden;
					text-overflow: ellipsis;
				}
			}
		}
	}
</style>
