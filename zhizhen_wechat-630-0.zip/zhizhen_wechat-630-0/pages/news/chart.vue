<template>
	<view class="chart-box">
		<!-- 头部 -->
		<view class="chat-header" @tap="goWechatInfo">
			<view class="header-image-box">
				<image class="header-image"
					:src="receivebaseInfo.avatar?receivebaseInfo.avatar:'../../static/img/anonymity.png'"></image>
			</view>
			<view>
				<view class="namePostion">
					<view class="chat-name">{{receivebaseInfo.user_name?receivebaseInfo.user_name:''}}
					</view>
					<view class="chart-position">{{receivebaseInfo.position_name?receivebaseInfo.position_name:""}}</view>
				</view>
				<view class="chat-company">{{receivebaseInfo.company_name?receivebaseInfo.company_name:''}}</view>
			</view>
		</view>
		<!-- 消息主体 -->
		<view class='news'>
			<view class="historycon">
				<scroll-view scroll-y="true" :scroll-into-view="scrollid" scroll-with-animation="true"
					:style="{height:scrollHeight}" class="history" refresher-enabled="true" @refresherrefresh="refresh"
					:refresher-triggered="triggered">
					<!-- 历史记录部分start -->
					<view v-if="historyList.length > 0">
						<view class="historyText">历史消息</view>
						<block v-for="(item,index) in historyList" :key="index">
							<!--此处为other -->
							<view v-if="item.type==1" :id="'historyscrollid' + index">
								<view>
									<text class='chat-time'>{{item.create_time?item.create_time:''}}</text>
								</view>
								<view class='other-record'>
									<image class='other-head-img' :src='receivebaseInfo.avatar'></image>
									<view class='other-record-content-triangle'></view>
									<view class='other-record-content'>{{item.content_msg}}</view>
								</view>
							</view>
							<!--此处为结尾 -->
							<!--此处为own -->
							<view v-else :id="'historyscrollid' + index">
								<view>
									<text class='chat-time'>{{item.create_time?item.create_time:''}}</text>
								</view>
								<view class='own-record'>
									<view class='own-record-content'>{{item.content_msg}}</view>
									<view class='own-record-content-triangle'></view>
									<image class='own-head-img' :src='sendAvatar'></image>
								</view>
							</view>
							<!-- own结尾 -->
						</block>
						<view class="historyText">以上为历史消息</view>
					</view>
					<!-- 历史记录部分end -->
					<block v-for="(item,index) in newsList" :key="index">
						<!--此处为other -->
						<view v-if="item.type==1" :id="'scrollid' + index">
							<view>
								<text class='chat-time'>{{item.create_time?item.create_time:''}}</text>
							</view>
							<view class='other-record'>
								<image class='other-head-img' :src='receivebaseInfo.avatar'></image>
								<view class='other-record-content-triangle'></view>
								<view class='other-record-content'>{{item.message}}</view>
							</view>
						</view>
						<!--此处为结尾 -->
						<!--此处为own -->
						<view v-else :id="'scrollid' + index">
							<view>
								<text class='chat-time'>{{item.create_time?item.create_time:''}}</text>
							</view>
							<view class='own-record'>
								<view class='own-record-content'>{{item.message}}</view>
								<view class='own-record-content-triangle'></view>
								<image class='own-head-img' :src='sendAvatar'></image>
							</view>
						</view>
						<!-- own结尾 -->
					</block>
				</scroll-view>
			</view>
		</view>
		<!-- 消息发送 -->
		<view class="sendmessage">
			<view class="send-message">
				<input class="chat-input" type="text" @input="bindChange" confirm-type="done" :value='input'
					cursor-spacing="16px" :hold-keyboard="holdKeyboardFlag" placeholder="请输入..." />
				<view class="iconfont icon-fabiaoqing" @tap="emotionChange"></view>
				<button class="btn" @tap='send'>发送</button>
			</view>
			<view class="emotions" v-if="emotionVisible">
				<view class="emotions-item" v-for="(item,index) in connectemoji" :key="index" @tap="addemotion(index)">
					{{item}}
				</view>
			</view>
		</view>
		<!-- 全部结束----------------------------------------- -->
	</view>
</template>

<script>
	import {
		mapState
	} from "vuex";
	import {
		wssUrl
	} from "../../utils/config.js";
	export default {
		data() {
			return {
				receivebaseInfo: {}, //存储在缓存中的好友信息
				sendAvatar: '../../static/img/anonymity.png', //发送消息的用户头像（自己的头像）
				newsList: [], //消息列表
				historyList: [], //历史记录
				input: null, // 发送内容
				openid: null,
				// connectemoji: ["😘", "😡", "😔", "😄", "❤", "🌹"],
				// emoji_list: ['emoji1i1', 'emoji2i2', 'emoji3i3', 'emoji4i4', 'emoji5i5', 'emoji5i6'],
				connectemoji: ["🙂", "😃", "😬", "😊", "😎", "😂", "🤑", "🙃", "🤐", "☹️", "😥", "😭", "😠", "😷", "👀",
					"👌", "👏", "👍", "👎", "💪", "💩", "🐷", "🐶", "🐈", "🌹", "🍋", "🍉", "🍻"
				],
				emotionVisible: false,
				inputShowed: false,
				scrollTop: 0,
				inputBottom: '0px',
				receiveMemberId: null,
				sendMemberId: null,
				scrollid: 'scrollid',
				historyscrollid: 'historyscrollid8',
				scrollHeight: '600rpx',
				triggered: true, //  下拉刷新
				pageNo: 1, //  历史记录当前页
				onSocketCloseFlag: true,
				onUnloadFlag: false,
				holdKeyboardFlag: true,
				onShowFlag: 0,
				timeId: null, //定时器标识
				zxMsg: [], //小助手初始化数据
			}
		},
		computed: {
			...mapState(['loginInfoObj', 'userInfoObj'])
		},
		mounted() {

		},
		/**
		 * 生命周期函数--监听页面加载
		 */
		onLoad(options) {
			var receiveMemberId = options.receiveMemberId
			var sendMemberId = this.loginInfoObj.open_id
			var sendAvatar = this.userInfoObj.avatarUrl
			// var receiveMemberId = 'oNIYe5KA-Lf9klIV05lKpuBNm52M'
			// var sendMemberId = 'oNIYe5IOvP5QXe31nMCGsBErGKbk'
			// var sendAvatar = '../../static/img/anonymity.png'
			this.receiveMemberId = receiveMemberId
			this.sendMemberId = sendMemberId
			this.sendAvatar = sendAvatar
			console.log(this.sendAvatar, 'hahha')
			console.log('发送者：' + sendMemberId, '接收者：' + receiveMemberId, 'hahha')
			//  获取内存中的数据
			this.getStorageBaseInfo()
			//  设置滚动区域的高度
			this.setScrollHeight()
			// 指真小助手添加一条消息
			this.zxAddMsg()
			//  获取历史记录 
			this.getHistory()
			// 初始化websocket
			this.initWebSocket()
			//  页面进入滚动到底部
			this.scrollBottom()
		},
		/**
		 * 生命周期函数--监听页面显示
		 */
		onShow() {
			console.log(this.onShowFlag, '看下参数')
			var onShowFlag = this.onShowFlag
			this.onShowFlag = onShowFlag + 1
			if (this.onShowFlag != 1) {
				// 初始化websocket
				this.initWebSocket()
				this.onSocketCloseFlag = false
				this.onUnloadFlag = false
			}

		},
		/**
		 * 生命周期函数--监听页面隐藏
		 */
		onHide() {
			uni.closeSocket();
			this.onSocketCloseFlag = true
			this.onUnloadFlag = true
			if (this.timeId) {
				clearTimeout(this.timeId)
			}
		},
		/**
		 * 生命周期函数--监听页面卸载
		 */
		onUnload() {
			uni.closeSocket();
			this.onSocketCloseFlag = true
			this.onUnloadFlag = true
			if (this.timeId) {
				clearTimeout(this.timeId)
			}
		},
		beforeDestroy() {
			if (this.timeId) {
				clearTimeout(this.timeId)
			}
		},
		methods: {
			//  websocket初始化
			initWebSocket() {
				var _this = this;
				var {
					receiveMemberId,
					sendMemberId
				} = this
				//建立连接
				uni.connectSocket({
					url: `${wssUrl}/zxxt/${sendMemberId}/${receiveMemberId}`, //正式
					success: function() {
						console.log('websocket连接成功~')
					},
					fail: function() {
						console.log('websocket连接失败~')
					},
				})

				//连接成功
				uni.onSocketOpen(function() {
					console.log('onSocketOpen', '连接成功,真正的成功');
				})

				//  接收服务器的消息事件
				uni.onSocketMessage(function(res) {

					// 接收到的消息{date,message,type}  type类型为 1 是对方的消息 为 0 是自己的消息

					var list = [];
					list = _this.newsList;
					var _data = JSON.parse(res.data);

					list.push(_data);
					_this.newsList = list
					_this.scrollBottom()
				}, )

				//  监听连接关闭
				uni.onSocketClose(function() {
					_this.onSocketCloseFlag = false

					if (!_this.onSocketCloseFlag && (!_this.onUnloadFlag)) {
						// 重新打开websocket
						_this.onSocketCloseFlag = true
						_this.initWebSocket()
					}
				})

			},
			// 获取历史记录
			async getHistory() {
				if (this.timeId) {
					clearTimeout(this.timeId)
				}
				var {
					receiveMemberId,
					sendMemberId,
					pageNo
				} = this
				var params = {
					receiveMemberId,
					sendMemberId,
					pageNo,
					pageSize: 5,
				}
				let res = await this.$http.getNoLoad('/zxxt/chat/msg/list', params);
				if (!res.data) return
				var resData = res.data.data
				// if(resData && resData.length == 0 && this.pageNo > 1) {
				// 	return uni.showToast({
				// 		title: '没有更多历史记录了',
				// 		icon: 'none',
				// 		duration: 2000
				// 	})
				// }
				resData.reverse()
				var queryHistoryList = this.historyList
				queryHistoryList = [...this.zxMsg, ...resData, ...queryHistoryList]
				var newHistory = [];
				var arryObj = {};
				for (var i = 0; i < queryHistoryList.length; i++) {
					if (!arryObj[queryHistoryList[i].id]) {
						newHistory.push(queryHistoryList[i])
						arryObj[queryHistoryList[i].id] = true
					}
				}
				newHistory.forEach(item => {
					if (item.send_member_id == sendMemberId) {
						item.type = 0
					} else {
						item.type = 1
					}
				});
				this.historyList = newHistory
				// this.timeId = setTimeout(()=>{
				// 	this.getHistory()
				// },1000*15)
			},
			// 指真小助手添加一条欢迎消息
			zxAddMsg() {
				// 为指真小助手添加一条固定数据
				if (this.receiveMemberId == 'zx') {
					var historyList = []
					historyList.unshift({
						content_msg: 'Hi，欢迎加入指真！快去完善个人信息。',
						create_time: '',
						type: 1,
						id: '010',
					})
					this.zxMsg = historyList
				}
			},
			// 设置滚动区域的高度
			setScrollHeight() {
				uni.getSystemInfo({
					success: (res) => {
						let scrollHeight = res.windowHeight - uni.upx2px(100) //获取系统信息，可使用窗口的高度
						// this.scrollHeight = (scrollHeight - 236) + 'px';
						this.scrollHeight = (scrollHeight - 128) + 'px';
					}
				});
			},
			// 滚动到底部
			scrollBottom() {
				var {
					newsList
				} = this
				if (newsList.length > 0) {
					var scrollid = `scrollid${newsList.length - 1}`
					this.scrollid = scrollid
				}
			},
			// 获取内存中聊天列表的用户信息
			getStorageBaseInfo() {
				//获取存储信息
				uni.getStorage({
					key: 'receivebaseInfo',
					success: (res) => {
						this.receivebaseInfo = res.data
					}
				})
			},
			// 跳转聊天好友信息详情页面
			goWechatInfo() {
				var openId = this.receivebaseInfo.open_id
				if (openId == 'zx') {
					return
				}
				if (openId) {
					uni.redirectTo({
						url: '/pages/multiEntry/information?openId=' + openId,
					})
				}
			},
			// 自定义下拉刷新
			refresh() {
				this.triggered = true
				// 下拉的实际操作
				var pageNo = this.pageNo + 1
				this.pageNo = pageNo
				if (this.timer) {
					clearTimeout(this.timer)
				}
				this.timer = setTimeout(() => {
					this.triggered = false
					this.getHistory()
				}, 2000)
			},
			// 发送消息
			send() {
				var _this = this;
				console.log('send发送前的数据查看', '发送者：' + this.sendMemberId, '接收者：' + this.receiveMemberId,
					'hahha')
				// 点击发送后关闭表情区域
				this.emotionVisible = false
				if (!_this.onSocketCloseFlag) {
					// 重新打开websocket
					_this.onSocketCloseFlag = true
					_this.initWebSocket()
				}
				if (_this.input) {
					uni.sendSocketMessage({
						data: _this.input,
						success: (res) => {
							console.log(res)
						},
						fail: (err) => {
							console.log('sendSocketMessage', '失败')
						}
					})
					var list = [];
					list = _this.newsList;
					var temp = {
						message: _this.input,
						create_time: this.$util.formatTime(new Date().getTime()),
						type: 0
					};
					list.push(temp);
					_this.newsList = list
					_this.input = null
					_this.scrollBottom()

				}
			},
			// 输入框输入
			bindChange(res) {
				this.input = res.detail.value
			},
			back() {
				uni.closeSocket();
			},
			emotionChange() {
				this.emotionVisible = !this.emotionVisible
				if(!this.emotionVisible) {
					uni.hideKeyboard()
				}
				uni.pageScrollTo({
					scrollTop: 0,
					duration: 0
				});
			},
			addemotion(index) {
				let {
					connectemoji,
					input
				} = this
				if (input) {
					input = input + connectemoji[index];
				} else {
					input = connectemoji[index]
				}

				this.input = input
			},
		}
	}
</script>

<style lang="scss" scoped>
	.chart-box {
		// background-color: #f7f7f7;
		.chat-header {
			display: flex;
			align-items: flex-start;
			justify-content: flex-start;
			height: 88px;
			padding: 0 37rpx;
			background-color: #fff;
			border-radius: 0px 0px 10px 10px;
		}

		.header-image-box {
			margin-right: 12px;
		}

		.header-image {
			width: 80rpx;
			height: 80rpx;
			border-radius: 50%;
		}
		
		.namePostion {
			display: flex;
			justify-content: flex-start;
			align-items: center;
			margin-bottom: 20rpx;
		}

		.chat-name {
			color: #333;
			font-size: 36rpx;
			font-weight: 600;
			min-width: 160rpx;
			max-width: 180rpx;
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
		}

		.chat-company {
			width: 446rpx;
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
			font-size: 28rpx;
			color: rgba(81, 81, 81, 100);
		}

		.chart-position {
			width: 416rpx;
			white-space: nowrap;
			overflow: hidden;
			text-overflow: ellipsis;
			font-size: 28rpx;
			color: rgba(81, 81, 81, 100);
			// margin-left: 12rpx;
		}

		.tab {
			padding: 20rpx 20rpx 40rpx 50rpx;
			height: 20%;
			background-color: white;
		}

		.tab .tent {
			font-size: 33rpx;
			margin-bottom: 30rpx;
		}

		.jia_img {
			height: 80rpx;
			width: 90rpx;
		}

		.new_imgtent {
			height: 180rpx;
			width: 190rpx;
		}

		.tab .fabu {
			font-size: 33rpx;
			margin-top: 30rpx;
			margin-bottom: 30rpx;
		}

		.xiahuaxia {
			width: 80%;
			text-align: center;
			margin: 0 auto;
			position: relative;
			top: 60rpx;
		}

		.chat-time {
			text-align: center;
			padding: 5rpx 20rpx 5rpx 20rpx;
			width: 200rpx;
			font-size: 26rpx;
			color: #AAAAAA;
		}

		.new_top_txt {
			width: 50%;
			position: relative;
			top: 38rpx;
			text-align: center;
			margin: 0 auto;
			font-size: 30rpx;
			color: #787878;
			background-color: #f7f7f7;
		}

		/* 聊天内容 */

		.news {
			// margin-top: 30px;
			text-align: center;
			// margin-bottom: 98px;
			background-color: #f7f7f7;
		}

		.img_null {
			height: 60rpx;
		}

		.l {
			height: 5rpx;
			width: 20%;
			margin-top: 30rpx;
			color: #000;
		}

		/* 聊天 */

		.my_right {
			float: right;
			position: relative;
			right: 40rpx;
		}

		.you_left {
			float: left;
			position: relative;
			left: 5rpx;
		}

		.new_img {
			width: 100rpx;
			height: 100rpx;
			border-radius: 50%;
		}

		.sanjiao {
			top: 20rpx;
			position: relative;
			width: 0px;
			height: 0px;
			border-width: 10px;
			border-style: solid;
		}

		.my {
			border-color: transparent transparent transparent #95d4ff;
		}

		.you {
			border-color: transparent #95d4ff transparent transparent;
		}

		.sendmessage {
			width: 100%;
			min-height: 60px;
			position: fixed;
			bottom: 0px;
			padding: 0 16px;
			background-color: rgba(242, 242, 242, 100);
			box-shadow: 0px -1px 5px 1px rgba(57, 57, 57, 0.1);
		}

		.send-message {
			display: flex;
			align-items: center;
			padding: 16px;
		}

		.sendmessage input {
			height: 80rpx;
			background-color: white;
			line-height: 80rpx;
			font-size: 28rpx;
			padding-left: 20rpx;
			border-radius: 36rpx;
		}

		.sendmessage button {
			width: 52px !important;
			height: 32px;
			line-height: 32px;
			background: #169171 !important;
			color: #fff !important;
			font-size: 14px !important;
			text-align: center;
			border: 0 !important;
			padding: 0 !important;
			margin: 0 !important;
			border-radius: 36rpx;
		}

		.historycon {
			height: 90%;
			width: 100%;
			flex-direction: column;
			display: flex;
			border-top: 0px;
		}

		.hei {
			margin-top: 50px;
			height: 20rpx;
		}

		.history {
			/* height: 300px;  */
			margin-top: 30rpx;
			// margin: 20rpx;
			font-size: 28rpx;
			line-height: 80rpx;
			word-break: break-all;
		}

		.chat-input {
			width: 60%;
			height: 40px;
			border: 0;
			border-radius: 8px;
			margin-left: 5rpx;
		}

		.back-icon {
			margin-top: 25rpx;
			margin-left: 25rpx;
			width: 40rpx;
			height: 40rpx;
		}

		.other-record-content {
			background-color: #fff;
			max-width: 180px;
			border-radius: 7px;
			padding: 0 20px;
			text-align: left;
			margin: 6px 0;
			line-height: 60rpx;
		}

		.other-record {

			display: flex;
			justify-content: flex-start;
		}

		.other-head-img {
			width: 70rpx;
			height: 70rpx;
			border-radius: 50%;
			margin: 10rpx 10rpx 10rpx 10rpx;
		}

		.other-record-content-triangle {
			width: 0;
			height: 0;
			border-top: 10rpx solid transparent;
			border-right: 15rpx solid #fff;
			border-bottom: 10rpx solid transparent;
			margin-top: 36rpx;
		}

		.own-record {
			display: flex;
			justify-content: flex-end;
			padding-right: 30rpx;
		}

		.own-record-content {
			background-color: #92D9C6;
			max-width: 180px;
			border-radius: 8px;
			padding: 0 20px;
			color: #000;
			text-align: left;
			margin: 6px 0;
			line-height: 60rpx;
		}

		.own-record-content-triangle {
			width: 0;
			height: 0;
			border-top: 10rpx solid transparent;
			border-left: 15rpx solid #92D9C6;
			border-bottom: 10rpx solid transparent;
			margin-top: 36rpx;
		}

		.own-head-img {
			width: 70rpx;
			height: 70rpx;
			border-radius: 50%;
			margin: 10rpx 10rpx 10rpx 10rpx;
		}

		::-webkit-scrollbar {
			width: 0;
			height: 0;
			color: transparent;
		}

		.chat-emotion {
			width: 28px;
			height: 28px;
			margin: 0 12px;
		}

		.emotions {
			// display: flex;
			// align-items: flex-start;
			// justify-content: flex-start;
			// width: 200px;
			// height: 36px;
			margin: 6px;
			margin-left: 12px;
			margin-right: 12px;
		}

		.emotions-item {
			display: inline-block;
			width: 24px;
			height: 24px;
			margin: 0 8px;
		}

		.historyText {
			color: #ccc;
		}

		.iconfont {
			font-size: 64rpx;
			margin: 0 19rpx;
			color: #999;
		}
	}
</style>
