<template>
	<view class="search-container">
		<view class="search-box">
			<vSearch class="vserch" @emitSearch="emitSearch" ref="vSearch"></vSearch>
			<view class="total-message">共 {{searchList.length}} 条信息</view>
		</view>
		<view class="search-list" v-if="searchList.length > 0">
			<view class="list-item" v-for="(item,index) in searchList" :key="index" @tap="goWechat(item)">
				<view class="icon-box">
					<image v-if="item.open_id == 'zx'" src="../../static/img/zhizhen_help.png" mode="widthFix" class="left"></image>
					<image v-else-if="item.avatar" :src="item.avatar" mode="widthFix" class="left"></image>
					<image v-else src="../../static/img/anonymity.png" mode="widthFix" class="left"></image>
					<view v-if="item.online_flag != 1" class="imgMask"></view>
				</view>
				<view class="right">
					<view class="titleTime">
						<view v-if="item.open_id == 'zx'" class="title">指真小助手</view>
						<rich-text class="title" :nodes="$util.brightenKeyword((item.user_name?item.user_name:(item.nickname?item.nickname:'')),searchIptValue)"></rich-text>
						<view class="time">{{item.create_time}}</view>
					</view>
					<rich-text class="text" :nodes="$util.brightenKeyword(item.content_msg,searchIptValue)"></rich-text>
				</view>
			</view>
		</view>
		<vNoResult v-else :txt="txt"></vNoResult>
	</view>
</template>

<script>
	import vSearch from "components/common/vSearch"
	import vNoResult from "components/common/vNoResult"
	import {
		mapState
	} from "vuex"
	export default {
		components: {
			vSearch,
			vNoResult
		},
		data() {
			return {
				txt: '暂无数据',		//noresult
				searchIptValue: '', //搜索框输入
				searchList: [], //搜索结果列表
				pageNo: 1,	//当前页
				pageSize: 20,	//每页多少条
				dataTotal: 0,	//总条数
				isSearch: false,	//是否是搜索中状态-搜索中列表覆盖;非搜索中，列表合并;
			}
		},
		mounted() {},
		computed: {
			...mapState(['loginInfoObj'])
		},
		methods: {
			// 子组件输入框值获取
			emitSearch(data) {
				this.searchIptValue = data.val
				if (data.val.length > 0) {
					// 搜索中标识
					this.isSearch = true
					this.getSearchList()
				}
			},
			// 根据输入框的值搜索结果
			async getSearchList() {
				let data = {
					openId:this.loginInfoObj.open_id,
					pageNo: this.pageNo,
					pageSize: this.pageSize,
					name: this.searchIptValue
				}
				let res = await this.$http.getHasLoad('/zxxt/user/messageSearch', data);
				var searchList = res.data.message_vos
				if (searchList) {
					// 搜索中列表覆盖
					if (this.isSearch) {
						this.searchList = searchList
					}else {
						// 非搜索中列表合并
						searchList = [...this.searchList,...searchList]
						var newSearchList  = [];
						var arryObj = {};
						for(var i=0; i < searchList.length; i++ ) {
							if(!arryObj[searchList[i].open_id]) {
								newSearchList.push(searchList[i])
								arryObj[searchList[i].open_id] = true
							}
						}
						this.searchList = newSearchList
					}
					// 总条数
					this.dataTotal = res.data.data_total || 0
				}
			},
			// 点击好友列表项,进入会话
			async goWechat(receivebaseInfo) {
				// 存入缓存信息
				uni.setStorageSync('receivebaseInfo', receivebaseInfo)
				// 埋点请求
				let open_id = this.loginInfoObj.open_id
				let re_open_id = receivebaseInfo.open_id
				let data = {
					open_id,
					re_open_id
				}
				var res = await this.$http.postHasLoad('/zxxt/chat/readMsg', data);
				if (res.code == 'success') {
					// 跳转会话页面
					uni.navigateTo({
						url: '/pages/news/chart?receiveMemberId=' + re_open_id,
					});
				}
			
			},
			// 上拉加载更多
			onReachBottom() {
				// 搜索中的标识
				this.isSearch = false
				if(!(this.pageNo * this.pageSize >= this.dataTotal)) {
					this.pageNo = this.pageNo + 1
					this.getSearchList()
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	.search-container {
		padding: 0 30rpx;

		.search-box {
			border-bottom: 1px solid #E0E0E0;

			.total-message {
				color: #AAAAAA;
				font-size: 24rpx;
				margin: 37rpx 0 28rpx 0;
			}
		}

		.search-list {
			.list-item {
				display: flex;
				justify-content: flex-start;
				align-items: center;
				padding: 29rpx 0 31rpx 0;
				border-bottom: 1px solid #E0E0E0;

				.icon-box {
					position: relative;
					.imgMask {
						position: absolute;
						left: 0;
						top: 0;
						width: 80rpx;
						height: 80rpx;
						background-color: #fff;
						opacity: 0.5;
					}
				}

				.iconfont {
					font-size: 90rpx;
				}

				.brage {
					position: absolute;
					top: 0;
					right: 0;
					padding: 6rpx;
					font-size: 20rpx;
					color: #fff;
					background-color: #F64135;
					border-radius: 50%;
				}

				.left {
					width: 80rpx !important;
					height: 80rpx;
					border-radius: 50%;
				}

				.right {
					width: 100%;
					margin-left: 24rpx;

					.titleTime {
						display: flex;
						justify-content: space-between;
						align-items: center;
						margin-bottom: 19rpx;

						.title {
							color: #333333;
							font-size: 28rpx;
						}

						.time {
							font-size: 24rpx;
							color: #AAAAAA;
						}
					}

					.text {
						width: 540rpx;
						font-size: 28rpx;
						color: #999999;
						white-space: nowrap;
						overflow: hidden;
						text-overflow: ellipsis;
					}
				}
			}
		}
	}
</style>
