<template>
	<!-- 临时跳转页面，兼容版本 -->
	<view></view>
</template>

<script>
	export default {
		data() {
			return {}
		},
		onLoad() {
			uni.switchTab({
				url: '/pages/index/index',
			});
		},
		methods: {}

	}
</script>

<style lang="scss" scoped>
</style>
