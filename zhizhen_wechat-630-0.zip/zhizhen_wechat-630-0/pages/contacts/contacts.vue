<template>
	<view :style="{'padding-top':statusBarHeight+'px', height: `calc(100vh - ${statusBarHeight}px)`}">
		<vStatusbar txt="人脉"></vStatusbar>
		<!-- 顶部搜索框 -->
		<view class="top-search">
			<navigator url="../contacts/contactsSearch" hover-class="none">
				<view class="search-input">
					<view class="iconfont icon-sousuo icon-search"></view>
					<view class="searchtips">
						请输入关键字
					</view>
				</view>
			</navigator>
			<navigator url="../contacts/inviteComments" hover-class="none">
				<view class="iconfont icon-yaoqingxiexin1 icon-yao"></view>
			</navigator>
		</view>
		<!-- 我的好友 -->
		<view class="friend-title" @tap="toMyfriend">
			<text class="friend-tl">我的好友</text>
			<view class="friend-tr">
				<text>全部</text>
				<view class="iconfont icon-s-xiangyou icon-tor"></view>
			</view>
		</view>
		<view class="myfriend">
			<view class="myfrienditem" v-for="(item,index) in friendList" :key="index">
				<template v-if="item.avatar || item.user_name || item.open_id">
					<image class="friendimg" :src="item.avatar ? item.avatar : '/static/img/anonymity.png'"
						mode="aspectFill" :data-openid='item.open_id' @tap="tofriendInfo"></image>
					<view class="friendname" :data-openid='item.open_id' @tap="tofriendInfo">
						{{item.user_name ? item.user_name : '--'}}
					</view>
					<view class="newfriend" v-if="item.online_flag == 0" :data-openid='item.open_id'
						@tap="tofriendInfo">
						new
					</view>
				</template>
			</view>
		</view>
		<!-- 推荐，同事，同学，同行 - 人脉列表 -->
		<view class="top-tab">
			<view class="tabson">
				<view class="tabsons">
					<block v-for="(item, key) in titleList" :key="key">
						<view class="tabitem" :data-key="key" @tap="titleClick">
							<view class="tabitemname" :class="[tabCurrentIndex == key ? 'actcol' : '' ]">
								{{item}}
							</view>
							<view class="actbor" v-if="tabCurrentIndex == key"></view>
						</view>
					</block>
				</view>
				<!-- 新增 最新最亲 列表条件  2021.7.26-->
				<view class="tabsons2" @tap="relationPop">
					{{relation == 0 ? '最新' : '最亲'}}
					<view class="iconfont icon-s-xiangxia icon-tox"></view>
				</view>
				<view class="pop" v-if="repop == true"></view>
				<view class="jian" v-if="repop == true"></view>
				<view class="sellisttype" v-if="repop == true">
					<view :class="selactive == 0 ? 'selitem bor selthis' : 'selitem bor'" @tap="selRelation">
						最新<view class="iconfont icon-s-OK icon-ok" v-if="selactive == 0"></view>
					</view>
					<view :class="selactive == 1 ? 'selitem selthis' : 'selitem'" @tap="selRelation">
						最亲<view class="iconfont icon-s-OK icon-ok" v-if="selactive == 1"></view>
					</view>
				</view>
				
			</view>
		</view>
		<!-- 列表数据 -->
		<block v-if="fillInFlag == '1' && dataList.length > 0">
			<view class="list">
				<scroll-view scroll-y="true" style="height: 100%;" @scrolltolower="onLower">
					<block v-for="(item, key) in dataList" :key="key">
						<view class="listitem">
							<view class="list-l" :data-states="item.states" :data-openid="item.open_id"
								:data-phone="item.can_phone" :data-outerid='item.outer_id' @tap="toInfo">
								<view class="list-limg">
									<image :src="item.avatar" mode="aspectFill" class="list-limgs"></image>
									<view class="newf" v-if="item.new_flag == 1">
										new
									</view>
								</view>
								<view class="list-info">
									<view class=""
										style="height: 100rpx;display: flex;flex-direction: column;justify-content: space-around;align-items: flex-start;">
										<view class="list-name">
											{{item.user_name}}<text class="list-position"
												v-if="item.position_name">{{item.position_name}} </text>
										</view>
										<view class="list-company" v-if="item.company_name">
											{{item.company_name}}
										</view>
									</view>
									<template v-if="item.div == 2 || item.div == 3">
										<view class="list-samefriend" v-if="item.div == 2">
											<!-- <text class="list-samenum">{{item.common_friends}}</text>位共同好友 -->
											<view class="iconfont icon-gongtonghaoyou2 icon-samenum"></view>
											二度人脉-共同好友{{item.div_count}}人
										</view>
										<view class="list-samefriend" v-if="item.div == 3">
											<view class="iconfont icon-gongtonghaoyou3 icon-samenum"></view>三度人脉
										</view>
									</template>
								</view>
							</view>
							<!-- 0:申请中，1：同意，2：忽略 -->
							<view v-if="item.states == 1" class="iconfont icon-tianjiahaoyou1 icon-addf"></view>
							<view v-else-if="item.states == 0" class="iconfont icon-jiahaoyouzhong icon-addf"></view>
							<view v-else :data-phone="item.can_phone" :data-id="item.id" @tap="addThisfriend"
								class="iconfont icon-jiahaoyou1 icon-addf"></view>
						</view>
					</block>
				</scroll-view>
			</view>

		</block>
		<block v-if="fillInFlag == '1' && dataList.length <= 0">
			<!-- <view class="tips-info">暂无推荐信息...</view> -->
			<vNoResult :txt="txt"></vNoResult>
		</block>

		<!-- 完善履历 - 弹层 -->
		<view class="pop" v-if="fillInFlag == '0'">
			<view class="popmain">
				<image class="popback" src="../../static/img/popback2.png" mode=""></image>
				<image class="pophead" :src=" avatar ? avatar : '../../static/img/anonymity.png'" mode=""></image>
				<view class="popname">
					{{username ? username : nickName}}
				</view>
				<view class="poptips">完善您的履历信息 ,</view>
				<view class="poptips">轻松建立职场人脉~</view>
				<view class="popbtn" v-if="flag == 0" @tap="toAddInfo0">
					完善履历
				</view>
				<view class="popbtn" v-if="flag == 1" @tap="toAddInfo1">
					完善履历
				</view>
			</view>
			<view class="iconfont icon-s-shanchutupian icon-delpop" @tap="delPop"></view>
		</view>

	</view>
</template>
<script>
	/**
	 * 人脉页面  
	 */
	import vNoResult from "components/common/vNoResult"
	import vStatusbar from "components/common/vStatusbar.vue"
	export default {
		components: {
			vNoResult,
			vStatusbar
		},
		data() {
			return {
				txt: '暂无数据',
				showDelete: false,
				inputValue: '',
				openid: '',
				friendList: [], //
				titleList: ['推荐', '同事', '同学', '同行'],
				tabCurrentIndex: 0,
				flag: 0, //人脉类别
				dataList: [], //列表
				avatar: '', //头像
				nickName: '', //
				username: '',
				first: 0, //用于限制onshow
				pageSize: 10, //每页数量
				pageNo: 1, //当前页码
				alldata: 0, //列表总数据
				allpage: 1, //总页码
				fillInFlag: '', //
				statusBarHeight: 0,
				flagother: true, //上拉加载scroll多频触发问题
				canclick: true, //可点击tab
				friendshow: 0, //用于限制请求出发多次登录页，并且首次进入人脉页获取人脉列表，并且返回人脉页时不触发onshow
				onshowFlag: 0, //用于限制onshow触发

				relation: 0, //0最新 1最亲
				repop: false, //最新最亲灰色弹层
				selactive: 0, //
			}
		},

		onLoad(options) {
			let res = uni.getSystemInfoSync();
			let menu = wx.getMenuButtonBoundingClientRect();
			this.statusBarHeight = (menu.top - res.statusBarHeight) * 2 + menu.height + res.statusBarHeight;
			if (res.model.indexOf('iPhone') > -1) {
				this.statusBarHeight += 4
			}
			this.openid = uni.getStorageSync("loginInfoObj").open_id
			this.username = uni.getStorageSync("loginInfoObj").user_name
			let info = uni.getStorageSync("userInfoObj")
			// let hasphone = uni.getStorageSync("userPhoneObj")
			// if (info || hasphone) {
			this.avatar = info.avatarUrl
			this.nickName = info.nickName
			this.newFriend() //好友列表
			// } else {
			// 	//无信息跳转登录
			// 	uni.navigateTo({
			// 		url: '/pages/login/login'
			// 	});
			// }
		},

		onShow() {
			this.onshowFlag++
			// 重新获取列表
			if (this.onshowFlag != 1) {
				this.newFriend() //好友列表
			}
		},

		onShareAppMessage(res) {
			if (res.from == "menu") {
				return {
					title: `欢迎进入指真小程序！`,
					path: "/pages/index/index",
					imageUrl: '/static/img/forward_details.png'
				}
			}
		},

		methods: {
			// 触发选择最新最亲
			relationPop() {
				this.repop = true
			},
			// 选择最新 最亲
			selRelation() {
				if (this.relation == 0) {
					this.selactive = 1
					this.relation = 1
					this.repop = false
					this.dataList = []
				} else if (this.relation == 1) {
					this.selactive = 0
					this.relation = 0
					this.repop = false
					this.dataList = []
				}
				this.getList(1)
			},
			// 好友详情
			tofriendInfo(e) {
				uni.navigateTo({
					url: '/pages/multiEntry/information?openId=' + e.currentTarget.dataset.openid
				});
			},

			//去添加履历
			toAddInfo0() {
				uni.navigateTo({
					url: '/pages/my/myRecord/exerciseDetail'
				})
			},

			//去添加学历
			toAddInfo1() {
				uni.navigateTo({
					url: '/pages/my/myRecord/eduDetail'
				})

			},

			// 去我的好友
			toMyfriend() {
				uni.navigateTo({
					url: '/pages/friendPage/friendList'
				});
			},

			// 添加好友
			async addThisfriend(e) {
				console.log(e)
				let phone = "";
				let reOpenId = "";
				let re_states = 0;
				if (this.flag == 1) {
					re_states = 0
				}
				if (this.flag == 2) {
					re_states = 1
				}
				if (this.flag == 5) {
					re_states = 5
				}
				if (e.target.dataset.id) {
					reOpenId = e.target.dataset.id;
				}
				if (e.target.dataset.phone) {
					phone = e.target.dataset.phone;
				}
				let that = this
				let params = {
					open_id: this.openid,
					re_open_id: reOpenId,
					can_phone: phone,
					re_states: re_states
				}
				let res = await this.$http.postHasLoad('/zxxt/user/addFriend', params)
				if (res.code == 'success') {
					uni.showToast({
						title: "请求已发送！",
						icon: 'success',
						duration: 2000,
						success: function() {
							that.dataList.forEach(item => {
								if (phone == item.can_phone) {
									item.states = 0
								}
							})
							that.dataList = that.dataList
							// setTimeout(function () {
							//   that.getAppendFriend()
							// }, 2000) //获取人脉红点数据
						},
						fail: function() {},
						complete: function() {}
					})
				}
			},

			// 切换tab
			titleClick(e) {
				// this.flagother = true
				if (this.canclick) {
					this.canclick = false
					setTimeout(() => {
						this.canclick = true
					}, 500)
					this.dataList = []
					this.tabCurrentIndex = e.currentTarget.dataset.key;
					if (e.currentTarget.dataset.key == 3) {
						this.flag = 5
					} else {
						this.flag = e.currentTarget.dataset.key
					}
					this.getList(1)
				}
			},

			// 进入详情 states =  0: 申请中，1：同意，2：忽略
			toInfo(e) {
				let that = this
				console.log(this.flag)
				if (e.currentTarget.dataset.states == 1) { //好友 > 好友详情
					uni.navigateTo({
						url: '/pages/multiEntry/information?openId=' + e.currentTarget.dataset.openid
					});
				} else { //非好友 > 猜你认识
					uni.navigateTo({
						url: '/pages/multiEntry/guessYoudo?phone=' + e.currentTarget.dataset.phone +
							'&hisopenid=' + e.currentTarget.dataset.openid + '&flag=' + that.flag + '&outerid=' + e
							.currentTarget.dataset.outerid
					});
				}
			},

			// 获取人脉列表
			async getList(pageNo) {
				let that = this
				let params = {
					openId: this.openid,
					flag: this.flag,
					pageNo: pageNo,
					pageSize: this.pageSize,
					sort: this.relation
				}
				let res = await this.$http.getHasLoad('/zxxt/recommend/myListDetailed', params)
				if (res) {
					let friendList = res.data.wx_parameter_vos
					friendList.forEach(item => {
						if (!item.avatar) { //无头像
							if (item.sex) { //有性别
								if (item.sex == '女') {
									item.avatar = "/static/img/woman.png"
								}
								if (item.sex == '男') {
									item.avatar = "/static/img/man.png"
								}
							} else { //无性别
								item.avatar = "/static/img/anonymity.png"
							}
						}
					})
					if (that.dataList.length > 0) {
						that.dataList = that.dataList.concat(friendList)
					} else {
						that.dataList = friendList
					}
					that.fillInFlag = res.data.fill_in_flag
					that.pageNo = res.data.cur_page
					that.alldata = res.data.total
					let allpage = Math.ceil(res.data.total / that.pageSize)
					that.allpage = allpage
					// that.canclick = true//可以点击tab切换
					// that.flag = true
				}
			},

			delPop() {
				this.fillInFlag = '1'
			},

			// 上拉加载更多
			onLower() {
				let that = this;
				// if (!that.flagother) {
				// 	return
				// }
				// that.flagother = false
				if (that.pageNo >= that.allpage) { //最后一页
					uni.showToast({
						title: '到底啦~',
						icon: 'none',
						duration: 1500
					})
				} else { //还没到最后一页
					uni.showLoading({
						title: '加载更多',
						make: true
					})
					that.pageNo = that.pageNo + 1
					that.getList(that.pageNo);
				}
			},

			//顶部好友列表
			async newFriend() {
				let that = this
				let params = {
					openId: that.openid,
				}
				let res = await that.$http.getNoLoad('/zxxt/user/newFriend', params)
				if (res) {
					if (res.code == "success") {
						that.friendList = res.data
						that.friendshow++
						if (that.friendshow == 1) {
							that.getList(1) //人脉列表
						}
					}
				}
			},
		}
	}
</script>

<style lang="scss" scoped>
	// @import "../../wxcomponents/vant-weapp/tabs/index.wxss";
	// @import "../../wxcomponents/vant-weapp/tab/index.wxss";

	.pop {
		width: 100%;
		height: 100%;
		position: fixed;
		top: 0;
		left: 0;
		bottom: 0;
		right: 0;
		background-color: rgba(0, 0, 0, 0.3);
		z-index: 99;

		.popmain {
			width: 540rpx;
			height: 640rpx;
			background: #FFFFFF;
			border-radius: 26rpx;
			position: absolute;
			left: 50%;
			margin-left: -270rpx;
			top: 20%;
			background: #fff;
			display: flex;
			flex-direction: column;
			align-items: center;
			overflow: hidden;

			.popback {
				width: 100%;
				height: 240rpx;
				position: absolute;
				top: 0;
				left: 0;
				z-index: 1;
			}

			.pophead {
				width: 160rpx;
				height: 160rpx;
				border-radius: 50%;
				z-index: 2;
				margin-top: 152rpx;
				margin-bottom: 43rpx;
			}

			.popname {
				width: 100%;
				text-align: center;
				position: absolute;
				top: 96rpx;
				color: #fff;
				height: 35px;
				z-index: 9;
				font-size: 36rpx;
				font-weright: 400;
				color: #FFFFFF;
				line-height: 35rpx;
			}

			.poptips {
				font-size: 30rpx;
				font-weight: 400;
				color: #333333;
				line-height: 48rpx;
			}

			.popbtn {
				width: 360rpx;
				height: 88rpx;
				background: #209072;
				border-radius: 44rpx;
				display: flex;
				justify-content: center;
				align-items: center;
				font-size: 30rpx;
				color: #FFFFFF;
				font-weight: 400;
				margin-top: 50rpx;
			}
		}

		.icon-delpop {
			font-size: 90rpx;
			color: #0E1623;
			opacity: 0.5;
			position: absolute;
			left: 50%;
			margin-left: -45rpx;
			top: 80%;
		}
	}

	.top-search {
		display: flex;
		align-items: center;
		justify-content: space-between;
		flex-direction: row;
		width: 100%;
		height: 88rpx;
		box-sizing: border-box;
		padding: 0 30rpx;

		.search-input {
			width: 600rpx;
			height: 88rpx;
			background-color: #F3F3F3;
			border-radius: 44rpx;
			display: flex;
			flex-direction: row;
			align-items: center;
			box-sizing: border-box;
			padding: 0 0 0 30rpx;

			.icon-search {
				font-size: 34rpx;
				color: #333;
			}

			.searchtips {
				font-size: 30rpx;
				color: #AAAAAA;
				box-sizing: border-box;
				padding-left: 20rpx;
			}
		}

		.icon-yao {
			font-size: 42rpx;
			color: #209072;
		}
	}

	.friend-title {
		display: flex;
		height: 30rpx;
		box-sizing: border-box;
		padding: 0 40rpx 0 32rpx;
		justify-content: space-between;
		align-items: center;
		margin: 30rpx 0 20rpx;
	}

	.friend-tl {
		font-size: 30rpx;
		font-weight: 400;
		color: #333333;
	}

	.friend-tr {
		display: flex;
		align-items: center;
		justify-content: flex-end;
	}

	.icon-tor {
		color: #AAAAAA;
	}

	.friend-tr text {
		font-size: 24rpx;
		margin-right: 18rpx;
		font-weight: 400;
		color: #333333;
	}

	.myfriend {
		width: 100%;
		height: 118rpx;
		display: flex;
		flex-direction: row;
		justify-content: flex-start;
		box-sizing: border-box;
		padding: 0 10rpx;

		.myfrienditem {
			width: 20%;
			height: 118rpx;
			display: flex;
			justify-content: space-between;
			flex-direction: column;
			align-items: center;
			position: relative;

			.friendimg {
				width: 80rpx;
				height: 80rpx;
				border-radius: 50%;
			}

			.friendname {
				width: 120rpx;
				height: 36rpx;
				font-size: 24rpx;
				font-weight: 400;
				text-align: center;
				line-height: 36rpx;
				display: -webkit-box;
				-webkit-box-orient: vertical;
				-webkit-line-clamp: 1;
				overflow: hidden;
				color: #333333;
			}

			.newfriend {
				width: 51rpx;
				position: absolute;
				top: 2rpx;
				right: 2rpx;
				background-color: #F64135;
				line-height: 18rpx;
				height: 24rpx;
				box-sizing: border-box;
				border-radius: 12rpx;
				border: 2rpx solid #fff;
				display: flex;
				align-items: center;
				justify-content: center;
				font-size: 18rpx;
				color: #fff;
			}
		}
	}

	.top-tab {
		width: 100%;
		height: 105rpx;
		box-sizing: border-box;
		padding: 0 32rpx;

		.tabson {
			width: 100%;
			height: 105rpx;
			box-sizing: border-box;
			border-bottom: 1rpx solid #E0E0E0;
			padding-left: 11rpx;
			display: flex;
			justify-content: space-between;
			padding-top: 44rpx;
			position: relative;

			.tabsons2 {
				display: flex;
				flex-direction: row;
				justify-content: flex-end;
				font-size: 30rpx;
				color: #209072;
				line-height: 48rpx;
				align-items: center;
				margin-top: -30rpx;
				box-sizing: border-box;

				.icon-tox {
					font-size: 25rpx;
					color: #aaa;
					margin-left: 20rpx;
				}
			}

			.jian {
				border-top: 18rpx solid transparent;
				border-bottom: 18rpx solid #fff;
				width: 0;
				height: 0;
				border-right: 18rpx solid transparent;
				border-left: 18rpx solid transparent;
				position: absolute;
				top: 62rpx;
				right: 55rpx;
				z-index: 100;
			}

			.sellisttype {
				width: 320rpx;
				height: 200rpx;
				background: #FFFFFF;
				box-shadow: 0rpx 4rpx 16rpx 0rpx rgba(18, 18, 18, 0.19);
				border-radius: 12rpx;
				position: absolute;
				top: 93rpx;
				right: 0;
				z-index: 99;
				box-sizing: border-box;
				padding: 0 32rpx;

				.selitem {
					font-size: 30rpx;
					color: #333;
					display: flex;
					align-items: center;
					height: 99rpx;
					justify-content: space-between;
					box-sizing: border-box;
					padding-right: 10rpx;
				}

				.selthis {
					color: #209072 !important;
				}

				.bor {
					border-bottom: 2rpx solid #E2E2E2;
				}

				.icon-ok {
					font-size: 34rpx;
					color: #209072;
				}
			}

			.tabsons {
				display: flex;
				justify-content: flex-start;
				flex-direction: row;

				.tabitem {
					width: 60rpx;
					height: 52rpx;
					display: flex;
					flex-direction: column;
					justify-content: flex-start;
					align-items: center;
					margin-right: 55rpx;

					.tabitemname {
						font-size: 30rpx;
						line-height: 30rpx;
						color: #333;
						margin-bottom: 13rpx;
					}

					.actbor {
						width: 40rpx;
						height: 4rpx;
						background: #209072;
						border-radius: 2rpx;
					}

					.actcol {
						color: #209072 !important;
					}
				}
			}
		}
	}

	.tips-info {
		box-sizing: border-box;
		padding: 100rpx;
		color: #999;
		font-size: 28rpx;
		text-align: center;
	}

	.list {
		height: calc(100% - 400rpx);
		box-sizing: border-box;
		padding: 0 32rpx 0;

		.listitem {
			width: 100%;
			height: auto;
			box-sizing: border-box;
			border-bottom: 1rpx solid #E0E0E0;
			display: flex;
			padding: 36rpx 14rpx 40rpx;
			min-height: 160rpx;
			justify-content: space-between;
			align-items: center;

			.icon-addf {
				font-size: 48rpx;
				color: #209072;
			}

			.list-l {
				display: flex;
				flex-direction: row;
				justify-content: flex-start;

				.list-limg {
					width: 80rpx;
					display: flex;
					justify-content: flex-start;
					align-items: center;
					margin-right: 17rpx;
					height: 100%;
					position: relative;

					.list-limgs {
						width: 80rpx;
						height: 80rpx;
						border-radius: 50%;
					}

					.newf {
						width: 51rpx;
						position: absolute;
						top: 2rpx;
						right: -14rpx;
						background-color: #F64135;
						line-height: 18rpx;
						height: 24rpx;
						box-sizing: border-box;
						border-radius: 12rpx;
						border: 2rpx solid #fff;
						display: flex;
						align-items: center;
						justify-content: center;
						font-size: 18rpx;
						color: #fff;
					}
				}

				.list-info {
					width: 500rpx;
					min-height: 100rpx;
					display: flex;
					flex-direction: column;
					justify-content: space-around;
					align-items: flex-start;
					margin-top: -10rpx;

					.list-name {
						font-size: 34rpx;
						font-weight: 400;
						color: #333333;
						line-height: 34rpx;
						box-sizing: border-box;
						padding-left: 3rpx;
						// margin-bottom: 20rpx;
						display: -webkit-box;
						-webkit-box-orient: vertical;
						-webkit-line-clamp: 1;
						overflow: hidden;

						.list-position {
							width: 200rpx;
							height: 24rpx;
							font-size: 24rpx;
							color: #999999;
							margin-left: 24rpx;
							line-height: 24rpx;

						}
					}

					.list-company {
						font-size: 28rpx;
						color: #999999;
						height: 28rpx;
						line-height: 28rpx;
						display: -webkit-box;
						-webkit-box-orient: vertical;
						-webkit-line-clamp: 1;
						overflow: hidden;

					}

					.list-samefriend {
						font-size: 28rpx;
						color: #999999;
						margin-top: 28rpx;
						line-height: 28rpx;
						display: flex;
						flex-direction: row;
						align-items: center;

						.icon-samenum {
							font-size: 40rpx;
							color: #209072 !important;
							margin-right: 10rpx;
						}

						.list-samenum {
							color: #F64135 !important;
							margin-right: 4rpx;
						}
					}
				}
			}
		}
	}
</style>
