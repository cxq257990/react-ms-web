<template>
	<view>
		<view class="top-search">
			<vSearch @emitSearch="emitSearch" style="width: 100%;"></vSearch>
		</view>
		<view class="list" v-if="friendList.length > 0">
			<view class="listitem" v-for="(item,index) in friendList" :key="index">
				<view class="list-l" :data-states="item.states" :data-openid="item.open_id" :data-username="item.user_name" :data-outerid='item.outer_id' :data-phone="item.can_phone" @tap="toInfo">
					<view class="list-limg">
						<image :src="item.avatar ? item.avatar : '../../static/img/anonymity.png'" mode="aspectFill"
							class="list-limgs"></image>
					</view>
					<view class="list-info">
						<view class="list-name">
							<rich-text class="title" style="width: 130rpx;"
								:nodes="$util.brightenKeyword((item.user_name?item.user_name:item.nickname),hisname)">
							</rich-text>
							<!-- {{item.user_name}} -->
							<text class="list-position" v-if="item.position_name">{{item.position_name}} </text>
						</view>
						<view class="list-company" v-if="item.company_name">
							{{item.company_name}}
						</view>
					</view>
				</view>

				<!-- 0:申请中，1：同意，2：忽略 -->
				<view v-if="item.states == 1" class="iconfont icon-tianjiahaoyou1 icon-addf"></view>
				<view v-else-if="item.states == 0" class="iconfont icon-jiahaoyouzhong icon-addf"></view>
				<view v-else :data-phone="item.can_phone" :data-id="item.id" @tap="addThisfriend"
					class="iconfont icon-jiahaoyou1 icon-addf"></view>
				<!-- <view v-if="item.states != 0" class="iconfont icon-jiahaoyou1 icon-addf" :data-phone="item.can_phone"
					:data-id="item.id" @tap="addThisfriend"></view> -->
			</view>
		</view>
		<vNoResult v-else :txt="txt"></vNoResult>
	</view>
</template>

<script>
	/**
	 * 人脉搜索
	 */
	import vSearch from "components/common/vSearch"
	import vNoResult from "components/common/vNoResult"
	export default {
		components: {
			vSearch,
			vNoResult
		},
		data() {
			return {
				txt: '暂无数据',
				friendList: [], //数据列表
				pageSize: 10, //每页数量
				pageNo: 1, //页码
				alldata: 0, //返回数据总条数
				hisname: '', //搜索名字

				oldname: '', //
			}
		},
		onLoad(options) {
			this.openid = uni.getStorageSync("loginInfoObj").open_id
		},
		methods: {
			emitSearch(data) {
				console.log(data)
				if (this.oldname != data.val) {
					this.friendList = []
					this.oldname = data.val
				}
				this.hisname = data.val
				if (data.val.length > 0) {
					this.getList(1)
				}
			},
			
			// 进入详情 states =  0: 申请中，1：同意，2：忽略 
			toInfo(e) {
				console.log(e)
				if (e.currentTarget.dataset.states == 1) { //好友 > 好友详情
					uni.navigateTo({
						url: '/pages/multiEntry/information?openId=' + e.currentTarget.dataset.openid
					});
				} else { //非好友 > 猜你认识
					uni.navigateTo({
						url: '/pages/multiEntry/guessYoudo?phone=' + e.currentTarget.dataset.phone + '&hisopenid=' + e.currentTarget.dataset.openid + '&username=' + e.currentTarget.dataset.username + '&outerid=' + e.currentTarget.dataset.outerid
					});
				}
			},

			async getList(pageNo) {
				let that = this
				let params = {
					openId: that.openid,
					userName: that.hisname,
					pageNo: pageNo,
					pageSize: that.pageSize
				}
				let res = await this.$http.getHasLoad('/zxxt/recommend/connectionSearch', params)
				console.log(res)
				let friendList = res.data.wx_parameter_vos
				friendList.forEach(item => {
					// if (item.sex && item.sex == '男') {
					// 	item.avatar = "/static/img/man.png"
					// } else {
					// 	if (item.sex && item.sex == '女') {
					// 		item.avatar = "/static/img/woman.png"
					// 	} else {
					// 		item.avatar = "/static/img/anonymity.png"
					// 	}
					// }
					if(!item.avatar){//无头像
						if (item.sex){//有性别
							if(item.sex == '女'){
								item.avatar = "/static/img/woman.png"
							}
							if(item.sex == '男'){
								item.avatar = "/static/img/man.png"
							}
						}else{//无性别
							item.avatar = "/static/img/anonymity.png"
						}
					}
				})
				if (that.friendList.length > 0) {
					that.friendList = that.friendList.concat(friendList)
				} else {
					that.friendList = friendList
				}
				that.pageNo = res.data.cur_page
				that.alldata = res.data.total
				let allpage = Math.ceil(res.data.total / that.page_size)
				that.allpage = allpage
			},

			// 添加好友
			async addThisfriend(e) {
				let phone = "";
				let reOpenId = "";
				let re_states = 0;
				if (this.flag == 1) {
					re_states = 0
				}
				if (this.flag == 2) {
					re_states = 1
				}
				if (this.flag == 5) {
					re_states = 5
				}
				if (e.target.dataset.id) {
					reOpenId = e.target.dataset.id;
				}
				if (e.target.dataset.phone) {
					phone = e.target.dataset.phone;
				}
				let that = this
				let params = {
					open_id: this.openid,
					re_open_id: reOpenId,
					can_phone: phone,
					re_states: re_states
				}
				let res = await this.$http.postHasLoad('/zxxt/user/addFriend', params)
				if (res.code == 'success') {
					uni.showToast({
						title: "请求已发送！",
						icon: 'success',
						duration: 1500,
						success: function() {
							that.friendList.forEach(item => {
								if (phone == item.can_phone) {
									item.states = 0
								}
							})
							that.friendList = that.friendList
						},
						fail: function() {},
						complete: function() {}
					})
				}
			},

			// 上拉加载更多
			onReachBottom: function() {
				let that = this;
				if (that.pageNo >= that.allpage) { //最后一页
					uni.showToast({
						title: '到底啦~',
						icon: 'none',
						duration: 1500
					})
				} else { //还没到最后一页
					uni.showLoading({
						title: '加载更多',
						make: true
					})
					that.pageNo = that.pageNo + 1
					that.getList(that.pageNo);
				}
			},

		}
	}
</script>

<style lang="scss" scoped>
	.top-search {
		display: flex;
		align-items: center;
		justify-content: space-between;
		flex-direction: row;
		width: 100%;
		// height: 88rpx;
		box-sizing: border-box;
		padding: 10rpx 30rpx;

		.search-input {
			width: 690rpx;
			height: 88rpx;
			background-color: #F3F3F3;
			border-radius: 44rpx;
			display: flex;
			flex-direction: row;
			align-items: center;
			box-sizing: border-box;
			padding: 0 0 0 30rpx;

			.icon-search {
				font-size: 34rpx;
				color: #333;
			}

			.inpname {
				font-size: 30rpx;
				color: #333;
				box-sizing: border-box;
				padding-left: 20rpx;
				border: 0;
			}
		}
	}

	.list {
		box-sizing: border-box;
		padding: 0 32rpx 32rpx;
		margin-top: 21rpx;

		.listitem {
			width: 100%;
			height: auto;
			box-sizing: border-box;
			margin-top: -1rpx;
			border-bottom: 1rpx solid #E0E0E0;
			border-top: 1rpx solid #E0E0E0;
			display: flex;
			padding: 36rpx 14rpx 40rpx;
			min-height: 160rpx;
			justify-content: space-between;
			align-items: center;

			.icon-addf {
				font-size: 48rpx;
				color: #209072;
			}

			.list-l {
				display: flex;
				flex-direction: row;
				justify-content: flex-start;

				.list-limg {
					width: 80rpx;
					display: flex;
					justify-content: flex-start;
					align-items: center;
					margin-right: 17rpx;
					height: 100%;

					.list-limgs {
						width: 80rpx;
						height: 80rpx;
						border-radius: 50%;
					}
				}

				.list-info {
					width: 500rpx;
					height: auto;
					display: flex;
					flex-direction: column;
					justify-content: space-between;
					align-items: flex-start;

					.list-name {
						font-size: 34rpx;
						font-weight: 400;
						color: #333333;
						line-height: 34rpx;
						box-sizing: border-box;
						padding-left: 3rpx;
						margin-bottom: 20rpx;
						width: 100%;
						display: flex;
						align-items: center;
						flex-direction: row;

						.list-position {
							font-size: 24rpx;
							color: #999999;
							margin-left: 24rpx;
							line-height: 24rpx;
							width: 400rpx;
						}
					}

					.list-company {
						font-size: 28rpx;
						color: #999999;
						line-height: 28rpx;
					}

					.list-samefriend {
						font-size: 28rpx;
						color: #999999;
						margin-top: 28rpx;
						line-height: 28rpx;

						.list-samenum {
							color: #F64135 !important;
							margin-right: 4rpx;
						}
					}
				}
			}
		}
	}
</style>
