<template>
	<view class="body">
		<template v-if="forwardtype == 1">
			<view class="top-type">
				<view class="top-title">
					私聊邀请
				</view>
				<view class="top-status" @tap="changForwardType">
					切换为群聊邀请
				</view>
			</view>
		</template>
		<template v-if="forwardtype == 2">
			<view class="top-type">
				<view class="top-title">
					群聊邀请
				</view>
				<view class="top-status" @tap="changForwardType">
					切换为私聊邀请
				</view>
			</view>
		</template>

		<template v-if="forwardtype == 1">
			<view class="info">
				<view class="inp">
					<picker class="pickf" @change="bindRelationChange" :value="relationindex" :range="relationarray">
						<view class="pickeritem">
							{{relationindex == null ? "您和TA的关系" : relationarray[relationindex]}}
							<view class="iconfont icon-s-xiangxia icon-xia"></view>
						</view>
					</picker>
				</view>
				<view class="inp" v-if="relationindex != null && relationindex == 0">
					<picker class="pickf" @change="bindCompanyChange" :value="companyindex" :range="companyarray"
						:range-key="'name'">
						<view class="pickeritem">
							{{companyindex == null ? "请选择共事公司" : companyarray[companyindex].name}}
							<view class="iconfont icon-s-xiangxia icon-xia"></view>
						</view>
					</picker>
				</view>
				<view class="inp" v-if="relationindex != null && relationindex == 1">
					<picker class="pickf" @change="bindSchoolChange" :value="schoolindex" :range="schoolarray"
						:range-key="'school_name'">
						<view class="pickeritem">
							{{schoolindex == null ? "请选择共同院校" : schoolarray[schoolindex].school_name}}
							<view class="iconfont icon-s-xiangxia icon-xia"></view>
						</view>
					</picker>
				</view>
				<view class="inp bor"
					v-if="(companyarray[companyindex].name == '其他' && relationindex == 0) || (schoolarray[schoolindex].school_name == '其他' && relationindex == 1)"
					style="padding: 0 20rpx;box-sizing: border-box;">
					<view class="inpson" @tap="toAddInfo">
						<view class="inpson-l">
							<view class="iconfont icon-s-tianjia icon-add"></view>
							<view class="inpson-ltitle">
								添加{{relationindex == 0 ? '工作' : relationindex == 1 ? '教育' : ''}}履历</view>
						</view>
						<view class="iconfont icon-s-xiangyou icon-r"></view>
					</view>
				</view>
				<view class="inp">
					<input class="inpname" placeholder="TA的姓名" v-model="hisname" @input="inputName"
						placeholder-style="color:#aaa;" />
				</view>
				<view class="tex">
					<textarea class="inptext" placeholder="帮我评价一下呗~比心~"
						placeholder-style="color:#aaa;line-height: 45rpx;font-size: 26rpx;" v-model="wantsay"
						@input="inputWantsay" />
				</view>
			</view>
		</template>
		<template v-if="forwardtype == 2">
			<view class="info">
				<view class="tex">
					<textarea class="inptext" placeholder="指真网信用调查~大家帮我评价一下呗~比心~"
						placeholder-style="color:#aaa;line-height: 45rpx;font-size: 26rpx;" v-model="wantsayall"
						@input="inputWantsayall" />
				</view>
			</view>
		</template>
		<template v-if="forwardtype == 1">
			<button v-if="!relationindex || (relationindex == 0 && (companyindex == null || companyarray[companyindex].name == '其他')) || (relationindex == 1 && (schoolindex == null || schoolarray[schoolindex].school_name == '其他')) || hisname.length == 0" class="btn2">微信邀请</button>
			<button v-else data-name='one' class="btn" open-type="share">微信邀请</button>
		</template>
		
		<button v-if="forwardtype == 2" data-name='group' class="btn" open-type="share">微信邀请</button>
	</view>
</template>

<script>
	/**
	 * 邀请页面  
	 */
	export default {
		data() {
			return {
				relationarray: ['同事', '同学', '同行', '其他'],
				relationindex: null, //
				companyarray: [],
				companyindex: null, //
				schoolarray: [],
				schoolindex: null, //
				hisname: '',
				wantsay: '帮我评价一下呗~比心~',
				wantsayall: '指真网信用调查~大家帮我评价一下呗~比心~',
				forwardtype: 1,
				openid: '', //本人openid

				first: true, //用于限制onshow
			}
		},

		onLoad(options) {
			this.openid = uni.getStorageSync("loginInfoObj").open_id //提交人openid
		},

		onShow() {
			if (!this.first) {
				this.relationindex = null
				this.companyindex = null
				this.schoolindex = null
			}
		},

		onShareAppMessage(res) {
			console.log(res)
			let that = this
			let path, say
			if (res.target.dataset.name == "one") { //私聊
				let commonid = 0 //学校或公司的id标识
				let re_states
				if (that.relationindex == 0 && that.companyindex) { //同事
					commonid = that.companyarray[that.companyindex].id
					re_states = 0
				}
				if (that.relationindex == 1 && that.schoolindex) { //同学
					commonid = that.schoolarray[that.schoolindex].id
					re_states = 1
				}
				if (that.relationindex == 2) { //同行
					re_states = 5
				}
				if (that.relationindex == 3) { //其他
					re_states = 6
				}
				say = that.wantsay
				path = '/pages/evaluate/evaluationScore?states=' + re_states + '&openid=' + that.openid + '&commonid=' + commonid
			}
			if (res.target.dataset.name == "group") { //群聊
				say = that.wantsayall
				path = '/pages/evaluate/evaluationScore?states=4&commonid=0&openid=' + that.openid
			}
			return {
				title: say,
				path: path,
				imageUrl: '../../static/img/forward_evaluation.png',
				success(res) {},
				fail(res) {}
			}
		},

		methods: {
			// 切换转发类型
			changForwardType() {
				if (this.forwardtype == 1) {
					this.forwardtype = 2
				} else {
					this.forwardtype = 1
				}
			},
			//去添加信息
			toAddInfo() {
				this.first = false
				if (this.relationindex == 0) {
					uni.navigateTo({
						url: '/pages/my/myRecord/exerciseDetail'
					})
				}
				if (this.relationindex == 1) {
					uni.navigateTo({
						url: '/pages/my/myRecord/eduDetail'
					})
				}
			},
			//邀请个人姓名输入监听
			inputName(e) {
				console.log(e)
				this.hisname = e.target.value
			},
			//私人邀请留言输入监听
			inputWantsay(e) {
				console.log(e)
				this.wantsay = e.target.value
			},
			//群聊邀请留言输入监听
			inputWantsayall(e) {
				console.log(e)
				this.wantsayall = e.target.value
			},
			// 监听  选择关系
			bindRelationChange: function(e) {
				this.relationindex = e.target.value
				this.getlist()
			},
			// 监听 - 共事公司
			bindCompanyChange: function(e) {
				console.log('=', e)
				this.companyindex = e.target.value
			},
			// 监听 - 共同院校
			bindSchoolChange: function(e) {
				this.schoolindex = e.target.value
			},

			// 获取 - 共同院校和公司列表数据
			async getlist() {
				let that = this
				let params = {
					openId: this.openid
				}
				let res = await this.$http.getHasLoad('/zxxt/user/inviteMessage', params)
				if (res.code == 'success') {
					that.companyarray = res.data.record_vo_list
					that.schoolarray = res.data.education_vo_list
				}
				that.companyarray.push({
					name: '其他'
				})
				that.schoolarray.push({
					school_name: '其他'
				})
			},

			//私聊邀请
			// async toWechatone() {
			// 	let that = this
			// 	let commonid = 0 //学校或公司的id标识
			// 	let re_states
			// 	if (that.relationindex == 0 && that.companyindex) { //同事
			// 		commonid = that.companyarray[that.companyindex].id
			// 		re_states = 0
			// 	}
			// 	if (that.relationindex == 1 && that.schoolindex) { //同学
			// 		commonid = that.schoolarray[that.schoolindex].id
			// 		re_states = 1
			// 	}
			// 	if (that.relationindex == 2) { //同行
			// 		re_states = 5
			// 	}
			// 	if (that.relationindex == 3) { //其他
			// 		re_states = 6
			// 	}

			// 	if (!that.relationindex) {
			// 		return uni.showToast({
			// 			title: '请选择关系',
			// 			icon: 'none',
			// 			duration: 2000
			// 		})
			// 	}
			// 	if ((that.relationindex == 0 && that.companyindex == null) || (that.relationindex == 0 && that
			// 			.companyarray[that.companyindex].name == '其他')) {
			// 		return uni.showToast({
			// 			title: '请选择共同公司',
			// 			icon: 'none',
			// 			duration: 2000
			// 		})
			// 	}
			// 	if ((that.relationindex == 1 && that.schoolindex == null) || (that.relationindex == 1 && that
			// 			.schoolarray[that.schoolindex].school_name == '其他')) {
			// 		return uni.showToast({
			// 			title: '请选择共同学校',
			// 			icon: 'none',
			// 			duration: 2000
			// 		})
			// 	}
			// 	if (that.hisname.length == 0 && that.relationindex == 0) {
			// 		return uni.showToast({
			// 			title: '请填写Ta的姓名',
			// 			icon: 'none',
			// 			duration: 2000
			// 		})
			// 	}
			// 	let params = {
			// 		open_id: that.openid,
			// 		re_states: re_states,
			// 		re_name: that.hisname,
			// 		explains: that.wantsay,
			// 		is_index: 0, //来自首页 1是 0非
			// 		common_id: commonid
			// 	}
			// 	let res = await this.$http.postHasLoad('/zxxt/user/addInvite', params)
			// 	if (res.code == 'success') {
			// 		let id = res.data //用于获取转发中间页的展示信息
			// 		wx.navigateTo({
			// 			url: '/pages/contacts/forwardInfo?id=' + id + '&states=' + re_states +
			// 				'&commonid=' + commonid,
			// 		})
			// 	}
			// },
			// 群聊邀请
			// async toWechatgroup() {
			// 	// app.globalData.log_evaluate = 1
			// 	let that = this
			// 	let params = {
			// 		open_id: that.openid,
			// 		explains: that.wantsayall,
			// 		is_index: 0
			// 	}
			// 	let res = await this.$http.postHasLoad('/zxxt/user/addInvite', params)
			// 	if (res.code == 'success') {
			// 		let id = res.data //用于获取转发中间页的展示信息
			// 		wx.navigateTo({
			// 			url: '/pages/contacts/forwardInfo?id=' + id + '&states=4',
			// 		})
			// 	}
			// },
		}
	}
</script>

<style lang="scss" scoped>
	.body {
		background-color: #F7F7F7;
		width: 100%;
		height: 100%;
		position: absolute;
	}

	.top-type {
		width: 100%;
		height: 48rpx;
		box-sizing: border-box;
		padding: 0 34rpx 0 31rpx;
		display: flex;
		justify-content: space-between;
		align-items: flex-end;
		margin-bottom: 37rpx;
		margin-top: 40rpx;

		.top-title {
			font-size: 48rpx;
			color: #333;
			line-height: 48rpx;
		}

		.top-status {
			font-size: 30rpx;
			color: #209072;
			line-height: 30rpx;
		}
	}

	.info {
		width: 100%;
		height: auto;
		box-sizing: border-box;
		// border-top: 1rpx solid #E0E0E0;
		background-color: #fff;
		padding: 0 32rpx;

		.inp {
			width: 100%;
			height: 89rpx;
			box-sizing: border-box;
			border-bottom: 1rpx solid #E0E0E0;

			.pickf {
				width: 100%;
				height: 88rpx;
				box-sizing: border-box;
				font-size: 32rpx;
				color: #666;
				padding-right: 16rpx;

				.pickeritem {
					width: 100%;
					display: flex;
					justify-content: space-between;
					align-items: center;
					color: #666;
					height: 88rpx;

					.icon-xia {
						font-size: 26rpx;
						color: #aaa;
					}
				}
			}

			.inpson {
				width: 100%;
				display: flex;
				justify-content: space-between;
				align-items: center;
				height: 88rpx;

				.inpson-l {
					display: flex;
					flex-direction: row;
					align-items: center;
					justify-content: flex-start;

					.icon-add {
						color: #209072;
						font-size: 26rpx;
					}

					.inpson-ltitle {
						font-size: 32rpx;
						color: #333333;
						margin-left: 12rpx;
					}
				}

				.icon-r {
					color: #AAAAAA;
					font-size: 26rpx;
				}
			}

			.inpname {
				color: #666;
				width: 100%;
				height: 88rpx;
				font-size: 26rpx;
			}

		}

		.tex {
			width: 100%;
			min-height: 320rpx;
			box-sizing: border-box;
			padding-top: 22rpx;

			.inptext {
				color: #666;
				width: 100%;
				height: 298rpx;
				font-size: 26rpx;
				line-height: 36rpx;
			}
		}
	}

	.btn {
		width: 640rpx;
		height: 88rpx;
		margin: 60rpx auto;
		background: #209072;
		display: flex;
		justify-content: center;
		align-items: center;
		font-size: 34rpx;
		color: #fff;
		border-radius: 44rpx;
	}
	.btn2 {
		width: 640rpx;
		height: 88rpx;
		margin: 60rpx auto;
		background: #ccc;
		display: flex;
		justify-content: center;
		align-items: center;
		font-size: 34rpx;
		color: #fff;
		border-radius: 44rpx;
	}
</style>
