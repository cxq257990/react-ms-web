<template>
	<view class="friend-list">
		<view class="friend-header">
			<vSearch class="vserch" @emitSearch="emitSearch"></vSearch>
			<view class="iconfont icon-yaoqingxiexin1" @tap="inviteComments"></view>
		</view>
		<view class="friend-tap">
			<view class="totalmessage">共{{allMessage}}条信息</view>
			<view class="tap">
				<view class="tap-item" v-for="(item,index) in tapList" :key="index" @tap="changeTap(index)">
					<view class="text">
						<view v-if="tapIndex != index" class="content">{{item.content}}</view>
						<view v-else class="content-color  content">{{item.content}}</view>
						<view class="line" v-if="tapIndex == index"></view>
					</view>
					<view class="num">{{item.num}}</view>
				</view>
			</view>
		</view>
		<view class="index-bar" v-if="searchList && searchList.length > 0">
			<view class="letters">
				<view class="letter-item" v-for="(item, index) in letters" :key="index"
					@click="goAnchor('#anchor-'+index,index)">{{item}}</view>
			</view>
			<view class="list-box">
				<view class="list-items" v-for="(item,index) in searchList" :key="index" :id="'anchor-'+index">
					<view class="letter">{{item.name}}</view>
					<view class="listitem" v-for="(items,indexs) in item.list" :key="indexs" @tap="goWechat(items)">
						<!-- <image :src="items.avatar?items.avatar:'../../static/img/man.png'"></image> -->
						<view class="imageBox">
							<image v-if="items.avatar" :src="items.avatar"></image>
							<image v-else src="../../static/img/man.png"></image>
							<view v-if="item.online_flag != 1" class="imgMask"></view>
						</view>
						<view class="detail">
							<view class="info">
								<rich-text class="name" :nodes="$util.brightenKeyword(items.user_name,searchIptValue)">
								</rich-text>
								<view class="position">{{items.position_name?items.position_name:''}}</view>
							</view>
							<view class="company">{{items.company_name?items.company_name:''}}</view>
						</view>
					</view>
				</view>
			</view>
		</view>
		<vNoResult v-else txt='暂无数据'></vNoResult>
	</view>
</template>
<script>
	import vSearch from "components/common/vSearch"
	import vNoResult from "components/common/vNoResult"
	import {
		mapState
	} from "vuex";
	export default {
		components: {
			vSearch,
			vNoResult
		},
		data() {
			return {
				tapList: [{
						content: '同事',
						line: true,
						num: 0
					},
					{
						content: '同学',
						line: false,
						num: 0
					},
					{
						content: '同行',
						line: false,
						num: 0
					},
					{
						content: '其他',
						line: false,
						num: 0
					}
				],
				searchList: [],
				// letters:['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'],
				letters: [],
				searchIptValue: '', //搜索框输入
				strings: '', //姓名高亮时返回的节点
				tapIndex: 0, //tap默认的索引
				pageNo: 1, //当前页
				pageSize: 100, //每页多少条
				flag: 0, //搜素分类标识
				edu_count: 0, //同学
				job_count: 0, //同事
				public_job_count: 0, //同行
				other_count: 0, //其他
			}
		},
		onLoad() {

		},
		computed: {
			...mapState(['loginInfoObj']),
			allMessage() {
				return this.edu_count + this.job_count + this.public_job_count + this.other_count
			}
		},
		mounted() {},
		methods: {
			// 锚点跳转
			goAnchor(id, index) {
				uni.createSelectorQuery().select(id).boundingClientRect(data => { //目标位置的节点：类或者id
					uni.createSelectorQuery().select('.list-box').boundingClientRect(res => { //最外层盒子的节点：类或者id
						uni.pageScrollTo({
							duration: 100, //过渡时间
							scrollTop: data.top - res.top, //到达距离顶部的top值
						})
					}).exec();
				}).exec();
			},
			// 子组件输入框值获取
			emitSearch(data) {
				this.searchIptValue = data.val
				if (this.searchIptValue.length > 0) {
					// 获取好友搜索列表
					this.getSearchList()
				}

			},
			// tap切换
			changeTap(index) {
				this.tapIndex = index
				if (index == 0) {
					this.flag = 0
				}
				if (index == 1) {
					this.flag = 1
				}
				if (index == 2) {
					this.flag = 5
				}
				if (index == 3) {
					this.flag = 6
				}
				if (this.searchIptValue.length > 0) {
					// 获取好友搜索列表
					this.getSearchList()
				}
			},
			// 获取好友搜索列表
			async getSearchList() {
				let data = {
					openId: this.loginInfoObj.open_id,
					name: this.searchIptValue,
					pageNo: this.pageNo,
					pageSize: this.pageSize,
					flag: this.flag
				}
				let res = await this.$http.getHasLoad('/zxxt/user/friendSearch', data);
				this.edu_count = res.data.edu_count //同学
				this.job_count = res.data.job_count //同事
				this.public_job_count = res.data.public_job_count //同行
				this.other_count = res.data.other_count //其他
				this.searchList = res.data.list
				// 处理左侧索引
				var letters = []
				this.searchList.forEach(item => {
					if (item.name) {
						letters.push(item.name)
					}
				})
				this.letters = letters
				// 处理tap
				this.tapList.forEach((item, index) => {
					if (index == 0) {
						item.num = this.edu_count
					}
					if (index == 1) {
						item.num = this.job_count
					}
					if (index == 2) {
						item.num = this.public_job_count
					}
					if (index == 3) {
						item.num = this.other_count
					}
				})

			},
			// 点击好友列表项,进入会话
			async goWechat(receivebaseInfo) {
				// 存入缓存信息
				uni.setStorageSync('receivebaseInfo', receivebaseInfo)
				let openId = receivebaseInfo.open_id
				uni.redirectTo({
					url: '/pages/multiEntry/information?openId=' + openId,
				})
			},
			inviteComments() {
				uni.navigateTo({
					url: '/pages/contacts/inviteComments',
				});
			}
		}
	}
</script>

<style lang="scss" scoped>
	.friend-header {
		display: flex;
		justify-content: flex-start;
		align-items: center;
		padding: 0 30rpx;

		.vserch {
			width: 600rpx;
			margin-right: 26rpx;
		}

		.iconfont {
			color: rgb(32, 144, 114);
			font-size: 40rpx;
		}
	}

	.friend-tap {
		padding: 0 30rpx;
		margin-bottom: 40rpx;

		.totalmessage {
			font-size: 24rpx;
			color: #AAAAAA;
			margin: 30rpx 0;
		}

		.tap {
			display: flex;
			padding-left: 15rpx;

			.tap-item {
				display: flex;
				margin-right: 31rpx;

				.text {
					display: flex;
					flex-direction: column;
					align-items: center;
					justify-content: center;
					margin-right: 8rpx;

					.content {
						font-size: 30rpx;
						margin-bottom: 12rpx;
					}

					.content-color {
						color: #209072;
					}

					.line {
						width: 40rpx;
						height: 4rpx;
						background-color: #209072;
					}
				}

				.num {
					padding-top: 4rpx;
					font-size: 24rpx;
					color: #AAAAAA;
				}
			}

			.item-active {
				color: #209072;
			}
		}

	}

	.index-bar {
		padding: 0 32rpx;

		.letters {
			position: fixed;
			right: 10rpx;
			top: 300rpx;
			font-size: 24rpx;
			font-weight: 400;
			color: #209072;

			.letter-item {
				margin-bottom: 2rpx;
			}
		}

		.list-box {
			.letter {
				width: 100%;
				font-size: 24rpx;
				font-weight: bold;
				color: #209072;
				padding: 0 0 21rpx 3rpx;
				border-bottom: 1rpx solid #E0E0E0;
			}

			.listitem {
				display: flex;
				justify-content: flex-start;
				align-items: center;
				padding: 34rpx 0 46rpx 0;
				border-bottom: 1px solid #E0E0E0;

				.imageBox {
					position: relative;
				}
				
				.imgMask {
					position: absolute;
					left: 0;
					top: 0;
					width: 80rpx;
					height: 80rpx;
					background-color: #fff;
					opacity: 0.5;
				}

				.iconfont {
					position: absolute;
					right: 16rpx;
					bottom: 0;
					color: #999;
					font-size: 20rpx;
					font-weight: 700;
				}

				.online {
					color: #209072;
				}

				image {
					width: 80rpx;
					height: 80rpx;
					border-radius: 50%;
					margin-right: 17rpx;
				}

				.detail {
					color: #999;
					font-size: 24rpx;
					font-weight: 400;

					.info {
						display: flex;
						justify-content: flex-start;
						align-items: center;

						.name {
							width: 102rpx;
							font-size: 34rpx;
							color: #333;
							overflow: hidden;
							white-space: nowrap;
							text-overflow: ellipsis;
							margin-right: 25rpx;
						}

						.position {
							width: 192rpx;
							overflow: hidden;
							white-space: nowrap;
							text-overflow: ellipsis;
						}
					}

					.company {
						width: 380rpx;
						overflow: hidden;
						white-space: nowrap;
						text-overflow: ellipsis;
					}
				}
			}
		}
	}
</style>
