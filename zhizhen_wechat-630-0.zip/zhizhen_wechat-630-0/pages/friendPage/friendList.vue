<template>
	<view class="friend-list">
		<view class="friend-header">
			<view class="input-mask" @click="goSearch"></view>
			<vSearch class="vserch" @emitSearch="emitSearch"></vSearch>
			<view class="iconfont icon-yaoqingxiexin1" @tap="inviteComments"></view>
		</view>
		<view class="friend-tap">
			<!-- <view class="totalmessage">共6条信息</view> -->
			<view class="tap">
				<view class="tap-item" v-for="(item,index) in tapList" :key="index" @tap="changeTap(index)">
					<view class="text">
						<view v-if="tapIndex != index" class="content">{{item.content}}</view>
						<view v-else class="content-color content">{{item.content}}</view>
						<view class="line" v-if="tapIndex == index"></view>
					</view>
					<!-- <view class="num">{{item.num}}</view> -->
				</view>
			</view>
		</view>
		<view class="index-bar" v-if="friendList && friendList.length > 0">
			<view class="letters">
				<view class="letter-item" v-for="(item, index) in letters" :key="index"
					@click="goAnchor('#anchor-'+index,index)">{{item}}</view>
			</view>
			<view class="list-box">
				<view class="list-items" v-for="(item,index) in friendList" :key="index" :id="'anchor-'+index">
					<view class="letter">{{item.name}}</view>
					<view class="listitem" v-for="(items,indexs) in item.list" :key="indexs" @tap="goWechat(items)">
						<view class="imageBox">
							<image v-if="items.avatar" :src="items.avatar"></image>
							<image v-else src="../../static/img/man.png"></image>
							<view v-if="items.online_flag != 1" class="imgMask"></view>
						</view>
						<view class="detail">
							<view class="info">
								<rich-text class="name"
									:nodes="$util.brightenKeyword((items.user_name?items.user_name:''),searchIptValue)">
								</rich-text>
								<view class="position">{{items.position_name?items.position_name:''}}</view>
							</view>
							<view class="company">{{items.company_name?items.company_name:''}}</view>
						</view>
					</view>
				</view>
			</view>
		</view>
		<vNoResult v-else :txt='txt'></vNoResult>
	</view>
</template>
<script>
	import vSearch from "components/common/vSearch"
	import vNoResult from "components/common/vNoResult"
	import {
		mapState
	} from "vuex";
	export default {
		components: {
			vSearch,
			vNoResult
		},
		data() {
			return {
				txt: '暂无数据',
				tapList: [{
						content: '同事',
						line: true,
						num: 0
					},
					{
						content: '同学',
						line: false,
						num: 0
					},
					{
						content: '同行',
						line: false,
						num: 0
					},
					{
						content: '其他',
						line: false,
						num: 0
					}
				],
				friendList: [],
				// letters:['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'],
				letters: [], //右侧索引字母数组
				searchIptValue: '', //搜索框输入
				strings: '', //姓名高亮时返回的节点
				tapIndex: 0, //tap默认的索引
				pageNo: 1, //当前页
				pageSize: 100, //每页多少条
				flag: 0, //好友查询类型标识(0同事，1同学，2战友，3亲属，4群聊，5同行，6其他)
				goWritterflag: false,	//好友列表是否要跳转推荐信（默认不跳转；写推荐信跳转至好友列表携带标识则跳转写推荐信）
			}
		},
		onLoad(options) {
			let goWritterflag = options.goWritterflag
			if (goWritterflag && goWritterflag == 'yes') {
				this.goWritterflag = true
			}else {
				this.goWritterflag = false
			}
		},
		onShow() {
			//未读信息-查看接口-已经查看
			this.getLooked()
		},

		mounted() {
			// 获取好友列表
			this.getFriendList()
		},
		computed: {
			...mapState(['loginInfoObj'])
		},
		methods: {
			// 锚点跳转
			goAnchor(id, index) {
				uni.createSelectorQuery().select(id).boundingClientRect(data => { //目标位置的节点：类或者id
					uni.createSelectorQuery().select('.list-box').boundingClientRect(res => { //最外层盒子的节点：类或者id
						uni.pageScrollTo({
							duration: 100, //过渡时间
							scrollTop: data.top - res.top, //到达距离顶部的top值
						})
					}).exec();
				}).exec();
			},
			// 子组件输入框值获取
			emitSearch(data) {
				this.searchIptValue = data.val

			},
			// tap切换
			changeTap(index) {
				this.tapIndex = index
				if (index == 0) {
					this.flag = 0
				}
				if (index == 1) {
					this.flag = 1
				}
				if (index == 2) {
					this.flag = 5
				}
				if (index == 3) {
					this.flag = 6
				}
				// 获取不同类型好友
				this.getFriendList()
			},
			// 获取好友列表
			async getFriendList() {
				let data = {
					openId: this.loginInfoObj.open_id,
					pageNo: this.pageNo,
					pageSize: this.pageSize,
					flag: this.flag
				}
				let res = await this.$http.getHasLoad('/zxxt/user/sapplyOaFriendListV2', data);
				if (res.data.list) {
					this.friendList = res.data.list
					// 处理右侧索引数组
					let letters = []
					this.friendList.forEach((item, index) => {
						if (item.name) {
							letters.push(item.name)
						}
					})
					this.letters = letters
				}
			},
			// 前往搜索结果
			goSearch() {
				uni.navigateTo({
					url: '/pages/friendPage/friendSearch',
				});
			},
			// 点击好友列表项,进入会话
			async goWechat(receivebaseInfo) {
				if (this.goWritterflag) {
					// 跳转推荐信
					uni.redirectTo({
						url: '/pages/recommendation/forOthers?name=' + receivebaseInfo.user_name + '&avatar=' +
							receivebaseInfo.avatar + '&hisopenid=' + receivebaseInfo.open_id,
					})
				}else {
					// 跳转好友详情
					// 存入缓存信息
					uni.setStorageSync('receivebaseInfo', receivebaseInfo)
					let openId = receivebaseInfo.open_id
					uni.redirectTo({
						url: '/pages/multiEntry/information?openId=' + openId,
					})
				}
			},
			//未读信息-查看接口-已经查看 1为已经查看w
			async getLooked() {
				const params = {
					openId: this.loginInfoObj.open_id,
					friendSign: 1,
					remarkSign: 0,
					lookSign: 0
				}
				await this.$http.getHasLoad('/zxxt/user/center', params);
			},
			inviteComments() {
				uni.navigateTo({
					url: '/pages/contacts/inviteComments',
				});
			}
		}
	}
</script>

<style lang="scss" scoped>
	.friend-header {
		display: flex;
		justify-content: flex-start;
		align-items: center;
		padding: 0 30rpx;

		.input-mask {
			position: absolute;
			left: 0;
			top: 0;
			width: 630rpx;
			height: 88rpx;
			background-color: transparent;
			z-index: 6;
		}

		.vserch {
			width: 600rpx;
			margin-right: 26rpx;
		}

		.iconfont {
			color: rgb(32, 144, 114);
			font-size: 40rpx;
		}
	}

	.friend-tap {
		padding: 0 30rpx;
		margin-bottom: 40rpx;
		margin-top: 40rpx;

		.totalmessage {
			font-size: 24rpx;
			color: #AAAAAA;
			margin: 30rpx 0;
		}

		.tap {
			display: flex;
			padding-left: 15rpx;

			.tap-item {
				display: flex;
				margin-right: 31rpx;

				.text {
					display: flex;
					flex-direction: column;
					align-items: center;
					justify-content: center;
					margin-right: 8rpx;

					.content {
						font-size: 30rpx;
						margin-bottom: 12rpx;
					}

					.content-color {
						color: #209072;
					}

					.line {
						width: 40rpx;
						height: 4rpx;
						background-color: #209072;
					}
				}

				.num {
					padding-top: 4rpx;
					font-size: 24rpx;
					color: #AAAAAA;
				}
			}

			.item-active {
				color: #209072;
			}
		}

	}

	.index-bar {
		padding: 0 32rpx;

		.letters {
			position: fixed;
			right: 10rpx;
			top: 300rpx;
			font-size: 24rpx;
			font-weight: 400;
			color: #209072;

			.letter-item {
				margin-bottom: 2rpx;
			}
		}

		.list-box {
			.letter {
				width: 100%;
				font-size: 24rpx;
				font-weight: bold;
				color: #209072;
				padding: 0 0 21rpx 3rpx;
				border-bottom: 1rpx solid #E0E0E0;
			}

			.listitem {
				display: flex;
				justify-content: flex-start;
				align-items: center;
				padding: 34rpx 0 46rpx 0;
				border-bottom: 1px solid #E0E0E0;
				
				.imageBox {
					position: relative;
				}
				
				.imgMask {
					position: absolute;
					left: 0;
					top: 0;
					width: 80rpx;
					height: 80rpx;
					background-color: #fff;
					opacity: 0.5;
				}

				.iconfont {
					position: absolute;
					right: 16rpx;
					bottom: 0;
					color: #999;
					font-size: 20rpx;
					font-weight: 700;
				}
				
				.online {
					color: #209072;
				}

				image {
					width: 80rpx;
					height: 80rpx;
					border-radius: 50%;
					margin-right: 17rpx;
				}

				.detail {
					color: #999;
					font-size: 24rpx;
					font-weight: 400;

					.info {
						display: flex;
						justify-content: flex-start;
						align-items: center;

						.name {
							width: 102rpx;
							font-size: 34rpx;
							color: #333;
							overflow: hidden;
							white-space: nowrap;
							text-overflow: ellipsis;
							margin-right: 25rpx;
						}

						.position {
							width: 192rpx;
							overflow: hidden;
							white-space: nowrap;
							text-overflow: ellipsis;
						}
					}

					.company {
						width: 380rpx;
						overflow: hidden;
						white-space: nowrap;
						text-overflow: ellipsis;
					}
				}
			}
		}
	}
	
	.gray {
		filter: grayscale(100%);
		filter: gray;
	
	}
</style>
