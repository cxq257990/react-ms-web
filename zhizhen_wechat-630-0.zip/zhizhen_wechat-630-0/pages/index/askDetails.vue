<template>
	<view class="askDetails">
		<view class="up-container" id="upContainer">
			<vAskItem parentType="details" :obj="askItemObj" @emitAskItem="eventAskItem"></vAskItem>
		</view>
		<view class="split"></view>
		<view class="down-container">
			<view class="up">
				<text class="txt">回答 {{allList.length}}</text>
				<view class="swith-con">
					<view class="btn-container" @click="onToggleShow()">
						<text>{{showLatest?"最新":"最热"}}</text>
						<view class="iconfont icon-s-xiangxia"></view>
					</view>

					<view class="swith-wrapper" v-if="showSort">
						<view class="triangle-up"></view>
						<view class="swith-main">
							<view class="item" :class="{active:!showLatest}" @click="onToggleShow('hot')">
								<text class="txt">最热</text>
								<view class="iconfont icon-s-OK"></view>
							</view>
							<view class="item" :class="{active:showLatest}" @click="onToggleShow('last')">
								<text class="txt">最新</text>
								<view class="iconfont icon-s-OK"></view>
							</view>
						</view>
					</view>
					<view class="bg" v-if="showSort" @click="onToggleShow()"></view>
				</view>
			</view>
			<!-- <view class="down" :style="{height:`calc(100vh - var(--safe-area-inset-bottom) - ${upH}px)`}"> -->
			<view class="down">
				<vReplyItem class="item" parentType="details" passInType="ask" v-for="(item,index) in replyList" :key="item.id"
					:serverTime="serverTime" :replyObj="item" @emitReplyItem="eventReplyItem"></vReplyItem>
			</view>
		</view>
		<view class="send-container">
			<vSend @emitSend="eventSend"></vSend>
		</view>
		<vSecondReply v-if="showSecondRely" passInType='ask'  :serverTime="serverTime" :obj="secondRelyObj"
			:mainId="askData.id" @emitSecondReply="eventSecondReply"></vSecondReply>
		<vActionSheet v-if="showActionsheet" :arr="actions" @emitActionSheet="eventActionSheet"></vActionSheet>
		<vDialog class="vDialog" v-if="showDialog" msg="确定要删除此评论吗？" @emitDialog="eventDialog"></vDialog>
	</view>
</template>

<script>
	import {
		mapState
	} from "vuex";
	import vAskItem from "components/index/vAskItem.vue"
	import vReplyItem from "components/index/vReplyItem.vue"
	import vSecondReply from "components/index/vSecondReply.vue"

	import vSend from "components/common/vSend.vue"
	import vDialog from "components/common/vDialog.vue"
	import vActionSheet from "components/common/vActionSheet.vue"
	export default {
		components: {
			vAskItem,
			vReplyItem,
			vSend,
			vSecondReply,
			vDialog,
			vActionSheet
		},

		data() {
			return {
				msgId: "",
				askData: {},
				askItemObj: {},
				serverTime: "",

				upH: 0,
				replyList: [],
				allList: [],

				showSort: false,
				showLatest: true,

				showSecondRely: false,
				secondRelyObj: {},

				showActionsheet: false,
				showDialog: false,
				selectDeleteObj: {},
				actions: [{
					txt: '删除',
					type: 'delete'
				}, {
					txt: '取消',
					type: 'cancel'
				}],
			}
		},
		computed: {
			...mapState(['userPhone', 'userInfoObj', 'loginInfoObj'])
		},
		onLoad(option) {
			this.msgId = option.id
			//this.msgId = '397'
			//console.log("this.msgId:",this.msgId)
			this.getData()
		},
		onReady() {
			// const query = uni.createSelectorQuery().in(this);
			// query.select('#upContainer').boundingClientRect(data => {
			// 	this.upH = data.height + 12 + 46 + 52 + 60;
			// }).exec();
		},
		methods: {
			onToggleShow(val) {
				if (!!val) {
					if (val == 'hot') {
						this.showLatest = false
					} else {
						this.showLatest = true
					}
					this.replyList = [];
					this.$nextTick(()=>{
						this.sortFun();
					})
				}
				this.showSort = !this.showSort;
			},
			eventAskItem(obj) {
				//console.log("askDetails-eventAskItem:", obj)
				if (obj.type == 'avatar' || obj.type == 'name') {
					let fn = (obj) => {
						this.$util.checkJumpRelation(obj.dataDetails.open_id)
					}
					this.$util.checkIslogin(fn.bind(null, obj))
				}
			},
			eventReplyItem(obj) {
				console.log("eventReplyItem:", obj)
				let fn = async (obj) => {
					if (obj.type == "goto") {
						if (obj.dataDetails.roleType == "1") {
							this.$util.checkJumpRelation(obj.dataDetails.open_id)
						}
					} else if (obj.type == 'showMore') {
						this.secondRelyObj = obj.dataDetails;
						this.showSecondRely = true;
					} else if (obj.type == 'longpress') {
						if (obj.item.open_id == this.loginInfoObj.open_id) {
							this.selectDeleteObj = obj.item;
							this.showActionsheet = true;
						}
					} else if (obj.type == "like") {
						let data = {
							"parent_id": obj.dataDetails.id,
							"comment_type": "2",
							"oper_type": obj.dataDetails.isFabu == "1" ? "2" : "1",
							"show_name": this.userInfoObj.nickName,
							"open_id": this.loginInfoObj.open_id
						}
						let res = await this.$http.postHasLoad('/zxxt/askEmploy/operComment', data);
						if (res) {
							this.allList.forEach(item => {
								if (item.id == obj.dataDetails.id) {
									item.fabuCount = item.isFabu == "1" ? Number(item.fabuCount) - 1 :
										Number(item
											.fabuCount) + 1;
									item.isFabu = item.isFabu == "1" ? "0" : "1";

								}
							})
							this.replyList = [];
							this.$nextTick(()=>{
								this.sortFun();
							})
						}
					}
				}
				this.$util.checkIslogin(fn.bind(null, obj));
			},
			eventActionSheet(item) {
				console.log("eventActionSheet:", item)
				if (item.type == "delete") {
					this.showDialog = true;
				} else {
					this.showActionsheet = false
				}
			},
			async eventDialog(type) {
				if (type == "ok") {
					let data = {
						"comment_type": "2",
						"open_id": this.loginInfoObj.open_id,
						"oper_type": "3",
						"parent_id": this.selectDeleteObj.id,
						"show_name": this.userInfoObj.nickName
					}
					let res = await this.$http.postHasLoad("/zxxt/askEmploy/operComment", data);
					if (res) {
						this.$util.toast('删除成功');

						this.getData();
						this.showDialog = false;
						this.showActionsheet = false;

					}
				} else {
					this.showDialog = false;
				}
			},
			eventSecondReply() {
				this.getData();
				this.showSecondRely = false;
			},
			async eventSend(obj) {
				console.log("eventSend:", obj);
				let data = {
					"cid1": this.askData.id,
					"comment_type": "2",
					"in_open_id": this.askData.open_id,
					"open_id": this.loginInfoObj.open_id,
					"open_show_name": obj.openName,
					"role_type": obj.roleType,
					"text_evaluate": obj.val
				}
				let res = await this.$http.postHasLoad("/zxxt/askEmploy/addAskEmployComment", data);
				if (res) {
					this.getData()
				}
			},
			async getData() {
				let data = {
					msgId: this.msgId,
					open_id: this.loginInfoObj.open_id
				}
				let res = await this.$http.getHasLoad("/zxxt/askEmploy/lookSubComment", data);
				if (res) {
					this.replyList = [];
					this.serverTime = res.data.time;
					this.askData = res.data.oneCommentData[0];
					this.askItemObj = {
						headImg: this.askData.operAvatar ? this.askData.operAvatar : this.$defaultHeadimg,
						name: this.askData.open_idName,
						roleType: this.askData.roleType,
						company: this.askData.roleType == "1" ? this.askData.operCompany_name : "",
						title: this.askData.text_evaluate,
						content: this.askData.detailDescription,

						time: this.$util.timeMatch(this.askData.create_time, this.serverTime),
						imgArr: this.askData.picture ? this.askData.picture.split(',') : [],
						dataDetails: this.askData
					}
					this.allList = res.data.twoRelativesDoList;
					this.$nextTick(()=>{
						this.sortFun();
					})
					
				
				}
			},
			sortFun() {
				this.replyList = [];
			
				let arr = [];
				if (this.showLatest) {
					arr = this.allList;
				} else {
					arr = this.allList.concat([]).sort((a, b) => {
						return b.fabuCount - a.fabuCount
					});
					//console.log("问员工-最热：",arr)
				}
				arr.forEach(item => {
					this.replyList.push({
						headImg: item.avatar ? item.avatar : this.$defaultHeadimg,
						name: this.$util.nameTransform("ask",item.in_open_id, this.askData.roleType, item
							.open_id, item.roleType, item.openShowName),
						roleType: item.roleType,
						time: this.$util.timeMatch(item.create_time, this.serverTime),
						content: item.text_evaluate,
						secondReplyArr: item.threeRelativesList,
						isLike: item.isFabu == "1" ? true : false,
						likeCount: item.fabuCount,
						imgArr: [], //this.askData.picture ? this.askData.picture.split(',') : [],
						dataDetails:{
							...item,
							orgRoletype:this.askData.roleType
						}
					})

				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.askDetails {
		height: calc(100vh - var(--safe-area-inset-bottom));
		padding-bottom: 88rpx;
		box-sizing: border-box;
		overflow-y: auto;

		.up-container {
			padding: 0 30rpx;

			/deep/ .vAskItem {
				border-bottom: none;
			}
		}

		.split {
			width: 100%;
			height: 24rpx;
			background-color: #F3F3F3;
		}

		.down-container {
			.up {
				padding: 0 30rpx;
				height: 90rpx;
				font-size: 30rpx;
				font-family: Microsoft YaHei;
				font-weight: 400;
				color: $uni-text-color;
				border-bottom: 1rpx solid $uni-border-color;

				display: flex;
				align-items: center;
				justify-content: space-between;

				.swith-con {
					position: relative;
					margin-right: 10rpx;

					.btn-container {
						display: flex;
						align-items: center;

						.iconfont {
							margin-top: 8rpx;
							margin-left: 18rpx;
							color: $uni-text-color-greyA;
						}

					}

					.swith-wrapper {
						position: absolute;
						top: 45rpx;
						right: 0rpx;
						z-index: 999;

						.triangle-up {
							position: relative;
							top: 5rpx;
							left: 230rpx;
							width: 0;
							height: 0;
							border-left: 10rpx solid transparent;
							border-right: 10rpx solid transparent;
							border-bottom: 20rpx solid #fff;
						}

						.swith-main {
							padding: 0 30rpx;
							width: 320rpx;
							box-sizing: border-box;
							background: #FFFFFF;
							border-radius: 12rpx;

							.item {
								height: 100rpx;
								display: flex;
								align-items: center;
								justify-content: space-around;

								.txt {
									font-size: 30rpx;
									font-family: Microsoft YaHei;
									font-weight: 400;
									color: $uni-text-color;
								}

								.iconfont {
									font-size: 32rpx;
									color: #fff;
								}
							}

							.item:first-of-type {
								border-bottom: 1rpx solid $uni-border-color;
							}

							.active {
								.txt {
									color: $uni-color-active;
								}

								.iconfont {
									color: $uni-color-active;
								}
							}
						}
					}

					.bg {
						width: 100vw;
						height: 100vh;
						position: fixed;
						top: 0;
						left: 0;
						z-index: 99;
						background: #000;
						opacity: 0.3;
					}
				}
			}

			.down {
				padding: 0 30rpx;
				overflow-y: auto;

				.item:last-of-type {
					/deep/ .vReplyItem {
						.item {
							border-bottom: none;
						}
					}
				}
			}

		}

		.send-container {
			position: fixed;
			left: 0;
			bottom: var(--safe-area-inset-bottom);
			z-index: 2;
			width: 100%;
		}


	}
</style>
