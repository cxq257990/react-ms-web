<template>
  <view
    class="index"
    :style="{
      'padding-top': statusBarHeight + 'px',
      height: `calc(100vh - ${statusBarHeight}px)`
    }"
  >
    <vStatusbar txt="职评圈"></vStatusbar>
    <view class="vSearchd">
      <vSearch ref="vSearch" @emitSearch="eventSearch"></vSearch>
    </view>
    <view class="nav">
      <view
        class="item"
        :class="{ active: showComment }"
        @click="onSwitch(true)"
        >职评圈</view
      >
      <view
        class="item"
        :class="{ active: !showComment }"
        @click="onSwitch(false)"
        >问员工</view
      >
    </view>
    <view class="container">
      <view class="comment" v-if="showComment">
        <scroll-view
          v-if="commentList.length > 0"
          class="scroll-Y"
          scroll-y="true"
          :scroll-top="scrollTop"
          refresher-enabled="true"
          :refresher-triggered="triggeredComment"
          @scrolltolower="onLowerComment"
          @refresherrefresh="onRefreshComment"
          @refresherrestore="onRestoreComment"
        >
          <view class="item" v-for="item in commentList" :key="item.id">
            <vCommentItem :obj="item" @emitCommentItem="eventCommentItem">
              <vForwardLikeBtnList
                :btnList="item.btnList"
                @emitForwardLike="eventForwardLike($event)"
              >
              </vForwardLikeBtnList>
            </vCommentItem>
          </view>
        </scroll-view>
        <vNoResult v-else txt="暂时没有相关的信息"></vNoResult>
        <view v-if="hasCheck" class="backtracking" @click="onGoto('progress')"
          >背调<br />进度</view
        >
      </view>
      <view class="ask" v-else>
        <scroll-view
          v-if="askList.length > 0"
          class="scroll-Y"
          scroll-y="true"
          :scroll-top="scrollTop"
          refresher-enabled="true"
          :refresher-triggered="triggeredAsk"
          @scrolltolower="onLowerAsk"
          @refresherrefresh="onRefreshAsk"
          @refresherrestore="onRestoreAsk"
        >
          <view class="item" v-for="item in askList" :key="item.id">
            <vAskItem
              parentType="search"
              :obj="item"
              @emitAskItem="eventAskItem"
            ></vAskItem>
          </view>
        </scroll-view>
        <vNoResult v-else txt="暂时没有相关的信息"></vNoResult>

        <view class="questions" @click="onGoto('askQuestions')">
          <view class="iconfont icon-i-huifukuangdehuifu"></view>
          <view class="txt"> 提问 </view>
        </view>
      </view>
    </view>
  </view>
</template>
<script>
import { mapState } from "vuex";
import vSearch from "components/common/vSearch";
import vForwardLikeBtnList from "components/common/vForwardLikeBtnList.vue";
import vNoResult from "components/common/vNoResult.vue";
import vStatusbar from "components/common/vStatusbar.vue";

import vCommentItem from "components/index/vCommentItem.vue";
import vAskItem from "components/index/vAskItem.vue";

export default {
  components: {
    vStatusbar,
    vSearch,
    vCommentItem,
    vAskItem,
    vForwardLikeBtnList,
    vNoResult
  },
  computed: {
    ...mapState(["hasSendAsk", "userPhone", "userInfoObj", "loginInfoObj"])
  },
  data() {
    return {
      statusBarHeight: 0,
      searchVal: "",
      pageNo: 1,
      showComment: true,
      commentList: [],
      askList: [],
      triggeredComment: true,
      triggeredAsk: true,
      scrollTop: 0,
      hasCheck: false
    };
  },
  //--------分享-----------
  async onShareAppMessage(res) {
    //console.log("onShareAppMessage:", res)

    if (res.from == "menu") {
      return {
        title: `欢迎进入指真小程序！`,
        path: "/pages/index/index",
        imageUrl: "/static/img/forward_details.png"
      };
    } else if (res.from == "button") {
      let { id, obj } = res.target.dataset;
      let data = {
        parent_id: obj.id,
        comment_type: "1",
        oper_type: "1",
        show_name: this.userInfoObj.nickName,
        open_id: this.loginInfoObj.open_id
      };
      let backRes = await this.$http.postHasLoad(
        "/zxxt/careerEvalu/operComment",
        data
      );
      if (backRes) {
        console.log("obj.id:", obj.id);
        this.commentList.forEach((item) => {
          if (item.dataDetails.id == obj.id) {
            console.log("item:", item);
            item.dataDetails.forward_count++;
            item.btnList[0].count++;
          }
        });
      }
      return {
        title: `${obj.role_type == "1" ? "匿名好友" : obj.open_id_name} 对 ${
          obj.in_open_id_name
        } 的评价详情`,
        path: `/pages/index/commentDetails?id=${id}`,
        imageUrl: "/static/img/forward_details.png"
      };
    }
  },
  onLoad() {
    let res = uni.getSystemInfoSync();
    let menu = wx.getMenuButtonBoundingClientRect();
    this.statusBarHeight =
      (menu.top - res.statusBarHeight) * 2 + menu.height + res.statusBarHeight;
    if (res.model.indexOf("iPhone") > -1) {
      this.statusBarHeight += 4;
    }

    console.log("loginInfoObj:", this.loginInfoObj);
    this.hasCheck =
      this.loginInfoObj && this.loginInfoObj.issue_id ? true : false;

    this.getCommentList(true);
  },
  onShow() {
    /* 
		    刷新- * 职评圈,问员工切换
			      * 搜索
				  * 下拉刷新
				  * 问员工发新的动态
				  * 初次进入首页
				  
		  不刷新: * 二次进入首页(离开首页，再进入首页 首页保持离开的滚动位置)
		          * 详情返回
				  */
    if (this.hasSendAsk) {
      this.$store.commit("submitSendAsk", false);
      this.getAsk(true);
    }
  },

  methods: {
    eventSearch(obj) {
      console.log("eventSearch:", obj);
      this.searchVal = obj.val;
      this.pageNo = 1;
      this.commentList = [];
      this.askList = [];
      if (this.showComment) {
        this.triggeredComment = true;
        this.triggeredAsk = "restore";
        this.getCommentList(true);
      } else {
        this.triggeredComment = "restore";
        this.triggeredAsk = true;
        this.getAsk(true);
      }
    },
    onSwitch(bool) {
      this.$refs.vSearch.clear();
      this.searchVal = "";
      this.showComment = bool;
      this.pageNo = 1;
      this.commentList = [];
      this.askList = [];
      if (this.showComment) {
        this.triggeredComment = true;
        this.triggeredAsk = "restore";
        this.getCommentList(true);
      } else {
        this.triggeredComment = "restore";
        this.triggeredAsk = true;
        this.getAsk(true);
      }
    },
    eventCommentItem(obj) {
      console.log("eventCommentItem:", obj);
      if (obj.type == "content") {
        uni.navigateTo({
          url: `/pages/index/commentDetails?id=${obj.dataDetails.id}`
        });
      } else {
        let fn = (obj) => {
          if (obj.type == "avatar" || obj.type == "name") {
            //可能是征信后台过来的，没有登陆过小程序
            this.$util.checkJumpRelation(
              obj.dataDetails.in_open_id,
              obj.dataDetails.in_phone,
              obj.dataDetails.in_outer_id
            );
          } else if (obj.type == "commentName") {
            this.$util.checkJumpRelation(obj.dataDetails.open_id);
          }
        };
        this.$util.checkIslogin(fn.bind(null, obj));
      }
    },
    eventAskItem(obj) {
      //console.log("index-eventAskItem:", obj)
      if (obj.type == "content" || obj.type == "comment") {
        uni.navigateTo({
          url: `/pages/index/askDetails?id=${obj.dataDetails.id}`
        });
      } else {
        let fn = (obj) => {
          if (obj.type == "avatar" || obj.type == "name") {
            this.$util.checkJumpRelation(obj.dataDetails.open_id);
          }
        };
        this.$util.checkIslogin(fn.bind(null, obj));
      }
    },
    //-----点赞、评论---------
    eventForwardLike(obj) {
      console.log("evetnForwardLike:", obj);
      let fn = async (obj) => {
        if (obj.type == "comment") {
          uni.navigateTo({
            url: `/pages/index/commentDetails?id=${obj.parentId}`
          });
        } else if (obj.type == "like") {
          let data = {
            parent_id: obj.parentId,
            comment_type: "1",
            oper_type: obj.isLike ? "3" : "2",
            show_name: this.userInfoObj.nickName,
            open_id: this.loginInfoObj.open_id
          };
          let res = await this.$http.postHasLoad(
            "/zxxt/careerEvalu/operComment",
            data
          );
          if (res) {
            this.commentList.forEach((item) => {
              if (item.dataDetails.id == obj.parentId) {
                item.btnList.forEach((opt) => {
                  if (opt.type == "like") {
                    opt.iconclass = obj.isLike
                      ? "icon-zan"
                      : "icon-msg-zan-xuanzhong active";
                    opt.count = obj.isLike
                      ? Number(opt.count) - 1
                      : Number(opt.count) + 1;
                    opt.isLike = !opt.isLike;
                  }
                });

                item.dataDetails.is_fabu = obj.isLike ? "0" : "1";
                item.dataDetails.fabu_count = obj.isLike
                  ? item.dataDetails.fabu_count--
                  : item.dataDetails.fabu_count++;
              }
            });
          }
        }
      };
      this.$util.checkIslogin(fn.bind(null, obj));
    },
    //----背景调查、问员工发问--------
    onGoto(type) {
      console.log("onGoto:", type);
      let fn = (type) => {
        if (type == "askQuestions") {
          uni.navigateTo({
            url: "/pages/index/askQuestions"
          });
        } else if (type == "progress") {
          uni.navigateTo({
            url: "/pages/multiEntry/backgroundCheck/progress"
          });
        }
      };
      this.$util.checkIslogin(fn.bind(null, type));
    },
    ///-----------------------
    onRefreshComment(e) {
      this.pageNo = 1;
      this.triggeredComment = true;
      this.getCommentList(true);
    },
    onRestoreComment() {
      this.triggeredComment = "restore"; // 需要重置
    },
    onLowerComment() {
      this.pageNo++;
      this.getCommentList(false);
    },
    //--------------------------
    onRefreshAsk(e) {
      this.pageNo = 1;
      this.triggeredAsk = true;
      this.getAsk(true);
    },
    onRestoreAsk() {
      this.triggeredAsk = "restore"; // 需要重置
    },
    onLowerAsk() {
      this.pageNo++;
      this.getAsk(false);
    },
    //---------请求-----------------------
    async getCommentList(isReload) {
      let data = {
        searchContent: this.searchVal,
        pageNo: this.pageNo,
        pageSize: 30,
        open_id: this.loginInfoObj.open_id
      };
      let res = await this.$http.getHasLoad(
        "/zxxt/careerEvalu/getCareEvalList",
        data
      );
      //console.log("res:", res.data)
      if (this.triggeredComment) {
        this.triggeredComment = false;
      }
      if (isReload) {
        this.commentList = [];
      }
      let tempArr = [];
	  tempArr = res.data.baseRelativesDoList;
      // res.data.baseRelativesDoList.forEach((item) => {
      //   if (item.in_open_id_name && item.company_name) {
      //     tempArr.push(item);
      //   }
      // });
      for (let i = 0; i < tempArr.length; i++) {
        let rand = parseInt(Math.random() * tempArr.length);
        let temp = tempArr[rand];
        tempArr[rand] = tempArr[i];
        tempArr[i] = temp;
      }

      tempArr.forEach((item) => {
        let obj = {
          headImg: item.avatar ? item.avatar : this.$defaultHeadimg,
          nameObj: {
            name:
              item.role_type == "2" ? this.matchFormat(item.open_id_name) : "",
            isName: item.role_type == "2" ? true : false
          },

          time: this.$util.timeMatch(item.modify_time, res.data.time),
          btnList: [
            {
              type: "forward",
              iconclass: "icon-i-zhuanfa",
              count: item.forward_count,
              parentId: item.id,
              obj: item
            },
            {
              type: "comment",
              iconclass: "icon-msg-pinglun",
              count: item.comment_count,
              parentId: item.id
            },
            {
              type: "like",
              iconclass:
                item.is_fabu == 1
                  ? "icon-msg-zan-xuanzhong active"
                  : "icon-zan",
              count: item.fabu_count,
              parentId: item.id,
              isLike: item.is_fabu == 1 ? true : false
            }
          ],
          dataDetails: item
        };
        if (this.searchVal.length > 0) {
          obj.name = this.matchFormat(item.in_open_id_name);
          obj.job = this.matchFormat(item.position_name);
          obj.company = this.matchFormat(item.company_name);
          obj.content = this.matchFormat(item.text_evaluate);
        } else {
          obj.name = item.in_open_id_name;
          obj.job = item.position_name;
          obj.company = item.company_name;
          obj.content = item.text_evaluate;
        }
        this.commentList.push(obj);
      });
    },
    async getAsk(isReload) {
      let data = {
        searchContent: this.searchVal,
        pageNo: this.pageNo,
        pageSize: 10,
        open_id: this.loginInfoObj.open_id
      };
      let res = await this.$http.getHasLoad(
        "/zxxt/askEmploy/getAskEmployList",
        data
      );
      if (this.triggeredAsk) {
        this.triggeredAsk = false;
      }

      if (isReload) {
        this.askList = [];
      }
      res.data.baseRelativesDoList.forEach((item) => {
        let obj = {
          headImg:
            item.role_type == "1" && item.avatar
              ? item.avatar
              : this.$defaultHeadimg,
          roleType: item.role_type,
          time: this.$util.timeMatch(item.create_time, res.data.time),
          imgArr: item.picture ? item.picture.split(",") : [],
          dataDetails: item
        };
        if (this.searchVal.length > 0) {
          obj.company =
            item.role_type == "1" ? this.matchFormat(item.company_name) : "";
          obj.name = this.matchFormat(item.open_show_name);
          obj.title = this.matchFormat(item.text_evaluate);
        } else {
          obj.company = item.role_type == "1" ? item.company_name : "";
          obj.name = item.open_show_name;
          obj.title = item.text_evaluate;
        }
        this.askList.push(obj);
      });
      if (isReload) {
        this.scrollTop = 1;
        this.$nextTick(function () {
          this.scrollTop = 0;
        });
      }
    },

    matchFormat(str) {
      //<span style='color:#F64135;'>吉利</span>汽车控股集团 (北京)
      if (!str) {
        return "";
      }
      return str.replace(
        new RegExp(this.searchVal, "g"),
        `<span style='color:#F64135;'>${this.searchVal}</span>`
      );
    }
  }
};
</script>

<style lang="scss" scoped>
.index {
  //height: 100%;
  // background-color: red;

  .vSearchd {
    padding: 0 30rpx;
  }

  .nav {
    padding: 0 30rpx;
    margin-top: 40rpx;
    margin-bottom: 38rpx;
    display: flex;
    align-items: center;
    justify-content: left;

    .item {
      font-size: 30rpx;
      font-family: Microsoft YaHei;
      font-weight: 400;
      color: $uni-text-color;
      border-bottom: 1rpx solid #ffffff;
      padding-bottom: 12rpx;
    }

    .item:first-of-type {
      margin-right: 54rpx;
    }

    .active {
      color: $uni-color-active;
      border-bottom-color: $uni-color-active;
    }
  }

  .container {
    height: calc(100% - 220rpx);

    .comment {
      height: 100%;
      position: relative;

      .scroll-Y {
        height: 100%;

        .item {
          padding: 0 30rpx;
          box-sizing: border-box;
          margin-bottom: 38rpx;
        }
      }

      .backtracking {
        position: fixed;
        right: 30rpx;
        bottom: 30rpx;
        z-index: 2;
        background-color: $uni-color-active;
        width: 110rpx;
        height: 110rpx;
        border-radius: 100rpx;
        box-sizing: border-box;
        padding-top: 20rpx;
        text-align: center;
        font-size: 26rpx;
        font-family: Microsoft YaHei;
        font-weight: 400;
        color: #ffffff;
      }
    }

    .ask {
      position: relative;
      height: 100%;

      .scroll-Y {
        height: 100%;

        .item {
          padding: 0 30rpx;
          box-sizing: border-box;
          margin-bottom: 38rpx;
        }
      }

      .questions {
        position: fixed;
        right: 30rpx;
        bottom: 30rpx;
        z-index: 2;
        background-color: #f9b134;
        width: 110rpx;
        height: 110rpx;
        border-radius: 100rpx;
        box-sizing: border-box;
        padding-top: 10rpx;
        text-align: center;
        font-size: 28rpx;
        font-family: Microsoft YaHei;
        font-weight: 400;
        color: #ffffff;

        .iconfont {
          font-size: 40rpx;
        }
      }
    }
  }
}
</style>
