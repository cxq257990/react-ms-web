<template>
	<view class="askQuestions">
		<view class="main">
			<view class="id-switch">
				<view class="id-wrapper" @click="onToggleIDSelect">
					<view class="header-img">
						<image class="avatar" v-if="selectIDObj.roleType==3" src="../../static/img/company.jpg" mode="">
						</image>
						<image class="avatar" v-else-if="selectIDObj.roleType==2" src="../../static/img/anonymity.png"
							mode="">
						</image>
						<image class="avatar" v-else :src="userInfoObj.avatarUrl" mode=""></image>
						<text class="name">{{selectIDObj.openName}}</text>
					</view>
					<view class="iconfont icon-s-xiangxia"></view>
				</view>
				<view class="switch-wrapper">
					<view class="id-Pop-ups" v-if="showIDSelect">
						<view class="triangle"></view>
						<view class="id-list">
							<view class="item" v-for="item in roleArr" :key="item.roleType" @click="onSelectID(item)">
								<image class="avatar" v-if="item.roleType==3" src="../../static/img/company.jpg"
									mode="">
								</image>
								<image class="avatar" v-else-if="item.roleType==2" src="../../static/img/anonymity.png"
									mode="">
								</image>
								<image class="avatar" v-else :src="userInfoObj.avatarUrl" mode=""></image>
								<text class="name">{{item.openName}}</text>
								<view class="iconfont icon-s-OK"></view>
							</view>
						</view>

					</view>
					<view class="bg" v-if="showIDSelect"></view>
				</view>
			</view>
			<view class="questions">
				<textarea class="title" :placeholder="`请输入问题（${minNum}-${maxNum}字）`"
					placeholder-class="title-placeholder" @input="onTitle" />
				<view class="tip" v-if="title.length<minNum">再写<text>{{minNum-title.length}}</text>个字符吧~</view>
				<view class="tip" v-if="title.length>maxNum">已超出<text>{{title.length - maxNum}}</text>个字符</view>

			</view>
			<view class="desc">
				<textarea class="utextarea" placeholder="添加问题描述（选填）" placeholder-class="desc-placeholder"
					@input="onTextarea" />
			</view>
			<view class="img-concontainer">
				<view class="item" v-for="(item,index) in imgList" :key="item.orgUrl">
					<image class="img" :class="{'gray':item.type=='err'}" :src="item.orgUrl" mode="aspectFit"
						@click="bigImg(item.orgUrl)"></image>
					<image class="img mask" v-if="item.type=='err'" src="../../static/img/split.png" mode="aspectFit">
					</image>
					<view class="iconfont icon-s-shanchutupian" @click="onDeleteImg(index)"></view>
				</view>
				<view class="chooseImage iconfont icon-shangchuanxiangpian" v-if="imgList.length<9"
					@click="onchooseImage"></view>
			</view>
		</view>
		<view class="btn" @click="onPostAsk">发布</view>
	</view>
</template>

<script>
	import {
		mapState
	} from "vuex";
	import {
		uploadFile
	} from "../../utils/fileRequest.js"
	export default {
		data() {
			return {
				showIDSelect: false,
				selectIDObj: {
					roleType: "2",
					openName: "访客"
				},
				title: '',
				desc: "",
				imgList: [],
				totalImgCount: 0,
				maxNum: 40,
				minNum: 6
			}
		},
		computed: {
			...mapState(['roleArr', 'userInfoObj', 'loginInfoObj'])
		},

		methods: {
			onchooseImage() {
				uni.chooseImage({
					count: 9 - this.imgList.length, //默认9
					success: async (res) => {
						//console.log("onchooseImage:", res);
						let hasBigimg = false;
						uni.showLoading({
							title: '上传中'
						});

						for (let item of res.tempFiles) {
							if (item.size <= 1024 * 1024) {
								this.totalImgCount++;
								let res = await uploadFile("/zxxt/askEmploy/upload", item.path);
								this.imgList.push({
									...res,
									orgUrl: item.path
								})
							} else {
								hasBigimg = true;
							}
						}
						uni.hideLoading();
						if (hasBigimg) {
							this.$util.toast('图片超过1M', 3000);
						}


						// for (let item of res.tempFilePaths) {
						// 	let res = await uploadFile("/zxxt/askEmploy/upload", item);
						// 	//console.log("--askQa--res---:",res)
						// 	this.imgList.push({
						// 		...res,
						// 		orgUrl: item
						// 	})
						// }
						// uni.hideLoading()



					}
				});
			},
			bigImg(item) {
				uni.previewImage({
					urls: [item]
				})
			},
			onToggleIDSelect() {
				this.showIDSelect = !this.showIDSelect;
				if (this.showIDSelect || this.showEmoji) {
					this.showBg = true;
				} else {
					this.showBg = false;
				}
			},
			onSelectID(item) {
				this.showIDSelect = false
				if (this.showIDSelect) {
					this.showBg = true;
				} else {
					this.showBg = false;
				}
				this.selectIDObj = item;
			},
			onTitle(e) {
				this.title = e.target.value;
			},
			onTextarea(e) {
				this.desc = e.target.value;
			},
			onDeleteImg(index) {
				this.imgList.splice(index, 1);
				this.totalImgCount--;
			},
			async onPostAsk() {
				if (this.totalImgCount > this.imgList.length) {
					this.$util.toast("正在上传图片，请稍等...")
					return
				}
				if (this.title.length >= this.minNum && this.title.length <= this.maxNum) {
					//console.log("ddddd:",this.imgList)
					let imgStr = "";
					this.imgList.forEach((item, index) => {
						if (index < this.imgList.length - 1) {
							imgStr += item.url + ',';
						} else {
							imgStr += item.url;
						}
					})
					let data = {
						"comment_type": "1",
						"detail_description": this.desc,
						"open_id": this.loginInfoObj.open_id,
						"open_show_name": this.selectIDObj.openName,
						"picture": imgStr,
						"role_type": this.selectIDObj.roleType,
						"text_evaluate": this.title
					}
					let res = await this.$http.postNoLoad("/zxxt/askEmploy/addAskEmployComment", data);
					if (res) {
						this.$store.commit('submitSendAsk', true)
						uni.navigateBack()
					}
				} else {
					this.$util.toast(`问题请输入${this.minNum}-${this.maxNum}个字符`)
				}

			}
		}
	}
</script>

<style lang="scss" scoped>
	.askQuestions {
		width: 100%;
		background-color: #F7F7F7;
		min-height: 100vh;

		.main {
			padding: 0 30rpx;
			background-color: #fff;

			.id-switch {
				width: 100%;
				height: 86rpx;
				border-bottom: 1rpx solid $uni-border-color;
				position: relative;

				.id-wrapper {
					width: 100%;
					height: 100%;
					display: flex;
					align-items: center;
					justify-content: space-between;

					.header-img {
						display: flex;
						align-items: center;

						.avatar {
							font-size: 50rpx;
							width: 60rpx;
							height: 60rpx;
							border-radius: 100rpx;
							margin-right: 18rpx;

						}

						.name {
							font-size: 32rpx;
							color: #666;
						}
					}

					.iconfont {
						font-style: 24rpx;
						color: $uni-text-color-greyA;
					}
				}

				.switch-wrapper {
					position: relative;
					z-index: 9;

					.id-Pop-ups {
						position: absolute;
						top: 0rpx;
						left: 0rpx;
						z-index: 2;

						.triangle {
							margin-left: 70rpx;
							width: 0;
							height: 0;
							border-left: 12rpx solid transparent;
							border-right: 12rpx solid transparent;
							border-bottom: 15rpx solid #fff;
						}

						.id-list {
							width: calc(100vw - 60rpx);
							padding: 10rpx 50rpx;
							box-sizing: border-box;
							background-color: #fff;
							border-radius: 12rpx;

							.item {
								display: flex;
								align-items: center;
								width: 100%;
								height: 86rpx;
								border-bottom: 1rpx solid $uni-border-color;

								.avatar {
									font-size: 50rpx;
									text-align: center;
									width: 60rpx;
									height: 60rpx;
									border-radius: 100rpx;
									display: flex;
									align-items: center;

								}

								.name {
									flex: 1;
									margin: 0 24rpx;
									font-size: 30rpx;
									font-family: Microsoft YaHei;
									font-weight: 400;
									color: $uni-text-color;
								}

								.icon-s-OK {
									color: #fff;
								}
							}

							.item:last-of-type {
								border-bottom: none
							}
						}


					}

					.bg {
						position: fixed;
						top: 0;
						left: 0;
						width: 100vw;
						height: 100vh;
						background-color: #000;
						opacity: 0.2;
					}
				}
			}

			.questions {
				border-bottom: 1rpx solid $uni-border-color;
				width: 100%;
				position: relative;

				.title {
					padding: 20rpx 0;
					width: 100%;
					height: 120rpx;
					border: none;
					outline: none;
					font-size: 26rpx;
					color: $uni-text-color;
				}

				.title-placeholder {
					font-size: 26rpx;
					color: $uni-text-color-greyA;
				}

				.tip {
					position: absolute;
					bottom: 8rpx;
					right: 0;
					z-index: 1;
					text-align: right;
					font-size: 24rpx;
					color: $uni-text-color-greyA;

					text {
						color: $uni-color-search-match;
					}
				}

			}

			.desc {
				width: 100%;
				height: 180rpx;
				padding: 20rpx 0;

				.utextarea {
					width: 100%;
					height: 100%;
					border: none;
					outline: none;
					font-size: 26rpx;
					color: $uni-text-color;
				}

				.desc-placeholder {
					font-size: 26rpx;
					color: $uni-text-color-greyA;
				}
			}

			.img-concontainer {
				padding: 40rpx 0;
				display: flex;
				align-items: center;
				flex-wrap: wrap;

				.item {
					//border: 1rpx solid #ccc;
					position: relative;
					display: flex;
					align-items: center;
					position: relative;
					margin-bottom: 20rpx;
					margin-right: 20rpx;

					.img {
						max-width: 106rpx;
						max-height: 80rpx;
					}

					.gray {
						filter: grayscale(100%);
						filter: gray;

					}

					.mask {
						position: absolute;
						top: 0;
						left: 0;
						z-index: 1;
					}


					.iconfont {
						color: #666;
						position: absolute;
						top: -15rpx;
						right: -15rpx;
						z-index: 1;
						font-size: 30rpx;
					}
				}

				.chooseImage {
					margin-left: 10rpx;
					font-size: 44rpx;
					color: #666;
				}
			}
		}

		.btn {
			margin: 60rpx 55rpx;
			width: calc(100% - 110rpx);
			height: 88rpx;
			line-height: 88rpx;
			font-size: 34rpx;
			background: $uni-color-active;
			border-radius: 44rpx;
			color: #fff;
			text-align: center;

		}
	}
</style>
