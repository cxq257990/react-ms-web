<template>
	<view class="details">
		<view class="up-container" id="upContainer">
			<view class="respondent-people">
				<view class="info">
					<image class="avatar " :src="commentData.avatar?commentData.avatar:defaultHeadimg" mode=""
						@click="onGoto('commented')"></image>
					<view class="desc-container">
						<view class="name-job">
							<text class="name" @click="onGoto('commented')">{{commentData.in_open_id_name?commentData.in_open_id_name:""}}</text>
							<text class="job">{{commentData.position_name}}</text>
						</view>
						<view class="company">
							{{commentData.company_name}}
						</view>
					</view>
				</view>
				<view class="iconfont icon-jiahaoyou1"
					v-if="friendRelation=='0'&&commentData.in_open_id!=loginInfoObj.open_id"
					:data-id="commentData.in_open_id" @click="onAddFriend"></view>
				<view class="iconfont icon-tianjiahaoyou1"
					v-else-if="friendRelation=='1'&&commentData.in_open_id!=loginInfoObj.open_id"
					:data-id="commentData.in_open_id"></view>
				<view class="iconfont icon-jiahaoyouzhong" v-else-if="commentData.in_open_id!=loginInfoObj.open_id"
					:data-id="commentData.in_open_id">
				</view>

			</view>
			<view class="comment-people">
				<vDetailsComment whichPage="details" :obj="commentItemObj" @emitMainComment="eventMainComment">
					<vForwardLikeBtnList :btnList="btnList" @emitForwardLike="eventForwardLike($event)">
					</vForwardLikeBtnList>
				</vDetailsComment>
			</view>
		</view>
		<view class="split"></view>

		<view class="down-container">
			<view class="up">
				<text class="txt">评论 {{allList.length}}</text>
				<view class="swith-con">
					<view class="btn-container" @click="onToggleShow()">
						<text>{{showLatest?"最新":"最热"}}</text>
						<view class="iconfont icon-s-xiangxia"></view>
					</view>

					<view class="swith-wrapper" v-if="showSort">
						<view class="triangle-up"></view>
						<view class="swith-main">
							<view class="item" :class="{active:!showLatest}" @click="onToggleShow('hot')">
								<text class="txt">最热</text>
								<view class="iconfont icon-s-OK"></view>
							</view>
							<view class="item" :class="{active:showLatest}" @click="onToggleShow('last')">
								<text class="txt">最新</text>
								<view class="iconfont icon-s-OK"></view>
							</view>
						</view>
					</view>
					<view class="bg" v-if="showSort" @click="onToggleShow()"></view>
				</view>

			</view>
			<!-- <view class="down" :style="{height:`calc(100vh - var(--safe-area-inset-bottom) - ${upH}px) `}"> -->
			<view class="down">
				<vReplyItem parentType="details" passInType="comment" v-for="(item,index) in replyList" :key="item.id"
					:serverTime="serverTime" :replyObj="item" @emitReplyItem="eventReplyItem">
				</vReplyItem>
			</view>
		</view>
		<view class="send-container">
			<vSend @emitSend="eventSend"></vSend>
		</view>
		<vSecondReply v-if="showSecondRely" passInType='comment' :serverTime="serverTime" :obj="secondRelyObj"
			:mainId="commentData.id" @emitSecondReply="eventSecondReply"></vSecondReply>
		<vActionSheet v-if="showActionsheet" :arr="actions" @emitActionSheet="eventActionSheet"></vActionSheet>
		<vDialog class="vDialog" v-if="showDialog" msg="确定要删除此评论吗？" @emitDialog="eventDialog"></vDialog>
	</view>
</template>

<script>
	import {
		mapState
	} from "vuex";
	import vDetailsComment from "components/index/vDetailsComment.vue"
	import vForwardLikeBtnList from "components/common/vForwardLikeBtnList.vue"
	import vSend from "components/common/vSend.vue"
	import vDialog from "components/common/vDialog.vue"
	import vActionSheet from "components/common/vActionSheet.vue"

	import vReplyItem from "components/index/vReplyItem.vue"
	import vSecondReply from "components/index/vSecondReply.vue"



	export default {
		components: {
			vDetailsComment,
			vForwardLikeBtnList,

			vReplyItem,
			vSend,
			vSecondReply,
			vDialog,
			vActionSheet
		},

		data() {
			return {
				defaultHeadimg: this.$defaultHeadimg,
				msgId: "",
				friendRelation: "0", // 0不是好友,1是好友,2申请中
				commentData: {
					avatar: "",
					in_open_id_name: "",
					in_phone: "",
					position_name: "",
					company_name: "",
					in_open_id: ""
				},
				commentItemObj: {
					headImg: "",
					job: "",
					nameObj: {
						name: "",
						isName: false
					},

					company: "",
					content: "",
					time: "",
					dataDetails: {}
				},
				serverTime: "",
				btnList: [],

				upH: 0,
				replyList: [],
				allList: [],

				showSort: false,
				showLatest: true,

				showSecondRely: false,
				secondRelyObj: {},

				showActionsheet: false,
				showDialog: false,
				selectDeleteObj: {},
				actions: [{
					txt: '删除',
					type: 'delete'
				}, {
					txt: '取消',
					type: 'cancel'
				}],

			}
		},
		computed: {
			...mapState(['userPhone', 'userInfoObj', 'loginInfoObj'])
		},
		//--------分享-----------
		async onShareAppMessage(res) {
			console.log('onShareAppMessage:', res);
			if (res.from == "button") {
				let data = {
					"parent_id": res.target.dataset.id,
					"comment_type": "1",
					"oper_type": "1",
					"show_name": this.userInfoObj.nickName,
					"open_id": this.loginInfoObj.open_id
				}
				let backRes = await this.$http.postHasLoad('/zxxt/careerEvalu/operComment', data);
				if (backRes) {
					this.btnList[0].count++
				}
				return {
					title: `${this.commentData.role_type=="1"?"匿名好友":this.commentData.open_id_name} 对 ${this.commentData.in_open_id_name} 的评价详情`,
					path: `/pages/index/commentDetails?id=${res.target.dataset.id}`,
					imageUrl: '/static/img/forward_details.png',
				}
			}
		},
		async onLoad(option) {
			uni.hideShareMenu();
			//console.log("details:", option);
			this.msgId = option.id
			//this.msgId = '250'
			this.getData();

		},
		onReady() {
			//console.log("userInfoObj:",this.userInfoObj)
			// const query = uni.createSelectorQuery().in(this);
			// query.select('#upContainer').boundingClientRect(data => {
			// 	this.upH = data.height + 12 + 46 + 52 + 80;
			// }).exec();
		},
		methods: {
			onGoto(type) {
				if (type == "commented") {
					let fn = async () => {
						this.$util.checkJumpRelation(this.commentData.in_open_id, this.commentData.in_phone,this.commentData.in_outer_id)
					};
					this.$util.checkIslogin(fn.bind(null));
				}
			},
			eventMainComment(obj) {
				//console.log("eventMainComment:", obj)

				if ((obj.type == "name" || obj.type == "avatar") && obj.dataDetails.open_id != "ZX") {
					this.$util.checkJumpRelation(obj.dataDetails.open_id)
				}

			},
			//-----点赞、评论---------
			eventForwardLike(obj) {
				console.log("evetnForwardLike:", obj)
				if (obj.type == "like" || obj.type == "unlike") {
					let fn = async (obj) => {
						if (obj.type == "like") {

							let data = {
								"parent_id": obj.parentId,
								"comment_type": "1",
								"oper_type": obj.isLike ? "3" : "2",
								"show_name": this.userInfoObj.nickName,
								"open_id": this.loginInfoObj.open_id
							}
							let res = await this.$http.postHasLoad('/zxxt/careerEvalu/operComment', data);
							if (res) {
								this.btnList.forEach(opt => {
									if (opt.type == "like") {
										opt.iconclass = obj.isLike ? "icon-zan" :
											"icon-msg-zan-xuanzhong active";
										opt.count = obj.isLike ?
											Number(opt.count) - 1 : Number(opt.count) + 1;
										opt.isLike = !opt.isLike;
									}
								})
							}

						} else if (obj.type == "unlike") {
							let data = {
								"parent_id": obj.parentId,
								"comment_type": "1",
								"oper_type": obj.isUnlike ? "5" : "4",
								"show_name": this.userInfoObj.nickName,
								"open_id": this.loginInfoObj.open_id
							}
							let res = await this.$http.postHasLoad('/zxxt/careerEvalu/operComment', data);
							if (res) {
								this.btnList.forEach(opt => {
									if (opt.type == "unlike") {
										opt.iconclass = obj.isUnlike ? "icon-cai" :
											"icon-msg-cai-xuanzhong active";
										opt.count = obj.isUnlike ?
											Number(opt.count) - 1 : Number(opt.count) + 1;
										opt.isUnlike = !opt.isUnlike;
									}
								})
							}

						}
					};
					this.$util.checkIslogin(fn.bind(null, obj));
				}
			},
			onToggleShow(val) {
				if (!!val) {
					if (val == 'hot') {
						this.showLatest = false
					} else {
						this.showLatest = true
					}
					this.replyList = [];
					this.$nextTick(() => {
						this.sortFun();
					})
				}
				this.showSort = !this.showSort;
			},
			eventReplyItem(obj) {
				console.log("eventReplyItem:", obj)
				let fn = async (obj) => {
					if (obj.type == "goto") {
						if (obj.dataDetails.roleType == "1") {
							this.$util.checkJumpRelation(obj.dataDetails.open_id)
						}
					} else if (obj.type == 'showMore') {
						this.secondRelyObj = obj.dataDetails;
						this.showSecondRely = true;
					} else if (obj.type == 'longpress') {
						if (obj.item.open_id == this.loginInfoObj.open_id) {
							this.selectDeleteObj = obj.item;
							this.showActionsheet = true;
						}


					} else if (obj.type == "like") {
						let data = {
							"parent_id": obj.dataDetails.id,
							"comment_type": "2",
							"oper_type": obj.dataDetails.isFabu == "1" ? "3" : "2",
							"show_name": this.userInfoObj.nickName,
							"open_id": this.loginInfoObj.open_id
						}
						let res = await this.$http.postHasLoad('/zxxt/careerEvalu/operComment', data);
						if (res) {
							this.allList.forEach(item => {
								if (item.id == obj.dataDetails.id) {
									item.fabuCount = item.isFabu == "1" ? Number(item.fabuCount) - 1 :
										Number(item
											.fabuCount) + 1;
									item.isFabu = item.isFabu == "1" ? "0" : "1";

								}
							})
							this.replyList = [];
							this.$nextTick(() => {
								this.sortFun();
							})
						}
					}

				}
				this.$util.checkIslogin(fn.bind(null, obj));
			},

			eventActionSheet(item) {
				console.log("eventActionSheet:", item)
				//this.selectDeleteObj
				if (item.type == "delete") {
					this.showDialog = true;
				} else {
					this.showActionsheet = false
				}
			},
			async eventDialog(type) {
				if (type == "ok") {
					let data = {
						"comment_type": "2",
						"open_id": this.loginInfoObj.open_id,
						"oper_type": "6",
						"parent_id": this.selectDeleteObj.id,
						"show_name": this.userInfoObj.nickName
					}
					let res = await this.$http.postHasLoad("/zxxt/careerEvalu/operComment", data);
					if (res) {
						this.$util.toast('删除成功');

						this.getData();
						this.showDialog = false;
						this.showActionsheet = false;

					}
				} else {
					this.showDialog = false;
				}
			},
			eventSecondReply() {

				this.getData();
				this.showSecondRely = false;
			},

			async eventSend(obj) {
				console.log("eventSend:", obj);
				let data = {
					"cid1": this.commentData.id,
					"comment_type": "2",
					"in_open_id": this.commentData.open_id,
					"open_id": this.loginInfoObj.open_id,
					"open_show_name": obj.openName,
					"role_type": obj.roleType,
					"text_evaluate": obj.val
				}
				let res = await this.$http.postHasLoad("/zxxt/careerEvalu/addSubComment", data);
				if (res) {
					this.getData()
				}
			},

			async onAddFriend(obj) {
				let fn = async (obj) => {
					let data = {
						"can_phone": "",
						"open_id": this.loginInfoObj.open_id,
						"re_open_id": obj.target.dataset.id,
						"source": 5
					}
					let res = await this.$http.postHasLoad("/zxxt/user/addFriend", data)
					if (res) {
						this.friendRelation = res.data
						this.$util.toast('请求发送成功')
					}
				}
				this.$util.checkIslogin(fn.bind(null, obj));

			},
			async getData() {
				this.replyList = [];
				let data = {
					msgId: this.msgId,
					open_id: this.loginInfoObj.open_id
				}
				let res = await this.$http.getHasLoad("/zxxt/careerEvalu/lookSubComment", data);
				if (res) {

					this.serverTime = res.data.time;
					this.friendRelation = res.data.relation;
					//console.log("oneCommentData:", res)
					this.commentData = res.data.oneCommentData[0];
					this.commentItemObj = {
						headImg: (this.commentData.role_type == '2' && this.commentData.oper_avatar) ? this
							.commentData.oper_avatar : this
							.$defaultHeadimg,
						job: this.commentData.role_type == '2' ? this.commentData.oper_position_name : "",
						nameObj: {
							name: this.commentData.role_type == '2' ? this.commentData.open_id_name : "访客",
							isName: this.commentData.role_type == '2' ? true : false
						},
						company: this.commentData.oper_company_name,
						content: this.commentData.text_evaluate,
						time: this.$util.timeMatch(this.commentData.modify_time, this.serverTime),
						dataDetails: this.commentData
					};
					console.log("commentItemObj:", this.commentItemObj)
					this.btnList = [{
							type: "forward",
							iconclass: "icon-i-zhuanfa",
							count: this.commentData.forward_count,
							parentId: this.commentData.id
						},
						{
							type: "comment",
							iconclass: "icon-msg-pinglun",
							count: this.commentData.comment_count,
							parentId: this.commentData.id
						},
						{
							type: "like",
							iconclass: this.commentData.is_fabu == 1 ? "icon-msg-zan-xuanzhong active" :
								"icon-zan",
							count: this.commentData.fabu_count,
							parentId: this.commentData.id,
							isLike: this.commentData.is_fabu == 1 ? true : false
						},
						{
							type: "unlike",
							iconclass: this.commentData.is_step == 1 ? "icon-msg-cai-xuanzhong active" :
								"icon-cai",
							count: this.commentData.step_count,
							parentId: this.commentData.id,
							isUnlike: this.commentData.is_step == 1 ? true : false
						}
					];
					this.allList = res.data.twoRelativesDoList;
					this.replyList = [];
					this.$nextTick(() => {
						this.sortFun();
					})

				}
			},

			sortFun() {
				this.replyList = [];
				let arr = [];
				if (this.showLatest) {
					arr = this.allList;

				} else {
					arr = this.allList.concat([]).sort((a, b) => {
						return b.fabuCount - a.fabuCount
					});
				}
				arr.forEach(item => {
					this.replyList.push({
						headImg: item.avatar,
						name: this.$util.nameTransform('comment', item.in_open_id, this.commentData
							.role_type, item
							.open_id, item.roleType, item.openShowName),
						roleType: item.roleType,
						time: this.$util.timeMatch(item.create_time, this.serverTime),
						content: item.text_evaluate,
						secondReplyArr: item.threeRelativesList,
						isLike: item.isFabu == "1" ? true : false,
						likeCount: item.fabuCount,
						dataDetails: {
							...item,
							orgRoletype: this.commentData.role_type
						}
					})
				})
			},
		}
	}
</script>

<style lang="scss" scoped>
	.details {
		height: calc(100vh - var(--safe-area-inset-bottom));
		padding-bottom: 88rpx;
		box-sizing: border-box;
		overflow-y: auto;

		.up-container {
			padding: 0 30rpx;

			.respondent-people {
				padding-bottom: 38rpx;
				border-bottom: 1rpx solid $uni-border-color;

				display: flex;
				align-items: center;
				justify-content: space-between;

				.info {
					display: flex;
					align-items: center;

					.avatar {
						width: 120rpx;
						height: 120rpx;
						margin-right: 30rpx;
						border-radius: 100rpx;
					}

					.desc-container {
						.name-job {
							margin-bottom: 15rpx;

							.name {
								font-size: 48rpx;
								font-family: Microsoft YaHei;
								font-weight: 400;
								color: $uni-text-color;
								margin-right: 28rpx;
							}

							.job {
								font-size: 28rpx;
								font-family: Microsoft YaHei;
								font-weight: 400;
								color: $uni-text-color-greyA;
							}
						}

						.company {
							font-size: 28rpx;
							font-family: Microsoft YaHei;
							font-weight: 400;
							color: $uni-text-color-greyA;
						}
					}
				}

				.iconfont {
					font-size: 45rpx;
					color: $uni-color-active;
					margin-right: 23rpx;
				}
			}

			.comment-people {
				padding-top: 30rpx;
			}
		}

		.split {
			width: 100%;
			height: 24rpx;
			background-color: #F3F3F3;
		}

		.down-container {
			.up {
				padding: 0 30rpx;
				height: 90rpx;
				font-size: 30rpx;
				font-family: Microsoft YaHei;
				font-weight: 400;
				color: $uni-text-color;
				border-bottom: 1rpx solid $uni-border-color;

				display: flex;
				align-items: center;
				justify-content: space-between;

				.swith-con {
					position: relative;
					margin-right: 10rpx;

					.btn-container {
						display: flex;
						align-items: center;

						.iconfont {
							margin-top: 8rpx;
							margin-left: 18rpx;
							color: $uni-text-color-greyA;
						}

					}

					.swith-wrapper {
						position: absolute;
						top: 45rpx;
						right: 0rpx;
						z-index: 999;

						.triangle-up {
							position: relative;
							top: 5rpx;
							left: 230rpx;
							width: 0;
							height: 0;
							border-left: 10rpx solid transparent;
							border-right: 10rpx solid transparent;
							border-bottom: 20rpx solid #fff;
						}

						.swith-main {
							padding: 0 30rpx;
							width: 320rpx;
							box-sizing: border-box;
							background: #FFFFFF;
							border-radius: 12rpx;

							.item {
								height: 100rpx;
								display: flex;
								align-items: center;
								justify-content: space-around;

								.txt {
									font-size: 30rpx;
									font-family: Microsoft YaHei;
									font-weight: 400;
									color: $uni-text-color;
								}

								.iconfont {
									font-size: 32rpx;
									color: #fff;
								}
							}

							.item:first-of-type {
								border-bottom: 1rpx solid $uni-border-color;
							}

							.active {
								.txt {
									color: $uni-color-active;
								}

								.iconfont {
									color: $uni-color-active;
								}
							}
						}
					}

					.bg {
						width: 100vw;
						height: 100vh;
						position: fixed;
						top: 0;
						left: 0;
						z-index: 99;
						background: #000;
						opacity: 0.3;
					}
				}
			}

			.down {
				padding: 0 30rpx;
				overflow-y: auto;
			}

		}

		.send-container {
			position: fixed;
			left: 0;
			bottom: var(--safe-area-inset-bottom);
			z-index: 2;
			width: 100%;
		}


	}
</style>
