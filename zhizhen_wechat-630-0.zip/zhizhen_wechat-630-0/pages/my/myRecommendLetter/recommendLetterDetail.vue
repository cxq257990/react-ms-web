<template>
	<view class="recommendInfo-box">
		<view class="recommendInfo">
			
			
			
		<view class="title"> 推荐信</view>
		<view class="top3">
			<view class="top3l">
				<image class="pophead" :src="avatar ? avatar : '../../static/img/anonymity.png'" mode=""></image>
			</view>
			<view class="top3r">
				<view class="top3r1">
					{{name}}
				</view>
				<view class="top3r2">
					{{common}}
				</view>
				<view class="top3r3">
					{{text}}{{['上级', '直属上司', '下属', '直属下属', '同事', '老师', '同学', '同行', '合作伙伴', '其他大咖'][states]}}
				</view>
			</view>
		</view>
		<view class="main margin-bottom" v-if="inType == 1">
			<view class=" content">
				{{recommendations}}
			</view>
		</view>
		<view class="main margin-bottom" v-if="inType == 2">
			<view class=" content">
				<textarea placeholder="请编辑推荐信内容..." maxlength="-1" auto-focus :value="recommendations"
					@input="bindKeyInput" />
			</view>

		</view>
		<view v-if="inType == 2" class="keep" @tap="keep">保 存</view>
	</view>
	
	</view>
</template>


<script>
	/**
	 * author        cxq
	 * time          2021-6-5 20:51:10
	 * description   
	 */
	export default {
		name: '',
		data() {
			return {
				inType: 0, //1由我收到的进入  2由我发出的进入
				editEvaluate: '',
				id: '',
				name: '',
				avatar: '',
				common: '',
				workpost: '',
				text:'',
				recommendations: '',
				modifytime: '',
				states: 0, //关系
				letteropenId: '', //
				openIds: '', //
				openId: '', //
			}
		},

		onLoad: function(options) {
			this.inType = options.type,
				this.id = options.id
			console.log("options------", options)
			if (options.letteropenId) {
				this.letteropenId = options.letteropenId
			}
			if (options.openId) {
				this.openIds = options.openId
			}
			this.getList()
			if (options.type == 1) {
				this.text='您曾经是他的'
				uni.setNavigationBarTitle({
					title: '我收到的'
				})
			} else {
				this.text='他曾经是我的'
				uni.setNavigationBarTitle({
					title: '我发出的'
				})
			}

		},


		onShow: function() {

		},

		onPullDownRefresh: function() {

		},

		onReachBottom: function() {

		},
		methods: {

			// 获取信息
			async getList() {
				let openId = this.openId
				let params
				if (this.inType == 1) {
					params = {
						openId: this.letteropenId,
						id: this.id
					}
				} else {
					params = {
						openId: this.openIds,
						id: this.id
					}
				}
				const res = await this.$http.getHasLoad('/zxxt/user/details', params);
				if (res.code == 'success') {
					this.name = res.data.user_name
					this.avatar = res.data.avatar
					this.common = res.data.common
					this.workpost = res.data.work_post
					this.recommendations = res.data.recommendations
					this.states = res.data.re_states
					let time
					time = res.data.modify_time || ''
					modifytime: time

				}
			},

			// 输入监听
			bindKeyInput(e) {
				console.log(e.detail.value)
				this.recommendations = e.detail.value
			},

			// 保存编辑
			async keep() {
				let params = {
					recommendations: this.recommendations,
					id: this.id
				}
				const res = await this.$http.getHasLoad('/zxxt/user/update', params);
				if (res.code == 'success') {
					uni.showToast({
						title: '编辑成功',
						icon: 'none',
						duration: 1500,
						success: function() {
							uni.navigateBack({
								delta: 1,
							})
						}
					})
				}

			}


		}

	}
</script>

<style lang="scss" scoped>
	
	
	.top3 {
		display: flex;
		flex-direction: row;
		width: 100%;
		min-height: 180rpx;
		margin-top: 28rpx;
		box-sizing: border-box;
		padding-left: 24rpx;
	
		.top3l {
			width: 97rpx;
			height: 180rpx;
			display: flex;
	
			.pophead {
				width: 80rpx;
				height: 80rpx;
				border-radius: 50%;
			}
		}
	
		.top3r {
			width: 600rpx;
			// overflow: hidden;
			height: 180rpx;
	
			.top3r1 {
				padding-left: 3rpx;
				font-size: 34rpx;
				line-height: 46rpx;
				color: #333333;
			}
	
			.top3r2 {
				font-size: 28rpx;
				line-height: 56rpx;
				color: #999;
			}
	
			.top3r3 {
				font-size: 28rpx;
				line-height: 42rpx;
				color: #999;
			}
		}
	}
	.recommendInfo {
		min-height: 1200rpx;
	}
	
	.recommendInfo-box {
		background: #f4f4f4;
		height: 100%;
		position: fixed;
	
		// background-color:red;
		width: 100%;
	}

	.margin-bottom {
		margin-bottom: 40rpx;
	}

	.title {
		padding-left: 32rpx;
		font-size: 48rpx;
		line-height: 150rpx;
	}

	.title1 {
		font-size: 34rpx;
		line-height: 80rpx;
	}

	.title2 {
		font-size: 28rpx;
		color: #999;
		line-height: 50rpx;
	}

	.head {
		width: 100%;
		height: 124rpx;
		box-sizing: border-box;
		padding: 30rpx;
		display: flex;
		flex-direction: row;
		align-items: center;
		justify-content: flex-start;
	}

	.head image {
		width: 64rpx;
		height: 64rpx;
		border-radius: 50%;
	}

	.headinfo {
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		margin-left: 16rpx;
		width: 600rpx;
	}

	.headname {
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		align-items: center;
	}

	.col9 {
		color: #999;
		font-size: 24rpx;
	}

	.headname view:nth-child(1) {
		width: 430rpx;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}

	.headname view:nth-child(2) {

		font-size: 24rpx;
		color: #999;
	}


	.main {
		width: 100%;
		height: auto;
		min-height: 300rpx;
		box-sizing: border-box;
		padding: 40rpx;
		font-size: 28rpx;
		color: #333;
		margin-top: 30rpx;
		word-break: break-all;
		background-color: #FFFFFF;
	}

	.content {}

	.main textarea {
		width: 100%;
		min-height: 300rpx;
		word-break: break-all;
	}

	.keep {
		width: 686rpx;
		height: 84rpx;
		border-radius: 18rpx 18rpx 18rpx 18rpx;
		left: 32rpx;
		position: fixed;
		bottom: 40rpx;
		font-size: 32rpx;
		color: #fff;
		background: #46A289;
		display: flex;
		justify-content: center;
		align-items: center;
	}
</style>
