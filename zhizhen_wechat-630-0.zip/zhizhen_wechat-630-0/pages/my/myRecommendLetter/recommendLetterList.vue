<template>
	<view class>
			<vTab @change='onTab' :activeIndex.sync="active" :tabTitleArr="tabTitleArr">
				<view slot="0">
					<view class=" receiveList-box" v-if="receiveList.length> 0">
					<vPageList  @onLower="onLower" @onRefresh="onRefresh"
						:pageListObj="pageListObj" :isShowNoResult="false">
						<view slot="item" v-for="item in receiveList" :key="item.id">
							<vHeadTitle 
							  :avatarOpenIdType="'letter_open_id'"
							 :obj="item">
							</vHeadTitle>
							<vMyCommentItem @tap="toRecommendDetail(item)" :noDetail="true" :hasOneLine="true" :obj="item">
							</vMyCommentItem>
						</view>
					</vPageList>
					</view>
					<view v-if="receiveList.length > 0" class="bottom-box">
						<view class="receiveList-botton-box" @tap="toinviteWrite">邀请写信</view>
					</view>
					<view class="nodata-box" v-if="receiveList.length=== 0">
						<view class="nodata">
							<view>您还没有收到推荐信，</view>
							<view>邀请好友为您写推荐信吧~</view>
							<view class="botton" @tap="toinviteWrite">邀请写信</view>
						</view>
					</view>
				</view>
				
				<view slot="1">
					<view class=" emitList-box" v-if="emitList.length> 0">
						<vPageList :isShowNoResult="false" @onLower="onLower" @onRefresh="onRefresh"
							:pageListObj="pageListObj">
							<view  class="" slot="item" v-for="item in emitList" :key="item.id">
								<view class="emitList-content-box">
									<view class="content-title">
										<view class>我推荐</view>
										<view>
											<text @tap="toRecommenSendedDetail(item)"
												class="iconfont icon-s-bianji btn"></text>
											<text @tap="revokeBtn(item)" class="iconfont icon-shanchu btn"></text>
										</view>
									</view>
									<view>
										<vHeadTitle
										 :hasOneLine="true"  :obj="item">
										</vHeadTitle>
										<view @tap="toRecommenSendedDetail(item)">
											<vMyCommentItem :noDetail="true" :obj="item"></vMyCommentItem>
										</view>
									</view>
								</view>
							</view>
						</vPageList>
					</view>
					<view v-if=" emitList.length > 0" class="bottom-box">
						<view class="emitList-botton-box" @tap="toWrite">写推荐信</view>
					</view>
					<view class="nodata-box" v-if="emitList.length === 0">
						<view class="nodata">
							<view>您还没有发出推荐信，</view>
							<view>请为好友写推荐信吧~</view>
							<view class="botton" @tap="toWrite">写推荐信</view>
						</view>
					</view>
					</view>
			</vTab >
			
	</view>
</template>

<script>
	/**
	 * author        cxq
	 * time          2021-6-5 10:34:17
	 * description
	 */

	import vMyCommentItem from "components/my/myNews/vMyCommentItem.vue"
	import vHeadTitle from "components/my/common/vHeadTitle.vue"
	import vPageList from "components/my/common/vPageList.vue"
	import vTab from "components/my/common/vTab.vue"

	import {
		mapState
	} from "vuex";

	export default {
		components: {
			vMyCommentItem,
			vHeadTitle,
			vPageList,
			vTab
		},
		computed: {
			...mapState(["loginInfoObj", 'userBaseInfo'])
		},
		data() {
			return {
				active: 0,
				tabTitleArr: [
					"我收到的", '我发出的'
				],
				pageListObj: {
					pageNo: 1,
					pageSize: 25,
					totalPageSize: 1

				},
				emitList: [], //发出的
				receiveList: [] //收到的
			};
		},

		watch: {

			active() {
				this.getFirstPage()

			},


		},

		onLoad() {

			this.openId = this.loginInfoObj.open_id

		},
		onShow() {


			this.getFirstPage()
		},
		methods: {
			onTab(item) {
				console.log('onTab=', item)
			},
	
			getFirstPage() {
				this.pageListObj.pageNo = 1
				if (this.active == 1) {
					this.emitList = []
					this.getEmitList()
				}
				if (this.active == 0) {
					this.receiveList = []
					this.getReceiveList()
				}
			},

			// 去邀请写推荐信
			toinviteWrite() {
				//被写人姓名 +  //被写人openid + avatar //被写人头像
				console.log("this.userBaseInfo--", this.userBaseInfo)
				uni.navigateTo({

					url: "/pages/recommendation/invitation?type=1&name=" +
						this.userBaseInfo.user_name +
						"&hisopenid=" +
						this.userBaseInfo.open_id +
						"&avatar=" +
						this.userBaseInfo.avatar
				});
			},
			// 去写推荐信
			// hisopenid //被邀请人openid + name //被邀请人姓名 + avatar //被邀请人头像
			toWrite() {
				uni.navigateTo({
					url: '/pages/friendPage/friendList?goWritterflag=yes',
				});
			},
			onChange(event) {

			},

			// 去-我收到的-详情
			// letteropenId  是写评论的那个人的
			toRecommendDetail(item) {
		
				uni.navigateTo({
					url: "/pages/my/myRecommendLetter/recommendLetterDetail?type=1&id=" +
						item.id +
						"&letteropenId=" +
						item.letter_open_id
				});
			},
			// 去-我发出的-详情i

			toRecommenSendedDetail(item) {
		
				uni.navigateTo({
					url: "/pages/my/myRecommendLetter/recommendLetterDetail?type=2&id=" + item.id + "&openId=" +
						item.open_id
				});
			},


			// ------------------------滚动加载，刷新-----------------------------
			onLower(pageNo) {

				this.pageListObj.pageNo = pageNo



				if (this.active == 1) {

					this.getEmitList()
				}
				if (this.active == 0) {

					this.getReceiveList()
				}
			},
			onRefresh() {

				this.getFirstPage()
			},


			// ================请求getReceiveList=====================================
			async getReceiveList() {
				var data = {
					pageNo: this.pageListObj.pageNo,
					pageSize: this.pageListObj.pageSize,
					openId: this.openId

				}

				const res = await this.$http.getHasLoad('/zxxt/user/receiveRecommendation', data);
				if (res && res.code == 'success' && res.data) {
					var data = res.data

					if (data.receive_vos && data.receive_vos.length == 0) {
						return
					}
					this.pageListObj.totalPageSize = data.total ? data.total : ""
					let list = this.resToData(data.receive_vos)
					this.receiveList = this.receiveList.concat(list)
			
					


				}
			},



			// ================请求getEmitList=====================================
			async getEmitList() {
				var data = {
					pageNo: this.pageListObj.pageNo,
					pageSize: this.pageListObj.pageSize,
					openId: this.openId

				}

				const res = await this.$http.getHasLoad('/zxxt/user/emitRecommendation', data);
				if (res && res.code == 'success' && res.data) {
					var data = res.data

					if (data.emit_vos && data.emit_vos.length == 0) {
						return
					}
					this.pageListObj.totalPageSize = data.total ? data.total : ""
					let list = this.resToData(data.emit_vos)
					this.emitList = this.emitList.concat(list)
		
				}
			},
			// =========resToData===============
			resToData(data) {

				let datas = []
				data.map(item => {
					let obj = {
						avatar: item.avatar ? item.avatar : this.$defaultHeadimg,
						user_name: item.user_name ? item.user_name : '',
						company_name: item.common ? item.common : '',
						if_anonymity: item.if_anonymity ? item.if_anonymity : '', //ttt
						position_name: item.work_post ? item.work_post : '', //
						commentContent: item.recommendations ? item.recommendations : '',
						time: item.modify_time ? item.modify_time : '',
						id: item.id ? item.id : '',
						letter_open_id: item.letter_open_id ? item.letter_open_id : '',
						open_id: item.open_id ? item.open_id : '',
						dataDetails: item
					}

					datas.push(obj)

				})
				return datas
			},
			//请求删除
			async getDelete(id) {
				let params = {
					id: id
				};
				const res = await this.$http.getHasLoad("/zxxt/user/delete", params);

				if (res.code == "success") {
					this.getFirstPage();
					uni.showToast({
						title: "撤销成功",
						icon: "none",
						duration: 2000
					});
				}

				if (res.code !== "success") {
					console.log("msg", res.message);
					uni.showToast({
						title: "撤销失败",
						icon: "none",
						duration: 2000
					});
				}
			},

			// 撤销操作
			revokeBtn(item) {
				let id = item.id;
				let that = this;
				uni.showModal({
					title: "要撤销推荐信吗？",
					content: "撤销后再无法恢复",
					confirmText: "撤销",
					confirmColor: "#209072",

					success: function(res) {
						if (res.confirm) {
							that.getDelete(id);
							console.log("撤销");
						} else if (res.cancel) {
							console.log("取消");
						}
					}
				});
			}
		}
	};
</script>


<style lang="scss" scoped>

	.reset__van-tabs {
		/deep/ .van-tab--active {
			color: $uni-color-active;
		}

		/deep/ .van-tabs__line {
			background-color: $uni-color-active;
			width: 100rpx !important;
			left: 38rpx;
		}
	}

	.emitList-box {
		// background-color: pink;
		background: #f3f3f3;
		// padding: 32rpx 0;
		padding-top: 32rpx ;
		// padding-bottom: 160rpx ;
	}
	.emitList-content-box {
		border: 4rpx solid #dbdbdb;
		border-radius: 16rpx;
		padding: 32rpx;
		margin-bottom: 32rpx;
		background-color: white;
	
		

		.content-title {
			display: flex;
			color: $uni-color-active;
			justify-content: space-between;

			.btn {
				margin-left: 60rpx;
			}
		}
	}


	.bottom-box {
		width: 100%;
		height: 150rpx;
		// border: 2rpx solid gray;
		bottom: -1rpx;
		background: #ffffff;
		// padding:20rpx;
		display: flex;
		position: fixed;
		justify-content: center;
		align-items: center;
	}

	.botton {
		width: 260rpx;
		height: 72rpx;
		background-color: rgba(32, 144, 114, 1);
		display: flex;
		margin: auto;
		margin-top: 50rpx;
		justify-content: center;
		align-items: center;
		color: rgba(255, 255, 255, 100);
		font-size: 32rpx;
		border-radius: 60rpx 60rpx 60rpx 60rpx;
	}

	.emitList-botton-box {
		border: 2rpx solid $uni-color-active;
		color: $uni-color-active;
		width: 260rpx;
		height: 72rpx;
		display: flex;
		justify-content: center;
		align-items: center;
		font-size: 32rpx;
		border-radius: 60rpx 60rpx 60rpx 60rpx;
	}

	.receiveList-botton-box {
		width: 260rpx;
		height: 72rpx;
		background-color: rgba(32, 144, 114, 1);
		display: flex;
		justify-content: center;
		align-items: center;
		color: rgba(255, 255, 255, 100);
		font-size: 32rpx;
		border-radius: 60rpx 60rpx 60rpx 60rpx;
	}

	.nodata {
		display: flex;
		flex-direction: column;
		align-items: center;
	}

	.nodata-box {
		color: rgba(153, 153, 153, 100);
		font-size: 26rpx;
		margin: auto;
		width: 80%;
		margin-top: 200rpx;
		line-height: 40rpx;
	}
</style>
