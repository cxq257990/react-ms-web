<template>
	<view class="reset__van-tabs myCommentAndLike">
		<vTab @change='onTab' :activeIndex.sync="active" :tabTitleArr="tabTitleArr">
		<view slot="0">
			<vPageList @onLower="onLower" :pageListObj="pageListObj" @onRefresh="onRefresh">
				<view slot="item" v-for="item in myCommentList" :key="item.id">
					<view class="vMyPraiseItem">
						<vMyPraiseItem :obj="item"></vMyPraiseItem>
					</view>
					<template v-if="item.sign==1">
						<view class="bottom">
							<text :List="myCommentList" class="time"> {{item.time}}</text>
			
							<VBtnList :pageType="'ask'" class="vBtnList-myCommentList-ask" :btnList="item.btnList">
							</VBtnList>
						</view>
					</template>
					<!-- 评论 -->
					<template v-else>
						<vMyCommentItem :obj="item"></vMyCommentItem>
						<VBtnList  :List="myCommentList"
							@onLikeAndCai="onLikeAndCai" :btnList="item.btnList">
						</VBtnList>
					</template>
				</view>
			</vPageList>
			
		</view>
		<view slot="1">
			<vPageList @onLower="onLower" :pageListObj="pageListObj" @onRefresh="onRefresh">
				<view slot="item" v-for="item in caiList " :key="item.id">
					<vHeadTitle 
					:haveAnonymityType="false"
					:avatarOpenIdType="'in_open_id'"
					 :obj="item"></vHeadTitle>
					<vMyCommentItem :hasOneLine="item.commentContent?false :true" :obj="item"></vMyCommentItem>
					<VBtnList v-if="item.commentContent?true:false" :List="caiList" @onLikeAndCai="onLikeAndCai"
						:btnList="item.btnList"></VBtnList>
				</view>
			</vPageList>
		</view>
		<view slot="2">
			<vPageList @onLower="onLower" :pageListObj="pageListObj" @onRefresh="onRefresh">
				<view slot="item" v-for="item in zanList" :key="item.id">
					<vHeadTitle 
					:haveAnonymityType="false"
					 :avatarOpenIdType="'in_open_id'" :obj="item"></vHeadTitle>
					<vMyCommentItem :hasOneLine="item.commentContent?false :true" :obj="item"></vMyCommentItem>
					<VBtnList v-if="item.commentContent?true:false" @onLikeAndCai="onLikeAndCai" :List="zanList"
						:btnList="item.btnList"></VBtnList>
				</view>
			</vPageList>
			</view>
		</vTab>
	</view>
</template>
<script>
	import vPageList from "components/my/common/vPageList.vue"
	import {
		mapState
	} from "vuex";

	import vBtnList from "components/my/common/vBtnList"
	import vMyCommentItem from "components/my/myNews/vMyCommentItem.vue"
	import vMyPraiseItem from "components/my/myNews/vMyPraiseItem.vue"
	import vHeadTitle from "components/my/common/vHeadTitle.vue"
	import vTab from "components/my/common/vTab"
	export default {
		components: {
			vMyPraiseItem,
			vHeadTitle,
			vMyCommentItem,
			vBtnList,
			vPageList,
			vTab
		},
		computed: {
			...mapState(['loginInfoObj', 'userInfoObj'])
		},
		data() {
			return {
				myCommentList: [],
				zanList: [],
				caiList: [],
				openId: "",
				active: 0,
				  
				tabTitleArr: [
					"我的点评", '我的踩', '我的赞'
				],
				
				pageListObj: {
					pageNo: 1,
					pageSize: 25,
					totalPageSize: 1

				}

			}
		},
		watch: {
			active() {
				this.getFirstPage()
			},

		},
		//--------分享-----------
		async onShareAppMessage(res) {
			console.log("onShareAppMessage:", res)
			let {
				id,
				obj
			} = res.target.dataset;
			let data = {
				"parent_id": obj.id,
				"comment_type": "1",
				"oper_type": "1",
				"show_name": this.userInfoObj.nickName,
				"open_id": this.loginInfoObj.open_id
			}
			let backRes = await this.$http.postHasLoad('/zxxt/careerEvalu/operComment', data);
			if (backRes) {
				console.log("obj.id:", obj.id);

				if (this.active == 0) {
					this.myCommentList.forEach(item => {
						if (item.dataDetails.id == obj.id) {
							console.log("item:", item)
							item.dataDetails.forward_count++;
							item.btnList[0].count++
						}
					})
				}


				if (this.active == 1) {
					this.zanList.forEach(item => {
						if (item.dataDetails.id == obj.id) {
							console.log("item:", item)
							item.dataDetails.forward_count++;
							item.btnList[0].count++
						}
					})

				}

				if (this.active == 2) {
					this.caiList.forEach(item => {
						if (item.dataDetails.id == obj.id) {
							console.log("item:", item)
							item.dataDetails.forward_count++;
							item.btnList[0].count++
						}
					})

				}




			}
			return {
				title: `${obj.if_anonymity=="1"?"匿名好友": obj.writers_name} 对 ${obj.user_name} 的评价详情`,
				path: `/pages/index/commentDetails?id=${id}`,
				imageUrl: '/static/img/forward_details.png'
			}
		},
		onLoad() {
			this.openId = this.loginInfoObj.open_id
			this.getFirstPage()

		},


		methods: {
			onTab(item) {
				console.log('onTab=', item)
			},


			onLikeAndCai(obj) {
				if (this.active == 1) {
					this.caiList = obj

				}
				if (this.active == 2) {
					this.zanList = obj
				}
				if (this.active == 0) {
					this.myCommentList = obj
				}
			},


			getFirstPage() {
				this.pageListObj.pageNo = 1
				if (this.active == 1) {
					this.caiList = []
					this.getMyCaiList()

				}
				if (this.active == 2) {
					this.zanList = []
					this.getMyZanList()
				}
				if (this.active == 0) {
					this.myCommentList = []
					this.getMyCommentList()
				}
			},

			onActive(e) {
				this.active = e.detail.index
			},
			// ================请求-详情页================
			onAvatarDetails(obj) {

				this.$util.checkJumpRelation(obj.dataDetails.openId)
			},
			onCommentDetails(obj) {
				console.log('onCommentDetails:', obj)
				uni.navigateTo({
					url: `/pages/index/commentDetails?id=${obj.dataDetails.id}`
				});
			},
			OnAskDetails(item) {
				uni.navigateTo({
					url: `/pages/index/askDetails?id=${item.dataDetails.id}`
				});
			},

			// ------------------------滚动加载，刷新-----------------------------

			onLower(pageNo) {
				this.pageListObj.pageNo = pageNo
				this.getMyCommentList()
			},
			onRefresh() {
				this.getFirstPage()


			},

			// ================请求getMyCommentList=====================================
			async getMyCommentList() {
				var data = {
					pageNo: this.pageListObj.pageNo,
					pageSize: this.pageListObj.pageSize,
					openId: this.openId

				}


				console.log("data", data)
				const res = await this.$http.getHasLoad('/zxxt/user/praiseRemarks', data);
				if (res && res.code == 'success' && res.data && res.data.remarks_vos) {
					var data = res.data
					console.log("getMyCommentList=", data)
					if (data.remarks_vos.length == 0) {
						return
					}
					this.pageListObj.totalPageSize = data.total ? data.total : ""
					this.resToData(data.remarks_vos)
				}
			},

			// ================请求getMyCaiList=====================================
			async getMyCaiList() {
				var data = {
					pageNo: this.pageListObj.pageNo,
					pageSize: this.pageListObj.pageSize,
					openId: this.openId

				}
				const res = await this.$http.getHasLoad('/zxxt/user/praiseStep', data);
				if (res && res.code == 'success' && res.data && res.data.step_evaluation_vos) {
					var data = res.data
					console.log("getMyCaiList=", data)
					if (data.step_evaluation_vos.length == 0) {
						return
					}
					this.pageListObj.totalPageSize = data.total ? data.total : ""
					this.resToDataZanAndCai(data.step_evaluation_vos, 'cai')
				}
			},
			// ================请求getMyZanList=====================================
			async getMyZanList() {
				var data = {
					pageNo: this.pageListObj.pageNo,
					pageSize: this.pageListObj.pageSize,
					openId: this.openId

				}

				const res = await this.$http.getHasLoad('/zxxt/user/praiseLike', data);
				if (res && res.code == 'success' && res.data && res.data.fabu_evaluation_vos) {
					var data = res.data
					console.log("getMyZanList=", data)
					if (data.fabu_evaluation_vos.length == 0) {
						return
					}
					this.pageListObj.totalPageSize = data.total ? data.total : ""
					this.resToDataZanAndCai(data.fabu_evaluation_vos, 'zan')
				}
			},


			// =========resToData==============================
			// 显示问题人的信息和被评论人的信息
			resToData(data) {
				data.forEach(item => {
						let user_name2= item.if_anonymity == 1 ? '访客' : item.user_name
						let user_name3= user_name2 ? user_name2 : '--' //问题人或者被评论人
					   let obj = {

						time: item.create_time ? item.create_time : '--',
						sign: item.sign ? item.sign : '', //1为ask
						type: item.sign == 1 ? 'ask' : 'comment', //my
						writers_name: item.writers_name ? item.writers_name : '',
						imgArr: item.picture ? item.picture.split(',') : [],
						answerText: item.text ? item.text : '', //回答
						requestionText: item.text_evaluate ? item.text_evaluate : '', //问题
						user_name: user_name3, //问题人或者被评论人
						id: item.id ? item.id : '',
						myOpenId: this.openId, //my
						in_open_id: item.open_id ? item.open_id : '', //问题人或者被评论人
						comment_count: item.comment_count ? item.comment_count : '',
						if_anonymity: item.if_anonymity ?  item.if_anonymity  : '', //访客评论和回答ttt
						dataDetails: item

					}

					obj.btnList = this.btnListData(item)
					this.myCommentList.push(obj)
				})

			},


			resToDataZanAndCai(data, type) {

				data.forEach(item => {

					let obj = {

						avatar: item.avatar ? item.avatar : this.$defaultHeadimg,
						writers_name: item.if_anonymity==1 ? "**": item.writers_name?item.writers_name:'**' , //评论人
						user_name: item.user_name ? item.user_name : '', //被评论的人
						company_name: item.name ? item.name : '',
						position_name: item.position ? item.position : '', //不使用
						commentContent: item.text_evaluate ? item.text_evaluate : '',
						time: item.modify_time ? item.modify_time : '',
						in_phone: item.in_phone ? item.in_phone : '',
						in_outer_id: item.in_outer_id ? item.in_outer_id : '',
						id: item.id ? item.id : '',
						open_id: item.open_id ? item.open_id : '', //评论人
						myOpenId: this.openId, //my
						in_open_id: item.in_open_id ? item.in_open_id : '', //被评论的人
						if_anonymity: item.if_anonymity ? item.if_anonymity : '',
						dataDetails: item,

					}

					obj.btnList = this.btnListData(item)

					if (type == 'zan') {

						obj.type = 'zan';
						this.zanList.push(obj)

						return
					}

					obj.type = 'cai';
					this.caiList.push(obj)


				})
			},


			btnListData(item) {
				if (item.sign == 1) {
					let btnList = [{
						type: "comment",
						count: item.reply_sum ? item.reply_sum : 0,
						parentId: item.id,
						myOpenId: this.openId, //===自己的=缓存的
						obj: item
					}]
					return btnList
				}
				let btnList = [{
						type: "forward",
						count: item.forward_count ? item.forward_count : 0,
						parentId: item.id,
						myOpenId: this.openId, //===自己的=缓存的
						obj: item
					},
					{
						type: "comment",
						count: item.comment_count ? item.comment_count : 0,
						parentId: item.id,
						myOpenId: this.openId, //===自己的=缓存的

						obj: item
					},

					{
						type: "like",
						myOpenId: this.openId, //===自己的=缓存的
						count: item.fabu_count ? item.fabu_count : 0,
						parentId: item.id,
						isLike: item.if_like == 1 ? true : false,
						obj: item
					},
					{
						type: "cai",
						count: item.step_count ? item.step_count : 0, //???
						parentId: item.id,
						myOpenId: this.openId, //===自己的=缓存的
						isCai: item.if_tread == 1 ? true : false,
						obj: item
					}

				]

				return btnList

			}

		}




	}
</script>


<style lang="scss" scoped>
	.vBtnList-myCommentList-ask {
		padding-right: 40rpx;

	}

	.vMyPraiseItem {
		margin-top: 32rpx;

	}

	.reset__van-tabs {
		/deep/ .van-tab--active {
			color: $uni-color-active;
		}

		/deep/ .van-tabs__line {
			background-color: $uni-color-active;
			width: 100rpx !important;
			left: 20rpx;
		}
	}

	.bottom {
		border-bottom: 1rpx solid $uni-text-color-greyA;
		display: flex;
		justify-content: space-between;
		align-items: center;
		height: 100rpx;

		.time {
			line-height: 50rpx;
			font-size: 24rpx;
			font-family: Microsoft YaHei;
			font-weight: 400;
			color: $uni-text-color-greyA;


		}
	}
</style>
