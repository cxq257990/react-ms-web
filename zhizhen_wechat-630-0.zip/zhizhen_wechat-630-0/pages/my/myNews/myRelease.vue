<template>
	<view class="reset__van-tabs myRelease">
		<vTab @change='onTab' :activeIndex.sync="active" :tabTitleArr="tabTitleArr">
		<view slot="0">
			<vPageList @onLower="onLower" :pageListObj="pageListObj" @onRefresh="onRefresh"
				>
				<view slot="item" v-for="item in myPublishJobList" :key="item.id">
					<vHeadTitle 	
					:haveAnonymityType="false"
					 :avatarOpenIdType="'in_open_id'"  :isShowdeleteBtn="true" @onDeleteBtn="onDeleteBtn"
						:data-id="item.id" :obj="item">
					</vHeadTitle>
					<vMyCommentItem :hasOneLine="item.commentContent?false :true" :obj="item"></vMyCommentItem>
					<VBtnList :List="myPublishJobList" v-if="item.commentContent?true:false" :btnList="item.btnList"
						@onLikeAndCai="onLikeAndCai"></VBtnList>
				</view>
			</vPageList>
		</view>
		<view slot="1">
			<vPageList @onLower="onLower" :pageListObj="pageListObj" @onRefresh="onRefresh"
				>
				<view slot="item" v-for="item in myPublishAskList" :key="item.id">
					<view class="vHeadTitle">
						<!-- myOpenId -->
						<vHeadTitle 
						 :pageType="'ask'" 
						 :avatarOpenIdType="'myOpenId'" 
						 :isShowdeleteBtn="true" @onDeleteBtn="onDeleteBtn"
							:data-id="item.id" :obj="item">
						</vHeadTitle>
					</view>
			
					<vMyAskItem :obj="item"></vMyAskItem>
					<view class="bottom">
						<text class="time"> {{item.create_time}}</text>
						<view class="vBtnList-ask">
							<VBtnList :List="myPublishAskList" :btnList="item.btnList" :pageType="'ask'"
								@onLike="onLike"></VBtnList>
						</view>
					</view>
				</view>
			</vPageList>
		</view>
		<view slot="2">
			<vPageList @onLower="onLower" :pageListObj="pageListObj" @onRefresh="onRefresh"
				>
				<view slot="item" v-for="(item,index) in myCommentList" :key="item.id">
					<vHeadTitle  
					:haveAnonymityType="false"
					:isShowdeleteBtn="true" @onDeleteBtn="onDeleteBtn"
						:data-id="item.id" :obj="item"></vHeadTitle>
					<vTotalScoreItem @tap='toDetail(item)' :obj="item"></vTotalScoreItem>
					<vMyCommentItem :obj="item" :hasOneLine="item.commentContent?false :true"></vMyCommentItem>
				</view>
			</vPageList>
			</view>
		</vTab>
		

		
	</view>
</template>
<script>
	import {
		mapState
	} from "vuex";
	import vTotalScoreItem from "components/my/myNews/vTotalScoreItem.vue"
	import vMyCommentItem from "components/my/myNews/vMyCommentItem.vue"
	import vMyAskItem from "components/my/myNews/vMyAskItem.vue"
	import vHeadTitle from "components/my/common/vHeadTitle.vue"
	import vPageList from "components/my/common/vPageList.vue"
	import vBtnList from "components/my/common/vBtnList"
	import vTab from "components/my/common/vTab"
	export default {
		components: {
			vMyCommentItem,
			vHeadTitle,
			vPageList,
			vMyAskItem,
			vBtnList,
			vTotalScoreItem,
			vTab

		},
		computed: {
			...mapState(['loginInfoObj', 'userInfoObj']),

		},
		data() {
			return {
				tabTitleArr: [
					"职评圈", '问员工', '邀请评价'
				],
				myPublishJobList: [],
				myPublishAskList: [],
				myCommentList: [],
				openId: "",
				active: 0,
				pageListObj: {
					pageNo: 1,
					pageSize: 25,
					totalPageSize: 1
				
				}

			}
		},
		watch: {

			active() {

				this.getFirstPage()

			},


		},
		//--------分享-----------
		async onShareAppMessage(res) {
			console.log("onShareAppMessage:", res)
			let {
				id,
				obj
			} = res.target.dataset;
			let data = {
				"parent_id": obj.id,
				"comment_type": "1",
				"oper_type": "1",
				"show_name": this.userInfoObj.nickName,
				"open_id": this.loginInfoObj.open_id
			}
			let backRes = await this.$http.postHasLoad('/zxxt/careerEvalu/operComment', data);
			if (backRes) {
				console.log("obj.id:", obj.id);
				this.myPublishJobList.forEach(item => {
					if (item.dataDetails.id == obj.id) {
						console.log("item:", item)
						item.dataDetails.forward_count++;
						item.btnList[0].count++
					}
				})

			}

			return {
				title: `${obj.if_anonymity=="1"?"匿名好友":this.userInfoObj.nickName} 对 ${obj.user_name} 的评价详情`,
				path: `/pages/index/commentDetails?id=${id}`,
				imageUrl: '/static/img/forward_details.png'
			}
		},
		onLoad(option) {
			console.log("onLoad-option:", option)
			this.openId = this.loginInfoObj.open_id
			this.getFirstPage()

		},

		methods: {
			onTab(item) {
				console.log('onTab=', item)
			},

			getFirstPage() {

				this.pageListObj.pageNo = 1

				if (this.active == 0) {
					this.myPublishJobList = []
					this.getMyPublishJob()
				}
				if (this.active == 1) {
					this.myPublishAskList = []
					this.getMyPublishAskList()
				}
				if (this.active == 2) {
					this.myCommentList = []
					this.getMyCommentList()
				}



			},




			onLike(obj) {
				this.myPublishJobList = obj
			},


			onLikeAndCai(obj) {
				this.myPublishJobList = obj

			},

			onActive(e) {
				this.active = e.detail.index
			},


			// 职评圈(删除),问员工删除
			async onDeleteBtn(id) {
				let obj = {
					id: id
				}
				let res
				if (this.active == 0) {
					res = await this.$http.getHasLoad('/zxxt/user/delJobEvaluation', obj);
				}
				if (this.active == 1) {
					res = await this.$http.getHasLoad('/zxxt/user/delAskStaff', obj);
				}
				if (this.active == 2) {
					res = await this.$http.getHasLoad('/zxxt/user/delJobEvaluation', obj);
				}
				if (res && res.code == 'success') {
					this.getFirstPage();
					uni.showToast({
						title: '删除成功',
						icon: 'none',
						duration: 2000
					})

				} else {
					uni.showToast({
						title: '删除失败',
						icon: 'none',
						duration: 2000
					})
				}
			},




			// ================请求-详情页================

			toDetail(item) {

		
				if (!item.commentContent) {

					this.$util.toast('无详情，不可点击')
				}


			},
			// ------------------------滚动加载，刷新-----------------------------
			onLower(pageNo) {
				console.log("onLower--",pageNo)
				this.pageListObj.pageNo = pageNo

				if (this.active == 0) {
					this.getMyPublishJob()
				}
				if (this.active == 1) {
					this.getMyPublishAskList()
				}
				if (this.active == 2) {
					this.getMyCommentList()
				}

			},
			onRefresh() {
				this.getFirstPage()
			},
			// ================请求getMyCommentList=====================================

			async getMyCommentList() {
				var data = {
					pageNo: this.pageListObj.pageNo,
					pageSize:this.pageListObj.pageSize,
					openId: this.openId

				}
				const res = await this.$http.getHasLoad('/zxxt/user/myInvite', data);
				if (res && res.code == 'success' && res.data && res.data.user_remark_vo_list) {
					var data = res.data
					console.log("---getMyCommentList--", data)
					if (data.user_remark_vo_list.length == 0) {
						return
					}
					this.pageListObj.totalPageSize = data.total ? data.total : ""
					this.resToDataMyCommentList(data.user_remark_vo_list)
				}
			},
			// ================请求getMyPublishJob=====================================
			async getMyPublishJob() {
				var data = {
	                pageNo: this.pageListObj.pageNo,
					pageSize:this.pageListObj.pageSize,
					openId: this.openId

				}
				const res = await this.$http.getHasLoad('/zxxt/user/myPublishJob', data);
				if (res && res.code == 'success' && res.data && res.data.job_evaluation_vos) {
					var data = res.data
					console.log("myPublishJob=", data)
					if (data.job_evaluation_vos.length == 0) {
						return
					}
					this.pageListObj.totalPageSize = data.total ? data.total : ""
					this.resToData(data.job_evaluation_vos)
				}
			},


			// ================请求getMyPublishAskList=====================================
			async getMyPublishAskList() {
				var data = {
				pageNo: this.pageListObj.pageNo,
				pageSize:this.pageListObj.pageSize,
					openId: this.openId

				}

				const res = await this.$http.getHasLoad('/zxxt/user/myPublishAsk', data);
				if (res && res.code == 'success' && res.data && res.data.ask_staff_vos) {
					var data = res.data
					console.log("myPublishAsk=", data)
					if (data.ask_staff_vos.length == 0) {
						return
					}
					this.pageListObj.totalPageSize = data.total ? data.total : ""
					this.resToDataAsk(data.ask_staff_vos)
				}
			},


			// =============resToData====结果返回数据转换处理
			resToDataMyCommentList(data) {
				data.map((item, index, arr) => {
					const obj = {
						commentContent: item.text_evaluate ? item.text_evaluate : '',
						labels: item.labels ? JSON.parse(item.labels) : [],
						company_name: item.company_name ? item.company_name : '',
						position_name: item.position_name ? item.position_name : '',
						time: item.create_time ? item.create_time : '',
						avatar: item.avatar ? item.avatar : this.$defaultHeadimg,
						online_flag: item.online_flag ? item.online_flag : '',
						unread: item.unread ? item.unread : '',
						total_score: item.total_score ? item.total_score : 0,
						myOpenId: this.openId, //===自己的=点评人
						open_id: item.open_id ? item.open_id : '', //==被点评的人
						id: item.id ? item.id : '',
						states: item.states ? item.states : '',
						nickname: item.nickname ? item.nickname : '', //0
						user_name: item.user_name ? item.user_name : ' ',
						if_anonymity: item.if_anonymity ? item.if_anonymity : '', //ttt
						dataDetails: item

					}
					this.myCommentList.push(obj)

				})
			},

			resToData(data) {

				data.forEach(item => {
					let obj = {

						user_name: item.user_name ? item.user_name : '',
						writers_name: item.writers_name ? item.writers_name : '',
						company_name: item.name ? item.name : '',
						avatar: item.avatar ? item.avatar : this.$defaultHeadimg,
						if_anonymity: item.if_anonymity ? item.if_anonymity : '', //tttt
						position_name: item.position ? item.position : '', //
						commentContent: item.text_evaluate ? item.text_evaluate : '',
						time: item.modify_time ? item.modify_time : '',
						in_phone: item.in_phone ? item.in_phone : '',
						in_outer_id: item.in_outer_id ? item.in_outer_id : '',
						id: item.id ? item.id : '',
						myOpenId: this.loginInfoObj.open_id,
						open_id: item.open_id ? item.open_id : '',
						in_open_id: item.in_open_id ? item.in_open_id : '',
						dataDetails: item
					}

					obj.btnList = this.btnListData(item, '')
					this.myPublishJobList.push(obj)
				})
			},
			resToDataAsk(data) {
				data.forEach(item => {
					let obj = {
						writers_name: item.writers_name ? item.writers_name : '', //0
						imgArr: item.picture ? item.picture.split(',') : [],
						// company_name: item.name ? item.name : '',//无返回需求
						avatar: item.avatar ? item.avatar : this.$defaultHeadimg,
						commentContent: item.text_evaluate ? item.text_evaluate : "",
						// open_id_name: item.open_show_name ? item.open_show_name : "", //1,3 1个人 3公司  role_type
						user_name: item.open_show_name ? item.open_show_name : "", //1,3 1个人 3公司  role_type
						id: item.id ? item.id : "",
						comment_count: item.reply_sum ? item.reply_sum : "",
						myOpenId: this.loginInfoObj.open_id,
						open_id: item.open_id ? item.open_id : '',
						in_open_id: item.in_open_id ? item.in_open_id : '', //0
						role_type: item.role_type ? item.role_type : "",
						create_time: item.create_time ? item.create_time : "",
						dataDetails: item
					}
			
					obj.btnList = this.btnListData(item, 'ask')
					this.myPublishAskList.push(obj)
				})
			},

			btnListData(item, type) {

				if (type == "ask") {
					let btnList = [

						{
							type: "comment",
							count: item.reply_sum ? item.reply_sum : 0,
							parentId: item.id,
							myOpenId: this.openId, //===自己的=缓存的
							obj: item
						}
					]
					return btnList
				}
				let btnList = [{
						type: "forward",
						count: item.forward_count ? item.forward_count : 0,
						parentId: item.id,
						myOpenId: this.openId, //===自己的=缓存的
						obj: item
					},
					{
						type: "comment",
						count: item.comment_count ? item.comment_count : 0,
						parentId: item.id,
						myOpenId: this.openId, //===自己的=缓存的
						obj: item
					},

					{
						type: "like",
						count: item.fabu_count ? item.fabu_count : 0,
						parentId: item.id,
						myOpenId: this.openId, //===自己的=缓存的
						isLike: item.if_like == 1 ? true : false,
						obj: item
					},
					{
						type: "cai",
						count: item.step_count ? item.step_count : 0, //???
						parentId: item.id,
						myOpenId: this.openId, //===自己的=缓存的
						isCai: item.if_tread == 1 ? true : false,
						obj: item
					}

				]

				return btnList

			}
		}
	}
</script>

<style lang="scss" scoped>
	
	// .vHeadTitle /deep/ .right {
	// 	padding-right: 100rpx;
	// }
	.vBtnList-ask {
		margin-right: 50rpx;
		margin-bottom: 20rpx;
		// padding-bottom: -200rpx;
		// background: red;
		width: 100rpx;
		height: 60rpx;


	}

	.reset__van-tabs {
		/deep/ .van-tab--active {
			color: $uni-color-active;
		}

		/deep/ .van-tabs__line {
			background-color: $uni-color-active;
			width: 100rpx !important;
			left: 10rpx;
		}
	}

	.bottom {
		border-bottom: 1rpx solid $uni-border-color;
		display: flex;
		justify-content: space-between;
		align-items: center;
		height: 100rpx;

		.time {
			line-height: 30rpx;
			font-size: 24rpx;
			font-family: Microsoft YaHei;
			font-weight: 400;
			color: $uni-text-color-greyA;


		}
	}

	.vMyCommentItem {
		padding: 32rpx;
	}
</style>
