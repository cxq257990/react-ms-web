<template>
	<view class="myNewsPage reset__van-tabs">
		<vTab @change='onTab' :activeIndex.sync="active" :tabTitleArr="tabTitleArr">

			<view slot="0">
				<view class="beCommentedNumInWeek">近一周被点评 +{{obj.beCommentedNumInWeek}}</view>
				<vPageList @onLower="onLower" :pageListObj="pageListObj" @onRefresh="onRefresh">
					<view class="icon-news-box" slot="item" v-for="(item,index) in byRemarkList" :key="item.id">
						<!-- unread:0, -->
						<view v-if='newbeCommentedNum>index' class="iconfont" :class="['icon-news','icon-news-you']">
						</view>
						<vHeadTitle :obj="item"></vHeadTitle>
						<vTotalScoreItem @tap="toDetail(item)" :obj="item"></vTotalScoreItem>
						<vMyCommentItem :obj="item" :hasOneLine="item.commentContent?false :true"></vMyCommentItem>
						<VBtnList :List="byRemarkList" v-if="item.commentContent?true:false" :btnList="item.btnList"
							@onLikeAndCai="onLikeAndCai"></VBtnList>
					</view>
				</vPageList>
			</view>

			<!-- <view  slot="1">
		
		</view>
		<view  slot="2">
		
		</view> -->
		</vTab>

	</view>
</template>

<script>
	/**
	 * author        cxq
	 * time          2021-5-31 17:16:38
	 * description   
	 */
	import vPageList from "components/my/common/vPageList.vue"
	import vMyCommentItem from "components/my/myNews/vMyCommentItem.vue"
	import vTotalScoreItem from "components/my/myNews/vTotalScoreItem.vue"
	import vHeadTitle from "components/my/common/vHeadTitle.vue"
	import vBtnList from "components/my/common/vBtnList"
	import vTab from "components/my/common/vTab"
	import {
		mapState
	} from "vuex";
	export default {
		computed: {
			...mapState(['loginInfoObj', 'userInfoObj']),
		},
		components: {
			vMyCommentItem,
			vTotalScoreItem,
			vHeadTitle,
			vBtnList,
			vTab,
			vPageList
		},
		data() {
			return {

				byRemarkList: [],
				tabTitleArr: [
					"我被点评", '我的发布', '我的评赞'
				],

				pageListObj: {
					pageNo: 1,
					pageSize: 25,
					totalPageSize: 1

				},
				openId: "",
				active: 0,
				newbeCommentedNum: 0,
				obj: {
					beCommentedNumInWeek: 0

				},
			}
		},
		watch: {

			active() {


				switch (this.active) {
					case 0:
						this.getFirstPage()
						break;
					case 1:
						uni.navigateTo({
							url: './myRelease',
						});
						this.active = 0
						break;

					case 2:
						uni.navigateTo({
							url: './myCommentAndLike',
						});
						this.active = 0
						break;


					default:
				}

			},
		},
		//--------分享-----------
		async onShareAppMessage(res) {
			let {
				id,
				obj
			} = res.target.dataset;

			let myOpenIdName = this.userInfoObj.nickName
			let data = {
				"parent_id": obj.id,
				"comment_type": "1",
				"oper_type": "1",
				"show_name": this.userInfoObj.nickName,
				"open_id": this.loginInfoObj.open_id
			}
			let backRes = await this.$http.postHasLoad('/zxxt/careerEvalu/operComment', data);
			if (backRes) {
				this.byRemarkList.forEach(item => {
					if (item.dataDetails.id == obj.id) {
						console.log("item:", item)
						item.dataDetails.forward_count++;
						item.btnList[0].count++
					}
				})

			}
			return {
				title: `${obj.if_anonymity=="1"?"匿名好友":obj.user_name} 对 ${myOpenIdName} 的评价详情`,
				path: `/pages/index/commentDetails?id=${id}`,
				imageUrl: '/static/img/forward_details.png'
			}
		},
		onLoad(option) {
			this.openId = this.loginInfoObj.open_id
			this.newbeCommentedNum = Number(option.newbeCommentedNum)
			this.getFirstPage()
			//未读信息-查看接口-已经查看
			this.getLooked()

		},

		onShow() {
			this.active = 0
		},


		methods: {
			onTab(item) {
				console.log('onTab=', item)
			},
			toDetail(item) {

				if (item.commentContent) {
					uni.navigateTo({
						url: `/pages/index/commentDetails?id=${item.id}`
					});
				}

				if (!item.commentContent) {

					this.$util.toast('无详情，不可点击')
				}


			},
			//未读信息-查看接口-已经查看  1为已经查看
			async getLooked() {
				const params = {
					openId: this.loginInfoObj.open_id,
					friendSign: 0,
					remarkSign: 1,
					lookSign: 0
				}
				await this.$http.getHasLoad('/zxxt/user/center', params);
			},
			onLikeAndCai(obj) {
				this.byRemarkList = obj
			},

			getFirstPage() {
				this.pageListObj.pageNo = 1
				this.byRemarkList = []
				this.getbyRemarkList()

			},

			// ------------------------滚动加载，刷新-----------------------------
			onLower(pageNo) {
				this.pageListObj.pageNo = pageNo
				this.getbyRemarkList()
			},
			onRefresh() {
				this.getFirstPage()
			},

			// ===========getbyRemarkList===

			async getbyRemarkList() {

				var data = {
					pageNo: this.pageListObj.pageNo,
					pageSize: this.pageListObj.pageSize,
					openId: this.openId

				}

				const res = await this.$http.getHasLoad('/zxxt/user/byRemark', data);
				if (res && res.code == 'success' && res.data && res.data.user_remark_vo_list) {
					var data = res.data
					console.log("---getbyRemarkList--", data)
					if (data.user_remark_vo_list.length == 0) {
						return
					}
					this.obj.beCommentedNumInWeek = data.number ? data.number : 0
					this.pageListObj.totalPageSize = data.total ? data.total : ""
					this.resToData(data.user_remark_vo_list)
				}
			},

			// =============resToData====结果返回数据转换处理
			// current_page: 1
			// 展示点评人的信息
			resToData(data) {
				data.map((item, index, arr) => {
					const obj = {
						commentContent: item.text_evaluate ? item.text_evaluate : '',
						labels: item.labels ? JSON.parse(item.labels) : [],
						company_name: item.company_name ? item.company_name : '',
						position_name: item.position_name ? item.position_name : '',
						time: item.create_time ? item.create_time : '',
						avatar: item.avatar ? item.avatar : this.$defaultHeadimg,
						// online_flag: item.online_flag ? item.online_flag : '',//不使用
						// unread: item.unread ? item.unread : '',//不使用
						total_score: item.total_score ? item.total_score : 0,
						in_open_id: this.openId, //==被点评人-my
						id: item.id ? item.id : '',
						// states: item.states ? item.states : '',//不使用
						nickname: item.nickname ? item.nickname : '', //===点评人
						open_id: item.open_id ? item.open_id : '', //===点评人==
						user_name: item.user_name ? item.user_name : item.nickname, //点评人
						if_anonymity: item.if_anonymity ? item.if_anonymity : '', //点评人访客//tttt
						btnList: [

							{
								type: "forward",
								count: item.forward_count,
								parentId: item.id,
								myOpenId: this.openId, //
								obj: item
							},
							{
								type: "comment",
								count: item.comment_count,
								parentId: item.id,
								myOpenId: this.openId, //===自己的
								obj: item
							},

							{
								type: "like",
								count: item.fabu_count,
								parentId: item.id,
								myOpenId: this.openId, //===自己的
								isLike: item.if_like == 1 ? true : false,
								obj: item
							},
							{
								type: "cai",
								count: item.step_count, //???
								parentId: item.id,
								myOpenId: this.openId, //===自己的=
								isCai: item.if_tread == 1 ? true : false,
								obj: item
							}

						],
						dataDetails: item

					}
					this.byRemarkList.push(obj)

				})
			}
		}
	}
</script>

<style lang="scss" scoped>
	.icon-news-box {
		position: relative
	}

	.reset__van-tabs {
		/deep/ .van-tab--active {
			color: $uni-color-active;
		}

		/deep/ .van-tabs__line {
			background-color: $uni-color-active;
			width: 100rpx !important;
			left: 20rpx;
		}
	}

	.myNewsPage {

		.icon-news {
			position: absolute;
			font-size: 70rpx;
			color: #fdbd33;
			right: 0;
			top: -10rpx;

		}

		.beCommentedNumInWeek {
			background-color: #FFFAE9;
			padding-left: 39rpx;
			line-height: 60rpx;
			font-size: $uni-font-size-base;
		}
	}
</style>
