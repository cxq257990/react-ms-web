<template>
	<view class="myIndex" :style="{'padding-top':statusBarHeight+'px', height: `calc(100vh - ${statusBarHeight}px)`}">
		<vStatusbar txt="个人中心"></vStatusbar>
		<scroll-view class="scroll-Y" scroll-y="true">
			<view class="myIndex-box">
				<!-- 档案完成度和头像信息 -->
				<view class="top-box">
					<view>
						<view class="name">{{userInfo.username}}</view>

						<view class=" archivesComplete">
							<view class="progress">
								<progress :percent="userInfo.archivesComplete" activeColor="#209072" active
									stroke-width="4" />
							</view>
							<view class="text ">档案完成度{{userInfo.archivesComplete}} %</view>
						</view>
					</view>
					<image class="image" :src="userInfo.avatar"></image>
				</view>
				<!-- ================================我的动态 =========================-->
				<view class="message-box">
					<navigator url="../friendPage/friendList">

						<view class="box">
							我的好友
							<view v-if="userInfo.friend_sum>0" class="circular-box">{{userInfo.friend_sum}}</view>
						</view>
					</navigator>
					<view class="one-line3"></view>

					<navigator :url="'./myNews/myNewsIndex?newbeCommentedNum='+userInfo.remark_sum">
						<view class="box">
							我的动态
							<view v-if="userInfo.remark_sum>0" class="circular-box">{{userInfo.remark_sum}}</view>
						</view>
					</navigator>

					<view class="one-line3"></view>
					<navigator url="./myInfo/lookAtMe">
						<view class="box">
							谁看过我
							<view v-if="userInfo.lookme_sum>0" class="circular-box">{{userInfo.lookme_sum}}</view>
						</view>
					</navigator>
				</view>
				<view class="one-line2"></view>
				<!-- ==============================list================================= -->
				<view class="cell-item-box cell-item-box-myArchives" @tap="goDetail('./myInfo/myArchives')">

					<view class="left iconfont icon-geren-dangan1"></view>
					<view class="center">我的档案</view>
					<view class=" myArchives-right">编辑档案</view>
				</view>
				<view class="one-line2"></view>
				<view class="cell-items-box">
					<template v-for="(i,index) in cellArrs">
						<view :key="index" v-if="i.text=='背调进度' && userInfo.issue_id ||i.text!='背调进度'">
							<view class="cell-item-box" @tap="goDetail(i.url)">
								<view class="left iconfont " :class="i.icon"></view>
								<view class="center">{{i.text}}</view>
								<view class="right iconfont icon-s-xiangyou"></view>
							</view>
							<view class="one-line2" v-if="i.text=='推荐信'"></view>
						</view>

					</template>
				</view>
				<view class=" loginout-btn-box">
					<navigator target="miniProgram" hover-class="none" open-type="exit">
						<view class="loginout-btn">退出</view>
					</navigator>
				</view>

			</view>

		</scroll-view>
	</view>
</template>

<script>
	/**
	 * author        cxq
	 * time          2021-5-27 13:37:26
	 * description   
	 */
	import vStatusbar from "components/common/vStatusbar.vue"
	import {
		mapState
	} from "vuex";
	export default {
		computed: {
			...mapState(['userPhone', 'userInfoObj', 'loginInfoObj'])
		},
		components: {
			vStatusbar

		},
		data() {
			return {
				// isShow:userInfo.issue_id?true:false,
				cellArrs: [{
						icon: 'icon-geren-xinxi',
						text: '基础信息',
						url: './myInfo/myBaseInfo'
					},
					
					{
						icon: 'icon-geren-gongzuo',
						text: '职业履历',
						url: './myRecord/exerciseList'
					},
					{
						icon: 'icon-geren-jiaoyu',
						text: '教育履历',
						url: '/pages/my/myRecord/eduList'
					},
					{
						icon: 'icon-geren-jindu',
						text: '背调进度',
						url: '/pages/multiEntry/backgroundCheck/progress'
					},
					{
						icon: 'icon-geren-xin',
						text: '推荐信',
						url: '/pages/my/myRecommendLetter/recommendLetterList'
					},
					{
						icon: 'icon-geren-xieyi',
						text: '用户协议',
						url: './myPage/userAgreement'
					},
					{
						icon: 'icon-geren-yinsi',
						text: '隐私政策',
						url: './myPage/privacyPolicy'
					},
					{
						icon: 'icon-bangzhu1',
						text: '帮助中心',
						url: './myPage/helpCenter'
					}
				],
				statusBarHeight: 0,
				userImg: "/static/img/anonymity.png",
				remarkSignNum: 0,
				friendSign: 0, //(我的好友)有无点击查看 0：未；1：已查看
				remarkSign: 0, // (我的动态)有无点击查看 0：未；1：已查看
				lookSign: 0, // (谁看过我)有无点击查看 0：未；1：已查看
				userInfo: {},

				onshowFlag: 0, //onshow标识

			}
		},
		//--------分享-----------
		async onShareAppMessage(res) {

			if (res.from == "menu") {
				return {
					title: `欢迎进入指真小程序！`,
					path: "/pages/index/index",
					imageUrl: '/static/img/forward_details.png'
				}
			}

		},
		onLoad(options) {
			console.log("onLoad==", this.first)
			let res = uni.getSystemInfoSync();
			let menu = wx.getMenuButtonBoundingClientRect();
			this.statusBarHeight = (menu.top - res.statusBarHeight) * 2 + menu.height + res.statusBarHeight;
			if (res.model.indexOf('iPhone') > -1) {
				this.statusBarHeight += 4
			}
			this.getUserInfo()
	
		},

		onShow() {
			this.getBarMsg()
			this.onshowFlag++
			if (this.onshowFlag != 1) {
				this.getUserInfo()
			}
	
		},
		methods: {
			goDetail(url) {

				uni.navigateTo({
					'url': url
				})
			},
			async getBarMsg() {
				// bar未读消息
				let params = {
					openId: this.loginInfoObj.open_id
				}
				let res = await this.$http.getNoLoad('/zxxt/user/getNoRead', params);
				if (res.data) {
				// if (1) {
					config.log('=========================')
					let text = res.data + ''
					uni.setTabBarBadge({
						index: 3,
						text
					})
				} else {
					uni.removeTabBarBadge({
						index: 3
					})
				}
			},
			async getUserInfo() {
				const params = {
					openId: this.loginInfoObj.open_id,
					friendSign: this.friendSign,
					remarkSign: this.remarkSign,
					lookSign: this.lookSign
				}
				const res = await this.$http.getHasLoad('/zxxt/user/center', params);
				this.resToData(res)
			},

			resToData(res) {
				if (res && res.code == 'success' && res.data) {
					let data = res.data
					console.log("---res--", data)
					this.userInfo = {
						avatar: data.avatar ? data.avatar : this.$defaultHeadimg,
						issue_id: data.issue_id ? data.issue_id : '',
						friend_sum: data.friend_sum ? data.friend_sum : '', //ttt
						archivesComplete: data.file_ratio ? data.file_ratio : 0,
						lookme_sum: data.lookme_sum ? data.lookme_sum : '', //ttt
						remark_sum: data.remark_sum ? data.remark_sum : '', //ttt
						username: data.user_name ? data.user_name : '',

					}


					let userInfo = {
						avatar: data.avatar ? data.avatar : this.$defaultHeadimg,
						user_name: data.user_name ? data.user_name : '',
						open_id: this.loginInfoObj.open_id

					}
					this.$store.commit("submitUserBaseInfo", userInfo);
					console.log("---res0--", data)
				}

			}


		}


	}
</script>

<style lang="scss" scoped>
	.myIndex {}

	.cell-items-box {}


	.cell-item-box {

		display: flex;
		justify-content: space-between;
		height: 100rpx;
		padding: 0 40rpx;
		align-items: center;
		border-bottom: 2rpx solid $uni-line-color-grayA;
		;

		.left {
			width: 40rpx;
			height: 40rpx;
			padding-right: 20rpx;

		}

		.center {
			flex: 1;
			font-size: 30rpx;
			// color: $uni-line-color-grayA;
		}

		.right {
			width: 40rpx;
			height: 40rpx;
			font-size: 26rpx;
			color:$uni-text-color-greyA;
		}

	}

	.cell-item-box-myArchives {
		// border-bottom: 20rpx solid $uni-line-color-grayA;
		;

		.myArchives-right {
			font-size: $uni-font-size-base;
			color: $uni-text-color-greyA;
			width: 160rpx;
			text-align: right;


		}
	}


	.left-icon {

		width: 40rpx;
		height: 40rpx;
		padding-right: 10rpx;
	}

	.archives-text {
		font-size: $uni-font-size-base;
		color: $uni-text-color-greyA;
	}

	.loginout-btn-box {
		height: 140rpx;
		padding-top: 100rpx;
		padding-right: 20rpx;
		padding-left: 20rpx;
		background-color: $uni-line-color-grayA;

		.loginout-btn {
			width: 100%;
			margin: auto;
			height: 100rpx;
			line-height: 100rpx;
			background-color: #FFFFFF;
			color: #4cd964;
			text-align: center;
			border: 2rpx solid #4cd964;

		}
	}

	.top-box {
		height: 200rpx;
		display: flex;
		justify-content: space-around;
		align-items: center;
		padding: 10rpx;

		.image {
			width: 120rpx;
			height: 120rpx;
			border-radius: 50%;
		}

		.name {
			font-size: 50rpx;
		}

	}

	.archivesComplete {
		// height: 200rpx;
		display: flex;
		align-items: center;
		margin-top: 40rpx;

		.text {
			font-size: $uni-font-size-base;
			color: $uni-text-color-greyA;
		}

		.progress {
			width: 250rpx;
			margin-right: 10rpx;
		}

	}

	.message-box {
		height: 100rpx;
		display: flex;
		justify-content: space-around;
		align-items: center;
		padding: 40rpx;

		.box {
			position: relative;
			font-weight: 500;
			font-size: 40rpx;
			.circular-box{
				position: absolute;
				right: 1rpx;
				bottom: 50rpx;
				width: 45rpx;
				height: 45rpx;
				line-height: 45rpx;
				border-radius: 50%;
				color: #FFFFFF;
				font-weight: 800;
				background-color: #f9290d;
				font-size: 24rpx;
				text-align: center;
				
				
			}
		}

		.one-line3 {
			height: 80rpx;
			width: 3rpx;
			background-color: $uni-line-color-grayA;
			// margin-left: 20rpx;
		}
	}

	.one-line2 {
		height: 40rpx;
		background-color: $uni-line-color-grayA;

	}
</style>
