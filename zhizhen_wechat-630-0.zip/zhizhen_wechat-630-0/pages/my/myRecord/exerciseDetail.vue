<template>
	<view class>
		<view class="newAddEdu-container">
			<view class="base-card">
				<view class="title">公司名称</view>
				<input class="weui-input input-item padding-style" maxlength="20" :value="experciseObj.name "
					data-input-flag="name" @input="bindKeyInput" @blur="blurInput" placeholder-class="input-placeholder"
					placeholder="请输入（必填）">
				<view class="schoolListQuery" v-if="companyListFlag " @touchstart="startOrMoveHandle"
					@touchmove="startOrMoveHandle" @touchend="startOrMoveEndHandle">
					<view v-for="(item,index)   in  companyList " :key="index" :data-company-index="index "
						@tap="schoolTap" class="schoolListItem">{{item.name}}</view>
				</view>
			</view>
			<view class="base-card">
				<view class="title">部门</view>
				<input class="weui-input input-item padding-style" maxlength="20" :value="experciseObj.department "
					data-input-flag="department" @input="bindKeyInput" @blur="blurInput"
					placeholder-class="input-placeholder" placeholder="请输入（选填）">
			</view>
			<view class="base-card">
				<view class="title">职位</view>
				<input class="weui-input input-item padding-style" maxlength="20" :value="experciseObj.position "
					data-input-flag="position" @input="bindKeyInput" @blur="blurInput"
					placeholder-class="input-placeholder" placeholder="请输入（选填）">
			</view>
			<view class="base-card">
				<view class="title">地区</view>
				<view class="section input-item selection-position">
					<view class="arrow-right">
						<view class="iconfont icon-s-xiangyou"></view>
					</view>
					<picker class="select--picker-style" mode="region" @change="bindRegionChange"
						:value="experciseObj.area " :custom-item="customItem ">
						<view class="picker picker-select">
							{{experciseObj.area[0] + experciseObj.area[1] + experciseObj.area[2]}}
						</view>
					</picker>
				</view>
			</view>
			<view class="base-card">
				<view class="title">入职时间</view>
				<view class="section input-item selection-position">
					<view class="arrow-right">
						<view class="iconfont icon-s-xiangyou"></view>
					</view>
					<picker class="select--picker-style" mode="date" :value="experciseObj.start " fields="month"
						start="1980-01" end="2050-12" @change="bindStartDateChange">
						<view class="picker picker-select">{{experciseObj.start}}</view>
					</picker>
				</view>
			</view>
			<view class="base-card">
				<view class="title">离职时间</view>
				<view class="section input-item selection-position">
					<view class="arrow-right">
						<view class="iconfont icon-s-xiangyou"></view>
					</view>
					<view>
							  <!-- :placeholder="'请选择(必填)'" -->
					  <!-- <text style="color: red">选中日期：{{endTime}}</text> -->
					  <pickerDate :fields="'month'" 
					  
					  
					  :selectDate="experciseObj.end" 
				
					   
					   quick @changeDate="onChangeDate"></pickerDate>
					</view>
			<!-- 		<picker class="select--picker-style" mode="date" :value="experciseObj.end" fields="month"
						start="1980-01" :end="end" @change="bindEndDateChange">
						<view class="picker picker-select">
							{{experciseObj.end}}
						</view>
					</picker> -->
				</view>
			</view>
			<view class="base-card">
				<view class="title">说明</view>
				<input class="weui-input input-item padding-style" maxlength="50" :value="experciseObj.describes "
					data-input-flag="describes" @input="bindKeyInput" @blur="blurInput"
					placeholder-class="input-placeholder" placeholder="请输入（选填）">
			</view>
			<view class="saveBtn" @tap="saveexperciseHandle">保 存</view>
		</view>
	</view>
</template>
<script>
	/**
	 * author        cxq
	 * time          2021-6-4 12:59:19
	 * description
	 */

	import {
		mapState
	} from "vuex";
	import pickerDate from "components/my/common/pickerDate.vue"
	export default {
		computed: {
			...mapState(["loginInfoObj"])
		},
		components: {
			pickerDate
		},
		data() {
			return {
				// endTime: '',
				// end: "",
				experciseObj: {
					name: "",
					department: "",
					position: "",
					area: ["请选择", "", ""],
					start: "2015-09",
					end: "",
					describes: ""
				},
				// 编辑/更新标识
				isEditor: false,
				// 是否滑动或者触摸
				startOrMove: false,
				// 公司初始列表
				companyList: [{
						name: "浙江吉利控股集团"
					},
					{
						name: "同盾科技股份有限公司"
					},
					{
						name: "北京慧博云通科技股份有限公司"
					},
					{
						name: "浙江大华科技集团"
					}
				],
				// 公司列表是否显示的最终判断标识
				companyListFlag: false,
				// 事件冲突标识
				eventConflictFlag: false
			};
		},

		/**
		 * 生命周期函数--监听页面加载
		 */
		onLoad: function(options) {
			
			// 查询及新增标识
			if (options && options.obj) {
				var obj = JSON.parse(options.obj);
				console.log("--obj---", obj);
				if (obj.isEditor) {
					uni.setNavigationBarTitle({
						title: "编辑职业履历"
					})
					this.experciseObj = obj.info;
					this.experciseObj.end=this.experciseObj.end.replace('.','-')
					this.experciseObj.start=this.experciseObj.start.replace('.','-')
					this.isEditor = obj.isEditor;
				}

			}
		},

		/**
		 * 生命周期函数--监听页面初次渲染完成
		 */
		onReady: function() {},
		created() {
			this.end=this.$util.todayTime()
			console.log("todayTime==", this.end);
		},

		methods: {
			onChangeDate(newDate) {
				console.log("newDate==", newDate);
		
				 this.experciseObj.end=newDate.date
			},
			// 输入框输入
			bindKeyInput(e) {
				var {
					inputFlag
				} = e.currentTarget.dataset;
				if (inputFlag == "name") {
					if (this.eventConflictFlag == false) {
						(this.experciseObj.name = e.detail.value),
						(this.companyListFlag = true);
						// 发送请求，获取最新的公司列表
						var params = {
							name: e.detail.value
						};

						this.getSelectCompanyList(params)
					}
				}

				if (inputFlag == "department") {
					this.experciseObj.department = e.detail.value;
				}
				if (inputFlag == "position") {
					this.experciseObj.position = e.detail.value;
				}
				if (inputFlag == "describes") {
					this.experciseObj.describes = e.detail.value;
				}
			},


			async getSelectCompanyList(params) {

				const res = await this.$http.getHasLoad(
					"/zxxt/gb/selectCompanyList",
					params
				);

				if (res.code == "success") {
					if (res.data && res.data.length > 0) {
						this.companyList = res.data;
					}
				} else {
					this.eventConflictFlag = false;
				}
			},



			// 地区选择
			bindRegionChange: function(e) {
				console.log("picker发送选择改变，携带值为", e.detail.value);
				this.experciseObj.area = e.detail.value;
			},

			// 开始及结束时间
			bindStartDateChange: function(e) {
				this.experciseObj.start = e.detail.value;
			},

			bindEndDateChange: function(e) {
				this.experciseObj.end = e.detail.value;
			},
			async getRoles() {
				let data = {
					open_id: this.loginInfoObj.open_id
				}
				let res = await this.$http.getNoLoad("/zxxt/askEmploy/lookRoles", data);
				if (res  &&  res.data&& res.data.roleMap) {
					let data = res.data.roleMap
					console.log("roleMap--",data)
					this.$store.commit("submitRole", data);
					uni.navigateBack()

					

				}
			},
			// 保存职业经历的事件
			async saveexperciseHandle(e) {
				// 数据准备
				
			    this.experciseObj.end=this.experciseObj.end?this.experciseObj.end:this.end
				var params = this.experciseObj;
				params.open_id = this.loginInfoObj.open_id;
				if (params.name.trim().length == 0) {
					return uni.showToast({
						title: "请输入公司名称",
						icon: "none",
						duration: 2000
					});
				}



				// 地区处理
				if (params.area.indexOf("请选择") > -1) {
					params.area = "";
				} else {
					// 处理后台节后报错及返回失败问题对area的处理
					if (params.area && params.area.length > 0) {
						if (Array.isArray(params.area)) {
							params.area = params.area.join(",");
						}
					} else {
						params.area = "";
					}
				}
				console.log(params, "----看下保存的参数");

				// 此处先按照新增的请求来写
				// 新增保存的请求
				if (this.isEditor) {
					// 编辑更新
					const res = await this.$http.postHasLoad(
						"/zxxt/user/updateRecord",
						params
					);


					if (res.code == "success") {
						this.$util.toast('保存成功')
						this.getRoles()
					
					}
				} else {
					// 新增

					const res = await this.$http.postHasLoad(
						"/zxxt/user/addRecord",
						params
					);
					if (res.code == "success") {
						
						this.$util.toast('保存成功')
						this.getRoles()
						
					}
				}
			},

			// 处理公司列表显示问题start
			blurInput: function(e) {
				var {
					inputFlag
				} = e.currentTarget.dataset;
				console.log(this.startOrMove, "startOrMove");
				if (inputFlag == "name" && this.startOrMove != true) {
					this.companyListFlag = false;
				}
			},

			startOrMoveHandle: function() {
				this.startOrMove = true;
				console.log(this.startOrMove, "滑动或者触摸的是");
			},

			startOrMoveEndHandle: function() {
				this.startOrMove = false;
			},

			// 点击某一项查询出来的公司列表并输入到input中
			schoolTap: function(e) {
				var {
					companyIndex
				} = e.currentTarget.dataset;

				if (this.companyList && this.companyList.length > 0) {
					this.experciseObj.name = this.companyList[companyIndex].name
					this.companyListFlag = false
					this.eventConflictFlag = true
				}
			}

			// 处理学校列表显示问题end
		}
	};
</script>

<style lang="scss" scoped>
	.newAddEdu-container {
		padding: 20px 12px;
		color: rgba(153, 153, 153, 100);
		font-size: 16px;
	}

	.base-card {
		position: relative;
		width: 100%;
		height: 88px;
	}

	.title {
		font-size: 12px;
		color: rgba(153, 153, 153, 100);
	}

	.input-item {
		position: relative;
		height: 32px;
		border-bottom: 1px solid #f6f6f6;
		padding: 10px 0;
		outline: none;
		color: #333;
	}

	.weui-cell {
		padding-left: 0 !important;
	}

	.weui-cell::before {
		border-top: 1px solid transparent !important;
	}

	.arrow-right {
		position: absolute;
		right: 0;
		top: 12px;
	}

	.arrow-right image {
		width: 20px;
		height: 20px;
	}

	.content-style {
		font-size: 16px;
		color: rgba(153, 153, 153, 100);
		font-family: PingFangSC-Regular;
	}

	.saveBtn {
		width: 98%;
		text-align: center;
		line-height: 88rpx;
		margin: 0 auto;
		border-radius: 8px;
		color: #ffffff;
		background-color: $uni-color-active;

	}

	.schoolListQuery {
		position: absolute;
		left: 0;
		top: 76px;
		width: 92%;
		height: 114px;
		font-size: 14px;
		z-index: 9;
		background-color: #fff;
		border: 1px solid #f6f6f6;
		color: rgb(180, 176, 176);
		border-radius: 8px;
		padding: 6px 16px 16px 6px;
		overflow-y: scroll;
	}

	.schoolListItem {
		padding: 6px 0 6px 6px;
		border-bottom: 1px solid #f6f6f6;
	}
</style>
