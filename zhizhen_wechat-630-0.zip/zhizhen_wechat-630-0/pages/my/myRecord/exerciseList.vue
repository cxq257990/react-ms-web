<template>
	<view class="">
		<view class="exe-container">
			<!-- 教育履历列表 -->
			<van-swipe-cell right-width="65 " v-for="  (item,index) in exeList " :data-index="  item.id" :key="index"
				@click="onClick">
				<view class="edu-card" @tap="jumpToEdit" :data-exeinfo="item">
					<view class="scholl-time">
						<view class="left">{{ item.name }}</view>
						<view class="right">
							<view>{{ item.start }}</view>
							<view>-</view>
							<view>{{ item.end }}</view>
							<view class="iconfont icon-s-xiangyou"></view>
						</view>
					</view>
					<view class="major">
						<view class="item-department">{{ item.department }}</view>
						<view v-if="item.department && item.position " class="line">|</view>
						<view class="item-position">{{ item.position }}</view>
					</view>
				</view>
				<view slot="right" class="delete-edu">删除</view>
			</van-swipe-cell>

			<!-- 暂无数据展示 -->
			<view v-if="exeList.length == 0 " class="nodata">暂无职业履历</view>
			<!-- 添加履历按钮 -->
			<view class="btn-box">
				<view class="add-new" @tap="addNewInfo">添加履历</view>
			</view>
		</view>


	</view>
</template>

<script>
	/**
	 * author        cxq
	 * time          2021-6-5 23:50:58
	 * description   
	 */
	import {
		mapState
	} from "vuex";



	export default {
		computed: {
			...mapState(['loginInfoObj'])
		},
		data() {
			return {
				exeList: [],
				startTimeMax: '',
				end: ''


			}
		},
	created() {
			this.end=this.$util.todayTime()
			console.log("todayTime==", this.end);
		},
		/**
		 * 生命周期函数--监听页面加载
		 */
		onLoad: function(options) {
			// 获取openId存储到状态中
			// 获取用户个人履历信息
			this.getPersonExercise()
		},
		/**
		 * 生命周期函数--监听页面显示
		 */
		onShow: function() {
			this.getPersonExercise()
		},
		methods: {
			// 个人履历查询
			async getPersonExercise() {
				var params = {
					openId: this.loginInfoObj.open_id
				}
				const res = await this.$http.getHasLoad('/zxxt/user/listRecord', params);
				this.resToData(res)
			},

			resToData(res) {
				if (res && res.code == 'success' && res.data) {
					let data = res.data
					console.log("---res--", data)

			
					this.exeList = data.map((item, index, arr) => {
		               let start= item.start.replace('-', '.')
						let end= item.end.replace('-', '.')
						return {
							del_flag: item.del_flag,
							department: item.department,
							id: item.id,
							name: item.name,
							open_id: item.open_id,
							position: item.position,
							describes: item.describes,
							area: item.area ? item.area.split(',') : '请选择,,'.split(','), //area: "北京市,customItem,customItem"
							start: start ? start : '2015.09',
							end: end ? end :this.end,
							department_fellow: item.department_fellow ? item.department_fellow : '',

						}



					})
                     

				
				}
			},
			
			

			// 删除个人经历
			async deleteExe(id) {
				const res = await this.$http.postHasLoad('/zxxt/user/deleteRecord?id=' + id + "&openId=" + '');
				if (res.code == 'success') {
					uni.showToast({
						title: '删除成功',
						icon: 'none',
						duration: 2000
					})
					this.getPersonExercise()
				}
			},

			// 删除经历弹窗
			onClick(event) {
				var _this = this
				var id = event.target.dataset.index
				if (event.detail == 'right') {
					uni.showModal({
						title: '提示',
						content: '确定删除吗？',
						success(res) {
							if (res.confirm) {
								console.log('用户点击确定')
								_this.deleteExe(id)
							} else if (res.cancel) {
								console.log('用户点击取消')
							}
						}
					})
				}
			},

			jumpToEdit: function(e) {
				console.log("--jumpToEdit--", e.currentTarget.dataset.exeinfo)
				let obj = {
					isEditor: true,
					info: e.currentTarget.dataset.exeinfo
				}
				uni.navigateTo({
					url: '/pages/my/myRecord/exerciseDetail?obj=' + JSON.stringify(obj)
				})

			},

			// 点击新增履历（实际是页面的跳转）
			addNewInfo: function() {

				let obj = {}
				uni.navigateTo({
					url: '/pages/my/myRecord/exerciseDetail?obj=' + JSON.stringify(obj)
				})


			}
		}

	}
</script>

<style lang="scss" scoped>
	page {
		width: 100%;
		padding-bottom: 60px;
	}

	.exe-container {
		padding: 12px;
		padding-top: 20px;
		font-size: 14px;
		color: rgba(153, 153, 153, 100);
		font-family: PingFangSC-Regular;
	}

	.edu-card {
		height: 88px;
		padding: 12px 0;
		border-bottom: 1px solid #f6f6f6;
	}

	.scholl-time {
		display: flex;
		justify-content: space-between;
		margin-bottom: 14px;
	}

	.scholl-time .left {
		width: 60%;
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
		font-size: 18px;
		color: #333;
		font-weight: 700;
	}

	.scholl-time .right {
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}

	.scholl-time .right image {
		width: 20px;
		height: 20px;
	}

	.major {
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}

	.item-department,
	.item-position {
		max-width: 80px;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}

	.major .line {
		margin: 0 10px;
	}

	.delete-edu {
		display: flex;
		justify-content: center;
		align-items: center;
		width: 200%;
		height: 100%;
		color: #fff;
		font-size: 16px;
		background-color: #F15757;
	}

	.btn-box {
		width: 100%;
		position: fixed;
		bottom: 0;
		left: 0;
		display: flex;
		justify-content: center;
		align-items: center;
		background-color: #fff;
		height: 60px;
	}

	.add-new {
		width: 92%;
		height: 42px;
		text-align: center;
		line-height: 42px;
		font-size: 16px;
		font-weight: 700;
		color: #fff;
		border-radius: 4px;
		background-color: rgba(70, 162, 137, 1);
		margin: 0 auto;
	}

	.nodata {
		text-align: center;
		margin: 88px 0;
		font-size: 16px;
	}
</style>
