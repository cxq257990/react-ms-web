<template>
	<view class="">
		<view class="edu-container">
			<!-- 教育履历列表 -->
			<van-swipe-cell right-width="65 " v-for="  (item,index) in   eduList " :data-index="item.id" :key="index"
				@click="onClick">
				<view class="edu-card" @tap="jumpToEdit" :data-eduinfo="item">
					<view class="scholl-time">
						<view class="left">{{ item.school_name }}</view>
						<view class="right">
							<view>{{ item.begin_time }}</view>
							<view>-</view>
							<view>{{ item.end_time }}</view>
							
							<view class="iconfont icon-s-xiangyou" ></view>
						</view>
					</view>
					<view class="major">
						<view class="item-education">{{ item.education }}</view>
						<view class="line">|</view>
						<view class="item-major">{{ item.major }}</view>
					</view>
				</view>
				<view slot="right" class="delete-edu">删除</view>
			</van-swipe-cell>

			<!-- 暂无数据展示 -->
			<view v-if="   eduList.length == 0 " class="nodata">暂无教育履历</view>
			<!-- 添加履历按钮 -->
			<view class="btn-box">
				<view class="add-new" @tap="addNewEdu">添加履历</view>
			</view>
		</view>

	</view>
</template>

<script>
	/**
	 * author        cxq
	 * time          2021-6-6 00:04:41
	 * description   
	 */

import {
		mapState
	} from "vuex";



	export default {
		computed: {
			...mapState(['loginInfoObj'])
		},
		data() {
			return {
				eduList: [],
			}
		},

		/**
		 * 生命周期函数--监听页面加载
		 */
		onLoad: function(options) {
			// 获取openId存储到状态中
			// 获取用户个人履历信息
			this.getList()
		},



		/**
		 * 生命周期函数--监听页面显示
		 */
		onShow: function() {
			this.getList()
		},

		methods: {
			// 个人履历查询
			async getList() {
				var params = {
					openId: this.loginInfoObj.open_id,
				}
				const res = await this.$http.getHasLoad('/zxxt/edu/myList', params);
				
				if (res && res.code == 'success' && res.data &&res.data.length ) {
					var data = res.data
					console.log("---res2--", data)
				
					this.eduList = data.map((item, index, arr) => {
						let begin_time= item.begin_time.replace('-', '.')
						let end_time= item.end_time.replace('-', '.')
						console.log("end_time", end_time)
						return {  
						
							education:item.education?item.education: '请选择',
							school_name:item.school_name?item.school_name: '',	
							used_name:item.used_name?item.used_name: ''	,
							faculty:item.faculty?item.faculty: '',	
							major:item.major?item.major: ''	,
							grade:item.grade?item.grade: ''	,
							area:  item.area?item.area.split(','):["请选择（选填）", "", ""],//'请选择,,'.split(',')
							begin_time:begin_time?begin_time:'2015.09',
							end_time: end_time?end_time: '至今',
							
							evaluate_id:item.evaluate_id?item.evaluate_id: '',
							id:item.id?item.id: '',
							open_id:item.open_id?item.open_id: '',
							school_type:item.school_type?item.school_type: ''
					
								
						}
						})
						}
			},

			// 删除个人经历
			async deleteInfo(id) {
				
				const res = await this.$http.postHasLoad('/zxxt/edu/deleteEducationMsg?id='+id);
				if (res.code == 'success') {
					uni.showToast({
						title: '删除成功',
						icon: 'none',
						duration: 2000
					})
					this.getList()
				}
			},

			// 删除教育经历弹窗
			onClick(event) {
				var _this = this
				var id = event.target.dataset.index
				console.log('------2',id)
				if (event.detail == 'right') {
					uni.showModal({
						title: '提示',
						content: '确定删除吗？',
						success(res) {
							if (res.confirm) {
								console.log('用户点击确定')
								_this.deleteInfo(id)
							} else if (res.cancel) {
								console.log('用户点击取消')
							}
						}
					})
				}
			},

			jumpToEdit: function(e) {
				console.log("--jumpToEdit--", e.currentTarget.dataset.eduinfo)
				let obj = {
							isEditor : true,
							info:e.currentTarget.dataset.eduinfo
						}
					uni.navigateTo({
						
					url:'/pages/my/myRecord/eduDetail?obj='+ JSON.stringify(obj)
					})
				           	
				
				
			
			},

			// 点击新增履历（实际是页面的跳转）
			addNewEdu: function() {
				let obj = {
						
						}
					uni.navigateTo({
					url:'/pages/my/myRecord/eduDetail?obj='+JSON.stringify(obj)
					})
           	
				
			
		}
		}

	}
</script>

<style lang="scss" scoped>
	page {
		width: 100%;
		padding-bottom: 60px;
	}

	.edu-container {
		padding: 12px;
		padding-top: 20px;
		font-size: 14px;
		color: rgba(153, 153, 153, 100);
		font-family: PingFangSC-Regular;
	}

	.edu-card {
		height: 88px;
		padding: 12px 0;
		border-bottom: 1px solid #f6f6f6;
	}

	.scholl-time {
		display: flex;
		justify-content: space-between;
		margin-bottom: 14px;
	}

	.scholl-time .left {
		width: 60%;
		white-space: nowrap;
		overflow: hidden;
		text-overflow: ellipsis;
		font-size: 18px;
		color: #333;
		font-weight: 700;
	}

	.scholl-time .right {
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}

	.scholl-time .right image {
		width: 20px;
		height: 20px;
	}

	.major {
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}

	.major .line {
		margin: 0 10px;
	}

	.delete-edu {
		display: flex;
		justify-content: center;
		align-items: center;
		width: 200%;
		height: 100%;
		color: #fff;
		font-size: 16px;
		background-color: #F15757;
	}

	.btn-box {
		width: 100%;
		position: fixed;
		bottom: 0;
		left: 0;
		display: flex;
		justify-content: center;
		align-items: center;
		background-color: #fff;
		height: 60px;
	}

	.add-new {
		width: 92%;
		height: 42px;
		text-align: center;
		line-height: 42px;
		font-size: 16px;
		font-weight: 700;
		color: #fff;
		border-radius: 4px;
		background-color: rgba(70, 162, 137, 1);
		margin: 0 auto;
	}

	.nodata {
		text-align: center;
		margin: 88px 0;
		font-size: 16px;
	}

	.item-education,
	.item-major {
		max-width: 80px;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}
</style>
