<template>
  <view class>
    <view class="newAddEdu-container">
      <view class="base-card">
        <view class="title">学历层次</view>
        <view class="weui-cell weui-cell_active weui-cell_select-after input-item">
          <view class="arrow-right">
            <view class="iconfont icon-s-xiangyou"></view>
          </view>
          <!-- v-if="eduinfoObj.length" -->
          <view class="weui-cell__bd">
            <picker @change="bindPickerChange" :value="stindex" :range="starray">
              <view class="weui-select content-style">{{eduinfoObj.education?eduinfoObj.education:"请选择"}}</view>
            </picker>
          </view>
        </view>
      </view>
      <view class="base-card">
        <view class="title">学校名称</view>
        <input
          class="weui-input input-item padding-style"
          maxlength="20"
          :value="eduinfoObj.school_name"
          data-input-flag="school_name"
          @input="bindKeyInput"
          @blur="blurInput"
          placeholder-class="input-placeholder"
          placeholder="请输入（必填）"
        >
        <view
          class="schoolListQuery"
          v-if="schoolListFlag"
          @touchstart="startOrMoveHandle"
          @touchmove="startOrMoveHandle"
          @touchend="startOrMoveEndHandle"
        >
          <view
            v-for=" (item,index) in schoolList"
            :key="index"
            :data-school-index="index"
            @tap="schoolTap
					"
            class="schoolListItem"
          >{{item.name}}</view>
        </view>
      </view>
      <view class="base-card">
        <view class="title">学校曾用名</view>
        <input
          class="weui-input input-item padding-style"
          maxlength="20"
          :value="eduinfoObj.used_name"
          data-input-flag="used_name"
          @input="bindKeyInput"
          @blur="blurInput"
          placeholder-class="input-placeholder"
          placeholder="请输入（选填）"
        >
      </view>
      <view class="base-card">
        <view class="title">院系</view>
        <input
          class="weui-input input-item padding-style"
          maxlength="20"
          :value="eduinfoObj.faculty"
          data-input-flag="faculty"
          @input="bindKeyInput"
          @blur="blurInput"
          placeholder-class="input-placeholder"
          placeholder="请输入（选填）"
        >
      </view>
      <view class="base-card">
        <view class="title">专业</view>
        <input
          class="weui-input input-item padding-style"
          maxlength="20"
          :value="eduinfoObj.major"
          data-input-flag="major"
          @input="bindKeyInput"
          @blur="blurInput"
          placeholder-class="input-placeholder"
          placeholder="请输入（必填）"
        >
      </view>
      <view class="base-card">
        <view class="title">班级</view>
        <input
          class="weui-input input-item padding-style"
          maxlength="20"
          :value="eduinfoObj.grade"
          data-input-flag="grade"
          @input="bindKeyInput"
          @blur="blurInput"
          placeholder-class="input-placeholder"
          placeholder="请输入（选填）"
        >
      </view>
      <view class="base-card">
        <view class="title">地区</view>
        <view class="section input-item selection-position">
          <view class="arrow-right">
            <view class="iconfont icon-s-xiangyou"></view>
          </view>
          <picker
            class="select--picker-style"
            mode="region"
            @change="bindRegionChange"
            :value="eduinfoObj.area"
            :custom-item="customItem"
          >
            <view
              class="picker picker-select"
            >{{eduinfoObj.area[0] + eduinfoObj.area[1] + eduinfoObj.area[2]}}</view>
          </picker>
        </view>
      </view>
      <view class="base-card">
        <view class="title">入学时间</view>
        <view class="section input-item selection-position">
          <view class="arrow-right">
            <view class="iconfont icon-s-xiangyou"></view>
          </view>
          <picker
            class="select--picker-style"
            mode="date"
            :value="eduinfoObj.begin_time"
            fields="month"
            start="1980-01"
            end="2050-12"
            @change="bindStartDateChange"
          >
            <view class="picker picker-select">{{eduinfoObj.begin_time}}</view>
          </picker>
        </view>
      </view>
      <view class="base-card">
        <view class="title">毕业时间</view>
        <view class="section input-item selection-position">
          <view class="arrow-right">
            <view class="iconfont icon-s-xiangyou"></view>
          </view>
          <picker
            class="select--picker-style"
            mode="date"
            :value="eduinfoObj.end_time"
            fields="month"
            start="1980-01"
            end="2031-12"
            @change="bindEndDateChange"
          >
            <view class="picker picker-select">
              <!-- {{date}} -->
              {{eduinfoObj.end_time}}
            </view>
          </picker>
        </view>
      </view>
      <view class="saveBtn" @tap="saveexperciseHandle">保 存</view>
    </view>
  </view>
</template>
<script>
/**
 * author        cxq
 * time          2021-6-5 23:36:33
 * description
 */

import { mapState } from "vuex";

export default {
  computed: {
    ...mapState(["loginInfoObj"])
  },
  data() {
    return {
      starray: ["请选择", "博士", "硕士", "本科", "专科", "其他"],
      stindex: 0,
      eduinfoObj: {
        education: "请选择（必填）",
        school_name: "",
        used_name: "",
        faculty: "",
        major: "",
        grade: "",
        area: ["请选择（选填）", "", ""],
        begin_time: "2015-09",
        end_time: "至今"
      },
      // 编辑/更新标识
      isEditor: false,
      // 是否滑动或者触摸
      startOrMove: false,
      // 学校初始列表
      schoolList: [
        {
          name: "浙江大学"
        },
        {
          name: "浙江理工大学"
        },
        {
          name: "同济大学浙江学院"
        },
        {
          name: "浙江科技学院"
        },
        {
          name: "上海财经大学浙江学院"
        }
      ],
      // 学校列表是否显示的最终判断标识
      schoolListFlag: false,
      // 事件冲突标识
      eventConflictFlag: false
    };
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    if (options && options.obj) {
      var obj = JSON.parse(options.obj);
      console.log("--obj---", obj);
	  if(obj.isEditor){
	  		 uni.setNavigationBarTitle({
	  		   	title:"编辑教育履历"
	  		   })
	  		 this.eduinfoObj = obj.info;
			 this.eduinfoObj.end_time=this.eduinfoObj.end_time.replace('.','-')
			 this.eduinfoObj.begin_time=this.eduinfoObj.begin_time.replace('.','-')
	  		 this.isEditor = obj.isEditor;
	  }
		 
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {},
  methods: {
    // 学历层次选择
    bindPickerChange: function(e) {
      console.log("picker发送选择改变，携带值为", e.detail.value);
      if (this.starray[e.detail.value] == "请选择") {
        (this.eduinfoObj.education = ""), (this.stindex = e.detail.value);
      } else {
        (this.eduinfoObj.education = this.starray[e.detail.value]),
          (this.stindex = e.detail.value);
      }
    },
	
	  // 获取搜索数据的功能函数
	  async getSearchList(params) {
		const res = await this.$http.getHasLoad(
		  "/zxxt/gb/selectSchoolName",
		  params
		);
		if (res.code == "success") {
		  if (res.data && res.data.length > 0) {
		    this.schoolList = res.data;
		  }
		  this.eventConflictFlag = false;
		}
	 
	  },
	 
    // 输入框输入
     bindKeyInput(e) {
      var { inputFlag } = e.currentTarget.dataset;
      if (inputFlag == "school_name") {
        if (this.eventConflictFlag == false) {
          this.eduinfoObj.school_name = e.detail.value;
          this.schoolListFlag = true;
          // 发送请求，获取最新的学校列表
          var params = {
            name: e.detail.value
          };
		  
		  this.getSearchList(params)
       
      }
      }
      if (inputFlag == "used_name") {
        this.eduinfoObj.used_name = e.detail.value;
      }
      if (inputFlag == "faculty") {
        this.eduinfoObj.faculty = e.detail.value;
      }
      if (inputFlag == "major") {
        this.eduinfoObj.major = e.detail.value;
      }
      if (inputFlag == "grade") {
        this.eduinfoObj.grade = e.detail.value;
      }
    },
	
	

    // 地区选择
    bindRegionChange: function(e) {
      console.log("picker发送选择改变，携带值为", e.detail.value);
      this.eduinfoObj.area = e.detail.value;
    },

    // 开始及结束时间
    bindStartDateChange: function(e) {
      this.eduinfoObj.begin_time = e.detail.value;
    },

    bindEndDateChange: function(e) {
      this.eduinfoObj.end_time = e.detail.value;
    },

    // 保存教育经历的事件
    async saveexperciseHandle(e) {
      // 数据准备
      var params = this.eduinfoObj;
      params.open_id = this.loginInfoObj.open_id;
      if (params.school_name.trim().length == 0) {
        return uni.showToast({
          title: "请输入学校名称",
          icon: "none",
          duration: 2000
        });
      }
      if (params.major.trim().length == 0) {
        return uni.showToast({
          title: "请输入专业",
          icon: "none",
          duration: 2000
        });
      }
      // 学历层次处理
      if (params.education == "请选择（必填）") {
        params.education = "";
      }
      // 地区处理
      if (params.area.indexOf("请选择") > -1) {
        params.area = "";
      } else {
        // 处理后台节后报错及返回失败问题对area的处理
        if (params.area && params.area.length > 0) {
          if (Array.isArray(params.area)) {
            params.area = params.area.join(",");
          }
        } else {
          params.area = "";
        }
      }
      console.log(params, "看下保存的参数");

      // 此处先按照新增的请求来写
      // 新增保存的请求
      if (this.isEditor) {
        // 编辑更新
        const res = await this.$http.postHasLoad("/zxxt/edu/updateEdu", params);
		
        if (res.code == "success") {
			
			this.$util.toast('保存成功')
			uni.navigateBack()
			// uni.switchTab({
			//                url: '/pages/my/myIndex',
			//              })
								
			
          
        }
      } else {
        // 新增
        const res = await this.$http.postHasLoad("/zxxt/edu/addEdu", params);
        if (res.code == "success") {
			
			this.$util.toast('保存成功')
			
			uni.navigateBack()
			// uni.navigateTo({
			//   url: "/pages/my/myRecord/eduList"
			// });
			
		
			// uni.switchTab({
			//   url: "/pages/my/myIndex"
			// });
        
        }
      }
    },

    // 处理学校列表显示问题start
    blurInput(e) {
      var { inputFlag } = e.currentTarget.dataset;
      console.log(this.startOrMove, "this.startOrMove");
      if (inputFlag == "school_name" && this.startOrMove != true) {
        this.schoolListFlag = false;
      }
    },

    startOrMoveHandle: function() {
      this.startOrMove = true;
      console.log(this.startOrMove, "滑动或者触摸的是");
    },

    startOrMoveEndHandle: function() {
      this.startOrMove = false;
    },

    // 点击某一项查询出来的公司列表并输入到input中
    schoolTap: function(e) {
      var { schoolIndex } = e.currentTarget.dataset;
      console.log(schoolIndex, "schoolIndex");
      if (this.schoolList && this.schoolList.length > 0) {
		  	this.eventConflictFlag = true
			this.schoolListFlag = false
        this.$set(
          this.eduinfoObj,
          "school_name",
          this.schoolList[schoolIndex].name
        )
	
      }
    }

    // 处理学校列表显示问题end
  }
};
</script>

<style lang="scss" scoped>
.newAddEdu-container {
  padding: 20px 12px;
  color: rgba(153, 153, 153, 100);
  font-size: 16px;
}

.base-card {
  position: relative;
  width: 100%;
  height: 88px;
}

.title {
  font-size: 12px;
  color: rgba(153, 153, 153, 100);
}

.input-item {
  position: relative;
  height: 32px;
  border-bottom: 1px solid #f6f6f6;
  padding: 10px 0;
  outline: none;
  color: #333;
}

.weui-cell {
  padding-left: 0 !important;
}

.weui-cell::before {
  border-top: 1px solid transparent !important;
}

.arrow-right {
  position: absolute;
  right: 0;
  top: 12px;
}

.arrow-right image {
  width: 20px;
  height: 20px;
}

.content-style {
  font-size: 16px;
  color: rgba(153, 153, 153, 100);
  font-family: PingFangSC-Regular;
}

.saveBtn {
 width: 98%;
 text-align: center;
 line-height: 88rpx;
 margin: 0 auto;
 border-radius: 8px;
 color:#ffffff;
  background-color: $uni-color-active;
}

.schoolListQuery {
  position: absolute;
  left: 0;
  top: 76px;
  width: 92%;
  height: 114px;
  font-size: 14px;
  z-index: 9;
  background-color: #fff;
  border: 1px solid #f6f6f6;
  color: rgb(180, 176, 176);
  border-radius: 8px;
  padding: 6px 16px 16px 6px;
  overflow-y: scroll;
}

.schoolListItem {
  padding: 6px 0 6px 6px;
  border-bottom: 1px solid #f6f6f6;
}
</style>
