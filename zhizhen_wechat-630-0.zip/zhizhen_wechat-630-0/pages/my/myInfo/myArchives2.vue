<template>
	<view class="myArchives">
		<!-- =========================top============================================== -->
		<view class="top-box">
			<view class="one"></view>
			<view class="two">
				<view class="img-box">
					<!-- 0:申请中，1：同意=已经是好友，2：添加 -->
					<view v-if="1" class="img-box-right">
					<!-- <view v-if="source==1  &&  !isMyShare" class="img-box-right"> -->
							<view v-if="0" class="box" class="iconfont icon-tianjiahaoyou1 icon-addf"></view>
							<!-- <view v-if="userBaseInfo.states == 1" class="box" class="iconfont icon-tianjiahaoyou1 icon-addf"></view> -->
							<view   v-else-if="1" class="box" class="iconfont icon-jiahaoyouzhong icon-addf"></view>
							<!-- <view   v-else-if="userBaseInfo.states == 0 ||hasadd" class="box" class="iconfont icon-jiahaoyouzhong icon-addf"></view> -->
							<view v-else class="box" @tap="addThisfriend(userBaseInfo)" class="iconfont icon-jiahaoyou1 icon-addf"></view>
					</view>


					<image mode="" class="image" :src="userBaseInfo.avatar">
						<image>
				</view>
				<view class="text">
					<text class="name">{{userBaseInfo.user_name}}</text>
					<text class="work">{{userBaseInfo.address}}</text>
				</view>
			</view>
		</view>
		<view class="one-line1"></view>
		<!-- ==================================基本信息============================================= -->
		<view class=" deep-title ">
			<van-cell border="false" title="基本信息">
				<template v-if="!otheropenId">
					<navigator slot="right-icon" url="./myBaseInfo">
						<view class="btn iconfont icon-s-bianji"></view>
					</navigator>

				</template>

			</van-cell>
		</view>
		<view class="base-info-box">
			<view class="text name">
				<van-row>
					<van-col span="23"> 姓 名：{{userBaseInfo.user_name}}</van-col>
				</van-row>
			</view>
			<view class="text ">
				<van-row>
					<van-col span="23"> 曾用名：{{userBaseInfo.oldName}}</van-col>
				</van-row>
			</view>
			<view class="text">
				<van-row>
					<van-col span="23"> 性 别：{{userBaseInfo.sex}}</van-col>
				</van-row>
			</view>
			<view class="text">
				<van-row>
					<van-col span="23"> 出生年月：{{userBaseInfo.birthDate}}</van-col>
				</van-row>
			</view>
			<view class="text">
				<van-row>
					<van-col span="23"> 地 区：{{userBaseInfo.address}}</van-col>
				</van-row>
			</view>

			<view class="text">
				<van-row>
					<van-col span="23"> 手 机：{{userBaseInfo.phone}}</van-col>
				</van-row>
			</view>
			<view class="text">
				<van-row>
					<van-col span="23"> 邮 箱：{{userBaseInfo.email}}</van-col>
				</van-row>
			</view>
		</view>
		<view class="one-line2"></view>
		<!-- =========================职业履历======================================= -->
		<vNoContent :List="workRecord" :title="'职业履历'">
			<view slot="contentItems">
				<view class="box-padding-right">
					<view class="deep-title">
						<van-cell border="false" title="职业履历">
							<view v-if="!otheropenId" slot="right-icon" class="">
								<navigator url="/pages/my/myRecord/exerciseDetail">
									<view class=" btn iconfont icon-s-tianjia"></view>
								</navigator>
							</view>
						</van-cell>
					</view>
					<vWorkRecordItem :isShowEdit="otheropenId?false:true" @jumpEdit="jumpEditExeinfo"
						:info="workRecord"> </vWorkRecordItem>
				</view>


			</view>

		</vNoContent>
		<!-- =========================教育履历======================================= -->

		<vNoContent :List="eduRecord" :title="'教育履历'">
			<view slot="contentItems">
				<view class="box-padding-right">
					<view class="deep-title">
						<van-cell border="false" title="教育履历">
							<view v-if="!otheropenId" @tap="addNewEdu" class="btn iconfont icon-s-tianjia"
								slot="right-icon">
							</view>
						</van-cell>

					</view>
					<vWorkRecordItem :isShowEdit="otheropenId?false:true" @jumpEdit="jumpEditEduinfo" :info="eduRecord"
						:isWork="false"> </vWorkRecordItem>
				</view>

			</view>

		</vNoContent>
		<!-- ========================推荐信========================-->
		<vNoContent :List="recommendations" :title="'推荐信'">
			<view slot="contentItems">
				<van-collapse border="false" :value="showMoreLetterRecommend" @change="onChangeLetterRecommend">
					<view class="box-padding-right recommendations-box">
						<van-collapse-item :is-link="isNotOneRecommendations" border="false" name="1">
							<view class="collapse-title" slot="title">推荐信</view>
							<view slot="value" v-if="isNotOneRecommendations">展开{{recommendations.length}}条</view>
							<template v-for="  (item,index)  in recommendations" v-if="isNotOneRecommendations">
								<view :key="index" class="">
									<vHeadTitle   :avatarOpenIdType="'letter_open_id'"  :obj="item"></vHeadTitle>
									<vMyCommentItem :obj="item" :hasOneLine="true"></vMyCommentItem>
								</view>
							</template>
						</van-collapse-item>
					</view>
				</van-collapse>
				<template v-if="showMoreLetterRecommend.length==0 && recommendations.length>0 ">
					<view class="justOne-item-box">
						<vHeadTitle  :avatarOpenIdType="'letter_open_id'"  :obj="recommendations[0]"></vHeadTitle>
						<vMyCommentItem :obj="recommendations[0]" :hasOneLine="true"></vMyCommentItem>
					</view>
				</template>

			</view>

		</vNoContent>



		<!--================================好友点评========================-->

		<vNoContent :List="beCommentedInfos" :title="'好友点评'">
			<view slot="contentItems">
				<van-collapse border="false" :value="showMoreBeCommentedInfos" @change="onChangeBeCommentedInfos">
					<view class="box-padding-right beCommentedInfos-box">
						<van-collapse-item border="false" :is-link="isNotOneBeCommentedInfos" name="1">
							<view class="collapse-title" slot="title">好友点评</view>
							<view slot="value" v-if="isNotOneBeCommentedInfos">展开{{beCommentedInfos.length}}条
							</view>
							<template v-for="  (item,index)  in beCommentedInfos" v-if="isNotOneBeCommentedInfos">
								<view :key="index" class="">

									<vHeadTitle :obj="item"></vHeadTitle>
									<vMyCommentItem :hasOneLine="true" :obj="item"></vMyCommentItem>
								</view>
							</template>
						</van-collapse-item>

					</view>
				</van-collapse>
				<template v-if="showMoreBeCommentedInfos.length==0  &&beCommentedInfos.length>0">
					<view class="justOne-item-box">
						<vHeadTitle :obj="beCommentedInfos[0]"></vHeadTitle>
						<vMyCommentItem :hasOneLine="true" :obj="beCommentedInfos[0]"></vMyCommentItem>
					</view>
				</template>

			</view>
		</vNoContent>
		<!-- ===================好友印象===================================== -->

		<vNoContent :List="friendImpression" :title="'好友印象'">
			<view slot="contentItems">
				<template>

					<view class="  deep-title">
						<van-cell border="false" title="好友印象">
						</van-cell>
					</view>
					<view class="friend-impression-box">
						<template v-for="(i,k) in friendImpression ">
							<view :key="k" class="friend-impression">
								<view v-if="i.labels"
									:style="'border:2px solid rgba('+i.colour+',0.1);color:rgb('+i.colour+');'	"
									class="btn">
									{{i.labels}}
								</view>
							</view>
						</template>
					</view>


				</template>
			</view>
		</vNoContent>



		<!-- ========================好友评分=========================== -->


		<vNoContent :List="friendScore" :title="'好友评分'">
			<view slot="contentItems">

				<view class="FriendScore-box ">
					<van-collapse :value="showMoreFriendScore" @change="onChangeFriendScore">
						<van-collapse-item :is-link="isNotOneFriendScore" name="1">
							<view class="collapse-title " border="false" slot="title">好友评分
							</view>
							<view slot="value" v-if="isNotOneFriendScore">展开{{friendScore.length}}条</view>
							<template v-for="(item,k) in friendScore" v-if="isNotOneFriendScore">
								<view :key="k">

									<view class="content-box">
										<vHeadTitle :obj="item" class="left"></vHeadTitle>
										<view class="one-line6"> </view>
										<view class="right">
											<view class="one">{{item.scoreNum}}</view>
											<view class="two">综合评分</view>
										</view>
									</view>
									<view class="one-line3"></view>
								</view>
							</template>
						</van-collapse-item>
					</van-collapse>
					<template v-if="friendScore.length && showMoreFriendScore.length==0">
						<view class="justOne-item-box">
							<view class="content-box">
								<vHeadTitle :obj="friendScore[0]" class="left"></vHeadTitle>
								<view class="one-line6"> </view>
								<view class="right">
									<view class="one">{{friendScore[0].scoreNum}}</view>
									<view class="two">综合评分</view>
								</view>
							</view>

						</view>
						<view class="one-line4"></view>
					</template>
				</view>

			</view>
		</vNoContent>
	</view>
</template>

<script>
	/**
	 * author        cxq
	 * time          2021-5-27 23:00:20
	 * description   
	 */
	import {
		mapState
	} from "vuex";


	import vNoResult from "components/common/vNoResult.vue"
	import vMyCommentItem from "components/my/myNews/vMyCommentItem.vue"
	import vHeadTitle from "components/my/common/vHeadTitle.vue"
	import vNoContent from "components/my/common/vNoContent.vue"
	import vWorkRecordItem from "components/my/myInfo/vWorkRecordItem"

	export default {
		computed: {
			...mapState(['loginInfoObj'])
		},
		components: {
			vWorkRecordItem,
			vHeadTitle,
			vMyCommentItem,
			vNoResult,
			vNoContent
		},
		data() {
			return {

				activeNames: [],
				eduList: [],
				userBaseInfo: {
					birthDate: "--",
					sex: "",
					user_name: "--",
					oldName: "",
					phone: "",
					states: "",
					schoolName: "",
					position_name: "",
					email: "",
					avatar: this.$defaultHeadimg,
					address: "",
				},
				source: 0,
				onShowNum: 0,
				otheropenId: '', //打开别人分享的档案时，别人的openid
				myopenid: '', //
				isMyShare: true, //
				isNotOneFriendScore: false,
				isNotOneBeCommentedInfos: false,
				isNotOneRecommendations: false,
				hasadd: false, //是否已申请添加好友
				showMoreBeCommentedInfos: [],
				showMoreLetterRecommend: [],
				showMoreFriendScore: [],

				friendImpression: [],
				friendScore: [],
				eduRecord: [],
				workRecord: [],
				beCommentedInfos: [],
				recommendations: []
			}
		},
		onShow() {
			this.onShowNum++
			if (this.onShowNum != 1) {
				this.getuserFileInfo()

			}


		},
		onLoad(options) {
			console.log("onLoadonLoad=======", options)
			if (options.type && options.otheropenid) { //打开的是别人的档案
				this.source = options.type, //来源分享 0否 1是
					this.otheropenId = options.otheropenid //分享人openid
				this.myopenid = this.loginInfoObj.open_id
				this.getuserFileInfo()
				this.isMyShare = this.myopenid == this.otheropenId ? true : false
			}
			if (this.source == 0) {
				this.myopenid = this.loginInfoObj.open_id
				this.getuserFileInfo()
			}


		},
		//--------分享-----------
		// 转发页面
		onShareAppMessage(options) {
			let path = '/pages/my/myInfo/myArchives?type=1&otheropenid=' + this.loginInfoObj.open_id;
			console.log("str:", path)
			return {
				title: "职业档案",
				path: path, // 
				imageUrl: ''
			};

		},


		methods: {
			// isReload() {
			// 	this.userBaseInfo = {}
			// 	this.eduRecord = []
			// 	this.workRecord = []

			// },

			// 添加好友
			async addThisfriend(item) {
				let params = {
					open_id: this.loginInfoObj.open_id,
					re_open_id: this.otheropenId,
					can_phone: ''
				}
				let res = await this.$http.postHasLoad('/zxxt/user/addFriend', params);
				console.log('addThisfriend', res)
				if (res.code == 'success') {
					uni.showToast({
						title: '请求已发送',
						icon: 'none',
						duration: 2000
					})

					this.hasadd = true
				}
			},

			async jumpEditExeinfo(id) {
				var params = {
					openId: this.loginInfoObj.open_id,
				}

				const res = await this.$http.getHasLoad('/zxxt/user/listRecord', params);
				this.getExeList(res)
				var exeItem = {}
				this.eduList.forEach((item, index, arr) => {
					if (item.id == id)

					{
						exeItem = item
					}
				})
				let obj = {
					isEditor: true,
					info: exeItem
				}

				uni.navigateTo({

					url: '/pages/my/myRecord/exerciseDetail?obj=' + JSON.stringify(obj)
				})

			},

			async jumpEditEduinfo(id) {
				var params = {
					openId: this.loginInfoObj.open_id,
				}
				const res = await this.$http.getHasLoad('/zxxt/edu/myList', params);
				this.getEduList(res)
				console.log("---getEduList----------", id, this.eduList)
				var eduItem = {}
				this.eduList.forEach((item, index, arr) => {
					if (item.id == id)
					{
						eduItem = item
					}
				})
				let obj = {
					isEditor: true,
					info: eduItem
				}
				uni.navigateTo({
					url: '/pages/my/myRecord/eduDetail?obj=' + JSON.stringify(obj)
				})

			},

			// 点击新增履历（实际是页面的跳转）
			addNewEdu() {
				let obj = {

				}
				uni.navigateTo({
					url: '/pages/my/myRecord/eduDetail?obj=' + JSON.stringify(obj)
				})



			},

			// 个人履历查询
			getEduList(res) {
				if (res && res.code == 'success' && res.data && res.data.length) {
					var data = res.data
					// console.log("---res23--", data)
					this.eduList = data.map((item, index, arr) => {

						return {
							education: item.education ? item.education : '请选择',
							school_name: item.school_name ? item.school_name : '',
							used_name: item.used_name ? item.used_name : '',
							faculty: item.faculty ? item.faculty : '',
							major: item.major ? item.major : '',
							grade: item.grade ? item.grade : '',
							area: item.area ? item.area.split(',') : ["请选择（选填）", "", ""], //'请选择,,'.split(',')
							begin_time: item.begin_time ? item.begin_time : '2015.09',
							end_time: item.end_time ? item.end_time : '至今',
							evaluate_id: item.evaluate_id ? item.evaluate_id : '',
							id: item.id ? item.id : '',
							open_id: item.open_id ? item.open_id : '',
							school_type: item.school_type ? item.school_type : ''
						}
					})
				}
			},

			// 个人履历查询work
			getExeList(res) {
				if (res && res.code == 'success' && res.data && res.data.length) {
					var data = res.data
					// console.log("---res23--", data)
					this.eduList = data.map((item, index, arr) => {
						return {
							del_flag: item.del_flag ? item.del_flag : '',
							department: item.department ? item.department : '',
							id: item.id ? item.id : '',
							name: item.name ? item.name : '',
							open_id: item.open_id ? item.open_id : '',
							position: item.position ? item.position : '',
							describes: item.describes ? item.describes : '',
							area: item.area ? item.area.split(',') : '请选择,,'.split(
							','), //area: "北京市,customItem,customItem"
							start: item.start ? item.start : '2015-09',
							end: item.end ? item.end : '至今',
							department_fellow: item.department_fellow ? item.department_fellow : '',
						}
					})
				}
			},

			//评分全部展示
			onChangeFriendScore(event) {
				if (this.friendScore.length > 1) {

					this.showMoreFriendScore = event.detail
				}


			},

			//推荐信全部展示
			onChangeLetterRecommend(event) {
				if (this.recommendations.length > 1) {
					this.showMoreLetterRecommend = event.detail
				}
			},

			//好友点评全部展示
			onChangeBeCommentedInfos(event) {
				if (this.beCommentedInfos.length > 1) {
					this.showMoreBeCommentedInfos = event.detail
				}
			},
			//请求数据

			async getuserFileInfo() {
				var params = {
					openId: this.myopenid,
					reOpenId: ''
				}
				if (this.source) {

					params = {
						openId: this.otheropenId,
						reOpenId: this.myopenid
					}
				}
				console.log("---params---------", params)

				const res = await this.$http.getHasLoad('/zxxt/user/userFile', params);
				// console.log("----res----", res)

				this.resToData(res.data)
			},

			// 结果返回数据转换处理
			resToData(res) {
				// const res = testData.myArchivesInfo
				const base_education_vos = res.base_education_vos
				const recommendations = res.recommendations
				const user_labels = res.user_labels
				const labels = res.labels
				const user_record_vos = res.user_record_vos
				const beCommentedInfos = res.user_text_evaluate
				const user_total_score = res.user_total_score
				this.isNotOneFriendScore = user_total_score.length > 1 ? true : false
				this.isNotOneRecommendations = recommendations.length > 1 ? true : false
				this.isNotOneBeCommentedInfos = beCommentedInfos.length > 1 ? true : false
				this.userBaseInfo = {
					birthDate: res.date_birth ? res.date_birth : "--",
					sex: res.sex ? res.sex : "",
					user_name: res.user_name ? res.user_name : "",
					oldName: res.used_name ? res.used_name : "",
					phone: res.phone ? res.phone : "",
					states: res.states ? res.states : "",
					schoolName: res.school_name ? res.school_name : "",
					position_name: res.position_name ? res.position_name : "",
					email: res.postbox ? res.postbox : "",
					avatar: res.avatar ? res.avatar : this.$defaultHeadimg,
					address: res.area ? res.area : "",
				}


				if (user_total_score && user_total_score.length) {


					this.friendScore = user_total_score.map((item, index, arr) => {

						return {
							avatar: item.avatar ? item.avatar : this.$defaultHeadimg,
							startDate: item.create_time ? item.create_time : "",
							company_name: item.company_name ? item.company_name : "",
							if_anonymity: item.if_anonymity ? item.if_anonymity : "",
							user_name: item.user_name ? item.user_name : "",
							position_name: item.position_name ? item.position_name : "",
							open_id: item.open_id ? item.open_id : "",
							scoreNum: item.total_score ? item.total_score : "",
						}

					})

				}
				if (base_education_vos && base_education_vos.length) {
					this.eduRecord = base_education_vos.map((item, index, arr) => {

						let begin_time = item.begin_time.replace('-', '.')
						let end_time = item.end_time.replace('-', '.')
						// console.log("end_time", end_time)
						return {
							startDate: begin_time ? begin_time : "",
							endDate: end_time ? end_time : "",
							id: item.id ? item.id : "",
							schoolName: item.school_name ? item.school_name : "",
							major: item.major ? item.major : "",
							education: item.education ? item.education : "",
						}
					})


				}
				if (user_record_vos && user_record_vos.length) {
					this.workRecord = user_record_vos.map((item, index, arr) => {
						let start = item.start.replace('-', '.')
						let end = item.end.replace('-', '.')
						// console.log("end", end)
						return {
							startDate: start ? start : "",
							endDate: end ? end : "",
							jobName: item.position ? item.position : "",
							companyName: item.name ? item.name : "",
							id: item.id ? item.id : "",

						}

					})
					// console.log('	this.workRecord ', this.workRecord)


				}

				if (labels && labels.length) {
					this.friendImpression = labels.map((item, index, arr) => {

						return {
							labels: item.labels ? item.labels : "",
							colour: item.colour ? item.colour : "",

						}

					})

				}
				if (recommendations && recommendations.length) {
					this.recommendations = recommendations.map((item, index, arr) => {


						return {

							user_name: item.user_name ? item.user_name : "",
							commentContent: item.recommendations ? item.recommendations : "",
							re_states: item.re_states ? item.re_states : "",
							open_id: item.open_id ? item.open_id : "",
							position_name: item.work_post ? item.work_post : "",
							company_name: item.common ? item.common : "",
							letter_open_id: item.letter_open_id ? item.letter_open_id : "",
							time: item.modify_time ? item.modify_time : "",
							avatar: item.avatar ? item.avatar : this.$defaultHeadimg,
						}

					})


				}

				if (beCommentedInfos && beCommentedInfos.length) {
					this.beCommentedInfos = beCommentedInfos.map((item, index, arr) => {

						return {
							company_name: item.company_name ? item.company_name : "",
							time: item.create_time ? item.create_time : "",
							education: item.education ? item.education : "",
							if_anonymity: item.if_anonymity ? item.if_anonymity : "",
							commentContent: item.text_evaluate ? item.text_evaluate : "",
							avatar: item.avatar ? item.avatar : this.$defaultHeadimg,
							user_name: item.user_name ? item.user_name : "",
							open_id: item.open_id ? item.open_id : "",


						}

					})

				}
				// console.log("---res-to-", this.recommendations, this.workRecord, this.friendScore, this.eduRecord, this
				// .userBaseInfo, this.friendImpression)

			}




		}

	}
</script>
<style>
	.myArchives .van-collapse-item__content {
		padding-bottom: 0;


	}

	.myArchives .van-hairline--top {
		border-width: 0 !important;
	}


	.myArchives .van-cell::after {
		border: none !important
	}




	.myArchives .van-hairline--top::after {
		border: none !important
	}
</style>
<style lang="scss" scoped>
	.img-box-right {
		position: absolute;
		left: 150rpx;
		top: 100rpx;
		padding-left: 60rpx;
		// background-color: red;

		.box {
			display: flex;
			width: 200rpx;
			// background-color: red;

		}

		.text {
			color: #209072;
			font-size: 28rpx;
			// background-color: red;

		}

		.icon-addf {
			font-size: 68rpx;
			color: #209072;
			width: 40rpx;
			maargin-left: 40rpx;

		}

	}





	.justOne-item-box {
		padding-right: 80rpx;
		padding-left: 40rpx;

	}

	.myArchives {
		width: 100%; //设置页面宽度为100%
		overflow-x: hidden; //禁止页面左右滑动

		/deep/ .van-hairline--top-bottom::after {
			border-width: 0 !important
		}


	}

	.box-padding-right {
		padding-right: 40rpx;
	}

	.one-line6 {
		height: 130rpx;
		width: 2rpx;
		background-color: $uni-border-color;
	}

	.FriendScore-box .content-box {
		display: flex;
		min-height: 150rpx;
		align-items: center;

		.right {
			margin-top: -3rpx;
			min-height: 150rpx;
			width: 25%;
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;
			// background: red;

			.one {
				font-size: $uni-font-size-30;
				font-weight: 900;
			}

			.two {
				font-size: $uni-font-size-base;
				color: $uni-text-color-placeholder;
			}

		}

		.left {
			min-height: 150rpx;
			// margin-right: 30rpx;
			width: 70%;
			box-sizing: border-box;
			flex-wrap: wrap;

		}

	}

	.right {
		min-height: 174rpx;
		display: flex;
		margin-top: 30rpx;
		// background-color: pink;
		flex-wrap: wrap;

		.btn {
			background-color: $uni-bg-color-blueA;
			border-radius: 20%;
			min-width: 75rpx;
			line-height: 25rpx;
			padding: 20rpx;
			height: 25rpx;
			text-align: center;
			margin-right: 20rpx;
			margin-bottom: 20rpx;
			border: 2rpx solid $uni-text-color-placeholder;
			font-size: $uni-font-size-13;
			color: $uni-text-color-greenA;

		}
	}

	.friend-impression-box {
		flex-wrap: wrap;
		margin: 0 32rpx;
		padding-bottom: 20rpx;
		border-bottom: 1rpx solid $uni-border-color;


		.friend-impression {
			display: inline-block;
		}

		.btn {
			min-width: 140rpx;
			line-height: 60rpx;
			height: 60rpx;
			font-size: 26rpx;
			margin-right: 25rpx;
			margin-bottom: 25rpx;
			text-align: center;
			border-radius: 32rpx 32rpx 32rpx 32rpx;
		}

	}

	.img-box {
		position: relative;
		width: 160rpx;
		height: 160rpx;
		margin: auto;
		margin-top: -80rpx;
	}

	.image {
		width: 160rpx;
		height: 160rpx;
		border-radius: 50%;
	}





	.deep-title /deep/ .van-cell__title {
		color: $uni-color-active;
		font-size: $uni-font-size-15;
		font-weight: bold;
	}

	.collapse-title {
		color: $uni-color-active;
		font-size: $uni-font-size-15;
		font-weight: bold;

	}

	.box-padding {
		padding: 0 32rpx;
	}

	.FriendScore-box {
		padding-bottom: 0rpx;

		/deep/ .van-cell {
			padding-right: 80rpx;
		}
	}

	.myArchives {
		margin-bottom: 200rpx;

		.top-box {
			.one {
				height: 225rpx;
				background-color: $uni-color-active;
			}

			.two {
				height: 270rpx;

			}

			.name {
				font-size: 60rpx;
				font-weight: solid;
			}

			.work {
				font-size: $uni-font-size-base;
				color: $uni-text-color-greyA;
				padding-left: 20rpx;
			}

			.text {
				height: 110rpx;
				width: 90%;
				margin: auto;
				margin-bottom: 40rpx;
				display: flex;
				justify-content: center;
				align-items: center;
			}

		}


	}

	.one-line2 {
		height: 1rpx;
		margin-left: 52rpx;
		margin-right: 52rpx;
		background-color: $uni-border-color;
	}

	.one-line3 {
		height: 1rpx;
		margin: auto;
		background-color: $uni-border-color;
		margin-top: 40rpx;
		margin-bottom: 40rpx;
	}


	.one-line4 {
		height: 2rpx;
		margin-left: 52rpx;
		margin-right: 52rpx;
		margin-top: 40rpx;
		background-color: $uni-border-color;
	}

	.one-line1 {
		height: 16rpx;
		background-color: $uni-line-color-grayA;
	}



	.btn {

		width: 30rpx;
		height: 30rpx;
		color: $uni-color-active;
	}


	.base-info-box {
		padding-left: 40rpx;
		padding-right: 40rpx;
		padding-bottom: 40rpx;

		.text {
			margin-top: 30rpx;
		}

		.name {
			margin-top: 2rpx;
		}
	}
</style>
