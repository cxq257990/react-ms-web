<template>
	<view class="">

		<view class="lookatme-container">
			<view class="lookatme-header">
				<view class="bg-image">
					<image src="http://zx.xuanyuclub.com/group1/M00/03/F4/CrpfwmBAd6iAZLyuAADwK-04bK8865.png"
						class="item-image"></image>
				</view>
				<view class="lookatme-title">
					<text>谁看过我</text>
					<image src="http://zx.xuanyuclub.com/group1/M00/03/F4/CrpfwmBAd6iAZLyuAADwK-04bK8865.png"
						class="user-image"></image>
				</view>
				<view class="lookatme-data">
					<view class="data-left">
						<view class="data-num">{{todayVisitor}}</view>
						<view class="data-text">今日访客数</view>
					</view>
					<view class="data-line"></view>
					<view class="data-right">
						<view class="data-num">{{weekVisitor}}</view>
						<view class="data-text">本周访客数</view>
					</view>
				</view>
			</view>
			<view class="lookatme-body">
				<view class="body-container">
					<view class="body-title">
						<image src="http://zx.xuanyuclub.com/group1/M00/03/F4/CrpfwmBAhFeAZW5kAAAGatNA8CU664.svg"
							class="up-image"></image>
						<text>访客数过去一周上升了{{riseRate}}%</text>
						<!-- <text v-if="lessZero">访客数过去一周下降了{{riseRate}}%</text> -->
					</view>
					<view class="lookatme-list">
						<view class="base-card" v-for="(item,index) in lookatmeList" :key="index">
							<view class="card-left imageBox">


								<!-- 已同意1 -->
								<image class="avatar" v-if="item.states == 1"
									:src="item.avatar || '/static/img/anonymity.png'" @tap="goWechatInfo(item.open_id)"
									:data-becommend-id="item.open_id" :data-receive-member-index="index"></image>
								<!-- 申请中0 + 忽略2 -->
								<image v-if="item.states == 0 || item.states == 2"  @tap="goWechatInfo(item.open_id)"
									:src="item.avatar || '/static/img/anonymity.png'" class="avatar">

								</image>

								<view v-if="item.online_flag != 1"  @tap="goWechatInfo(item.open_id)" class="avatar imgMask"></view>

							</view>
							<view class="card-middle">
								<view class="name">
									
									{{item.user_name?item.user_name:(item.nickname?item.nickname:'')}}
									<text v-if="item.isNowWeek" class="visitsInSomeone">本周 {{item.visits}} 次</text>
								</view>
								<view class="company">
									<text>{{item.company_name?item.company_name:''}}</text><text
										v-if="item.position_name">-{{item.position_name}}</text>
								</view>
							</view>
							<view class="card-right">
								<text   class="time">{{item.create_time}}</text>
								<!-- 0:申请中，1：同意，2：忽略 -->
								<view v-if="item.states == 1" class="iconfont icon-tianjiahaoyou1 icon-addf"></view>
								<view v-else-if="item.states == 0" class="iconfont icon-jiahaoyouzhong icon-addf"></view>
								
							
								<view v-else :data-receive-member-id="item.open_id" :data-receive-member-index="index" @tap="friendRequest"
									class="iconfont icon-jiahaoyou1 icon-addf"></view>
					
							</view>
						</view>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	/**
	 * author        cxq
	 * time          2021-6-3 17:20:59
	 * description   
	 */
	import {
		mapState
	} from "vuex";



	export default {
		computed: {
			...mapState(['loginInfoObj'])
		},
		data() {
			return {
				lookatmeList: [],
				riseRate: 0,
				todayVisitor: 0,
				weekVisitor: 0,
				pageNo: 1,
				flag: 0, //人脉类别
				pageSize: 40,
				data_total: 0,
				lessZero: true,
				lookSign: 1, // (谁看过我)有无点击查看 0：未；1：已查看

			}
		},


		/**
		 * 页面上拉触底事件的处理函数
		 */
		onReachBottom: function() {

			if (this.pageNo * this.pageSize < this.data_total) {
				uni.showToast({
					title: '加载中',
					icon: 'none',
					duration: 1000
				})
				this.pageNo++
				this.getlookatmeList()
			} else {
				uni.showToast({
					title: '到底啦~',
					icon: 'none',
					duration: 1500
				})
			}
		},

		/**
		 * 用户点击右上角分享
		 */
		onShareAppMessage: function() {

		},
		onLoad(option) {
			console.log("option-:", option, this.loginInfoObj.open_id)
			// this.openId = this.loginInfoObj.open_id
			this.getlookatmeList()
			

		},
		onShow() {
			//未读信息-查看接口-已经查看
			this.getLooked()
		},


		methods: {
			
			// 添加好友
			async addThisfriend(e) {
				console.log(e)
				let phone = "";
				let reOpenId = "";
				let re_states = 0;
				if (this.flag == 1) {
					re_states = 0
				}
				if (this.flag == 2) {
					re_states = 1
				}
				if (this.flag == 5) {
					re_states = 5
				}
				if (e.target.dataset.id) {
					reOpenId = e.target.dataset.id;
				}
				if (e.target.dataset.phone) {
					phone = e.target.dataset.phone;
				}
				let that = this
				// let params = {
				// 	open_id: this.loginInfoObj.open_id,
				// 	re_open_id: reOpenId,
				// 	can_phone: phone,
				// 	re_states: re_states
				// }
				
				let params = {
					open_id: this.loginInfoObj.open_id,
					re_open_id: reOpenId,
					can_phone: '',
					re_states: 1
				}
				let res = await this.$http.postHasLoad('/zxxt/user/addFriend', params)
				if (res.code == 'success') {
					uni.showToast({
						title: "请求已发送！",
						icon: 'success',
						duration: 2000,
						success: function() {
							that.lookatmeList.forEach(item => {
								console.log(e)
								if (reOpenId == item.open_id) {
									item.states = 0
								}
							})
							that.lookatmeList = that.lookatmeList
							// setTimeout(function () {
							//   that.getAppendFriend()
							// }, 2000) //获取人脉红点数据
						},
						fail: function() {},
						complete: function() {}
					})
				}
			},

			async getlookatmeList() {

				var params = {
					openId: this.loginInfoObj.open_id,
					pageNo: this.pageNo,
					pageSize: this.pageSize
				}
				const res = await this.$http.getHasLoad('/zxxt/user/lookMe', params);

				this.resToData(res)

			},
			//未读信息-查看接口-已经查看
			async getLooked() {
				const params = {
					openId: this.loginInfoObj.open_id,
					friendSign: 0,
					remarkSign: 0,
					lookSign: 1
				}
				await this.$http.getHasLoad('/zxxt/user/center', params);
			},





			// 两个：一个receiveMemberId，二：把用户信息以receivebaseInfo字段存入缓存
			async goWechat(e) {
				var {
					receiveMemberId,
					receiveMemberIndex
				} = e.currentTarget.dataset
				var receivebaseInfo = this.lookatmeList[receiveMemberIndex]
				var params = {
					re_open_id: receivebaseInfo.open_id,
					open_id: this.loginInfoObj.open_id
				}
				uni.setStorageSync('receivebaseInfo', receivebaseInfo)
				const res = await this.$http.postHasLoad('/zxxt/chat/readMsg', params);
				if (res.code == 'success') {
					uni.navigateTo({
						url: '/pages/news/chart?receiveMemberId=' + receivebaseInfo.open_id,
					})
				}

			},


			// 前往好友详情页面
			goWechatInfo(open_id) {
				this.$util.checkJumpRelation(open_id)
			},

			// 好友申请
			async friendRequest(e) {
			    let 	re_open_id= e.currentTarget.dataset.receiveMemberId
				if (!e.currentTarget.dataset.receiveMemberId) {
					return
				}
				let that = this
				let params = {
					open_id: this.loginInfoObj.open_id,
					re_open_id:re_open_id
				}
				const res = await this.$http.postHasLoad('/zxxt/user/addFriend', params);
				if (res.code == 'success') {
					uni.showToast({
						title: "请求已发送！",
						icon: 'success',
						duration: 2000,
						success: function() {
							that.lookatmeList.forEach(item => {
								if (re_open_id == item.open_id) {
									item.states = 0
								}
							})
							this.lookatmeList = that.lookatmeList
						},
						fail: function() {},
						complete: function() {}
					})
				}

			},


			resToData(res) {

				if (res && res.code == 'success' && res.data) {
					var lookatmeList = res.data.message_vo_list
					var riseRate = res.data.rise_rate || 0
					var todayVisitor = res.data.today_visitor || 0
					var weekVisitor = res.data.week_visitor || 0
					var data_total = res.data.total
					var server_time = res.data.server_time
					if (lookatmeList && lookatmeList.length > 0) {
						lookatmeList.forEach(item => {
							
							if (item.create_time) {
								// create_time: "06-25 14:59:13"
							item.isNowWeek=this.$util.isNowWeek(item.create_time, server_time)
							item.create_time = this.$util.timeMatch2(item.create_time, server_time)
							}
						})
					}
					// 将分页的数据整合
					var oldLookatmeList = this.lookatmeList
					if (oldLookatmeList.length > 0) {
						lookatmeList = oldLookatmeList.concat(lookatmeList)
					}
					console.log("---", riseRate < 0)
					// 上升及下降文字处理
					if (riseRate < 0) {
						this.lessZero = true
					} else {
						this.lessZero = false
					}
					this.lookatmeList = lookatmeList
					this.riseRate = riseRate
					this.todayVisitor = todayVisitor
					this.weekVisitor = weekVisitor
					this.data_total = data_total

					console.log('---res0-', this.lookatmeList)
				}

			}
		}
	}
</script>

<style lang="scss" scoped>
	
	

	.lookatme-container{
	}
	
	.icon-addf {
		font-size: 48rpx;
		color: #209072;
	}
	
	.imageBox {
		position: relative;
	}

	.imgMask {
		position: absolute;
		left: 0;
		top: 0;
		width: 80rpx;
		height: 80rpx;
		background-color: #fff;
		opacity: 0.5;
	}

	.page {
		font-size: 14px;
		font-family: PingFangSC-Medium;
	}

	.img_gray {
		-webkit-filter: grayscale(30%);

		-moz-filter: grayscale(40%);

		-ms-filter: grayscale(30%);

		-o-filter: grayscale(30%);

		filter: grayscale(30%);

		filter: gray;

	}

	.visitsInSomeone {

		font-size: 24rpx;
		// color:  $uni-text-color-greyA;
		color: #ce0000;
		margin-left: 20rpx;
	}

	.lookatme-header {
		position: relative;
	}

	.lookatme-title {
		position: absolute;
		left: 22px;
		top: 18px;
		font-size: 20px;
		color: rgba(255, 255, 255, 100);
	}

	.item-image {
		width: 100%;
		height: 600px;
	}

	.lookatme-title {
		display: flex;
		justify-content: flex-start;
		align-items: center;
	}

	.user-image {
		width: 18px;
		height: 18px;
	}

	.lookatme-data {
		font-size: 12px;
	}

	.lookatme-data {
		position: absolute;
		left: 50%;
		top: 110px;
		transform: translate(-50%);
		width: 60%;
		display: flex;
		justify-content: space-around;
		align-items: center;
		height: 80px;
	}

	.data-num {
		text-align: center;
		font-size: 20px;
		color: rgba(255, 255, 255, 0.8);
		font-family: DINAlternate-Bold;
	}

	.data-text {
		font-size: 12px;
		color: rgba(255, 255, 255, 0.8);
	}

	.data-line {
		width: 1px;
		background-color: rgba(255, 255, 255, 0.8);
		height: 24px;
	}

	.data-left,
	.data-right {
		display: flex;
		flex-direction: column;
		align-content: center;
		justify-content: center;
	}

	.lookatme-body {
		position: relative;
		padding: 20px;
	}

	.body-container {
		position: absolute;
		left: 50%;
		transform: translate(-50%);
		top: -396px;
		width: 100%;
		min-height: 600px;
		border-top-left-radius: 12px;
		border-top-right-radius: 12px;
		background-color: #fff;
	}

	.up-image {
		width: 16px;
		height: 16px;
	}

	.body-title {
		display: flex;
		align-items: center;
		justify-content: flex-start;
		padding: 20px;
		color: #12866B;
		font-size: 12px;
	}

	.lookatme-list {
		padding: 0 20px;
	}

	.base-card {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding-bottom: 12px;
		border-bottom: 1px solid #f6f6f6;
		margin-bottom: 12px;
	}

	.card-left {
		position: relative;
		width: 60px;
	}

	.avatar {
		width: 60px;
		height: 60px;
		border-radius: 50%;
	}

	.on-line {
		position: absolute;
		right: 0;
		bottom: 4px;
		width: 8px;
		height: 8px;
		border: 2px solid #12866B;
		border-radius: 50%;
	}

	.card-middle {
		width: 60%;
		font-size: 14px;
		color: #333;
	}

	.name {
		font-size: 16px;
		font-weight: 700;
		margin-bottom: 2px;
	}

	.card-right {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
		width: 40px;
		height: 100%;
	}

	.time {
		font-size: 12px;
		color: #999999;
	}



	.icon1 {
		font-size: 80rpx;
		color: $uni-color-active
	}

	.company {
		width: 100%;
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
	}

	.applaying {
		width: 52px;
		height: 28px;
		color: #ccc;
		text-align: center;
		line-height: 28px;
		font-size: 12px;
		border-radius: 14px;
		border: 1px solid #ccc;
	}
</style>
