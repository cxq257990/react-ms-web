<template>
	<view class="">
		<view class="baseinfo-container">
			<view class="baseinfo-card">
				<!-- 头像 -->
				<image class="avtarimg" v-if="picPaths" :src="picPaths" @click="onchooseImage"></image>
				<image class="avtarimg" v-else-if="baseInfo.avatar" :src="baseInfo.avatar" @click="onchooseImage">
				</image>

				<image class="avtarimg" v-else src="/static/img/anonymity.png" @click="onchooseImage"></image>
				<!-- 基本信息 -->
				<view class="baseinfo-detail">
					<view class="input-box">
						<text class="input-label">姓名：</text>
						<input class="weui-input input-item" :value="baseInfo.user_name" @change="Change"
							data-input-flag="user_name" placeholder-class="input-placeholder" placeholder="请输入姓名" />
					</view>
					<view class="input-box">
						<text class="input-label">曾用名：</text>
						<input class="weui-input input-item" :value="baseInfo.used_name" @change="Change"
							data-input-flag="used_name" placeholder="请输入曾用名" />
					</view>
					<view class="input-box">
						<text class="input-label">性别：</text>
						<view class="weui-cell   sex-input   weui-cell_active weui-cell_select-after input-item">
							<view class=" arrow-down icon-s-xiangxia iconfont">
							</view>
							<view class="weui-cell__bd">
								<picker @change="PickerChange" :value="index" :range="array">
									<view class="weui-select">{{array[index]}}</view>
								</picker>
							</view>
						</view>
					</view>
					<view class="input-box">
						<text class="input-label">出生年月：</text>
						<view class="section input-item">
							<picker class="select--picker-style" mode="date" :value="baseInfo.date_birth" :start="start"
								:range="rangeTime" :end="end" @change="DateChange">
								<view class="picker picker-select">
									{{baseInfo.date_birth}}
								</view>
							</picker>
						</view>
					</view>
					<view class="input-box">
						<text class="input-label">地区：</text>
						<view class="section input-item selection-position">

							<view class=" arrow-down icon-s-xiangxia iconfont">

							</view>
							<picker class="select--picker-style" mode="region" @change="RegionChange" :value="region"
								:custom-item="customItem">
								<view class="picker picker-select">
									{{region[0]}}{{region[1]}}{{region[2]}}
								</view>
							</picker>
						</view>
					</view>
					<view class="input-box">
						<text class="input-label">手机：</text>
						<text class="baseInfo-phone">{{baseInfo.phone}}</text>

						<!-- 	<input :disabled="'true'" class="weui-input input-item" :value="baseInfo.phone" @change="Change"
							data-input-flag="phone" placeholder="请输入手机" /> -->
					</view>
					<view class="input-box">
						<text class="input-label">邮箱：</text>
						<input class="weui-input input-item" :value="baseInfo.postbox" @change="Change"
							data-input-flag="postbox" placeholder="请输入邮箱" />
					</view>
				</view>
				<!-- 按钮 -->
				<view class="submit-btn" @tap="baseInfoSave">保存</view>
			</view>
			<!-- test datePicker -->
			<!-- <view style="margin-top:106px;">
       <text style="color: red">选中日期：{{endTime}}</text>
       <pickerDate fields="day" selectDate="endTime" placeholder="请选择离职日期" quick @:changeDate="onChangeDate"></pickerDate>
     </view> -->
		</view>
	</view>
</template>
<script>
	/**
	 * author        cxq
	 * time          2021-6-3 16:03:14
	 * description   
	 */
	import {
		mapState
	} from "vuex";

	import {
		uploadFile
	} from "../../../utils/fileRequest.js"

	export default {
		computed: {
			...mapState(['userPhone', 'userInfoObj', 'loginInfoObj'])
		},
		data() {
			return {
				array: ['女', '男'],
				index: 0,
				// date: '2020-12-8',
				date: "1960-01-01",
				start: "1960-01-01",
				end: "2025-12-01",
				rangeTime: ["1960-01-01", "2025-12-01"], //data不支持
				region: ['广东省', '广州市', '海珠区'],
				baseInfo: {},
				oldUserName: '',
				newUserName: '',
				sendAvatar: '',
				// imgs: [], //本地图片地址数组
				picPaths: '', //网络路径
				endTime: '', //test datePicker endtime
				globalDataPhone: '', //获取全局中授权的手机号码

			}
		},

		onLoad(options) {
			console.log(options, 'options', this.loginInfoObj.open_id)
			// 获取用户个人基本信息
			this.getBaseInfo()
		},

		onShow(options) {
			console.log(options, 'options---s', this.loginInfoObj.open_id)
			// 获取用户个人基本信息
			this.getBaseInfo()
		},
		methods: {

			async getRoles() {
				let data = {
					open_id: this.loginInfoObj.open_id
				}
				let res = await this.$http.getNoLoad("/zxxt/askEmploy/lookRoles", data);
				if (res && res.data && res.data.roleMap) {
					let data = res.data.roleMap
					console.log("roleMap-----------", data)
					this.$store.commit("submitRole", data);
					uni.navigateBack()



				}
			},

			// 基本信息获取
			async getBaseInfo() {

				var params = {
					openId: this.loginInfoObj.open_id,
				}

				let res = await this.$http.getHasLoad('/zxxt/user/listMessage', params);

				this.resToData(res)
			},

			resToData(res) {
				if (res && res.code == 'success' && res.data) {
					var baseInfo = res.data
					console.log("---res--", baseInfo)
					if (baseInfo.sex && baseInfo.sex == "女") {
						baseInfo.sex = '女'
						this.index = 0
					} else {
						baseInfo.sex = '男'
						this.index = 1
					}
					1


					// 地区处理
					if (baseInfo.area) {
						this.region = baseInfo.area.split(",")
					}

					this.baseInfo = {
						avatar: baseInfo.avatar ? baseInfo.avatar : '',
						user_name: baseInfo.user_name ? baseInfo.user_name : '',
						used_name: baseInfo.used_name ? baseInfo.used_name : '',
						sex: baseInfo.sex,
						date_birth: baseInfo.date_birth ? baseInfo.date_birth : '1960-01-01',

						area: baseInfo.area ? baseInfo.area : '浙江省, 杭州市, 滨江区',
						phone: baseInfo.phone ? baseInfo.phone : this.userPhone ? this.userPhone : '',
						postbox: baseInfo.postbox ? baseInfo.postbox : ''
					}
					this.oldUserName = this.baseInfo.user_name

					console.log("---res0--", this.baseInfo, this.userPhone)
				}

			},
			// 表单信息变化动态赋值及收集
			Change: function(e) {
				if (e.currentTarget.dataset.inputFlag == "user_name") {
					this.baseInfo.user_name = e.detail.value
				}
				if (e.currentTarget.dataset.inputFlag == "used_name") {
					this.baseInfo.used_name = e.detail.value
				}
				if (e.currentTarget.dataset.inputFlag == "phone") {
					this.baseInfo.phone = e.detail.value
				}
				if (e.currentTarget.dataset.inputFlag == "postbox") {
					this.baseInfo.postbox = e.detail.value
				}
			},
			// 基本信息保存
			async baseInfoSave() {
				console.log(this.baseInfo, '看收集的信息')
				var params = this.baseInfo
				params.avatar = this.picPaths ? this.picPaths : params.avatar
				params.open_id = this.loginInfoObj.open_id
				console.log(params, '赋值之后')
				if (!params.user_name) {
					return uni.showToast({
						title: '请输入姓名',
						icon: 'none',
						duration: 2000
					})
				}
				if (!params.phone) {
					return uni.showToast({
						title: '请输入手机号码',
						icon: 'none',
						duration: 2000
					})
				}
				// if(!params.postbox) {
				//   return uni.showToast({
				//     title: '请输入邮箱',
				//     icon: 'none',
				//     duration: 2000
				//   })
				// }

				this.newUserName = this.baseInfo.user_name
				let res = await this.$http.postHasLoad('/zxxt/user/updateMessage', params);
				if (res.code == 'success') {

					uni.showToast({
						title: "保存成功",
						icon: 'success', //图标，支持"success"、"loading" 
						// image: '',//自定义图标的本地路径，image 的优先级高于 icon
						duration: 2000, //提示的延迟时间，单位毫秒，默认：1500 
						// mask: true,//是否显示透明蒙层，防止触摸穿透，默认：false 
						success: () => {
							if (this.oldUserName != this.newUserName) {

								this.getRoles()
							} else {
								uni.navigateBack()
							}
						},
						fail: function() {},
						complete: function() {}
					})
				}




			},

			PickerChange: function(e) {
				console.log('picker发送选择改变，携带值为', e.detail.value)
				this.baseInfo.sex = this.array[e.detail.value],
					this.index = e.detail.value
			},

			DateChange: function(e) {
				console.log('picker发送选择改变，携带值为', e.detail.value)
				this.date = e.detail.value,
					this.baseInfo.date_birth = e.detail.value
			},

			RegionChange: function(e) {
				console.log('picker发送选择改变，携带值为', e.detail.value)
				this.region = e.detail.value,
					this.baseInfo.area = e.detail.value.join(',')
			},


			onchooseImage() {
				var that = this;
				uni.chooseImage({
					count: 1, //默认1
					success: async (res) => {
						console.log("onchooseImage--------:", res)
						this.picPaths = res.url
						uni.showToast({
							title: "上传中",
							icon: "none",
							duration: 2000
						});
						for (let item of res.tempFilePaths) {
							let res = await uploadFile("/zxxt/askEmploy/upload", item);
							console.log("this.baseInfo.avatar=====:", res)
							this.baseInfo.avatar = res.url
						}
						uni.hideLoading()
					}
				});
			},

			// 至今选择变化
			onChangeDate(e) {
				console.log(e.detail, '看下展示的样式')
				this.endTime = e.detail.date
			},

		}
	}
</script>

<style lang="scss" scoped>
	.baseinfo-container {
		/* min-height: 560px; */
		padding-top: 3%;
		/* background-color: #F2F2F2; */
		background-color: #209072;
		font-family: PingFangSC-regular;

		.baseInfo-phone {
			margin-right: 170rpx;
		}
	}

	.baseinfo-card {
		min-height: 180px;
		position: relative;
		border-radius: 14px;
		border-bottom-left-radius: 0;
		border-bottom-right-radius: 0;
		background-color: #fff;
		margin-top: 36px;
		padding: 56px 30px 30px 30px;
	}

	.input-box {
		display: flex;
		justify-content: space-between;
		align-items: center;
		margin-bottom: 22px;
	}

	.sex-input {
		position: relative;

		/deep/ .weui-select {
			line-height: 31px;
			// margin-top: 10rpx;
		}


	}

	.arrow-down {
		position: absolute;
		right: 12px;
		top: 16rpx;
		;
	}

	.arrow-down image {
		width: 9px;
		height: 9px;
	}

	.weui-select {
		font-size: 14px;
	}

	.select--picker-style {
		width: 100%;
		height: 100%;
	}

	.picker-select {
		height: 31px;
		line-height: 31px;
		font-size: 14px;
	}

	.avtarimg {
		position: absolute;
		left: 50%;
		top: 0;
		transform: translate(-50%, -50%);
		width: 68px;
		height: 68px;
		border-radius: 50%;
	}

	.input-label {
		text-align: right;
		width: 88px;
		color: rgba(16, 16, 16, 100);
	}

	.input-item {
		width: 55% !important;
		height: 31px;
		lin-height: 31px;
		border-radius: 8px;
		border: 1px solid rgba(187, 187, 187, 100);
		padding: 3px 12px;
	}

	.input-bgc {
		background-color: #eee;
	}

	.input-placeholder {
		color: rgba(136, 136, 136, 100);
		font-size: 14px;
	}

	.selection-position {
		position: relative;
		overflow: hidden;
	}

	.submit-btn {
		height: 37px;
		line-height: 37px;
		width: 100%;
		background-color: #169171;
		border-radius: 18px;
		margin: 36px auto;
		text-align: center;
		color: rgba(255, 255, 255, 100);
	}
</style>
