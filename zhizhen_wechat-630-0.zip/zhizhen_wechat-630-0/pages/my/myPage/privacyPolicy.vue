<template>
<view class="user-agreement-box">
  <view class="user-agree-title">隐私政策</view>
  <view class="user-agree-line">
    <view class="line-left"></view>
    <view class="line-circle"></view>
    <view class="line-right"></view>
  </view>
  <view class="user-agree-content">
    <!-- 一 -->
    <view class="base-para">
      <view class="content">
        <view>1、我们尊重并保护您的个人隐私，收集个人的信息是仅出于遵守国家法律法规的规定以及提供服务及提升服务质量的目的。我们将秉持勤勉、尽责的义务，按照本协议及《授权书》的约定使用和披露您的个人信息。 </view>
      </view>
    </view>
    <!-- 二 -->
    <view class="base-para">
      <view class="content">
        <view>2、我们承诺将使您的信息安全保护达到业界领先的安全水平，致力于使用各种安全技术及配套的管理体系和应急预案来避免信息的丢失、不当使用、未经授权访问或披露。</view>
      </view>
    </view>
    <!-- 三 -->
    <view class="base-para">
      <view class="content">
        <view>3、我们可能会对您的信息进行去标识化后的综合统计、分析加工，以便为您提供更加准确、个性、流畅及便捷的服务，或帮助我们评估、改善或设计产品、服务及运营活动等。我们可能根据前述信息向潜在客户方提供营销活动通知、商业性电子信息或可能感兴趣的广告。但是，除非事先获得您的明确同意或法律法规或强制性的行政或司法要求，我们不会将您的个人信息转让给任何公司、组织和个人。</view>
      </view>
    </view>
    <!-- 四 -->
    <view class="base-para">
      <view class="content">
        <view>4、由于相关法律法规的变更，我们可能会不定时修改本政策。因此，我们保留自行决定实施此类修改的权利，如该等修订造成您在本《隐私政策》下权利的实质减少，我们将在修订生效前通过在网站主页上显著位置提示或向您推送通知或以其他方式通知您。
		<text class="text-solid">在该种情况下，若您继续使用我们的服务，即表示同意受经修订后的《隐私条款》的约束。如果您不同意任一条款，您应立即停止使用产品或服务。</text>
		
		</view>
      </view>
    </view>
  </view>
</view>
</template>

<script>
	/**
	 * author        cxq
	 * time          2021-5-25 15:38:56
	 * description   
	 */


	export default {
		name: '',
		data() {
			return {

			}
		}
	}
</script>

<style>
	.text-solid{
		font-weight: 900;
	}
	.user-agreement-box {
		font-size: 14px;
		margin: 20px auto 0;
	}

	.user-agree-title {
		text-align: center;
		font-size: 25px;
	}

	.user-agree-line {
		display: flex;
		justify-content: space-between;
		align-items: center;
		padding: 20px;
	}

	.line-left,
	.line-right {
		height: 2px;
		width: 46%;
		background-color: #209072;
	}

	.line-circle {
		width: 5px;
		height: 5px;
		border-radius: 50%;
		background-color: #209072;
	}

	.user-agree-content {
		padding: 0 20px;
	}

	.user-agree-content view {
		text-indent: 9%;
	}

	.base-para {
		margin: 12px 0;
	}

	.title {
		margin: 12px 0;
	}
</style>
