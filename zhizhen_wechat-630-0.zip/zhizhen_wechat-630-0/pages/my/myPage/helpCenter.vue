<template>
<view class="help-center-box">
  <view class="help-center-title">帮助中心</view>
  <view class="help-center-line">
    <view class="line-left"></view>
    <view class="line-circle"></view>
    <view class="line-right"></view>
  </view>
  <view class="content">
    <view class="q1">
      <view class="question">Q1：什么是职业信用？</view>
      <view class="answer">
        职业信用是指雇员担任某一职位时，在职业规范要求的基础上，在履行职业行为过程中所表现出来的关于职业技能、职业道德和各个方面素质的综合记录和评估，重点体现在个人对工作所负责任的承诺和遵守上。
      </view>
    </view>
    <view class="q2">
      <view class="question">Q2：什么是职业信用档案？</view>
      <view class="answer">
        职业信用档案是职业信用的载体，是对雇员工作经历的权威记录，内容包括雇员的基本信息、教育经历、工作经历、项目经验、绩效考核、奖惩记录、重大失误、职业道德、在职合规、综合评价、主要成就等。
      </view>
    </view>
    <view class="q3">
      <view class="question">Q3：什么是雇前背景调查？</view>
      <view class="answer">
        雇前背景调查是指企业在面试应聘者的同时，对应聘者的资历信息进行调查核实的过程，企业普遍将雇前背景调查安排在发放offer与入职报到的前后进行。雇前背景调查能够从多方面核实雇员提供的背景信息，帮助企业挑选出最可靠的人选。
      </view>
    </view>
    <view class="more-help">
      <view>
        <text class="telText">产品联系：</text>
        <view class="phone">0571-28272452</view>
		<text class="telText">背调问题联系：</text>
		<view class="phone">13683638681</view>
		
      </view>
    </view>
  </view>
</view>
</template>

<script>
/**
* author        cxq
* time          2021-5-25 16:28:33
* description   
*/


export default {
  name: '',
  data () {
    return {
      
    }
  }
}
</script>

<style >
.help-center-box {
  font-size: 14px;
  padding: 20px;
}

.help-center-title {
  text-align: center;
  font-size: 25px;
}

.question {
  color: #209072;
  font-weight: 700;
  margin: 12px 0;
}

.answer {
  text-indent: 9%;
}

.help-center-line {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding:20px;
}

.line-left,
.line-right {
  height: 2px;
  width: 46%;
  background-color: #209072;
}

.line-circle {
  width: 5px;
  height: 5px;
  border-radius: 50%;
  background-color: #209072;
}

.more-help {
  display: flex;
  justify-content: flex-end;
  padding-top: 36px;
}

.telText {
  color: #209072;
  font-size: 14px;
  font-weight: 700;
}

.phone {
  font-weight: 700;
}

</style>
