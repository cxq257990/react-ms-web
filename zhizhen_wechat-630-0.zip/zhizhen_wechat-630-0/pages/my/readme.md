
##  结构说明
说明---
myRecord ------- 
                |---eduDetail  : 教育履历详情
                |---eduList   : 教育履历列表
                |---evaluatedetail      : 工作履历详情
                |---exerciseList      : 工作履历列表

myRecommendLetter 
                |-- recommendLetterList  : 推荐信入口
			    |-- recommendLetterDetail : 推荐信详情

myPage ---------- 
                |---helpCenter : 帮助中心
                |---privacyPolicy :隐私政策
                |---userAgreement : 用户协议
				
myNews ---------- 
                |---myCommentAndLike : 我的点赞
                |---myNewsIndex : 我的动态入口
                |---myRelease : 我的发布
myInfo ---------- 
                |---lookAtMe : 谁看过我
                |---myArchives : 我的档案
                |---myBaseInfo : 基础信息          
     
		  
