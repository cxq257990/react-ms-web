<template>
	<view class="">
		<image class="logo" src="../../static/img/login/toplogo.png" mode="widthFix"></image>
		<view class="getText">
			<view class="getTextfir">你好,</view>
			<view class="getTextsec">欢迎登录指真</view>
			<view></view>
		</view>

		<!-- <button class="btnget" open-type="getUserInfo" type="primary" @getuserinfo="onGetUserInfo" v-if="nophonebtn">
		  <image src="../../static/img/login/weChat.svg" class="auth-img"></image>微信登录授权
		</button> -->

		<!-- 无个人信息 -->
		<template v-if="!hasInfo">
			<button class="btnget" v-if="canIUseGetUserProfile" @click="getUserProfile">
				<image src="../../static/img/login/weChat.svg" class="auth-img"></image>微信登录授权
			</button>
			<button v-else class="btnget" open-type="getUserInfo" @getuserinfo="getUserInfo">
				<image src="../../static/img/login/weChat.svg" class="auth-img"></image>微信登录授权
			</button>
		</template>
		<!-- 有个人信息，无手机号 -->
		<button class="btnget2" open-type="getPhoneNumber" type="primary" @getphonenumber="getPhoneNumber"
			v-if="!hasphone && hasInfo">
			手机号码绑定
		</button>

		<view class="user-agreement" v-if="!hasInfo">
			<view>登录注册即表示同意</view>
			<view class="click-text" @tap="userdialog">《用户协议及隐私条款》</view>
		</view>

		<!-- ------------------------------------------------ -->
		<view class="dialog-container" v-if="dialogVisible">
			<view class="mask"></view>
			<view class="dialog">
				<view class="header">用户协议&隐私政策</view>
				<view class="body">
					<view class="user-agree-content">
						<view>提示条款</view>
						<view>欢迎您阅读《用户协议》（“本协议”）！</view>
						<view>
							本协议适用于指真小程序（“指真”）提供的所有产品和服务。指真服务提供者（“我们”）提醒您，为维护您的权利，在使用指真各项产品或服务前，请您务必审慎阅读并透彻理解本协议各条款内容。如您对本协议有任何疑问、意见或建议，请通过本协议提供的联系方式及时与我们联系。
						</view>
						<view>
							在确认充分理解并同意后，您可以使用指真的产品或服务。当您开始使用指真的产品或服务时，即表示您已充分理解并同意本协议。在阅读本协议、使用指真的产品或服务的过程中，如果您不同意本协议中的任一条款，您应立即停止使用指真的产品或服务。
						</view>
						<!-- 一 -->
						<view class="base-para">
							<view class="title">第一部分 定义</view>
							<view class="content">
								<view>指真小程序：指指真向用户提供服务的产品载体。</view>
								<view>指真服务提供者：指指真的网络及软件技术服务提供者杭州轩宇人力资源有限公司及关联公司。</view>
								<view>除另有约定外，本协议所用定义与《隐私政策》中的定义具有相同的涵义。</view>
							</view>
						</view>
						<!-- 二 -->
						<view class="base-para">
							<view class="title"> 第二部分 服务协议</view>
							<view class="content">
								<view>本服务协议将包含以下内容：</view>
								<view>一、授权登录和使用</view>
								<view>二、用户信息的提供、保护和保证、授权</view>
								<view>三、指真小程序服务使用规则</view>
								<view>四、不可抗力及其他免责事由</view>
								<view>五、未成年人条款</view>
								<view>六、适用及变更</view>
								<view>七、管辖及法律应用</view>
								<view>八、如何联系我们</view>
							</view>
						</view>
						<!-- 三 -->
						<view class="base-para">
							<view class="title">一、授权登录和使用</view>
							<view class="content">
								<view>（一）用户资格</view>
								<view>
									请确认，在您开始授权登录小程序使用指真服务前，您应当具备中华人民共和国法律规定的与您行为相适应的民事行为能力。若您不具备前述与您行为相适应的民事行为能力，则您及您的监护人应依照法律规定承担因此而导致的后果。
								</view>
								<view>此外，您还需确保您不是任何国家、国际组织或者地域实施的贸易限制、制裁或其他法律、规则限制的对象。</view>
								<view>（二）账户说明</view>
								<view>1、账户获得 </view>
								<view>当您阅读并同意本协议，且按照提示完成全部授权登录小程序后，您可获得指真账户。</view>
								<view>如指真系统判断您存在不当注册或不当使用账户的情形，我们可采取封禁账户等措施。</view>
								<view>2、账户使用</view>
								<view>您有权使用微信授权登录（账户名称为微信昵称）及您设置或确认的手机号码手机绑定（账户名及手机号码合称“账户”）登录指真。</view>
								<view>
									由于您的账户关联您的个人信息，您的账户仅限您本人使用。您享有您账户的使用权。我们享有账户的所有权。在使用中，您不应以任何方式私自转让该使用权，也不应以任何形式盗用他人账户。账户的行为将被视为账户注册用户的行为。
								</view>
								<view>如您账户的使用可能危及您的账户安全及/或其他用户信息安全的，我们可采取相应安全措施。</view>
								<view>3、账户安全</view>
								<view>
									您的账户为您自行设置并由您保管，我们在任何时候均不会主动要求您提供您的账户信息。我们强烈建议您务必保管好您的账户。账户因您主动泄露或因您遭受他人攻击、诈骗等行为导致的损失及后果，您应通过司法、行政等救济途径向侵权行为人追偿。此外，您应对您账户项下的所有行为结果（包括但不限于发布信息、评论）负责。
								</view>
								<view>4、日常维护</view>
								<view>
									如发现任何未经授权使用您账户登录指真或其他可能导致您账户遭窃、遗失的情况，建议您立即通知我们，并授权我们为保护您的账户信息采取相应措施。请理解，我们对您的任何请求采取行动均需要合理时间，且应您请求而采取的行动可能无法避免或阻止侵害后果的形成或扩大。
								</view>
							</view>
						</view>
						<!-- 四 -->
						<view class="base-para">
							<view class="title">二、用户信息的提供、保护和保证、授权</view>
							<view class="content">
								<view>（一）用户信息的提供、保护</view>
								<view>1、信息的真实合法和更新</view>
								<view>在使用指真服务时，需要您按页面的提示准确完整地提供您的信息。您了解并同意，您应提供真实且有效的信息。 </view>
								<view>
									为给您提供更好的服务，需要您及时更新您提供的信息。在法律有明确规定要求平台服务提供者必须对用户信息进行核实的情况下，我们将依法进行检查核实，需要您配合提供最新、真实、完整、有效的信息。
								</view>
								<view>
									如您未及时提供信息、您提供的信息存在明显不实或行政司法机关核实您提供的信息无效的，您将承担因此对您自身、他人等造成的损失与后果。我们可能向您发出询问通知，并要求您进行重新认证，直至中止、终止对您提供部分或全部指真服务。
								</view>
								<view>2、用户信息的保护</view>
								<view>
									保护用户信息是我们的一项基本原则。我们将按照本协议及《隐私政策》《授权书》的规定收集、使用、储存和分享您的个人信息。本协议对信息保护相关内容未作明确规定的，均以《隐私政策》《授权书》的内容为准。
								</view>
								<view>（二）用户信息的保证、授权 </view>
								<view>1、用户信息的保证</view>
								<view>
									为了维护互联网环境，保护权利人相应的权利，请您声明并保证，您对您所发布的信息拥有相应、合法的权利。否则，我们可对您发布的信息依法或依本协议采取删除或屏蔽等措施，以减轻因不当行为而造成的影响。
								</view>
								<view>您应当确保您所发布的信息不包含以下内容：</view>
								<view>（1）违反国家法律法规禁止性规定的；</view>
								<view>（2）封建迷信、淫秽、色情、赌博、暴力、恐怖或者教唆犯罪的；</view>
								<view>（3）欺诈、虚假、不准确或存在误导性的；</view>
								<view>（4）侵犯他人知识产权或涉及第三方商业秘密及其他专有权利的； </view>
								<view>（5）侮辱、诽谤、恐吓、涉及他人隐私等侵害他人合法权益的；</view>
								<view>（6）存在可能破坏、篡改、删除、影响指真系统正常运行或未经授权秘密获取指真及其他用户的数据、个人资料的病毒、木马、爬虫等恶意软件、程序代码的；</view>
								<view>（7）其他违背社会公共利益或公共道德不适合在指真上发布的。</view>
								<view>2、用户信息的授权</view>
								<view>
									对于您提供、发布及在使用指真服务中形成的除个人信息外的文字、图片、视频、音频等非个人信息，在法律规定的保护期限内您免费授予我们获得全球排他的许可使用权利及再授权给其他第三方使用并可以自身名义对第三方侵权行为取证及提起诉讼的权利。请确认，您同意我们存储、使用、复制、修订、编辑、发布、展示、翻译、分发您的非个人信息或制作其派生作品，并以已知或日后开发的形式、媒体或技术将上述信息纳入其它作品内。
								</view>
								<view>
									为方便您使用指真的其他相关服务，请您授权我们将您在账户注册和使用指真服务过程中提供、形成的信息传递给其他相关服务提供者，或从其他相关服务提供者获取您在注册、使用相关服务期间提供、形成的信息。
								</view>
							</view>
						</view>
						<!-- 五 -->
						<view class="base-para">
							<view class="title">三、服务使用规则</view>
							<view class="content">
								<view>（一）在使用指真的产品或服务过程中，您应当遵守如下规则：</view>
								<view>1、遵守中国法律、法规、行政规章及规范性文件；</view>
								<view>2、遵守与指真服务有关的协议、政策等文件； </view>
								<view>3、不应为任何违法、犯罪目的而使用指真服务；</view>
								<view>4、不应以任何形式侵犯任何第三方的合法权利；</view>
								<view>5、不应进行任何可能对互联网正常运转造成不利影响的行为。</view>
								<view>对于您上传到指真平台的任何文本、图片、图形、音频和/ 或视频等，或您的其他使用行为，我们将依据法律法规的规定，保留对其内容监督的权利。</view>
								<view>（二）知识产权条款 </view>
								<view>
									我们提供的与指真的产品或服务相关的各种类的过去有效的、现行有效的、或即将产生的权利归指真服务提供者所有，包括但不限于专利权、商标权、著作权及其他知识产权以及相关申请的权利。未经指真服务提供者书面许可，任何人不得以任何形式使用或创造相关衍生作品，或用于其他任何商业目的。
								</view>
								<view>（三）用户行为违约及处理</view>
								<view>1、在使用指真的产品或服务时，如您有如下情形之一的，视为违约：</view>
								<view>（1）违反法律法规等相关规定的；</view>
								<view>（2）违反本协议、《隐私政策》等约定的；</view>
								<view>
									2、请确认，您对指真产品或服务的使用承担独立且完全的法律责任。如您有违约行为，相关国家机关或机构可能会对您提起诉讼、罚款或采取其他制裁措施，并要求我们给予协助。因此造成损害的（包括但不限于直接经济损失、商誉损失及支出的赔偿金、律师费、诉讼费等间接经济损失），您应承担全部责任。
								</view>
								<view>
									此外，我们保留对您的使用等行为进行监督的权利。如您被投诉或被发现有违约行为，为及时解决问题，保护各方合法权利，我们可以独立判断并采取相应措施（包括但不限于通过技术手段删除、屏蔽相关内容或断开链接、暂停或中止向您提供服务等）。
								</view>
								<view>（四）服务的变更、中断、终止</view>
								<view>1、请您理解并同意，我们基于经营策略的调整，可能会对服务内容进行变更，也可能会中断、中止或终止服务。</view>
								<view>2、如发生下列任何一种情形，我们有权中断或终止向您提供服务：</view>
								<view>（1）根据法律法规规定，您应提交真实信息，而您提供的信息不真实、或与注册时信息不一致又未能提供合理证明。</view>
								<view>（2）您违反相关法律法规的规定、违反《隐私政策》或违反本协议的约定。</view>
								<view>（3）按照法律法规规定，司法机关或主管部门的要求。</view>
								<view>（4）出于安全的原因或其他必要的情形。</view>
								<view>
									3、您有责任自行备份存储在使用服务中的数据。如果您的服务被终止，我们有权从服务器上永久地删除您的数据,法律法规另有规定的除外。服务中止或终止后，我们没有义务向您提供或返还数据
								</view>
								<view>（五）我们可能发送的信息</view>
								<view>
									1、请确认，我们可能自行或由第三方通过短信、电子邮件或电子信息等多种方式向您发送、展示广告或其他信息（包括商业与非商业信息），广告或其他信息的具体发送及展示形式、频次及内容等以实际提供为准。如您不希望收到这些信息，可以按照我们的相关提示，在设备上选择取消订阅。
								</view>
								<view>2、我们将依照相关法律法规要求开展广告业务。对指真的产品或服务中出现的广告，您应审慎判断其真实性和可靠性，除法律明确规定外，您应对因该广告而实施的行为负责。
								</view>
								<view>3、我们可能在必要时（例如因系统维护而暂停某一项服务时）向您发出与服务有关的公告。您可能无法取消这些与服务有关、性质不属于推广的公告。</view>
							</view>
						</view>
						<!-- 六 -->
						<view class="base-para">
							<view class="title">四、不可抗力及其他免责事由</view>
							<view class="content">
								<view>
									（一）在使用指真的产品或服务的过程中，可能会遇到不可抗力等风险因素，使产品或服务受到影响。不可抗力是指不能预见、不能克服并不能避免且造成重大影响的客观事件，包括但不限于自然灾害如洪水、地震、瘟疫流行和风暴等以及社会事件如战争、动乱、政府行为等。出现上述情况时，我们将努力在第一时间与相关单位配合，争取及时进行处理，但是由此给您造成的损失在法律允许的范围内免责。
								</view>
								<view>（二）在法律允许的范围内，我们对以下情形导致的服务中断或受阻、损失等后果不承担责任：</view>
								<view>1、受到计算机病毒、木马或其他恶意程序、黑客攻击的破坏。</view>
								<view>2、您或我们的电脑软件、系统、硬件和通信线路出现故障。</view>
								<view>3、由您的操作不当或通过违法违规、非授权的方式使用本服务。</view>
								<view>4、程序版本过时、设备的老化和/或其兼容性问题、系统不稳定问题。</view>
								<view>5、其他我们无法控制或合理预见的情形。</view>
								<view>
									（三）在使用指真服务的过程中，可能会遇到网络信息或其他用户行为带来的风险，可能会遇到其他用户损害合法权利（包括但不仅限于知识产权）的行为，我们不对任何信息的准确性、真实性、适用性、合法性作承诺保证或承担责任，也不对因用户的侵权行为造成的损害负责。这些风险包括但不限于：
								</view>
								<view>1、来自他人匿名或冒名的含有威胁、诽谤、令人反感或非法内容的信息。</view>
								<view>2、遭受他人误导、欺骗或其他导致或可能导致的任何心理、生理上的伤害以及经济上的损失。</view>
								<view>3、其他因网络信息或用户行为引起的风险。</view>
								<view>
									（四）我们对第三方依托指真提供的内容或服务等无法做承诺或保证，对因前述未作承诺或保证的内容或服务等可能或将导致的直接、间接、偶然、特殊及后续损害，在法律允许的范围内免责
								</view>
								<view>（五）我们依据本协议约定获得处理违法违规内容的权利，该权利不构成我们的义务或承诺，请理解，由于用户行为的不可控性，我们不能保证及时发现违法行为或进行相应处理。
								</view>
								<view>（六）在任何情况下，我们强烈建议您不轻信借款、索要账户信息或其他涉及财产的信息。涉及财产操作的，请一定先核实对方身份。</view>
							</view>
						</view>
						<!-- 七 -->
						<view class="base-para">
							<view class="title">五、未成年人条款</view>
							<view class="content">
								<view> 如您为未成年人，我们要求您请您的父母或监护人仔细阅读本协议，并在征得您的父母或监护人同意的前提下使用我们的服务。</view>
							</view>
						</view>
						<!-- 八 -->
						<view class="base-para">
							<view class="title">六、适用及变更</view>
							<view class="content">
								<view>（一）适用范围</view>
								<view>1、我们的所有服务均适用本协议。</view>
								<view>2、某些服务有其特定的规则或协议，该规则或协议会针对相应的服务有更具体的说明，如本协议与特定服务的规则或协议有不一致之处，请以该规则或协议为准。</view>
								<view>3、请您注意，本协议不适用由其他公司或个人提供的服务。您使用该等第三方服务需受其服务协议（而非本协议）的约束，需要您仔细阅读其协议内容。 </view>
								<view>（二）变更 </view>
								<view>1、未经您明确同意，我们不会限制您按照本协议所应享有的权利。</view>
								<view>
									2、对于重大变更（包括但不限于我们的服务模式发生重大变化），我们还会提供更为显著的通知。在该种情况下，若您继续使用我们的服务，即表示同意受经修订的协议约束。若您不接受修改后的最新协议条款，可立即停止使用指真服务，或注销账户。
								</view>
							</view>
						</view>
						<!-- 九 -->
						<view class="base-para">
							<view class="title">七、管辖及法律适用</view>
							<view class="content">
								<view>1、本协议的成立、生效、履行、解释及因本协议产生的任何争议，均适用中华人民共和国法律（不包括港澳台地区法律）。如法律无相关规定的，参照商业惯例及/或行业惯例。
								</view>
								<view>
									2、您因使用指真产品或服务所产生的与指真服务有关的任何纠纷或争议，首先应友好协商解决；协商不成的，您同意将纠纷或争议提交杭州轩宇人力资源有限公司所在地有管辖权的人民法院管辖。
								</view>
								<view>3、本协议所有条款的标题仅为阅读方便，本身并无实际涵义，不能作为本协议涵义解释的依据。</view>
								<view>4、本协议条款无论因何种原因部分无效或不可执行，其余条款仍有效。</view>
							</view>
						</view>
						<!-- 十 -->
						<view class="base-para">
							<view class="title">八、如何联系我们</view>
							<view class="content">
								<view> 本协议的最终解释权及修改权归指真服务提供者所有。若有如下情形，您可以通过客服热线【0571-
									28272452】或发送邮件至【admin@91zhizhen.com 】与我们联系，我们将在【10】个工作日内回复您：</view>
								<view>1、如对本协议内容有任何疑问、意见或建议；</view>
								<view>2、如对指真的产品和服务有任何疑问、意见或建议。</view>
							</view>
						</view>
					</view>
					<view class="user-agree-content">
						<view class="yspolicy">隐私政策</view>
						<!-- 一 -->
						<view class="base-para">
							<view class="content">
								<view>
									1、我们尊重并保护您的个人隐私，收集个人的信息是仅出于遵守国家法律法规的规定以及提供服务及提升服务质量的目的。我们将秉持勤勉、尽责的义务，按照本协议及《授权书》的约定使用和披露您的个人信息。
								</view>
							</view>
						</view>
						<!-- 二 -->
						<view class="base-para">
							<view class="content">
								<view>2、我们承诺将使您的信息安全保护达到业界领先的安全水平，致力于使用各种安全技术及配套的管理体系和应急预案来避免信息的丢失、不当使用、未经授权访问或披露。
								</view>
							</view>
						</view>
						<!-- 三 -->
						<view class="base-para">
							<view class="content">
								<view>
									3、我们可能会对您的信息进行去标识化后的综合统计、分析加工，以便为您提供更加准确、个性、流畅及便捷的服务，或帮助我们评估、改善或设计产品、服务及运营活动等。我们可能根据前述信息向潜在客户方提供营销活动通知、商业性电子信息或可能感兴趣的广告。但是，除非事先获得您的明确同意或法律法规或强制性的行政或司法要求，我们不会将您的个人信息转让给任何公司、组织和个人。
								</view>
							</view>
						</view>
						<!-- 四 -->
						<view class="base-para">
							<view class="content">
								<view>
									4、由于相关法律法规的变更，我们可能会不定时修改本政策。因此，我们保留自行决定实施此类修改的权利，如该等修订造成您在本《隐私政策》下权利的实质减少，我们将在修订生效前通过在网站主页上显著位置提示或向您推送通知或以其他方式通知您。在该种情况下，若您继续使用我们的服务，即表示同意受经修订后的《隐私条款》的约束。如果您不同意任一条款，您应立即停止使用产品或服务。ss
								</view>
							</view>
						</view>
					</view>
				</view>
				<view class="dialogbtn" @tap="agreeBtn">确定</view>
			</view>
		</view>
		<!-- ------------------------------------------------- -->
	</view>
</template>

<script>
	// import {
	// 	mapState
	// } from "vuex";
	export default {
		data() {
			return {
				hasInfo: uni.getStorageSync("userInfoObj") ? true : false, //无个人信息
				canIUseGetUserProfile: false,
				hasphone: uni.getStorageSync("userPhone") ? true : false,
				dialogVisible: false,
			}
		},
		// computed: {
		// 	...mapState(['userInfoObj', ])
		// },
		created() {
			if (uni.getUserProfile) {
				this.canIUseGetUserProfile = true
			}
		},
		methods: {
			userdialog() {
				this.dialogVisible = true
			},

			agreeBtn() {
				this.dialogVisible = false
			},
			getUserProfile(e) {
				// 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认
				// 开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
				wx.getUserProfile({
					desc: '用于完善会员资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
					success: async (res) => {
						console.log(res)
						this.$store.commit('submitUsrInfo', res.userInfo);
						let open_id = uni.getStorageSync("loginInfoObj").open_id;
						let id = uni.getStorageSync("loginInfoObj").id;
						let issue_id = uni.getStorageSync("loginInfoObj").issue_id;
						let params = {
							nickname: res.userInfo.nickName,
							avatar: res.userInfo.avatarUrl,
							id,
							issue_id,
							open_id
						}
						let data = await this.$http.postHasLoad('/zxxt/wechat/updateInfo', params)
						this.hasInfo = true;
					},
					fail(err){
						uni.switchTab({
							url:'/pages/index/index'
						})
					}
				})
			},
			async getUserInfo(e) {
				this.$store.commit('submitUsrInfo', e.detail.userInfo)
				// 不推荐使用getUserInfo获取用户信息，预计自2021年4月13日起，getUserInfo将不再弹出弹窗，并直接返回匿名的用户个人信息
				let open_id = uni.getStorageSync("loginInfoObj").open_id;
				let id = uni.getStorageSync("loginInfoObj").id;
				let issue_id = uni.getStorageSync("loginInfoObj").issue_id;
				let params = {
					nickname: res.userInfo.nickName,
					avatar: res.userInfo.avatarUrl,
					id,
					issue_id,
					open_id
				}
				let data = await this.$http.postHasLoad('/zxxt/wechat/updateInfo', params)
				this.hasInfo = true;
			},
			async getPhoneNumber(e) {
				console.log(e)
				if (e.detail.errMsg == "getPhoneNumber:ok") {
					var ivObj = e.detail.iv;
					var telObj = e.detail.encryptedData;
					let {
						session_key,
						open_id
					} = uni.getStorageSync("loginInfoObj");
					let params = {
						uid: "",
						encrypted_data: telObj,
						iv: ivObj,
						session_key,
						open_id
					}
					let res = await this.$http.postHasLoad('/zxxt/wechat/getPhone', params)
					this.$store.commit('submitUserPhone', res.data)
					uni.navigateBack()
				}else{
					uni.switchTab({
						url:'/pages/index/index'
					})
				}
			},

		}
	}
</script>

<style lang="scss" scoped>
	.logo {
		position: absolute;
		left: 50%;
		top: 50px;
		transform: translate(-50%);
		width: 420rpx;
		height: auto;
		/* margin-left: 25%;
	  margin-top: 460px; */
	}

	.getinfo {
		width: 500rpx;
		height: auto;
		left: 125rpx;
		position: absolute;
		bottom: 10%;
	}

	.getText {
		position: absolute;
		left: 50% !important;
		top: 400rpx;
		transform: translate(-50%);
		width: 600rpx !important;
	}

	.getTextfir,
	.getTextsec {
		font-size: 42rpx;
		font-weight: bold;
		color: #222;
		line-height: 72rpx;
	}

	.auth-img {
		width: 50rpx;
		height: 50rpx;
		vertical-align: middle;
		margin-right: 8px;
	}

	.btnget {
		width: 560rpx !important;
		left: 50% !important;
		position: absolute;
		transform: translate(-50%);
		bottom: 158px;
		height: 88rpx !important;
		display: flex !important;
		justify-content: center;
		align-items: center;
		color: #fff;
		font-size: 32rpx;
		text-align: center;
		background-color: #209072 !important;
	}

	.btnget2 {
		width: 560rpx !important;
		left: 50% !important;
		position: absolute;
		transform: translate(-50%);
		bottom: 158px;
		height: 88rpx !important;
		display: flex !important;
		justify-content: center;
		align-items: center;
		color: #209072 !important;
		font-size: 32rpx;
		background-color: #fff !important;
		border: 2rpx solid #209072 !important;
	}

	.user-agreement {
		display: flex;
		justify-content: center;
		align-items: center;
		position: absolute;
		transform: translate(-50%);
		left: 50%;
		bottom: 120px;
		width: 100%;
		font-size: 24rpx;
		color: #333;
	}

	.click-text {
		color: #169171;
	}

	/* 对话框样式start */

	.mask {
		position: fixed;
		left: 0;
		top: 0;
		width: 100%;
		height: 100%;
		background-color: rgba(0, 0, 0, 0.6);
		z-index: 8;
	}

	.dialog {
		width: 80%;
		height: 80%;
		position: absolute;
		left: 50%;
		top: 10%;
		padding: 16px;
		padding-bottom: 52px;
		box-sizing: border-box;
		border-radius: 16px;
		transform: translate(-50%);
		background-color: #fff;
		z-index: 9;
	}

	.header {
		font-size: 14px;
		font-weight: 700;
		text-align: center;
		margin-bottom: 16px;
	}

	.body {
		text-indent: 28px;
		color: #999;
		height: 88%;
		overflow-y: scroll;
	}

	.dialogbtn {
		position: fixed;
		left: 50%;
		bottom: 12px;
		transform: translate(-50%);
		width: 88%;
		height: 36px;
		line-height: 36px;
		color: #fff;
		border-radius: 18px;
		text-align: center;
		background-color: rgba(32, 144, 114, 1);
	}

	.yspolicy {
		margin: 12px 0;
	}

	/* 对话框样式end */
</style>
