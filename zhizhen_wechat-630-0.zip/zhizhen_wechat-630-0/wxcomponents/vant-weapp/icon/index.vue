<template>
<uni-shadow-root class="vant-weapp-icon-index"><view :class="'custom-class '+(classPrefix)+' '+(utils.isSrc(name) ? 'van-icon--image' : classPrefix + '-' + name)" :style="(color ? 'color: ' + color + ';' : '')+(size ? 'font-size: ' + size + ';' : '')+(customStyle)" @click="onClick">
  <van-info v-if="info !== null" :info="info"></van-info>

</view></uni-shadow-root>
</template>
<wxs src="../wxs/utils.wxs" module="utils"></wxs>
<script>
import VanInfo from '../info/index.vue'
global['__wxVueOptions'] = {components:{'van-info': VanInfo}}

global['__wxRoute'] = 'vant-weapp/icon/index'
import { VantComponent } from '../common/component';
VantComponent({
  props: {
    info: null,
    name: String,
    size: String,
    color: String,
    customStyle: String,
    classPrefix: {
      type: String,
      value: 'van-icon'
    }
  },
  methods: {
    onClick: function onClick() {
      this.$emit('click');
    }
  }
});
export default global['__wxComponents']['vant-weapp/icon/index']
</script>
<style platform="mp-weixin">
@import '../common/index.css';

@font-face {
	font-style: normal;
	font-weight: 400;
	font-family: vant-icon;
	src: url(https://img.yzcdn.cn/vant/vant-icon-6a2b1e.woff2) format('woff2'), url(https://img.yzcdn.cn/vant/vant-icon-6a2b1e.woff) format('woff'), url(https://img.yzcdn.cn/vant/vant-icon-6a2b1e.ttf) format('truetype')
}

.van-icon {
	position: relative;
	display: inline-block;
	font: normal normal normal 14px/1 vant-icon;
	font-size: inherit;
	text-rendering: auto;
	-webkit-font-smoothing: antialiased
}

.van-icon::before {
	display: inline-block
}

.van-icon-add-o:before {
	content: "\F000"
}

.van-icon-add-square:before {
	content: "\F001"
}

.van-icon-add:before {
	content: "\F002"
}

.van-icon-after-sale:before {
	content: "\F003"
}

.van-icon-aim:before {
	content: "\F004"
}

.van-icon-alipay:before {
	content: "\F005"
}

.van-icon-apps-o:before {
	content: "\F006"
}

.van-icon-arrow-down:before {
	content: "\F007"
}

.van-icon-arrow-left:before {
	content: "\F008"
}

.van-icon-arrow-up:before {
	content: "\F009"
}

.van-icon-arrow:before {
	content: "\F00A"
}

.van-icon-award-o:before {
	content: "\F00B"
}

.van-icon-award:before {
	content: "\F00C"
}

.van-icon-bag-o:before {
	content: "\F00D"
}

.van-icon-bag:before {
	content: "\F00E"
}

.van-icon-balance-list-o:before {
	content: "\F00F"
}

.van-icon-balance-list:before {
	content: "\F010"
}

.van-icon-balance-o:before {
	content: "\F011"
}

.van-icon-balance-pay:before {
	content: "\F012"
}

.van-icon-bar-chart-o:before {
	content: "\F013"
}

.van-icon-bars:before {
	content: "\F014"
}

.van-icon-bell:before {
	content: "\F015"
}

.van-icon-bill-o:before {
	content: "\F016"
}

.van-icon-bill:before {
	content: "\F017"
}

.van-icon-birthday-cake-o:before {
	content: "\F018"
}

.van-icon-bookmark-o:before {
	content: "\F019"
}

.van-icon-bookmark:before {
	content: "\F01A"
}

.van-icon-browsing-history-o:before {
	content: "\F01B"
}

.van-icon-browsing-history:before {
	content: "\F01C"
}

.van-icon-brush-o:before {
	content: "\F01D"
}

.van-icon-bulb-o:before {
	content: "\F01E"
}

.van-icon-bullhorn-o:before {
	content: "\F01F"
}

.van-icon-calender-o:before {
	content: "\F020"
}

.van-icon-card:before {
	content: "\F021"
}

.van-icon-cart-o:before {
	content: "\F022"
}

.van-icon-cart:before {
	content: "\F023"
}

.van-icon-cash-back-record:before {
	content: "\F024"
}

.van-icon-cash-on-deliver:before {
	content: "\F025"
}

.van-icon-cashier-o:before {
	content: "\F026"
}

.van-icon-certificate:before {
	content: "\F027"
}

.van-icon-chart-trending-o:before {
	content: "\F028"
}

.van-icon-chat-o:before {
	content: "\F029"
}

.van-icon-chat:before {
	content: "\F02A"
}

.van-icon-checked:before {
	content: "\F02B"
}

.van-icon-circle:before {
	content: "\F02C"
}

.van-icon-clear:before {
	content: "\F02D"
}

.van-icon-clock-o:before {
	content: "\F02E"
}

.van-icon-clock:before {
	content: "\F02F"
}

.van-icon-close:before {
	content: "\F030"
}

.van-icon-closed-eye:before {
	content: "\F031"
}

.van-icon-cluster-o:before {
	content: "\F032"
}

.van-icon-cluster:before {
	content: "\F033"
}

.van-icon-comment-circle-o:before {
	content: "\F034"
}

.van-icon-comment-o:before {
	content: "\F035"
}

.van-icon-comment:before {
	content: "\F036"
}

.van-icon-completed:before {
	content: "\F037"
}

.van-icon-contact:before {
	content: "\F038"
}

.van-icon-coupon-o:before {
	content: "\F039"
}

.van-icon-coupon:before {
	content: "\F03A"
}

.van-icon-credit-pay:before {
	content: "\F03B"
}

.van-icon-cross:before {
	content: "\F03C"
}

.van-icon-debit-pay:before {
	content: "\F03D"
}

.van-icon-delete:before {
	content: "\F03E"
}

.van-icon-description:before {
	content: "\F03F"
}

.van-icon-desktop-o:before {
	content: "\F040"
}

.van-icon-diamond-o:before {
	content: "\F041"
}

.van-icon-diamond:before {
	content: "\F042"
}

.van-icon-discount:before {
	content: "\F043"
}

.van-icon-ecard-pay:before {
	content: "\F044"
}

.van-icon-edit:before {
	content: "\F045"
}

.van-icon-ellipsis:before {
	content: "\F046"
}

.van-icon-empty:before {
	content: "\F047"
}

.van-icon-envelop-o:before {
	content: "\F048"
}

.van-icon-exchange:before {
	content: "\F049"
}

.van-icon-expand-o:before {
	content: "\F04A"
}

.van-icon-expand:before {
	content: "\F04B"
}

.van-icon-eye-o:before {
	content: "\F04C"
}

.van-icon-eye:before {
	content: "\F04D"
}

.van-icon-fail:before {
	content: "\F04E"
}

.van-icon-failure:before {
	content: "\F04F"
}

.van-icon-filter-o:before {
	content: "\F050"
}

.van-icon-fire-o:before {
	content: "\F051"
}

.van-icon-fire:before {
	content: "\F052"
}

.van-icon-flag-o:before {
	content: "\F053"
}

.van-icon-flower-o:before {
	content: "\F054"
}

.van-icon-free-postage:before {
	content: "\F055"
}

.van-icon-friends-o:before {
	content: "\F056"
}

.van-icon-friends:before {
	content: "\F057"
}

.van-icon-gem-o:before {
	content: "\F058"
}

.van-icon-gem:before {
	content: "\F059"
}

.van-icon-gift-card-o:before {
	content: "\F05A"
}

.van-icon-gift-card:before {
	content: "\F05B"
}

.van-icon-gift-o:before {
	content: "\F05C"
}

.van-icon-gift:before {
	content: "\F05D"
}

.van-icon-gold-coin-o:before {
	content: "\F05E"
}

.van-icon-gold-coin:before {
	content: "\F05F"
}

.van-icon-goods-collect-o:before {
	content: "\F060"
}

.van-icon-goods-collect:before {
	content: "\F061"
}

.van-icon-home-o:before {
	content: "\F062"
}

.van-icon-hot-o:before {
	content: "\F063"
}

.van-icon-hot-sale-o:before {
	content: "\F064"
}

.van-icon-hot-sale:before {
	content: "\F065"
}

.van-icon-hot:before {
	content: "\F066"
}

.van-icon-hotel-o:before {
	content: "\F067"
}

.van-icon-idcard:before {
	content: "\F068"
}

.van-icon-info-o:before {
	content: "\F069"
}

.van-icon-info:before {
	content: "\F06A"
}

.van-icon-label-o:before {
	content: "\F06B"
}

.van-icon-label:before {
	content: "\F06C"
}

.van-icon-like-o:before {
	content: "\F06D"
}

.van-icon-like:before {
	content: "\F06E"
}

.van-icon-location-o:before {
	content: "\F06F"
}

.van-icon-location:before {
	content: "\F070"
}

.van-icon-logistics:before {
	content: "\F071"
}

.van-icon-manager-o:before {
	content: "\F072"
}

.van-icon-manager:before {
	content: "\F073"
}

.van-icon-map-marked:before {
	content: "\F074"
}

.van-icon-medel-o:before {
	content: "\F075"
}

.van-icon-medel:before {
	content: "\F076"
}

.van-icon-more-o:before {
	content: "\F077"
}

.van-icon-more:before {
	content: "\F078"
}

.van-icon-music-o:before {
	content: "\F079"
}

.van-icon-new-arrival-o:before {
	content: "\F07A"
}

.van-icon-new-arrival:before {
	content: "\F07B"
}

.van-icon-new:before {
	content: "\F07C"
}

.van-icon-newspaper-o:before {
	content: "\F07D"
}

.van-icon-notes-o:before {
	content: "\F07E"
}

.van-icon-orders-o:before {
	content: "\F07F"
}

.van-icon-other-pay:before {
	content: "\F080"
}

.van-icon-paid:before {
	content: "\F081"
}

.van-icon-passed:before {
	content: "\F082"
}

.van-icon-pause:before {
	content: "\F083"
}

.van-icon-peer-pay:before {
	content: "\F084"
}

.van-icon-pending-payment:before {
	content: "\F085"
}

.van-icon-phone-circle-o:before {
	content: "\F086"
}

.van-icon-phone-o:before {
	content: "\F087"
}

.van-icon-phone:before {
	content: "\F088"
}

.van-icon-photo-o:before {
	content: "\F089"
}

.van-icon-photo:before {
	content: "\F08A"
}

.van-icon-photograph:before {
	content: "\F08B"
}

.van-icon-play:before {
	content: "\F08C"
}

.van-icon-plus:before {
	content: "\F08D"
}

.van-icon-point-gift-o:before {
	content: "\F08E"
}

.van-icon-point-gift:before {
	content: "\F08F"
}

.van-icon-points:before {
	content: "\F090"
}

.van-icon-printer:before {
	content: "\F091"
}

.van-icon-qr-invalid:before {
	content: "\F092"
}

.van-icon-qr:before {
	content: "\F093"
}

.van-icon-question-o:before {
	content: "\F094"
}

.van-icon-question:before {
	content: "\F095"
}

.van-icon-records:before {
	content: "\F096"
}

.van-icon-refund-o:before {
	content: "\F097"
}

.van-icon-scan:before {
	content: "\F098"
}

.van-icon-search:before {
	content: "\F099"
}

.van-icon-send-gift-o:before {
	content: "\F09A"
}

.van-icon-send-gift:before {
	content: "\F09B"
}

.van-icon-service-o:before {
	content: "\F09C"
}

.van-icon-service:before {
	content: "\F09D"
}

.van-icon-setting-o:before {
	content: "\F09E"
}

.van-icon-setting:before {
	content: "\F09F"
}

.van-icon-share:before {
	content: "\F0A0"
}

.van-icon-shop-collect-o:before {
	content: "\F0A1"
}

.van-icon-shop-collect:before {
	content: "\F0A2"
}

.van-icon-shop-o:before {
	content: "\F0A3"
}

.van-icon-shop:before {
	content: "\F0A4"
}

.van-icon-shopping-cart-o:before {
	content: "\F0A5"
}

.van-icon-shopping-cart:before {
	content: "\F0A6"
}

.van-icon-sign:before {
	content: "\F0A7"
}

.van-icon-smile-comment-o:before {
	content: "\F0A8"
}

.van-icon-smile-comment:before {
	content: "\F0A9"
}

.van-icon-smile-o:before {
	content: "\F0AA"
}

.van-icon-star-o:before {
	content: "\F0AB"
}

.van-icon-star:before {
	content: "\F0AC"
}

.van-icon-stop:before {
	content: "\F0AD"
}

.van-icon-success:before {
	content: "\F0AE"
}

.van-icon-thumb-circle-o:before {
	content: "\F0AF"
}

.van-icon-todo-list-o:before {
	content: "\F0B0"
}

.van-icon-todo-list:before {
	content: "\F0B1"
}

.van-icon-tosend:before {
	content: "\F0B2"
}

.van-icon-tv-o:before {
	content: "\F0B3"
}

.van-icon-umbrella-circle:before {
	content: "\F0B4"
}

.van-icon-underway-o:before {
	content: "\F0B5"
}

.van-icon-underway:before {
	content: "\F0B6"
}

.van-icon-upgrade:before {
	content: "\F0B7"
}

.van-icon-user-circle-o:before {
	content: "\F0B8"
}

.van-icon-user-o:before {
	content: "\F0B9"
}

.van-icon-video-o:before {
	content: "\F0BA"
}

.van-icon-video:before {
	content: "\F0BB"
}

.van-icon-vip-card-o:before {
	content: "\F0BC"
}

.van-icon-vip-card:before {
	content: "\F0BD"
}

.van-icon-volume-o:before {
	content: "\F0BE"
}

.van-icon-volume:before {
	content: "\F0BF"
}

.van-icon-wap-home:before {
	content: "\F0C0"
}

.van-icon-wap-nav:before {
	content: "\F0C1"
}

.van-icon-warn-o:before {
	content: "\F0C2"
}

.van-icon-wechat:before {
	content: "\F0C3"
}

.van-icon-youzan-shield:before {
	content: "\F0C4"
}

.van-icon--image {
	width: 1em;
	height: 1em
}

/* .van-icon--image image {
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	margin: auto;
	max-width: 100%;
	max-height: 100%;
	position: absolute
}
 */
</style>