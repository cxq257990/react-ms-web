export var RED = '#f44';
export var BLUE = '#1989fa';
export var GREEN = '#4b0';